# What the June result can establish

In `artifacts/adjudications/hqwi/verdicts.json`, the historical surreal
optimization-rate result was a held-out perplexity ratio of 0.5392 on
synthetic shuffled hierarchy. The stricter eligibility audit lists all 13
selected evaluations as excluded. Six precede the operational
registration. Seven lack training lineage. The newer evaluation cohort
replay retains the blocked disposition. These counts are taken from the
recorded audit. No historical checkpoint was retrained or re-evaluated here.

The evaluation producer was `97f587c5a3d1b4f69f808dab8cd8eec8be46644c` for
the initial seed set. Its GPT initialization zeroed the attention output
weight for dense projections and skipped it for SurrealLayer. The latter
starts with unit effective row norm. Its optimizer factory also builds the
Muon-plus-AdamW split for non-HOSS optimizers. In that source the gain
tensor has rank two, so it belongs to the matrix group. In today's
factory, `weight_s` is exempt from Muon, and the explicit AdamW mode uses
AdamW on all groups. These differences identify concrete confounds and a
change in replication conditions. They do not quantify how much each
affected the historical result, given the missing training lineage.

For a nonzero direction (v) above the normalization clamp, put
(u=v/\|v\|) and (g=\exp(s)). The effective weight is (w=g u).
This is exponential weight normalization. With a positive linear gain
the effective-weight families coincide. The gradient in the log-gain
coordinate obeys (\partial L/\partial s = g\,\partial L/\partial g), so
the training dynamics can still differ. The original linear weight norm
is due to Salimans and Kingma, and Morwani and Ramaswamy explicitly study
the exponential form. Their gradient-flow results do not apply directly
to AdamW Transformer training. More recent matching prior art uses
separate magnitude and direction updates in much larger models.

[Weight normalization (2016)](https://arxiv.org/abs/1602.07868) ·
[Exponential weight normalization (published 2022)](https://proceedings.mlr.press/v167/morwani22a.html) ·
[Magnitude–direction decoupling (2026 preprint)](https://arxiv.org/abs/2606.25971)
