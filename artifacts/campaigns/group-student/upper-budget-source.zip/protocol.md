# Exact acquisition with propagated feasible cost ceilings

The previous exhaustive and pruned algorithms all exhausted 300,000 units
at orders 10 and 12. Keep the original target and denominator. Solve every
marked action at orders 6 and 10 within the same 300,000-unit cap per order,
recover the previously verified order-6 minimum, and strictly beat both
original greedy costs on at least one primary order while exceeding
neither. Attempt order 12 at the same cap and publish its result either way.
The public roster, four mandatory anchors, audited complete inventory,
uniform shape weighting, read price 16 and unit commands remain fixed.
Run separate processes with different names, reversed order and hash seeds.
Report costs, reads, both symbols, regressions and CPU. Compare all four live
controls and replay them against the frozen classical tapes. Report the
gap to generalized binary search (GBS), including any ties.

The unchanged bounded-menu GBS selection rule builds a feasible policy.
The optimizer's GBS construction runs under the planning work meter in
place of the control's structural depth cap. Before growing a profitable
continuation, price the seed independently in every post-anchor reply
history. This costs one unit per replayed state plus two per queried word.
Charge precomputed GBS endpoint columns and, at every seed decision,
every scored menu word and the decision state. A frontier fallback is
charged an upper bound on generated and scored candidates. The frontier
expands each forced reply at most once and generates two children per
expansion. The seed is included in the 300,000 units. The proof search
charges expanded states (including re-expansions), reachable product
endpoint vectors when first stored, and examined candidate words.

A bounded call either returns an optimal solution of cost at most its
ceiling or proves infeasibility at that ceiling. At a candidate word, each
child's exact return plus the known minimum naming costs of its siblings
must fit in the parent's remaining allowance. Price the word on every
compatible action. If one child is infeasible below the resulting bound,
the candidate cannot improve the best complete policy. Reuse a proved
negative answer only at an equal or lower ceiling. A found optimum can be
reused at every ceiling. Once a candidate fits, continue at its cost minus
one, so the first equal-cost incumbent is retained.

In the shortest-first product traversal, once the paid word cost plus
the naming floor after one free new label is greater than the ceiling,
every remaining word can be pruned. When guessing which endpoint the
next word names, charge the cheapest required access words and allow
one unseen label to be inferred as usual. This is a lower bound for each
compatible shape independently. The finite endpoint-vector coverage and
anchor partition proof from the original exact planner still apply.

Exhaustion produces no certified policy. Treat this as exact
branch-and-bound on a finite regular-action oracle. The results do not
establish training, hardware or cross-domain superiority. Branch-and-bound
and reuse of subproblem optima are established optimal decision-tree
strategies. [Aglin, Nijssen and Schaus](https://ijcai.org/proceedings/2020/662)
