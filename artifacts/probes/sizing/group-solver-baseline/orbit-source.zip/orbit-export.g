if LoadPackage("smallgrp") <> true or LoadPackage("autpgrp") <> true then
  Error("SmallGrp and AutPGrp are required");
fi;
Reset(GlobalRandomSource, 251601);;
Reset(GlobalMersenneTwister, 251601);;
SizeScreen([4096, 100]);;

OrbitRecord := function(group, n, identifier)
  local sorted, positionOfOne, elementOrder, elements, indices, i,
        automorphisms, permutations, action, automorphismOrder,
        phi, quotientElements, quotientIdentity, cosets, squares,
        available, firstOrbit, first, second, stabilizer, pairOrbits;
  sorted := AsSSortedList(group);
  positionOfOne := PositionSorted(sorted, One(group));
  elementOrder := Concatenation([positionOfOne], Filtered([1 .. n], i -> i <> positionOfOne));
  elements := List(elementOrder, i -> sorted[i]);
  indices := ListWithIdenticalEntries(n, 0);
  for i in [1 .. n] do
    indices[elementOrder[i]] := i;
  od;

  automorphisms := AutomorphismGroup(group);
  permutations := List(GeneratorsOfGroup(automorphisms),
    map -> List(elements, g -> indices[PositionSorted(sorted, g ^ map)]));
  action := Group(List(permutations, PermList));
  automorphismOrder := Size(automorphisms);
  if Size(action) <> automorphismOrder then Error("Element action is not faithful"); fi;

  phi := NaturalHomomorphismByNormalSubgroup(group, FrattiniSubgroup(group));
  quotientIdentity := One(Image(phi));
  quotientElements := Concatenation([quotientIdentity],
    Filtered(AsList(Image(phi)), x -> x <> quotientIdentity));
  if Length(quotientElements) <> 4 then Error("Expected rank two"); fi;
  cosets := List(elements, g -> Position(quotientElements, Image(phi, g)) - 1);
  squares := List(elements, g -> g ^ 2);
  available := Filtered([1 .. n], i -> cosets[i] <> 0);
  pairOrbits := [];
  for firstOrbit in OrbitsDomain(action, available) do
    first := Minimum(firstOrbit);
    stabilizer := Stabilizer(action, first);
    second := Filtered(available,
      i -> cosets[i] <> cosets[first] and squares[i] <> squares[first]);
    for i in OrbitsDomain(stabilizer, second) do
      Add(pairOrbits, [first - 1, Minimum(i) - 1, Length(firstOrbit) * Length(i)]);
    od;
  od;
  Sort(pairOrbits);
  return [identifier, automorphismOrder, List(permutations, p -> List(p, i -> i - 1)), cosets, pairOrbits];
end;;

Print("[\"", GAPInfo.Version, "\",\"", PackageInfo("smallgrp")[1].Version, "\",\"",
      PackageInfo("autpgrp")[1].Version, "\",", MgrOrbitOrder, ",\n[\n");
firstRecord := true;;
for id in IdsOfAllSmallGroups(MgrOrbitOrder, RankPGroup, 2) do
  group := SmallGroup(id[1], id[2]);
  if not IsAbelian(group) then
    if not firstRecord then Print(",\n"); fi;
    firstRecord := false;
    Print(OrbitRecord(group, id[1], id[2]));
  fi;
od;
Print("\n]]\n");
QUIT;
