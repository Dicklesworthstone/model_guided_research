# Route Observatory Report (`mgr.bench.routes.v2`)

- **Mechanism**: `tropical`
- **Task**: `hier`
- **Checkpoint**: `/private/tmp/mgr-route-verifier.hMb9aRVM/training/baseline/nanochat/cpu-19/checkpoints` (step `1`)
- **Samples**: `8` (seed `42`)
- **Brute-force cross-check verified**: `True`

## 1. Route Reuse & Consolidation

- **Route entropy (bits)**: `3.1556` (first `3.1556` -> last `3.1556`, delta `0.0000`)
- **Program reuse ratio**: `0.3750` (first `0.3750` -> last `0.3750`, delta `0.0000`)
- **Top-5 program share**: `0.6875`

## 2. Perturbation & Paraphrase Stability (`vdc.1` Probe Spec)

- **Probe spec**: `vdc.1-linf-embedding-v1` (`default_eps=0.05`)
- **Margin aggregation**: `min` (tightest decision along route)
- **Spearman rho(gamma_min, stability)**: `unavailable`
- **Unchanged perturbation draws**: 3 / 64
- **Mean perturbation stability**: `0.0469`
- **Mean paraphrase stability**: `0.9082` (8 measured)

## 3. Unsupervised Trace Clustering vs Attention-Entropy Baseline

- **Latent task classes (`K=2`)**: `['2', '3']`
- **Trace clustering ARI**: `-0.1538`
- **Attention-entropy baseline ARI**: `-0.1034`
- **Prompt-only control ARI**: `1.0000`
- **ARI gain (trace - baseline)**: `-0.0504`
