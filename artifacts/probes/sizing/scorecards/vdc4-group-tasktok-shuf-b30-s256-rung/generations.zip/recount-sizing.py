"""Recount the saved greedy generations and the per-eval-seed majority prior."""

from collections import Counter
import json
from math import isclose
from pathlib import Path
import sys
from zipfile import ZipFile


def read(path):
    return json.loads(path.read_bytes())


root = Path(sys.argv[1])
tasks = sys.argv[2:]
cells = read(root / "manifest.json")["cells"]
expected = {(task, seed) for task in [*tasks, "placebo"] for seed in range(3)}
assert len(cells) == len(expected)
assert {(c["task"], c["seed"]) for c in cells} == expected
receipt = next(root.glob("dsr-*.json"))
assert read(receipt)["status"] == "passed"
with ZipFile(root / "generations.zip") as archive:
    assert archive.testzip() is None
    for c in cells:
        assert c["status"] == "done" and c["returncode"] == 0
        task = c["task"]
        folder = Path("evals/tasks") / ("eval-" + c["id"])
        evaluation = read(root / folder / "summary.json")
        for field in ("provenance", "train_provenance"):
            prov = evaluation[field]
            assert prov["git_sha"] == "a5abe773b4b5ce1073d63eafe499ef809dc071f3"
            assert prov["git_dirty"] is False and prov["tainted"] is False
        scores = evaluation["tasks"][task]
        assert scores["skipped_too_long"] == 0
        if task == "placebo":
            assert scores["answer_prior"] is None
            continue
        data = archive.read(str(folder / "generations.jsonl"))
        records = [json.loads(line) for line in data.splitlines()]
        for region in ("in_range", "held_out"):
            selected = [r for r in records if r["region"] == region and r["mode"] == "greedy"]
            assert len(selected) == 144
            assert {(r["eval_seed"], r["doc_index"]) for r in selected} == {
                (s, i) for s in range(3) for i in range(48)
            }
            correct = []
            priors = []
            for seed in range(3):
                rows = [r for r in selected if r["eval_seed"] == seed]
                matches = []
                for r in rows:
                    words = r["expected"].split()
                    assert words and r["task"] == task
                    match = r["got"].split()[:len(words)] == words
                    assert match == r["correct"]
                    matches.append(match)
                correct.append(sum(matches))
                priors.append(max(Counter(r["expected"] for r in rows).values()))
                assert isclose(correct[-1] / 48, scores["exact_match"]["greedy"][region]["per_seed"][seed])
                assert isclose(priors[-1] / 48, scores["answer_prior"][region]["per_seed"][seed])
            assert isclose(sum(correct) / 144, scores["exact_match"]["greedy"][region]["mean"])
            assert isclose(sum(priors) / 144, scores["answer_prior"][region]["mean"])
            print(task, c["seed"], region, sum(correct), "/ 144, prior", sum(priors), flush=True)
print("Completed", len(cells), "cells from", root.name)
