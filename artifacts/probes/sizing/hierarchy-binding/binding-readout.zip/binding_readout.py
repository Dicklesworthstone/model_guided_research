import copy
import json
import math
import re
import sys
from pathlib import Path

import pyarrow.parquet as pq
import torch
import torch.nn as nn
import torch.nn.functional as F

from binding_score import PANEL_HASH, WEIGHTS, load_model, pair_inputs, sha
from cli import _eval_split_examples
from nanochat.diagnostics_data import TASKS, _hier_paths, _parse_hier_tree

FIT_ROWS = 1536
BATCH = 16
EPOCHS = 3
EVAL_SEEDS = (4301, 4302, 4303)
REGIONS = ("in_range", "held_out")
CORPUS_MANIFEST = "e0bf1754ab8e0dc00b5f9b048496be258761f75496a01443112b5a3828d78e4c"


def identity(doc):
    tree = doc.split(" BIND ", 1)[0]
    parsed = _parse_hier_tree(tree.split()[3:])
    assert parsed is not None
    return tuple(sorted(_hier_paths(parsed)))


def make_panel(prior, output):
    corpus = prior / "default/hier_bind"
    manifest_path = corpus / "manifest.json"
    assert sha(manifest_path) == CORPUS_MANIFEST
    manifest = json.loads(manifest_path.read_bytes())
    forbidden = set()
    for filename, expected in manifest["sha256"].items():
        path = corpus / filename
        assert sha(path) == expected
        docs = pq.read_table(path, columns=["text"]).column("text").to_pylist()
        checked = {identity(doc) for doc in docs}
        assert len(checked) == len(docs) // 2 and not forbidden.intersection(checked)
        forbidden.update(checked)
    old_panel = prior / "baseline-panel.json"
    assert sha(old_panel) == PANEL_HASH
    old = json.loads(old_panel.read_bytes())
    assert set(old) == {"3301", "3302", "3303"}
    for cells in old.values():
        for docs in cells.values():
            checked = {identity(doc) for doc in docs}
            assert len(checked) == 12 and not forbidden.intersection(checked)
            forbidden.update(checked)
    assert len(forbidden) == 2120
    panel = {}
    for seed in EVAL_SEEDS:
        in_range, held_out, _ = _eval_split_examples(TASKS["hier_bind"], n=24, seed=seed)
        panel[seed] = dict(in_range=in_range, held_out=held_out)
        for docs in panel[seed].values():
            checked = {identity(doc) for doc in docs}
            assert len(checked) == 12 and not forbidden.intersection(checked)
            forbidden.update(checked)
    assert len(forbidden) == 2192
    with output.open("x", encoding="utf-8") as file:
        json.dump(panel, file)
    print("Locked 72 fresh evaluation trees disjoint from the generated corpus and the rank panel", flush=True)


def doc_arrays(doc, tok):
    prompt, answer = TASKS["hier_bind"].split_prompt(doc)
    tree = prompt.split(" BIND ", 1)[0]
    leaves = identity(doc)
    expected, = [path for path, value in leaves if value == answer]
    depth = len(expected)
    bos = tok.get_bos_token_id()
    ids = tok.encode(prompt, prepend=bos)
    full = tok.encode(doc, prepend=bos)
    assert full[:len(ids)] == ids and len(ids) < len(full) <= 192

    def position(end):
        partial = tok.encode(prompt[:end], prepend=bos)
        assert ids[:len(partial)] == partial
        return len(partial) - 1

    tree_positions = [0] * (2 ** (depth + 1) - 1)
    path_stack = [0]
    marker_end = len("TASK hier_bind TREE ")
    words = iter(re.finditer(r"\S+", tree[marker_end:]))
    visited = set()
    for match in words:
        if match.group() == "(":
            key = next(words)
            node = path_stack[-1] * 2 + 1 + int(key.group()[-1])
            assert node not in visited and key.group() in ("k0", "k1")
            tree_positions[node] = position(marker_end + key.end())
            path_stack.append(node)
            visited.add(node)
        elif match.group() == ")":
            path_stack.pop()
    assert visited == set(range(1, len(tree_positions))) and path_stack == [0]
    query_start = prompt.index(" PATH ") + len(" PATH ")
    query_positions = [position(query_start + match.end())
                       for match in re.finditer(r"\S+", prompt[query_start:]) if match.group() != "OUT"]
    assert len(query_positions) == depth
    return ids, query_positions, tree_positions, [int(key[-1]) for key in expected]


def prepare(docs, tok):
    return tuple(torch.tensor(block) for block in zip(*(doc_arrays(doc, tok) for doc in docs), strict=True))


class Readout(nn.Module):
    def __init__(self):
        super().__init__()
        self.query = nn.Linear(64, 16, bias=False)
        self.child = nn.Linear(64, 16, bias=False)

    def forward(self, query, tree):
        return torch.bmm(self.query(query), self.child(tree).transpose(1, 2)) / 4.0


def feature_rows(model, ids, query_pos, tree_pos):
    captured = []
    handle = model.lm_head.register_forward_pre_hook(lambda _module, args: captured.append(args[0]))
    try:
        model(ids)
    finally:
        handle.remove()
    state, = captured
    batch = torch.arange(ids.size(0))[:, None]
    return state[batch, query_pos], state[batch, tree_pos]


def gold_options(gold):
    parent = torch.zeros(gold.size(0), dtype=torch.long)
    options = []
    for side in gold.T:
        options.append(2 * parent[:, None] + torch.tensor([1, 2]))
        parent = 2 * parent + 1 + side
    return torch.stack(options, dim=1)


def fit(model, head, train, order, update_model):
    ids, qpos, tpos, gold = train
    options = gold_options(gold)
    groups = [{"params": head.parameters(), "lr": 0.003}]
    if update_model:
        groups.append({"params": model.parameters(), "lr": 0.0003})
        model.train().requires_grad_(True)
    else:
        model.eval().requires_grad_(False)
        with torch.no_grad():
            cached = [feature_rows(model, ids[i:i+BATCH], qpos[i:i+BATCH], tpos[i:i+BATCH])
                      for i in range(0, FIT_ROWS, BATCH)]
        q_cache, t_cache = (torch.cat(parts) for parts in zip(*cached, strict=True))
    optimizer = torch.optim.AdamW(groups, weight_decay=0)
    losses = []
    for index in order:
        if update_model:
            query, tree = feature_rows(model, ids[index], qpos[index], tpos[index])
        else:
            query, tree = q_cache[index], t_cache[index]
        local = head(query, tree).gather(-1, options[index])
        loss = F.cross_entropy(local.flatten(0, 1), gold[index].flatten())
        assert math.isfinite(float(loss.detach()))
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        optimizer.step()
        losses.append(float(loss.detach()))
    first = sum(losses[:FIT_ROWS//BATCH]) / (FIT_ROWS//BATCH)
    last = sum(losses[-FIT_ROWS//BATCH:]) / (FIT_ROWS//BATCH)
    return [first, last]


@torch.inference_mode()
def evaluate(model, head, packed):
    model.eval()
    head.eval()
    ids, qpos, tpos, gold = packed
    matrices = []
    for i in range(0, len(ids), BATCH):
        part = slice(i, i + BATCH)
        matrices += head(*feature_rows(model, ids[part], qpos[part], tpos[part])).tolist()
    return matrices


def run(prior, panel_path, output, seed):
    panel_data = json.loads(panel_path.read_bytes())
    corpus = prior / "default/hier_bind"
    manifest = json.loads((corpus / "manifest.json").read_bytes())
    assert sha(corpus / "manifest.json") == CORPUS_MANIFEST
    train_file = corpus / "train_000.parquet"
    assert sha(train_file) == manifest["sha256"]["train_000.parquet"]
    docs = pq.read_table(train_file, columns=["text"]).column("text").to_pylist()[:FIT_ROWS]
    assert len(docs) == FIT_ROWS
    held_identities = {identity(doc) for cells in panel_data.values() for batch in cells.values() for doc in batch}
    assert len(held_identities) == 72 and not held_identities.intersection(identity(doc) for doc in docs)
    model, tok = load_model(prior, seed)
    train = prepare(docs, tok)
    prepared = {}
    for region in REGIONS:
        eval_docs = [doc for eval_seed in EVAL_SEEDS for doc in panel_data[str(eval_seed)][region]]
        assert len(eval_docs) == 72
        edit_hops = [len(pair_inputs(a, b)["changed_scope"]) - 1
                     for a, b in zip(eval_docs[::2], eval_docs[1::2], strict=True)]
        pack = prepare(eval_docs, tok)
        prepared[region] = pack, edit_hops
    g = torch.Generator().manual_seed(23100 + seed)
    order = [batch for _ in range(EPOCHS) for batch in torch.randperm(FIT_ROWS, generator=g).split(BATCH)]
    torch.manual_seed(seed + 800)
    initial_head = Readout()
    arms = {}
    for arm, update in (("frozen", False), ("joint", True)):
        head = copy.deepcopy(initial_head)
        losses = fit(model, head, train, order, update)
        cells = {}
        for region, (packed, hops) in prepared.items():
            cells[region] = dict(scores=evaluate(model, head, packed), answer_paths=packed[-1].tolist(),
                                 edited_hops=hops)
        arms[arm] = dict(training_epoch_loss=losses, results=cells)
        print(f"Checkpoint {seed}: {arm} fit, first and last epoch loss {losses}", flush=True)
    with output.open("x", encoding="utf-8") as stream:
        json.dump(dict(checkpoint=WEIGHTS[seed], panel_sha256=sha(panel_path), fit_rows=FIT_ROWS, updates=len(order),
                       arms=arms), stream, allow_nan=False)


if __name__ == "__main__":
    torch.set_num_threads(2)
    mode, *args = sys.argv[1:]
    if mode == "prepare":
        make_panel(*map(Path, args))
    else:
        *paths, seed = args
        run(*map(Path, paths), int(seed))
