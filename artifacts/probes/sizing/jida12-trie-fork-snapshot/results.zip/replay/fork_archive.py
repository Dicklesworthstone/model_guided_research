import hashlib
import json
import statistics
import sys
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


REGISTRATION = "cdface7b9e0fd03b4f26ca32b6f34768c97ccf83"
LOCK = "679eae105f73022ea59193c3606234f197c75c6da593fe3a938e4ca23cac2670"
OLD_ENGINE = "527f9fb224bd0ada9e1c479600ecc6a6a24e42530de0ffe3cf9b42b01aa624f6"
OLD_ATTN = "778894a4b2e60dcae95fed905d34d5f7cc117d0b6623accd010ef2d390be50ae"
GRID = {(1, 128), (1, 512), (2, 128), (2, 512), (4, 512)}
METRICS = {"prefill", "fork", "first", "fork_first", "steady"}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def recount(read, names):
    frozen = read("replay/frozen.sha256")
    assert sha(frozen) == LOCK
    for line in frozen.decode().splitlines():
        expected, name = line.split()
        assert sha(read(f"replay/{name}")) == expected
    assert sha(read("replay/incumbent_engine.py")) == OLD_ENGINE
    assert sha(read("replay/incumbent_trie.py")) == OLD_ATTN
    paths = [name for name in names if name.endswith("/receipt.json")]
    assert len(paths) == 1 and "/hierarchy-trie-fork-snapshot/" in paths[0]
    receipt = json.loads(read(paths[0]))
    assert len(receipt["checks"]) == 1
    check, = receipt["checks"]
    log = paths[0].removesuffix("receipt.json") + Path(check["log_path"]).name
    assert sha(read(log)) == check["log_sha256"]
    meta = dict(registration=REGISTRATION, receipt_id=paths[0].split("/")[-2], status=receipt["status"])
    if receipt["status"] != "passed":
        return dict(**meta, advance=False)
    result = json.loads(read("results.json"))
    assert result["candidate_engine_sha256"] == sha(read("replay/candidate_engine.py"))
    assert result["candidate_attention_sha256"] == sha(read("replay/candidate_trie.py"))
    assert result["incumbent_engine_sha256"] == OLD_ENGINE and result["incumbent_attention_sha256"] == OLD_ATTN
    assert result["model_layers"] == 2 and result["width"] == 64 and result["query_heads"] == 4
    assert result["samples"] == 7 and result["exact_digit_elements"] == 162400
    assert result["fallback"] == dict.fromkeys(("rewound", "reset-and-kernel", "foreign-owner"), 256)
    assert len(result["other_controls"]) == 4 and all(v == 5888 for v in result["other_controls"].values())
    rows = {(item["heads"], item["context"]): item for item in result["workloads"]}
    assert len(result["workloads"]) == 5 and set(rows) == GRID
    for (heads, n), row in rows.items():
        old, clone = (row[arm] for arm in ("incumbent", "snapshot"))
        assert old["resident"] == clone["resident"]
        assert old["verified_buffer_copies"] == 0 and clone["verified_buffer_copies"] == 12 * heads
        assert row["logit_elements"] == (n + 18) * 128
        assert old["resident"]["dense"] == 2 * 2 * 2 * heads * (n + 9) * 16 * 4
        assert old["resident"]["total"] == old["resident"]["dense"] + old["resident"]["trie"]
        assert clone["overlap"] > old["overlap"]
        assert row["peak_ratio"] == (max(clone["overlap"], clone["resident"]["total"]) /
                                     max(old["overlap"], old["resident"]["total"]))
        samples = row["pairs"]
        assert len(samples) == 7 and all(set(s["order"]) == {"incumbent", "snapshot"} for s in samples)
        for sample in samples:
            for arm in ("incumbent", "snapshot"):
                points = sample[arm]
                assert set(points) == METRICS and all(value > 0 for value in points.values())
                assert points["fork_first"] == points["fork"] + points["first"]
        assert row["ratios"] == {key: statistics.median(s["incumbent"][key] / s["snapshot"][key] for s in samples)
                                 for key in METRICS}
    criteria = dict(faster_first_token_after_fork=all(row["ratios"]["fork_first"] >= 1.5 for (_, n), row in rows.items() if n == 512),
                    no_prefill_or_steady_regression=all(row["ratios"][m] >= .90 for row in rows.values() for m in ("prefill", "steady")),
                    bounded_overlap=all(row["peak_ratio"] <= 1.55 for row in rows.values()))
    assert result["criteria"] == criteria and result["advance"] == all(criteria.values())
    return dict(**meta, **result)


def bundle(root, out):
    frozen = root / "frozen.sha256"
    paths = {"replay/frozen.sha256": frozen, "replay/fork_archive.py": root / "fork_archive.py",
             "replay/incumbent_engine.py": root / "source/nanochat/engine.py",
             "replay/incumbent_trie.py": root / "source/nanochat/ultrametric_attention_torch.py"}
    for line in frozen.read_text().splitlines():
        _, name = line.split()
        paths[f"replay/{name}"] = root / name
    if (root / "results.json").is_file():
        paths["results.json"] = root / "results.json"
    for receipt in (root / "receipts").glob("*/*/receipt.json"):
        for name in ("receipt.json", "check-1.log", "checks-config.yaml"):
            path = receipt.with_name(name)
            paths[str(path.relative_to(root))] = path
    decision = recount(lambda name: paths[name].read_bytes(), paths)
    with ZipFile(out, "x", compression=ZIP_DEFLATED) as archive:
        for name, path in paths.items():
            archive.write(path, name)
        archive.writestr("decision.json", json.dumps(decision, indent=2) + "\n")


def verify(out):
    with ZipFile(out) as archive:
        assert archive.testzip() is None
        names = archive.namelist()
        assert len(names) == len(set(names))
        assert not any(name.endswith((".pt", ".parquet", ".safetensors")) for name in names)
        data = recount(archive.read, names)
        assert data == json.loads(archive.read("decision.json"))
    print(json.dumps(data))


if __name__ == "__main__":
    command, *paths = sys.argv[1:]
    {"bundle": bundle, "verify": verify}[command](*map(Path, paths))
