# Exact search with exchangeable naming probes in shortlex order

Keep the primary target from the four earlier attempts. Solve orders 6
and 10 under the same 300,000 work units per order, reproduce the exact
order-6 minimum, and improve one primary aggregate over both released
greedy policies without exceeding either. Attempt order 12 as stress.
Run all five arms with the same prices and audited census, including the
published GBS control. Replay the same labelled tables and all paid
queries under a second opaque labelling with reversed execution order.
Compare to the latest independently computed lower bounds and preserve
all outcomes, including exhausted attempts. The production compiler is
outside this experimental change until the primary result qualifies.

Call a query uniformly novel if it reaches an unobserved position in
every fitting shape. With opaque names it causes a single branch, with
one new name. Suppose a policy queries a uniformly novel word A and
then B at that branch. If B was also uniformly novel before A, asking
B first still yields one branch. After both queries, each shape either
assigns their two endpoints the same name or assigns two distinct names.
This equality and the position assignments are identical after permuting
the two newly observed ranks consistently across the compatible shapes.
The two word costs are unchanged. The continuation can be translated
by this rank permutation. Among optimum policies choose the one whose
vector of per-shape word sequences is smallest in shortlex word order
at the first difference. An adjacent inversion in the described pair
would contradict that choice, so the search may skip it. Count examined
skips as candidates, and do not apply this rule across the fixed anchors.

Key the search on compatible rows, their known endpoint positions and
the previous word only if it had a single novel reply. Use the first row
to choose a common canonical order of known ranks. If the previous word
must remain available to the exchange check, keep its result last.
The ordering test then recognizes words that reach either that rank
or a novel endpoint in every row. Restore ranks to their first-seen
order when emitting branches. Separate order-two and planted exchange
tests check the cost, cap boundary, positive and negative predicates,
and equality of both continuations.

Carry an upper bound from the feasible GBS policy and pass sibling
naming floors and the remaining cost ceiling to each child. An
infeasible search result can be reused only at an equal or lower
ceiling. The product traversal is shortlex and keeps only the shortest
representative of an endpoint vector. Longer words can be pruned when
even assigning the best additional label for free leaves an inadmissible
cost. The cap charges every explored state, stored endpoint vector and
examined candidate with the precomputed GBS menu and all its decisions
and post-anchor pricing work included. Report GBS preparation, skipped
orders, and total work for every solved order. Work exhaustion yields
no purported optimum. A true minimum here would be specific to the
finite oracle and cost model.
