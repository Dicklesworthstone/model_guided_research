"""Compare a literature-based active learner on the audited group census."""

import argparse
import json
from pathlib import Path
from time import process_time_ns
from zipfile import ZipFile

from check_catalogue import reference_catalogue

from bench_optimal import ANCHORS, ARCHIVE, READ_PRICE, acquire_case, counts, opaque_names, price

ARMS = ("square", "shortlist", "frontier", "gbs")
PRIMARY = (10, 12)
PRIOR_EXACT = "artifacts/campaigns/group-student/optimal-initial-results.zip"


def inventory(work):
    with ZipFile(work / ARCHIVE) as archive:
        graphs = reference_catalogue(json.loads(archive.read("catalogue.json")))
    if tuple(graphs) != (6, 10, 12, 14, 16, 20, 24) or sum(map(len, graphs.values())) != 368:
        raise ValueError("The audited action census differs")
    return graphs


def score(work, reverse):
    from nanochat import group_acquisition as acq

    if not Path(acq.__file__).resolve().is_relative_to(work.resolve()):
        raise ValueError("Acquisition runtime loaded outside the frozen checkout")
    output = {}
    for n, graphs in inventory(work).items():
        started = process_time_ns()
        index = acq._prepare([tuple(zip(graph["0"].values(), graph["1"].values(), strict=True)) for graph in graphs])
        index_ns = process_time_ns() - started
        arms = {}
        cases = [{} for graph in graphs]
        for arm in reversed(ARMS) if reverse else ARMS:
            started = process_time_ns()
            if arm == "square":
                policy = None
            elif arm == "gbs":
                policy = acq.compile_gbs_policy(index, read_price=READ_PRICE)
            else:
                policy = acq.compile_policy(index, exhaustive_frontier=arm == "frontier")
            arms[arm] = process_time_ns() - started
            slots = range(len(graphs) - 1, -1, -1) if reverse else range(len(graphs))
            for slot in slots:
                names = opaque_names(n, slot, reverse)
                roster = names[1:] + names[:1] if reverse else names[::-1]
                cases[slot][arm] = acquire_case(acq.acquire, graphs[slot], names, roster, policy)
        output[n] = {"index_ns": index_ns, "compile_ns": arms, "cases": cases}
    return {"reverse": reverse, "orders": output}


def checked_words(row, graph, names, arm):
    expected = {names[i]: [names[graph["0"][i]], names[graph["1"][i]]] for i in range(len(names))}
    if row["root"] != names[0] or row["table"] != expected:
        raise ValueError("Recovered named action differs")
    terminals = ("square",) if arm == "square" else ("unique", "cap")
    if row["terminal"] not in terminals:
        raise ValueError("Unknown terminal")
    words = [word for word, _ in row["tape"]]
    if words[:4] != list(ANCHORS) or len(set(words)) != len(words):
        raise ValueError("Missing anchors or repeated paid word")
    for word, reply in row["tape"]:
        if len(word) < 2 or set(word) - {"0", "1"}:
            raise ValueError("Invalid paid word")
        state = 0
        for mark in word:
            state = graph[mark][state]
        if reply != names[state]:
            raise ValueError("Incorrect paid endpoint")
    return words


def summary(work, forward, replay):
    graphs_by_order = inventory(work)
    for run, reverse in ((forward, False), (replay, True)):
        if run["reverse"] is not reverse or set(run["orders"]) != set(map(str, graphs_by_order)):
            raise ValueError("Wrong replay or order coverage")
    with ZipFile(work / PRIOR_EXACT) as archive:
        prior = json.loads(archive.read("scored.json"))["orders"]
        optimum = json.loads(archive.read("verified.json"))["orders"]["6"]["arms"]["optimal"]["cost"]
    output = {"checked_acquisitions": 0, "matched_archived_control_tapes": 0, "orders": {}}
    for n, graphs in graphs_by_order.items():
        first, second = (run["orders"][str(n)] for run in (forward, replay))
        if any(len(run["cases"]) != len(graphs) or set(run["compile_ns"]) != set(ARMS) for run in (first, second)):
            raise ValueError("Wrong arm or shape coverage")
        order = {"shapes": len(graphs), "index_ns": [first["index_ns"], second["index_ns"]], "arms": {}}
        output["orders"][n] = order
        costs = {arm: [] for arm in ARMS}
        for arm in ARMS:
            charges = []
            cpu = [0, 0]
            capped = 0
            for slot, (left, right, graph) in enumerate(zip(first["cases"], second["cases"], graphs, strict=True)):
                if set(left) != set(ARMS) or set(right) != set(ARMS):
                    raise ValueError("Incomplete case arms")
                left_row, right_row = left[arm], right[arm]
                left_words = checked_words(left_row, graph, opaque_names(n, slot, False), arm)
                right_words = checked_words(right_row, graph, opaque_names(n, slot, True), arm)
                if left_words != right_words or left_row["terminal"] != right_row["terminal"]:
                    raise ValueError(f"Paid strategy changed on replay, order {n}, slot {slot}, arm {arm}")
                if str(n) in prior and arm != "gbs":
                    archived = prior[str(n)]["cases"][slot][arm]
                    archived_words = [word for word, _ in archived["tape"]]
                    if archived_words != left_words or archived["terminal"] != left_row["terminal"]:
                        raise ValueError("Released control differs from archived run")
                    output["matched_archived_control_tapes"] += 1
                row = counts(left_words)
                charges.append(row)
                costs[arm].append(price(row))
                capped += left_row["terminal"] == "cap"
                cpu[0] += left_row["online_ns"]
                cpu[1] += right_row["online_ns"]
                output["checked_acquisitions"] += 2
            order["arms"][arm] = {
                "charges": list(map(sum, zip(*charges, strict=True))),
                "cost": sum(costs[arm]),
                "compile_ns": [first["compile_ns"][arm], second["compile_ns"][arm]],
                "online_ns": cpu,
                "capped": capped,
            }
        order["gbs_vs"] = {}
        for control in ARMS[:-1]:
            deltas = [a - b for a, b in zip(costs["gbs"], costs[control], strict=True)]
            order["gbs_vs"][control] = {
                "cheaper": sum(delta < 0 for delta in deltas),
                "tied": deltas.count(0),
                "dearer": sum(delta > 0 for delta in deltas),
                "largest_increase": max(0, max(deltas)),
            }
    primary = {arm: sum(output["orders"][n]["arms"][arm]["cost"] for n in PRIMARY) for arm in ARMS}
    best = min(primary["shortlist"], primary["frontier"])
    output["primary_costs"] = primary
    output["preregistered_win"] = 100 * primary["gbs"] <= 98 * best and all(
        entry["arms"]["gbs"]["capped"] == 0 for entry in output["orders"].values()
    )
    order_six = output["orders"][6]["arms"]["gbs"]["cost"]
    if order_six < optimum:
        raise ValueError("GBS exceeded the archived exact optimum")
    output["order_six_exact_gap"] = order_six - optimum
    return output


def main():
    parser = argparse.ArgumentParser()
    commands = parser.add_subparsers(dest="command", required=True)
    run = commands.add_parser("score")
    run.add_argument("work", type=Path)
    run.add_argument("output", type=Path)
    run.add_argument("--reverse", action="store_true")
    check = commands.add_parser("summary")
    check.add_argument("work", type=Path)
    check.add_argument("forward", type=Path)
    check.add_argument("replay", type=Path)
    args = parser.parse_args()
    if args.command == "score":
        with args.output.open("x", encoding="utf-8") as out:
            json.dump(score(args.work, args.reverse), out, sort_keys=True, separators=(",", ":"))
    else:
        first = json.loads(args.forward.read_text(encoding="utf-8"))
        second = json.loads(args.replay.read_text(encoding="utf-8"))
        print(json.dumps(summary(args.work, first, second), indent=2))


if __name__ == "__main__":
    main()
