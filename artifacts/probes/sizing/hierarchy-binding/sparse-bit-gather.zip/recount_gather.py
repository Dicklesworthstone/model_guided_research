import json
import math
import platform
import random
import statistics
import sys
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import gather_policy as gather
from compile_policy import digest

SOURCE = "a8f9a89119ffff16e49b419ee8864ee8d303472c"
MANIFEST = "91df6b82c5718311399a62d504e2e95db8450d6244d3019527f374e1da94d264"
INPUT = "94a8d7a97010089a771b5d6d6554ab7e08e297fc8748b9a5fe8647b740ccc75a"
FILES = (
    "compile_policy.py", "recount.py", "project_policy.py", "gather_policy.py",
    "gather.yaml", "frozen.sha256", "protocol.txt", "gather-benchmark.json",
    "recount_gather.py", "argument.md",
)


def active_bits(truth, depth):
    return [bit for bit in range(depth)
            if any(value != truth[index ^ (1 << bit)] for index, value in enumerate(truth))]


def check_runs(read, names):
    path, = (name for name in names if name.endswith("/receipt.json"))
    receipt = json.loads(read(path))
    assert receipt["tool"] == "hierarchy-binding-sparse-gather"
    assert receipt["status"] == "passed" and not receipt["dry_run"] and not receipt["skipped"]
    check, = receipt["checks"]
    assert check["passed"] and check["executed"] and check["exit_code"] == 0
    log = str(Path(path).with_name(Path(check["log_path"]).name))
    assert digest(read(log)) == check["log_sha256"]
    config = str(Path(path).with_name(Path(receipt["config_snapshot_path"]).name))
    assert read(config) == read("gather.yaml")
    assert digest(read(config)) == receipt["config_sha256"] == receipt["config_sha256_after"]
    return Path(path).parent.name


def check_timing(row, truth, depth, seed):
    samples = row["times"]
    arms = {"packed", "runs", "incumbent", "scattered"}
    assert samples.keys() == arms
    rng = random.Random(47097 + depth * 100 + seed)
    assert sum(truth[rng.randrange(len(truth))] for _ in range(16384)) == row["checksum"]
    assert len(row["orders"]) == 7
    assert all(len(order) == len(arms) and set(order) == arms for order in row["orders"])
    assert all(len(series) == 7 and all(math.isfinite(t) and t > 0 for t in series)
               for series in samples.values())
    ratios = {name: statistics.median(a / b for a, b in zip(samples["scattered"], samples[name], strict=True))
              for name in ("packed", "runs", "incumbent")}
    assert ratios == row["ratios"]
    return ratios


def replay(read, names, input_archive):
    lock = read("frozen.sha256")
    assert digest(lock) == MANIFEST
    for line in lock.decode().splitlines():
        sha, path = line.split()
        assert digest(read(path)) == sha
    assert digest(input_archive.read_bytes()) == INPUT
    raw = json.loads(read("gather-benchmark.json"))
    assert raw["python"].startswith("3.13.") and raw["samples"] == 7 and raw["queries"] == 16384
    assert raw["actual"] == gather.archived(input_archive) == {
        "documents": 216, "exact_slots": 1800, "tables": 648, "selected": {"packed": 648},
    }
    assert raw["single_off_mask_flip_rejected"] is True
    truth, positions = gather.synthesize("regular", 16, 8, 121)
    changed = bytearray(truth)
    omitted = next(bit for bit in range(16) if bit not in positions)
    changed[1 << omitted] ^= 1
    # The exceptional address can now be distinguished from every neighbor
    # along an omitted bit. Old support witnesses survive away from that address.
    assert active_bits(changed, 16) == list(range(16))
    assert gather.compile_scattered(changed, 16)[1]["selected"] != "gather"
    assert [(r["depth"], r["family"], r["count"], r["seed"]) for r in raw["rows"]] == list(gather.grid())
    runtime_match = (raw["host"], raw["machine"], raw["python"]) == (
        platform.node(), platform.machine(), platform.python_version()
    )
    gates = {key: [] for key in ("width12_fallback", "width13_gather", "width16_gather",
                                 "width16_wire", "width16_memory", "width16_incumbent_speed",
                                 "width16_packed_latency", "controls", "shared_banks")}
    slots = 0
    width16 = []
    for row in raw["rows"]:
        depth, family, count, seed = (row[k] for k in ("depth", "family", "count", "seed"))
        truth, intended = gather.synthesize(family, depth, count, seed)
        slots += len(truth)
        assert digest(truth) == row["truth"]
        assert active_bits(truth, depth) == intended == row["relevant"]
        assert len(intended) == count
        decoders, replayed = gather.compile_scattered(truth, depth)
        assert replayed["before"] == row["before"]
        assert {name: len(dec.wire()) for name, dec in decoders.items()} == row["wire"]
        if runtime_match:
            assert replayed["selected"] == row["selected"]
            assert replayed["candidate_resident"] == row["candidate_resident"]
            assert {name: dec.resident() for name, dec in decoders.items()} == row["resident"]
        ratios = check_timing(row, truth, depth, seed)
        selected = row["selected"] == "gather"
        preserved = decoders["scattered"].wire() == decoders["incumbent"].wire()
        if family in gather.CONTROLS:
            gates["controls"].append(not selected and preserved)
        elif depth == 12:
            gates["width12_fallback"].append(not selected and preserved)
        elif depth == 13:
            gates["width13_gather"].append(selected)
        else:
            memory = row["resident"]["packed"] / row["resident"]["scattered"]
            gates["width16_gather"].append(selected)
            gates["width16_wire"].append(row["wire"]["scattered"] <= 40)
            gates["width16_memory"].append(memory >= 8)
            gates["width16_incumbent_speed"].append(ratios["incumbent"] <= 0.5)
            gates["width16_packed_latency"].append(ratios["packed"] <= 1.80)
            width16.append(dict(family=family, count=count, seed=seed, wire=row["wire"],
                                resident=row["resident"], ratios=ratios, packed_byte_reduction=memory))
    assert slots == 1_245_184
    assert set(raw["banks"]) == {"12", "16"}
    banks = {}
    for depth, minimum in ((12, 1.30), (16, 16)):
        measured = raw["banks"][str(depth)]
        replayed = gather.bank(depth)
        assert measured["tables"] == replayed["tables"] == 16
        assert measured["verified_slots"] == replayed["verified_slots"] == 16 * (1 << depth)
        if runtime_match:
            assert measured == replayed
        reduction = measured["packed"] / measured["shared"]
        gates["shared_banks"].append(reduction >= minimum)
        banks[str(depth)] = dict(**measured, packed_byte_reduction=reduction)
    assert sum(row["verified_slots"] for row in banks.values()) == 1_114_112
    assert all(len(checks) == (2 if name == "shared_banks" else 12) for name, checks in gates.items())
    return dict(source=SOURCE, score_receipt=check_runs(read, names), gate=all(map(all, gates.values())),
                checks={name: [sum(outcomes), len(outcomes)] for name, outcomes in gates.items()},
                timed_cases=len(raw["rows"]), synthetic_verified_slots=slots, archived=raw["actual"],
                width16=width16, banks=banks)


def verify(bundle, input_archive):
    with ZipFile(bundle) as archive:
        names = archive.namelist()
        assert archive.testzip() is None and len(names) == len(set(names))
        expected = json.loads(archive.read("decision.json"))
        result = replay(archive.read, names, input_archive)
        assert result == expected
    print(json.dumps(result))


def bundle(root, path, input_archive):
    files = {name: root / name for name in FILES}
    receipt, = (root / "receipts").glob("*/*/receipt.json")
    for name in ("receipt.json", "check-1.log", "checks-config.yaml"):
        target = receipt.with_name(name)
        files[target.relative_to(root).as_posix()] = target
    result = replay(lambda name: files[name].read_bytes(), files, input_archive)
    with ZipFile(path, "x", compression=ZIP_DEFLATED) as archive:
        for name, target in files.items():
            archive.write(target, name)
        archive.writestr("decision.json", json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    mode, *args = sys.argv[1:]
    {"bundle": bundle, "verify": verify}[mode](*map(Path, args))
