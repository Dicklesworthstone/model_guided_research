"""Check symbolic closure, word transport, and exact oracle tapes."""
import hashlib
import itertools
import json
import re
import sys
from collections import Counter, defaultdict
from copy import deepcopy
from pathlib import Path

if not __debug__:
    raise RuntimeError("Certificate verification requires enabled assertions")

def pointwise(group, gens):
    identity = (0,) if group == "z60" else tuple(range(len(gens[0])))

    def advance(state, letter):
        if group == "z60":
            return ((state[0] + gens[letter][0]) % 60,)
        return tuple(gens[letter][i] for i in state)

    def evaluate(word):
        state = identity
        for letter in word:
            state = advance(state, int(letter))
        return state

    states = [identity]
    ids = {identity: 0}
    names = [""]
    edges = []
    for index, state in enumerate(states):
        row = []
        for ch in (0, 1):
            dst = advance(state, ch)
            if dst not in ids:
                ids[dst] = len(states)
                states.append(dst)
                names.append(names[index] + str(ch))
            row.append(ids[dst])
        edges.append(row)
    return edges, names, evaluate, ids


def digest(graph):
    return hashlib.sha256(json.dumps(graph).encode()).hexdigest()


def cancelled(left, right):
    left_start = 0
    for a, b in zip(left, right):
        if a != b:
            break
        left_start += 1
    left, right = left[left_start:], right[left_start:]
    right_start = 0
    for a, b in zip(reversed(left), reversed(right)):
        if a != b:
            break
        right_start += 1
    if right_start:
        left, right = left[:-right_start], right[:-right_start]
    return min((left, right), (right, left))


def replay(arm, table, graph, reps, action):
    known = 1
    used = [set(), set()]
    memo = {("", ""): True}
    count = Counter()
    rules = {}
    matcher = None
    normalized = {}

    def reduce_word(word):
        if word in normalized:
            return normalized[word]
        original = word
        steps = []
        if matcher is not None:
            while match := matcher.search(word):
                lhs = match[0]
                rhs = rules[lhs]
                steps.append([match.start(), lhs, rhs])
                newer = word[:match.start()] + rhs + word[match.end():]
                assert (len(newer), newer) < (len(word), word)
                word = newer
        assert action(word) == action(original)
        normalized[original] = (word, steps)
        return normalized[original]

    def key(a, b):
        pair = cancelled(a,b)
        if arm == "cancelled":
            return pair
        while True:
            a, b = (reduce_word(word)[0] for word in pair)
            nxt = cancelled(a,b)
            if nxt == pair:
                return pair
            pair = nxt

    input_tape = iter(table["trace"])
    for source, row in enumerate(graph):
        for digit, destination in enumerate(row):
            event = next(input_tape)
            word = reps[source] + str(digit)
            assert event["word"] == word and event["target"] == destination
            choices = set(range(known)) - used[digit]
            refs = {text: i for i, text in enumerate(reps[:known])}
            normal, proof = reduce_word(word) if arm == "congruence" else (word, [])
            trials = event["trials"]
            paid = 0
            if arm == "congruence" and normal in refs:
                assert event["normal_form"] == normal and event["substitutions"] == proof
                assert destination == refs[normal] and destination in choices and not trials
                count["rewritten"] += 1
                count["rewrite_steps"] += len(proof)
            elif known == len(graph) and len(choices) == 1:
                assert not trials and destination == next(iter(choices)) and "normal_form" not in event
                count["forced"] += 1
            else:
                assert "normal_form" not in event
                def priority(i):
                    a, b = (abs(word.count(c) - reps[i].count(c)) for c in "01")
                    return (144 * ((a % 2) + (b % 2)) + a + b, i)
                ordered = sorted(choices, key=priority)
                accept = False
                for index, (target, source_kind, answer) in enumerate(trials):
                    assert target == ordered[index] and type(answer) is bool
                    ref = reps[target]
                    pair = key(word, ref)
                    cached = memo.get(pair)
                    if arm == "congruence":
                        a,b = pair
                        if a == b:
                            cached = True
                        elif a in refs and b in refs:
                            cached = False
                    assert source_kind == ("cache" if cached is not None else "oracle")
                    assert answer is (action(word) == action(ref))
                    if cached is not None:
                        assert answer is cached
                    else:
                        memo[pair] = answer
                        paid += 1
                    count[f"{source_kind}_{'equal' if answer else 'different'}"] += 1
                    if answer:
                        assert index == len(trials)-1 and target == destination
                        accept = True
                if not accept:
                    assert len(trials) == len(ordered) and destination == known and reps[known] == word
                    known += 1
                    count["new"] += 1
                    count["paid_new"] += paid
            assert destination not in used[digit] and action(word) == action(reps[destination])
            used[digit].add(destination)
            if arm == "congruence" and word != reps[destination]:
                target = reps[destination]
                assert (len(word),word) > (len(target), target)
                rules[word] = target
                matcher = re.compile("|".join(sorted(rules, key=lambda w: (-len(w),w))))
                normalized.clear()
    assert next(input_tape, None) is None and known == len(graph)
    assert table["edges"] == graph and table["representatives"] == reps
    derived = {"paid_new", "rewrite_steps"}
    assert {k:v for k,v in count.items() if k not in derived and v} == table["counts"]
    assert table["memo_entries"] == len(memo)
    assert table["memo_symbols"] == sum(len(a)+len(b) for a,b in memo)
    if arm == "congruence":
        assert table["rule_count"] == len(rules)
        assert table["rule_symbols"] == sum(len(a)+len(b) for a,b in rules.items())
    assert 0 <= table["oracle_seconds"] <= table["seconds"]
    count["paid"] = count["oracle_equal"] + count["oracle_different"]
    return count


def build_catalog():
    perms = list(itertools.permutations(range(5)))
    graphs = {}
    for pair in itertools.product(perms, repeat=2):
        graph, reps, _, _ = pointwise("s5", pair)
        if len(graph) != 120:
            continue
        equations = sorted({
            tuple(sorted((reps[i]+str(g),reps[d])))
            for i,row in enumerate(graph) for g,d in enumerate(row) if reps[i]+str(g) != reps[d]
        })
        graphs[digest(graph)] = (graph, equations)
    return dict(sorted(graphs.items()))


def replay_family(family, catalog, action, target):
    remaining = list(catalog)

    def eval_graph(graph, word):
        i = 0
        for c in word:
            i = graph[i][int(c)]
        return i

    for question in family["queries"]:
        balances = []
        count = len(remaining)
        for a,b in catalog[remaining[0]][1]:
            pos = {
                h for h in remaining
                if eval_graph(catalog[h][0], a) == eval_graph(catalog[h][0], b)
            }
            if 0 < len(pos) < count:
                balances.append((abs(2 * len(pos)-count), (a,b), pos))
        _, best, yes = min(balances, key=lambda row: row[:2])
        assert best == tuple(question["pair"]) and len(yes) == question["predicted_yes"]
        assert question["candidates"] == count
        a,b = best
        answer = action(a) == action(b)
        assert question["answer"] is answer
        remaining = [h for h in remaining if (h in yes) is answer]
    assert remaining == [target] == [family["marked_class"]]
    assert 0 <= family["oracle_seconds"] <= family["seconds"]


BASE_RELATIONS = [
    ("00", ""), ("11", ""), ("22", ""), ("33", ""),
    ("010", "101"), ("121", "212"), ("232", "323"),
    ("02", "20"), ("03", "30"), ("13", "31"),
]


def check_closure(proof):
    laws = set(BASE_RELATIONS) | {(b, a) for a, b in BASE_RELATIONS}
    inventory = set()
    for rank in range(1, 5):
        tails = [""] + ["".join(str(k) for k in range(rank - 1, j - 1, -1)) for j in range(rank)]
        inventory.update((rank, tail, str(i)) for tail in tails for i in range(rank))
    for row in proof:
        rank, tail, generator = (row[k] for k in ("rank", "tail", "generator"))
        inventory.remove((rank, tail, generator))
        word = tail + generator
        for pos, left, right in row["steps"]:
            assert (left, right) in laws and all(0 <= int(c) < rank for c in left + right)
            assert 0 <= pos <= len(word) - len(left) and word[pos:pos + len(left)] == left
            word = word[:pos] + right + word[pos + len(left):]
        tails = [""] + ["".join(str(k) for k in range(rank - 1, j - 1, -1)) for j in range(rank)]
        assert word == row["target"]
        assert any(word == lead + suffix for lead in [""] + list("012"[:rank-1]) for suffix in tails)
    assert not inventory and len(proof) == 40


def check_transport(witness, candidate_id=None):
    generators = witness["generators"]
    points = witness["point_order"]
    assert sorted(points) == list(range(5)) and len(generators) == 2
    assert all(sorted(g) == list(range(5)) for g in generators)
    forward, backward = witness["forward"], witness["backward"]
    assert len(forward) == 4 and len(backward) == 2
    graph, _, evaluate, _ = pointwise("permutation", generators)
    assert len(graph) == 120
    if candidate_id is not None:
        assert digest(graph) == candidate_id
    simples = []
    for a, b in zip(points, points[1:]):
        transposition = tuple(b if i == a else a if i == b else i for i in range(5))
        simples.append(transposition)
    assert all(evaluate(w) == g for w, g in zip(forward, simples, strict=True))

    def expand(word):
        return "".join(forward[int(letter)] for letter in word)

    for i, word in enumerate(backward):
        assert set(word) <= set("0123") and evaluate(expand(word)) == tuple(generators[i])
    proposed = [(expand(a), expand(b)) for a, b in BASE_RELATIONS]
    proposed.extend((str(i), expand(word)) for i, word in enumerate(backward))
    equations = sorted({tuple(sorted((a, b))) for a, b in proposed if a != b})
    assert list(map(tuple, witness["equations"])) == equations
    assert 0 < len(equations) <= 12 and all(evaluate(a) == evaluate(b) for a, b in equations)
    return equations


def expect_failure(check, obj):
    try:
        check(obj)
    except (AssertionError, IndexError, KeyError):
        return
    raise AssertionError("Incorrect witness was accepted")


def audit_pilot(path):
    pilot = json.loads(path.read_bytes())
    check_closure(pilot["closure"])
    equations = check_transport(pilot["transport"])
    proof = deepcopy(pilot["closure"])
    next(row for row in proof if row["steps"])["steps"][0][0] = 100
    expect_failure(check_closure, proof)
    missing = deepcopy(pilot["transport"])
    missing["equations"].pop()
    expect_failure(check_transport, missing)
    recovery = deepcopy(pilot["transport"])
    recovery["backward"][1] = ""
    expect_failure(check_transport, recovery)
    print(json.dumps(dict(normal_form_obligations=40, checked_equations=len(equations),
                          checked_symbols=sum(len(a) + len(b) for a,b in equations), tamper_rejections=3)))


def embedding(family, pair):
    if family == "s5":
        return pair
    if family == "c120":
        return [[(x + g[0]) % 120 for x in range(120)] for g in pair]
    degree, factor = {"a5xc2": (5, 2), "s4xc5": (4, 5)}[family]
    return [
        [g[x] if x < degree else degree + (x - degree + g[-1]) % factor
         for x in range(degree + factor)]
        for g in pair
    ]


def audit_arm(arm, equations, catalog, truth, evaluate, names):
    proposal = arm["proposal"]
    target = proposal["marked_class"]
    replay_family({**proposal, "oracle_seconds": 0, "seconds": 0}, catalog, evaluate, target)
    selection = [[*q["pair"], q["answer"]] for q in proposal["queries"]]
    assert len(selection) == arm["selection"]
    known = {tuple(row[:2]): row[-1] for row in selection}
    assert len(known) == len(selection)
    trace = arm["certificate"]
    assert 0 < len(trace) <= len(equations)
    checks = []
    for i, event in enumerate(trace):
        a, b = equations[i]
        assert event["pair"] == [a, b]
        correct = evaluate(a) == evaluate(b)
        assert event["answer"] is correct
        assert event["reused"] is ((a, b) in known)
        if event["reused"]:
            assert known[a, b] is correct
        else:
            checks.append([a, b, correct])
        assert correct or i == len(trace)-1
    assert len(checks) == arm["checked"]
    accepted = trace[-1]["answer"]
    assert arm["accepted"] is accepted
    fallback_queries = []
    if accepted:
        assert len(trace) == len(equations) and catalog[target][0] == truth and arm["fallback"] is None
    else:
        fallback = dict(arm["fallback"], oracle_seconds=0)
        counts = replay("cancelled", fallback, truth, names, evaluate)
        fallback_queries = [
            [step["word"], names[ref], result]
            for step in fallback["trace"] for ref, method, result in step["trials"] if method == "oracle"
        ]
        assert len(fallback_queries) == counts["paid"]
    stages = (selection, checks, fallback_queries)
    assert arm["paid"] == selection + checks + fallback_queries
    assert 0 <= arm["oracle_seconds"] <= arm["seconds"]
    record = dict(accepted=int(accepted))
    for label, queries in zip(("selection", "certificate", "fallback"), stages, strict=True):
        record[label+"_checks"] = len(queries)
        record[label+"_symbols"] = sum(len(a)+len(b) for a,b,_ in queries)
    record["total_checks"] = len(arm["paid"])
    record["total_symbols"] = sum(len(a)+len(b) for a,b,_ in arm["paid"])
    return record


def audit_run(coverage, output, source):
    data = json.loads(output.read_bytes())
    panel = json.loads(coverage.read_bytes())

    def sha(path):
        return hashlib.sha256(path.read_bytes()).hexdigest()

    prior_dir = Path("artifacts/probes/sizing/group-congruence")
    earlier = [prior_dir / x for x in ("coverage.json", "proposal-coverage.json")]
    old, previous = [json.loads(x.read_bytes()) for x in earlier]
    assert panel["prior"] == [sha(x) for x in earlier] and panel["producer"] == sha(source)
    assert panel["seed"] == 2026112318 and data["coverage_sha256"] == sha(coverage)
    seen = set(old["spent"]) | {g["graph_sha"] for g in old["presentations"] + previous["cases"]}
    catalog = build_catalog()
    assert len(catalog) == len(data["transports"]) == 57
    assert set(catalog) == set(data["transports"])
    check_closure(data["closure"])
    compressed = {h: check_transport(entry, h) for h, entry in data["transports"].items()}
    totals = defaultdict(lambda: defaultdict(Counter))
    slots = ["s5"] * 6 + ["c120"] * 4 + ["a5xc2"] * 4 + ["s4xc5"] * 4
    assert len(data["cases"]) == len(panel["cases"]) == len(slots)
    cases = []
    for index, (case, expected, family) in enumerate(zip(data["cases"], panel["cases"], slots, strict=True)):
        assert index == case["index"] and case["family"] == expected["family"] == family
        assert all(case[key] == value for key,value in expected.items())
        truth, names, evaluate, ids = pointwise("permutation", embedding(family, case["pair"]))
        fingerprint = digest(truth)
        assert len(truth) == 120 and fingerprint == case["graph_sha"] and fingerprint not in seen
        seen.add(fingerprint)
        assert (fingerprint in catalog) is (family == "s5")
        edge, compact = (case["arms"][name] for name in ("edge", "compact"))
        assert edge["proposal"] == compact["proposal"]
        proposal_id = edge["proposal"]["marked_class"]
        _, edge_equations = catalog[proposal_id]
        assert len(edge_equations) == 121
        arm_stats = dict(
            edge=audit_arm(edge, edge_equations, catalog, truth, evaluate, names),
            compact=audit_arm(compact, compressed[proposal_id], catalog, truth, evaluate, names),
        )
        for name, stats in arm_stats.items():
            totals[family][name].update(stats)
        assert all(stats["accepted"] == (family == "s5") for stats in arm_stats.values())
        if family != "s5":
            assert edge["paid"][-arm_stats["edge"]["fallback_checks"]:] == compact["paid"][-arm_stats["compact"]["fallback_checks"]:]
        words = case["samples"]
        assert Counter(len(word) for word,_ in words) == {16:48,32:48,64:48,128:48}
        assert len({w for w,_ in words}) == 192 and all(ids[evaluate(w)] == y for w,y in words)
        cases.append(dict(index=index, family=family, **arm_stats))
    s5 = totals["s5"]
    query_savings = 1-s5["compact"]["total_checks"]/s5["edge"]["total_checks"]
    symbol_savings = 1-s5["compact"]["total_symbols"]/s5["edge"]["total_symbols"]
    outside = {arm: sum((t[arm] for f,t in totals.items() if f != "s5"), Counter()) for arm in ("edge","compact")}
    extra = outside["compact"]["total_checks"] - outside["edge"]["total_checks"]
    overhead = extra / outside["edge"]["fallback_checks"]
    summary = dict(
        catalog=len(catalog), certified_catalog=len(compressed), closure_obligations=len(data["closure"]),
        min_certificate=min(map(len,compressed.values())), max_certificate=max(map(len,compressed.values())),
        gate_passed=(query_savings >= .80 and symbol_savings >= .70 and overhead <= .02),
        query_savings=query_savings, symbol_savings=symbol_savings, outside_extra_checks=extra,
        outside_extra_as_fraction_of_fallback=overhead, held_out_words=18*192, checked_edges=18*240*2,
        totals=totals, cases=cases,
    )
    print(json.dumps(summary, sort_keys=True))


if __name__ == "__main__":
    if len(sys.argv) == 2:
        audit_pilot(Path(sys.argv[1]))
    else:
        audit_run(*(Path(x) for x in sys.argv[1:]))
