"""Exercise the installed endpoint CLI with an independent software oracle."""

import hashlib
import json
import selectors
import subprocess
import sys
from importlib.metadata import distribution
from importlib.resources import files
from pathlib import Path
from zipfile import ZipFile

from nanochat.group_acquisition import BUNDLED_POLICY_SHA256


def probe(executable, order):
    modulus = order // 2
    labels = {(i, s): f"opaque {i}-{s} / α" for i in range(modulus) for s in range(2)}

    def step(state, mark):
        rotation, reflected = state
        if mark == "1":
            return rotation, 1 - reflected
        return (rotation + (-1 if reflected else 1)) % modulus, reflected

    roster = Path(f"roster-{order}.json")
    with roster.open("x", encoding="utf-8") as handle:
        json.dump(list(reversed(labels.values())), handle)
    transcript = Path(f"session-{order}.jsonl")
    command = [str(executable), "group-acquire", str(roster), "--compiled", "--transcript", str(transcript)]
    words = []
    with subprocess.Popen(
        command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
    ) as process, selectors.DefaultSelector() as ready:
        try:
            ready.register(process.stdout, selectors.EVENT_READ)
            while True:
                if not ready.select(15):
                    raise AssertionError("The command did not flush its next JSON frame")
                line = process.stdout.readline()
                if not line:
                    raise AssertionError("Unexpected CLI EOF: " + process.stderr.read())
                frame = json.loads(line)
                if "action" in frame:
                    break
                word = frame["word"]
                assert set(frame) == {"word"} and len(word) >= 2 and set(word) <= {"0", "1"} and word not in words
                words.append(word)
                state = (0, 0)
                for mark in word:
                    state = step(state, mark)
                process.stdin.write(json.dumps({"label": labels[state]}) + "\n")
                process.stdin.flush()
            process.stdin.close()
            assert process.wait(timeout=10) == 0, process.stderr.read()
            assert not process.stdout.read()
        finally:
            if process.poll() is None:
                process.kill()
                process.wait(timeout=10)
    expected = {name: [labels[step(state, mark)] for mark in "01"] for state, name in labels.items()}
    assert frame == {"action": {"root": labels[0, 0], "transitions": expected}, "terminal": "unique"}
    events = [json.loads(line) for line in transcript.read_text(encoding="utf-8").splitlines()]
    assert events[0]["mode"] == "compiled" and events[0]["setup_ns"] > 0
    assert [row["word"] for row in events[1:-1:2] if row["event"] == "request"] == words
    assert [row["word"] for row in events[2:-1:2] if row["event"] == "reply"] == words
    assert events[-1]["action"] == frame["action"]
    assert words[:4] == ["00", "01", "10", "11"]
    print(f"Installed compiled CLI at order {order}: {2 * order} transitions on {len(words)} paid replies")


if __name__ == "__main__":
    executable, wheel = map(Path, sys.argv[1:])
    resource = files("nanochat").joinpath("research_data", "group_policies.zip")
    assert Path(str(resource)).resolve().is_relative_to(sys.prefix)
    assert hashlib.sha256(resource.read_bytes()).hexdigest() == BUNDLED_POLICY_SHA256
    assert json.loads(distribution("model-guided-research").read_text("direct_url.json"))["url"] == wheel.as_uri()
    with ZipFile(wheel) as archive:
        assert archive.read("nanochat/research_data/group_policies.zip") == resource.read_bytes()
    for order in (32, 64, 128):
        probe(executable, order)
