#!/bin/bash
set -euo pipefail
export PATH="/home/ubuntu/.local/bin:$PATH"
export MGR_TRIE=/data/ssd/tmp/mgr-trie-index.8LJsWrin MGR_TRIE_SHA="$1"
export DSR_REPOS_FILE="$MGR_TRIE/campaign.yaml" DSR_QUALITY_LOG_DIR="$MGR_TRIE/receipts"
export UV_PROJECT_ENVIRONMENT=/data/ssd/tmp/mgr-eval-ci.bevt3nLW/qualified-venv
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
mkdir -p "$MGR_TRIE/gate"
dsr quality --tool hierarchy-trie-index-width --work-dir "$MGR_TRIE/gate" --check-timeout 360
