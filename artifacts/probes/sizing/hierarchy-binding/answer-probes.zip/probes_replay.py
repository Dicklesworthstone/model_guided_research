import hashlib
import json
import statistics
import sys
from collections import Counter
from functools import cache
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import probes as study
from address_fixtures import DIM, POOLS, sha_json
from posterior_replay import independent_catalog, oracle_fixture

SOURCE = "f9220047e5b6e1ceaf5a39b5c37f817d1e058c5b"
LOCK = "d6b0269c142ea43aeffb87d6e080a42bb6d0a9fcd3a8c67d37de237631128cf6"
SHADOW = "03c66dc47b91756fd082ed775d56f9ed741b7b434f887fdd4a1c46a2a1471793"
FILES = ("address_fixtures.py", "topology.py", "posterior.py", "posterior_replay.py",
         "probes.py", "probes.yaml", "frozen.sha256", "protocol.txt", "probes-raw.json",
         "probes_replay.py", "argument.md", "replay.yaml")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def receipt_id(read, files):
    path, = (name for name in files if name.endswith("/receipt.json"))
    receipt = json.loads(read(path))
    assert receipt["tool"] == "hierarchy-answer-probes" and receipt["status"] == "passed"
    assert receipt["passed"] == receipt["executed"] == receipt["total"] == 1
    assert not receipt["dry_run"] and not receipt["skipped"]
    check, = receipt["checks"]
    assert check["passed"] and check["executed"] and check["exit_code"] == 0
    log = Path(path).with_name(Path(check["log_path"]).name).as_posix()
    assert digest(read(log)) == check["log_sha256"]
    config = Path(path).with_name("checks-config.yaml").as_posix()
    assert read(config) == read("probes.yaml")
    assert digest(read(config)) == receipt["config_sha256"] == receipt["config_sha256_after"]
    return Path(path).parent.name


def direct_encode(key, permutation, signs):
    digits = f"{key:08b}"[::-1]
    return int("".join(digits[i] for i in reversed(permutation)), 2) ^ signs


def finite_optimum(answers, tests):
    @cache
    def maximum(remaining, budget):
        if not remaining:
            return 0
        if len({answers[index] for index in remaining}) == 1:
            return len(remaining)
        if budget == 0:
            return 0
        scores = [maximum(remaining & proposed, budget - 1) + maximum(remaining - proposed, budget - 1)
                  for proposed in tests if remaining & proposed and remaining - proposed]
        return max(scores, default=0)

    return [maximum(frozenset(range(len(answers))), depth) for depth in (1, 2)]


def check_planted(raw):
    assert raw == study.planted()
    toy = [0, 0, 0, 1, 1, 2, 2, 3]
    test = [frozenset(j for j in range(8) if mask & (1 << j)) for mask in (15, 3, 48, 32)]
    exact = finite_optimum(toy, test)
    assert exact == [2, 4]
    assert raw["1"]["answer_greedy"]["uniform_certified"] == 2
    assert raw["2"]["answer_greedy"]["uniform_certified"] == 3
    assert raw["2"]["answer_lookahead"]["uniform_certified"] == 4
    return {"optimal": exact, "greedy_two": 3}


def check_traces(outcomes, keys, namespaces, answers, truth, gold):
    for width, cases in outcomes.items():
        assert tuple(cases) == study.ARMS
        for result in cases.values():
            possible = list(range(len(answers)))
            probes = result["probes"]
            assert len(probes) <= int(width)
            for key, position, bit in probes:
                assert key in keys and 0 <= position < DIM and bit in (0, 1)
                comparison = [i for i in possible if ((direct_encode(key, *namespaces[i]) >> position) & 1) == bit]
                assert 0 < len(comparison) < len(possible) and truth in comparison
                possible = comparison
            targets = {answers[i] for i in possible}
            assert len(possible) == result["surviving_maps"] and len(targets) == result["surviving_answers"]
            assert result["answer"] == (next(iter(targets)) if len(targets) == 1 else None)
            assert result["answer"] is None or result["answer"] == gold
            assert 0 <= result["uniform_certified"] <= len(answers)
        exact = cases["answer_lookahead"]["uniform_certified"]
        assert all(result["uniform_certified"] <= exact for result in cases.values())
        if len(set(answers)) > (1 << int(width)):
            assert exact < len(answers)


def replay(read, files, validate_catalogs=False):
    lock = read("frozen.sha256")
    assert digest(lock) == LOCK
    for line in lock.decode().splitlines():
        sha, path = line.split()
        assert digest(read(path)) == sha
    assert digest(read("posterior_replay.py")) == SHADOW
    raw = json.loads(read("probes-raw.json"))
    assert len(raw["rows"]) == len({row["fixture"] for row in raw["rows"]}) == 96
    controls = check_planted(raw["planted"])
    observed = {family: [] for family in study.FAMILIES}
    census_audits = []
    optimal_audits = []
    for row, case in zip(raw["rows"], study.fresh(), strict=True):
        seed, family, index, records, root, query, gold, namespace = case
        assert (row["seed"], row["family"], row["index"]) == (seed, family, index)
        assert row["fixture"] == sha_json([records, root, query]) and row["target"] == gold
        x0, p0 = row["base"]
        symbols = {root, *(ptr for branches in records.values() for ptr in branches)}
        assert set(POOLS[1]) - records.keys() == {x0}
        assert set(POOLS[min(symbols).bit_count() % 2]) - symbols == {p0}
        mappings = [tuple(mapping) for mapping, _ in row["versions"]]
        assert len(mappings) == len(set(mappings)) and all(sorted(m) == list(range(DIM)) for m in mappings)
        namespaces = [(mapping, direct_encode(x0, mapping, 0) ^ p0) for mapping in mappings]
        truth = namespaces.index(namespace)
        answers = [answer for _, answer in row["versions"]]
        assert answers[truth] == gold
        for mapping, answer in zip(namespaces, answers, strict=True):
            oracle_fixture(records, root, query, answer, mapping)
        check_traces(row["policies"], records, namespaces, answers, truth, gold)
        tests = study.partitions(records, row["versions"], x0, p0)
        assert len(tests) == row["probes"]
        assert study.assess(answers, tests, truth, seed + 223 * index) == row["policies"]
        if index == 0:
            census_audits.append([seed, family])
            if validate_catalogs:
                census = independent_catalog(records, root, query)
                events = Counter()
                for label, _, count in census["versions"]:
                    events[label] += count
                assert events == Counter(answers) and census["bank_maps"] == 40320
        if seed == study.SEEDS[0] and len(set(answers)) > 1 and family not in optimal_audits:
            optimal_audits.append(family)
            if validate_catalogs:
                candidates = set()
                for key in records:
                    words = [direct_encode(key, *version) for version in namespaces]
                    for bit in range(DIM):
                        candidates.add(frozenset(i for i, word in enumerate(words) if (word >> bit) & 1))
                exact = finite_optimum(answers, candidates)
                assert exact == [row["policies"][budget]["answer_lookahead"]["uniform_certified"]
                                 for budget in ("1", "2")]
        observed[family].append((row, answers))
    assert len(census_audits) == 6 and optimal_audits == list(study.FAMILIES)
    pooled = {}
    for family, results in observed.items():
        assert len(results) == 48
        ambiguous = [(row, labels) for row, labels in results if len(set(labels)) > 1]
        by_budget = {}
        for budget in ("1", "2"):
            metrics = {}
            for method in study.ARMS:
                outcomes = [(row["policies"][budget][method], len(labels)) for row, labels in ambiguous]
                metrics[method] = dict(
                    actual_certified=sum(out["answer"] is not None for out, _ in outcomes),
                    maps_identified=sum(out["surviving_maps"] == 1 for out, _ in outcomes),
                    certified_with_multiple_maps=sum(out["answer"] is not None and out["surviving_maps"] > 1
                                                      for out, _ in outcomes),
                    expected_uniform=statistics.mean(out["uniform_certified"] / total for out, total in outcomes),
                )
            by_budget[budget] = metrics
        pooled[family] = dict(cases=48, ambiguous=len(ambiguous), zero_certified=48-len(ambiguous), budgets=by_budget,
                              information_floor_two=sum(len(set(labels)) > 4 for _, labels in ambiguous))
    primary = sum(cell["ambiguous"] for cell in pooled.values())
    improvements = sum(cell["budgets"]["2"]["answer_lookahead"]["actual_certified"]
                       - cell["budgets"]["2"]["map_balance"]["actual_certified"] for cell in pooled.values())
    gates = dict(adequate_ambiguity=primary >= 48, actual_two_bit_gain=improvements >= 4)
    return dict(source=SOURCE, receipt=receipt_id(read, files), panel=96, primary=primary,
                actual_gain=improvements, gates=gates, pass_all=all(gates.values()), controls=controls,
                census_audits=census_audits, optimal_audits=optimal_audits, pooled=pooled)


def verify(path):
    with ZipFile(path) as archive:
        names = archive.namelist()
        assert archive.testzip() is None and len(names) == len(set(names))
        result = replay(archive.read, names, validate_catalogs=True)
        assert result == json.loads(archive.read("decision.json"))
    print(json.dumps(result))


def build(root, bundle):
    files = {name: root / name for name in FILES}
    receipt, = (root / "receipts").glob("*/*/receipt.json")
    for name in ("receipt.json", "check-1.log", "checks-config.yaml"):
        path = receipt.with_name(name)
        files[path.relative_to(root).as_posix()] = path
    result = replay(lambda name: files[name].read_bytes(), files.keys())
    with ZipFile(bundle, "x", compression=ZIP_DEFLATED) as archive:
        for name, path in files.items():
            archive.write(path, name)
        archive.writestr("decision.json", json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    mode, *args = sys.argv[1:]
    {"build": build, "verify": verify}[mode](*map(Path, args))
