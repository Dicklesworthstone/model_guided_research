import dataclasses
import itertools
import json
import math
import random
import sys
import time
from pathlib import Path

from distractor import encode, n_tokens
from leaf_position import (
    BATCH, F, LocationHead, SEED, SPEC, STEPS, WIDTH, HuggingFaceTokenizer, _load_eval_checkpoint,
    build_provenance, digest, leaf_entries, model_and_head, parameter_hash, pq, read, save_checkpoint,
    states, tokenizer_path, torch, tree_of, write,
)
from nanochat.diagnostics_data import _hier_paths, _hier_serialize


def tree_from_text(text):
    tree = {}
    for path, value, _ in leaf_entries(text):
        parent = tree
        for key in path[:-1]:
            parent = parent.setdefault(key, {})
        assert path[-1] not in parent
        parent[path[-1]] = value
    assert serialize(tree) == text
    return tree


def serialize(tree):
    return "TASK hier TREE " + _hier_serialize(tree)


def shuffle_tree(node, rng):
    if isinstance(node, str):
        return node
    pairs = list(node.items())
    rng.shuffle(pairs)
    return {key: shuffle_tree(value, rng) for key, value in pairs}


def corpus(reference):
    directory = reference / "data" / "hier_paired"
    manifest = read(directory / "manifest.json")
    known, training = set(), []
    for filename, sha in manifest["sha256"].items():
        path = directory / filename
        assert digest(path) == sha
        docs = pq.read_table(path, columns=["text"]).column("text").to_pylist()
        for first, second in zip(docs[::2], docs[1::2], strict=True):
            text = tree_of(first)
            assert text == tree_of(second) and text not in known
            known.add(text)
            if filename == "train_000.parquet":
                training.append(text)
    assert len(known) == 32000 and len(training) == 25600
    return known, training


def make_panel(out, reference, answer, pilot, replicated, crossed, distracted):
    known, _ = corpus(reference)
    for path in (reference / "panel.json", answer / "panel.json", pilot / "panel.json",
                 replicated / "seed-30" / "panel.json"):
        data = read(path)
        for rows in data.get("evaluation", data).values():
            known.update(tree_of(row["documents"][0]) for row in rows)
    known.update(block[cell]["tree"] for block in read(crossed)["blocks"] for cell in ("a", "b"))
    known.update(block[cell]["tree"] for block in read(distracted)["blocks"]
                 for cell in ("normal", "length_only", "nested"))
    assert len(known) == 32504
    tokenizer = HuggingFaceTokenizer.from_directory(str(tokenizer_path(reference)))
    rng = random.Random(74019)
    blocks = []
    for seed in (71, 72, 73):
        selected = 0
        docs = SPEC.generate(4800, seed, SPEC.resolve_dials(None))["train"]
        for doc in docs[::2]:
            text = tree_of(doc)
            leaves = leaf_entries(text)
            if text in known or len(leaves) != 9 or len({v for _, v, _ in leaves}) != 9:
                continue
            tree = tree_from_text(text)
            root = f"k0x{selected % 3}"
            omitted = f"k1x{(selected // 3 + seed) % 3}"
            chosen = {path for path, _ in _hier_paths(tree) if path[0] != root and path[1] != omitted}
            assert len(chosen) == 4
            normal = encode(text, chosen, tokenizer)
            permutation = shuffle_tree(tree, rng)
            permuted = encode(serialize(permutation), chosen, tokenizer)
            if text == permuted["tree"]:
                continue
            assert n_tokens(normal) == n_tokens(permuted)
            assert dict(_hier_paths(permutation)) == dict(_hier_paths(tree))
            labels = {tuple(row["path"]): row["label"] for row in normal["queries"]}
            if all(row["label"] == labels[tuple(row["path"])] for row in permuted["queries"]):
                continue
            nested_branch = {"k1x0": {f"k2x{k[-1]}": val for k, val in tree[root].items()}}
            nested = encode(serialize({r: nested_branch if r == root else branch for r, branch in tree.items()}),
                            chosen, tokenizer)
            for zeros in range(1, 49):
                alias = f"{root[:-1]}{'0' * zeros}{root[-1]}"
                expanded = encode(serialize({alias if r == root else r: branch for r, branch in tree.items()}),
                                  chosen, tokenizer)
                if n_tokens(expanded) == n_tokens(nested):
                    break
            else:
                raise ValueError("unable to match distractor control length")
            contexts = {entry["tree"] for entry in (normal, permuted, expanded, nested)}
            assert len(contexts) == 4
            if known.intersection(contexts):
                continue
            known.update(contexts)
            blocks.append(dict(seed=seed, index=selected, root=root, omitted=omitted, normal=normal,
                               permuted=permuted, expanded=expanded, nested=nested))
            selected += 1
            if selected == 12:
                break
        assert selected == 12
    assert len(blocks) == 36 and len(known) == 32648
    write(out, dict(blocks=blocks, tokenizer_sha256=digest(tokenizer_path(reference) / "tokenizer.json"),
                    unique_contexts=len(known)))
    print(dict(blocks=len(blocks), prompts={key: sorted({n_tokens(block[key]) for block in blocks})
                                           for key in ("normal", "permuted", "expanded", "nested")}), flush=True)


def prepare(root, reference, original_root):
    original_root = original_root / f"seed-{SEED}"
    _, training = corpus(reference)
    previous = read(original_root / "preflight.json")
    base_path = original_root / "schedule.pt"
    assert digest(base_path) == previous["schedule_sha256"]
    base = torch.load(base_path, weights_only=True)
    augmented = {name: tensor.clone() for name, tensor in base.items()}
    tokenizer = HuggingFaceTokenizer.from_directory(str(tokenizer_path(reference)))
    tokenizer_hash = digest(tokenizer_path(reference) / "tokenizer.json")
    assert tokenizer_hash == previous["tokenizer_sha256"]
    rng = random.Random(51001 + SEED)
    selected = set(rng.sample(range(8192), 6144))
    bos = tokenizer.get_bos_token_id()
    changed_tree_count, changed_label_count, changed_position_count = 0, 0, 0
    for ordinal, index in enumerate(previous["training_tree_indices"]):
        original = training[index]
        tree = tree_from_text(original)
        before = dict(_hier_paths(tree))
        shuffled = shuffle_tree(tree, rng) if ordinal in selected else tree
        assert dict(_hier_paths(shuffled)) == before
        transformed = serialize(shuffled)
        changed_tree_count += transformed != original
        leaves = leaf_entries(transformed)
        path_index = {route: n for n, (route, _, _) in enumerate(leaves)}
        prefixes = [tokenizer.encode(transformed[:end], prepend=bos) for _, _, end in leaves]
        assert len(prefixes) <= 9
        candidates = [len(item) - 1 for item in prefixes]
        for row in (ordinal * 2, ordinal * 2 + 1):
            q = int(base["queries"][row])
            expected_answer = base["targets"][row, q:][base["targets"][row, q:] != -1].tolist()
            old_ids = base["inputs"][row, :q + 1].tolist() + expected_answer
            assert old_ids[0] == bos
            old = tokenizer.decode(old_ids[1:])
            assert tree_of(old) == original and SPEC.checker(old) is True
            route = tuple(old.split(" PATH ", 1)[1].split(" OUT ", 1)[0].split())
            answer = before[route]
            assert leaf_entries(original)[int(base["labels"][row])][:2] == (route, answer)
            doc = f"{transformed} PATH {' '.join(route)} OUT {answer}"
            prompt, answer_text = SPEC.split_prompt(doc)
            ids = tokenizer.encode(doc, prepend=bos)
            assert answer_text == answer and SPEC.checker(doc) is True
            assert len(ids) == len(old_ids) and tokenizer.encode(prompt, prepend=bos) == ids[:q + 1]
            assert ids[q + 1:] == expected_answer
            assert all(ids[:len(prefix)] == prefix for prefix in prefixes)
            label = path_index[route]
            augmented["inputs"][row, :len(ids) - 1] = torch.tensor(ids[:-1])
            augmented["labels"][row] = label
            augmented["candidates"][row, :len(candidates)] = torch.tensor(candidates)
            changed_label_count += int(base["labels"][row]) != label
            changed_position_count += int(base["candidates"][row, base["labels"][row]]) != candidates[label]
            if ordinal not in selected:
                assert all(torch.equal(augmented[key][row], tensor[row]) for key, tensor in base.items())
    assert torch.equal(augmented["targets"], base["targets"]) and torch.equal(augmented["queries"], base["queries"])
    assert changed_tree_count > 5600 and changed_label_count > 0 and changed_position_count > 0
    root.mkdir(parents=True, exist_ok=True)
    torch.save(augmented, root / "permuted.pt")
    report = dict(seed=SEED, train_trees=8192, selected_for_permutation=len(selected),
                  changed_tree_count=changed_tree_count, changed_label_count=changed_label_count,
                  changed_position_count=changed_position_count,
                  base_sha256=previous["schedule_sha256"], permuted_sha256=digest(root / "permuted.pt"),
                  tokenizer_sha256=tokenizer_hash, answer_targets_identical=True, query_offsets_identical=True)
    write(root / "preflight.json", report)
    print(json.dumps(report), flush=True)


def train(root, reference, original_root):
    lock = read(root / "preflight.json")
    tokenizer = HuggingFaceTokenizer.from_directory(str(tokenizer_path(reference)))
    assert lock["seed"] == SEED and digest(tokenizer_path(reference) / "tokenizer.json") == lock["tokenizer_sha256"]
    prior = original_root / f"seed-{SEED}"
    start_hash = read(prior / "runs" / "joint" / "summary.json")["initial_parameters_sha256"]
    paths = {"canonical": (prior / "schedule.pt", lock["base_sha256"]),
             "augmented": (root / "permuted.pt", lock["permuted_sha256"])}
    for arm, (path, schedule_hash) in paths.items():
        assert digest(path) == schedule_hash
        schedule = torch.load(path, weights_only=True)
        model, head = model_and_head(tokenizer)
        parameters = (*model.parameters(), *head.parameters())
        assert parameter_hash(parameters) == start_hash
        optimizer = torch.optim.AdamW(parameters, lr=0.0006)
        start = time.perf_counter()
        for step in range(STEPS):
            part = slice(step * BATCH, (step + 1) * BATCH)
            optimizer.zero_grad(set_to_none=True)
            logits, hidden = states(model, schedule["inputs"][part])
            answer = F.cross_entropy(logits.float().flatten(0, 1), schedule["targets"][part].flatten(), ignore_index=-1)
            location_logits = head(hidden, schedule["queries"][part], schedule["candidates"][part])
            location = F.cross_entropy(location_logits, schedule["labels"][part])
            loss = answer + location
            if not math.isfinite(float(loss.detach())):
                raise ValueError(f"nonfinite {arm} loss at {step}")
            loss.backward()
            torch.nn.utils.clip_grad_norm_(parameters, 1.0)
            optimizer.step()
            if step == 0 or (step + 1) % 256 == 0:
                rate = float((location_logits.argmax(1) == schedule["labels"][part]).float().mean())
                print(f"{arm} {step+1}/{STEPS} answer_ce={float(answer.detach()):.5f} "
                      f"position_ce={float(location.detach()):.5f} batch_position_accuracy={rate:.3f}", flush=True)
        flops = float(model.estimate_flops() * (BATCH * WIDTH * STEPS))
        checkpoint = root / "runs" / arm / "checkpoints"
        checkpoint.mkdir(parents=True)
        tokenizer.save(str(checkpoint / "tokenizer"))
        save_checkpoint(str(checkpoint), STEPS - 1, model.state_dict(), None,
                        dict(model_config=dataclasses.asdict(model.config), optimizer_type="adamw", scheduler_type="none",
                             seed=SEED, tokenizer={"kind": "task", "dir": "tokenizer"},
                             budget={"target_flops": flops, "max_steps": STEPS},
                             lineage={"run_id": arm, "parent_run_ids": []}), rank=0)
        head_file = checkpoint / "location_head.pt"
        torch.save(head.state_dict(), head_file)
        settings = dict(run_id=arm, seed=SEED, steps=STEPS, batch=BATCH, width=WIDTH, lr=0.0006,
                        clip=1.0, location_gradient_multiplier=1, schedule_sha256=schedule_hash)
        report = dict(provenance=build_provenance(settings), settings=settings,
                      initial_parameters_sha256=start_hash, final_parameters_sha256=parameter_hash(parameters),
                      model_flops_est=flops, elapsed_seconds=time.perf_counter()-start,
                      location_head_sha256=digest(head_file), weights_sha256=digest(checkpoint / "model_002047.pt"))
        write(checkpoint.parent / "summary.json", report)
        print(json.dumps(report), flush=True)


@torch.inference_mode()
def evaluate(root, panel_path):
    panel = read(panel_path)
    device = torch.device("cpu")
    for arm in ("canonical", "augmented"):
        checkpoint = root / "runs" / arm / "checkpoints"
        model, meta, step = _load_eval_checkpoint(checkpoint, None, device, fingerprint_weights=True)
        summary = read(checkpoint.parent / "summary.json")
        assert step == 2047 and not summary["provenance"]["tainted"]
        assert meta["weights_sha256"] == summary["weights_sha256"]
        assert digest(checkpoint / "location_head.pt") == summary["location_head_sha256"]
        assert digest(checkpoint / "tokenizer" / "tokenizer.json") == panel["tokenizer_sha256"]
        head = LocationHead().eval()
        head.load_state_dict(torch.load(checkpoint / "location_head.pt", weights_only=True))
        outputs = []
        for block in panel["blocks"]:
            scores = {}
            for key in ("normal", "permuted", "expanded", "nested"):
                cell = block[key]
                inputs = torch.tensor([row["ids"] for row in cell["queries"]])
                _, hidden = states(model, inputs)
                candidates = torch.tensor([cell["candidates"]] * 4)
                logits = head(hidden, torch.full((4,), inputs.shape[1] - 1), candidates)
                assert bool(torch.isfinite(logits).all())
                scores[key] = logits.tolist()
            outputs.append(scores)
        write(root / "evals" / f"{arm}.json", dict(seed=SEED, arm=arm, panel_sha256=digest(panel_path),
              weights_sha256=meta["weights_sha256"], location_head_sha256=summary["location_head_sha256"], rows=outputs))
        print(SEED, arm, len(outputs), flush=True)


if __name__ == "__main__":
    command, *args = sys.argv[1:]
    functions = {"panel": make_panel, "prepare": prepare, "train": train, "evaluate": evaluate}
    functions[command](*map(Path, args))
