import json
import math
import sys
from pathlib import Path

import torch
from torch.nn import functional as F

from address_fixtures import ARMS, DIM, SEEDS, code, evaluation, feature, sha_json, training

BATCH, STEPS = 16, 288
KEYS = torch.tensor([feature(i) for i in range(1 << DIM)], dtype=torch.float64)


def input_tensors(docs):
    keys = KEYS[torch.tensor([doc["keys"] for doc in docs])]
    links = KEYS[torch.tensor([doc["link"] for doc in docs])]
    root = KEYS[torch.tensor([doc["root"] for doc in docs])]
    query = torch.tensor([doc["query"] for doc in docs])
    return keys, links, root, query


def scores(matrix, keys, links, root):
    candidates = keys.transpose(1, 2)
    start = (root[:, None, :] @ matrix @ candidates).squeeze(1)
    transition = (links.flatten(1, 2) @ matrix @ candidates).unflatten(1, links.shape[1:3])
    return start, transition


def endpoint_probs(start, transition, query):
    state = start.softmax(dim=-1)
    transitions = transition.softmax(dim=-1)
    ids = torch.arange(len(state))[:, None]
    rows = torch.arange(state.shape[1])[None, :]
    for alias in query.unbind(dim=1):
        hop = transitions[ids, rows, alias[:, None]]
        state = (state[:, None, :] @ hop).squeeze(1)
    return state


def fit(initial, docs, inputs, order, mode):
    matrix = torch.nn.Parameter(initial.clone())
    opt = torch.optim.AdamW([matrix], lr=.03, weight_decay=0)
    root_targets = torch.tensor([doc["chain"][0] for doc in docs]) if mode == "direct" else None
    edge_targets = torch.tensor([doc["edge"] for doc in docs]) if mode == "direct" else None
    compatible = torch.tensor([doc["candidates"] for doc in docs])
    trajectory = []
    for batch in order:
        *scope, query = [tensor[batch] for tensor in inputs]
        start, transition = scores(matrix, *scope)
        if mode == "direct":
            loss = (F.cross_entropy(start, root_targets[batch])
                    + F.cross_entropy(transition.flatten(0, 2), edge_targets[batch].flatten())) / 2
        else:
            observed = endpoint_probs(start, transition, query).gather(1, compatible[batch]).sum(dim=1)
            loss = -observed.log().mean()
        opt.zero_grad(set_to_none=True)
        loss.backward()
        opt.step()
        trajectory.append(float(loss.detach()))
    assert len(trajectory) == STEPS and all(map(math.isfinite, trajectory))
    return matrix.detach(), trajectory


@torch.inference_mode()
def predict(matrix, docs):
    *scope, query = input_tensors(docs)
    start, move = scores(matrix, *scope)
    current = start.argmax(dim=-1)
    trace = [current]
    ids = torch.arange(len(docs))
    for alias in query.unbind(dim=1):
        current = move[ids, current, alias].argmax(dim=-1)
        trace.append(current)
    return torch.stack(trace, dim=1).tolist()


def run(output, seed):
    train, panel = training(seed), evaluation(seed)
    assert len(train) == 1536
    inputs = input_tensors(train)
    generator = torch.Generator().manual_seed(seed + 52203)
    order = [batch for _ in range(3) for batch in torch.randperm(len(train), generator=generator).split(BATCH)]
    initial = .04 * torch.randn(DIM, DIM, dtype=torch.float64, generator=generator)
    matrices = {"raw": torch.eye(DIM, dtype=torch.float64), "initial": initial}
    trajectories = {}
    with torch.no_grad():
        example = [tensor[:16] for tensor in inputs]
        p = endpoint_probs(*scores(initial, *example[:-1]), example[-1])
        assert torch.allclose(p.sum(dim=1), torch.ones(len(p), dtype=p.dtype), rtol=0, atol=1e-12)
    for mode in ("direct", "weak"):
        matrices[mode], trajectories[mode] = fit(initial, train, inputs, order, mode)
        print(seed, mode, trajectories[mode][0], trajectories[mode][-1], flush=True)
    assert tuple(matrices) == ARMS
    with output.open("x", encoding="utf-8") as stream:
        json.dump(dict(seed=seed, namespace=code(seed), train=sha_json(train), panel=sha_json(panel),
                       steps=len(order), matrices={mode: matrix.tolist() for mode, matrix in matrices.items()},
                       losses=trajectories, trace={mode: {cell: predict(matrix, docs) for cell, docs in panel.items()}
                                                   for mode, matrix in matrices.items()}),
                  stream, allow_nan=False)


if __name__ == "__main__":
    torch.set_num_threads(1)
    target, seed = sys.argv[1:]
    assert int(seed) in SEEDS
    run(Path(target), int(seed))
