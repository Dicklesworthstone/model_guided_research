# eval-tasks — small-10-point

- checkpoint: `/data/ssd/tmp/mgr-cong.g50qfshI/dqpo/control/test_checkpoint_sweeps_adjudic0/weights/small-10/checkpoints` @ step 1
- attention_type: ultrametric
- n_params: 33,024
- seeds: [0] · examples/seed: 2 · decode: ['greedy']

| task | EM in-range | EM held-out | ppl in/held | slope held-out [CI95] | curve |
|---|---|---|---|---|---|
| arith | 0.000 | 0.000 | 320.0/319.8 | - | [curve](curve_arith.png) |

See `summary.json` (schema mgr.evaltasks.v4) for the full contract output and `generations.jsonl` for per-example receipts.
