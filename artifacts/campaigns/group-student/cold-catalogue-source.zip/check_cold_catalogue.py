"""Independently check conjugacy coverage, lattice parameters and live tapes."""

import hashlib
import json
import sys
from collections import Counter
from itertools import product
from pathlib import Path

from check_four_anchor import ANCHORS, outside_action, reconstruct, rooted, strip_timing
from check_replay import follow, independently_named, load


def verify_orbits(table, points):
    states = range(len(table))
    inverse = [row.index(0) for row in table]
    commute = {(a, b) for a, b in product(states, repeat=2) if table[a][b] == table[b][a]}
    covered = set()
    generating = 0
    for a, b in points:
        orbit = {
            (table[table[g][a]][inverse[g]], table[table[g][b]][inverse[g]])
            for g in states
        }
        if (a, b) != min(orbit) or covered.intersection(orbit) or commute.intersection(orbit):
            raise ValueError("Incorrect noncommuting pair representative")
        covered.update(orbit)
        generating += rooted(table, a, b) is not None
    if len(covered) + len(commute) != len(table) ** 2:
        raise ValueError("Conjugation orbits did not cover all noncommuting pairs")
    return len(covered), len(commute), generating


def lattice_coordinates(graph):
    if graph[graph[0][0]][1] != graph[graph[0][1]][0]:
        return None
    axis = [0]
    mark = graph[0][0]
    while mark != 0:
        axis.append(mark)
        mark = graph[mark][0]
    width = len(axis)
    height = len(graph) // width
    mark = 0
    for _ in range(height):
        mark = graph[mark][1]
    return width, (-axis.index(mark)) % width, height


def check_builders(library, graphs, arms):
    noncommuting = commuting = reps = 0
    abelian_groups = 0
    if len(arms["conjugacy"]["stats"]) != len(library[2]) or len(arms["combined"]["stats"]) != len(library[2]):
        raise ValueError("Wrong count of group-table statistics")
    negative = False
    for (n, index, table), orbit, hybrid in zip(
        library[2], arms["conjugacy"]["stats"], arms["combined"]["stats"], strict=True
    ):
        is_abelian = all(table[a][b] == table[b][a] for a, b in product(range(n), repeat=2))
        if any((row["order"], row["index"], row["abelian"]) != (n, index, is_abelian) for row in (orbit, hybrid)):
            raise ValueError("Group classification disagrees")
        if is_abelian:
            abelian_groups += 1
            generating = sum(rooted(table, a, b) is not None for a, b in product(range(n), repeat=2))
            if orbit["traversals"] != n * n or orbit["generating"] != generating or hybrid["traversals"] != 0:
                raise ValueError("Wrong abelian traversal accounting")
            continue
        actual = hybrid["representatives"]
        if orbit != hybrid or hybrid["traversals"] != len(actual):
            raise ValueError("The conjugacy arms disagreed")
        expanded, rejected, generating = verify_orbits(table, actual)
        if hybrid["generating"] != generating:
            raise ValueError("Canonical orbit traversal accepted the wrong generating count")
        noncommuting += expanded
        commuting += rejected
        reps += len(actual)
        if not negative:
            try:
                verify_orbits(table, actual[1:])
            except ValueError:
                negative = True
    if not negative:
        raise ValueError("The omitted-orbit negative control escaped")
    lattice_counts = {}
    for n, shapes in graphs.items():
        coords = [lattice_coordinates(shape) for shape in shapes]
        expected = [c for c in coords if c is not None]
        declared = [tuple(c) for c in arms["combined"]["coordinates"][str(n)]]
        if sorted(expected) != sorted(declared) or len(declared) != sum(w for w in range(1, n + 1) if n % w == 0):
            raise ValueError("The lattice builder omitted, duplicated or changed an abelian rooted shape")
        lattice_counts[str(n)] = len(expected)
    for arm in ("conjugacy", "combined"):
        if arms[arm]["traversals"] != sum(row["traversals"] for row in arms[arm]["stats"]):
            raise ValueError("Traversal count does not add up")
    return dict(noncommuting_pairs=noncommuting, commuting_pairs_skipped=commuting, noncommuting_representatives=reps,
                abelian_groups=abelian_groups, lattice_counts=lattice_counts, omitted_orbit_rejected=negative)


def check_online(cohort, prior, control_manifest, library, first):
    tables = {(n, index): table for n, index, table in library[2]}
    totals = Counter()
    index = first["online"]
    for arm, lane in index.items():
        if len(lane["rows"]) != 30 or lane["indexed_words"] != prior["word_counts"]:
            raise ValueError("Wrong count of complete acquisitions or prepared words")
        for i, row in enumerate(lane["rows"]):
            if row["index"] != i:
                raise ValueError("Acquisition case changed")
            n = row["order"]
            if i < 24:
                case = load(Path(cohort) / f"{i:02}.json")
                original = list(independently_named(case))
                val = [entry[:2] for split in ("primary", "secondary") for entry in case[split]]
                if row["control"] is not None:
                    raise ValueError("Historical action replaced by a control")
            else:
                number, a, b = control_manifest["control_pairs"][str(i - 24)]
                if (n, row["control"]) != (60 if i < 27 else 120, [number, a, b]):
                    raise ValueError("Outside action changed")
                original = outside_action(tables[n, number], (a, b))
                val = []
            result = row["result"]
            if result["action"] != original or row["anchors"] != {word: follow(original, word) for word in ANCHORS}:
                raise ValueError("Incorrect exact action or anchors")
            if any(follow(original, word) != label for word, label in result["tape"]):
                raise ValueError("Incorrect oracle reply")
            if any(follow(result["action"], word) != label for word, label in val):
                raise ValueError("Wrong held-out replay")
            if strip_timing(result) != strip_timing(prior["rows"][i]["arms"]["length_first"]):
                raise ValueError(f"The {arm} cold builder changed the published rooted action or paid tape")
            paid = [*row["anchors"].items(), *result["tape"]]
            totals.update(transitions=2 * n, heldout=len(val))
            if arm == "combined":
                scope = "historical" if i < 24 else "outside"
                totals.update({scope + "_reads": len(paid), scope + "_symbols": sum(len(word) for word, _ in paid)})
    return totals


def audit(cohort, library_path, control_path, prior_path, scored_path, replay_path):
    library, control_manifest, prior, first, second = map(
        load, (library_path, control_path, prior_path, scored_path, replay_path)
    )
    if strip_timing(first) != strip_timing(second):
        raise ValueError("Hash seed or relative arm order changed a non-timing result")
    graphs = reconstruct(library)
    independent = hashlib.sha256(json.dumps(graphs, separators=(",", ":"), sort_keys=True).encode()).hexdigest()
    if first["shape_digest"] != independent or first["shape_counts"] != {str(n): len(s) for n, s in graphs.items()}:
        raise ValueError("Wrong complete rooted shape set")
    proof = check_builders(library, graphs, first["arms"])
    totals = check_online(cohort, prior, control_manifest, library, first)
    timings = []
    for sample in (first, second):
        builders = [{key: row[key] for key in ("cpu_ns", "wall_ns", "traversals", "lattice_constructions")}
                    for row in sample["arms"].values()]
        by_arm = dict(zip(sample["arms"], builders, strict=True))
        ratio = by_arm["exhaustive"]["cpu_ns"] / by_arm["combined"]["cpu_ns"]
        pipeline = {}
        for arm, online in sample["online"].items():
            pipeline[arm] = dict(
                preparation=online["prepared"],
                online_cpu_ns=sum(row["result"]["cpu_ns"] + row["anchor_timing"]["cpu_ns"] for row in online["rows"]),
                online_wall_ns=sum(row["result"]["wall_ns"] + row["anchor_timing"]["wall_ns"] for row in online["rows"]),
            )
        timings.append(dict(builders=by_arm, parsed=sample["parsed"], pipeline=pipeline, speed_ratio=ratio, gate=ratio >= 3))
    print(json.dumps(dict(
        gate=all(item["gate"] for item in timings), shapes=first["shape_counts"],
        timings=timings, proof=proof, totals=totals, cases=30,
    ), sort_keys=True))


if __name__ == "__main__":
    audit(*sys.argv[1:])
