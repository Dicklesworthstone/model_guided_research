import itertools
import json
import math
import platform
import statistics
import sys
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import compile_policy as experiment

SOURCE = "390771b00d0765dbf680d5fec9e7649aa8ea4d7f"
MANIFEST = "311d31bc4a08ba3ae2d3c486a0182b6f524cf28c81d886513004e03e968c2b69"


def replay(read, names, original):
    assert experiment.digest(read("frozen.sha256")) == MANIFEST
    for line in read("frozen.sha256").decode().splitlines():
        checksum, path = line.split()
        assert experiment.digest(read(path)) == checksum
    evidence = json.loads(read("benchmark.json"))
    assert evidence["input"] == experiment.ARCHIVE
    assert evidence["python"].startswith("3.13.") and isinstance(evidence["logical_cpu"], int)
    assert evidence["queries"] == 16384 and evidence["samples"] == 7
    panel = experiment.load_panel(original)
    actual = experiment.actual(panel)
    assert actual == evidence["actual"] and actual["documents"] == 216 and actual["tables"] == 648
    assert actual["selected"] == {"packed": 648}
    assert evidence["controls"] == experiment.controls()
    expected = list(itertools.product((8, 12, 16), experiment.FAMILIES, (81, 82)))
    actual_grid = [(row["depth"], row["family"], row["seed"]) for row in evidence["synthetic"]]
    assert expected == actual_grid
    total = 0
    fast_affine, mixed_speed, iid_guard, motif_storage = [], [], [], []
    largest = {}
    for row in evidence["synthetic"]:
        d, family, seed = row["depth"], row["family"], row["seed"]
        f = experiment.synthesize(family, d, seed)
        total += len(f)
        assert experiment.digest(f) == row["truth_sha256"]
        decoders, selected = experiment.compile_all(f, d)
        assert row["selected"] == selected
        assert {name: len(decoder.wire()) for name, decoder in decoders.items()} == row["encoded"]
        worker = evidence["machine"], evidence["python"], evidence["host"]
        if worker == (platform.machine(), platform.python_version(), platform.node()):
            assert {name: decoder.resident() for name, decoder in decoders.items()} == row["resident"]
        assert row["encoded"]["packed"] == (1 << d) // 8 + 1
        assert row["encoded"]["adaptive"] == min(row["encoded"].values())
        timing = row["paired_ns_per_lookup"]
        assert set(timing) == {"packed", "runs", "graph", "adaptive"}
        assert len(row["orders"]) == 7 and all(sorted(order) == sorted(timing) for order in row["orders"])
        for samples in timing.values():
            assert len(samples) == 7 and all(math.isfinite(t) and t > 0 for t in samples)
        ratios = {name: statistics.median(t/u for t, u in zip(timing["adaptive"], timing[name], strict=True))
                  for name in ("packed", "runs")}
        assert ratios == row["ratios"]
        relative_resident = min(row["resident"][name] for name in ("packed", "runs")) / row["resident"]["adaptive"]
        if d >= 12:
            mixed_speed.append(max(ratios.values()) <= 2)
            if family == "iid":
                iid_guard.append(selected == "packed" and ratios["packed"] <= 1.15)
        if d == 16:
            largest.setdefault(family, []).append(dict(
                seed=seed, selected=selected, wire=row["encoded"], resident=row["resident"],
                ratios=ratios, median_ns={name: statistics.median(samples) for name, samples in timing.items()},
            ))
            if family == "affine":
                fast_affine.append(relative_resident >= 16 and max(ratios.values()) <= 1.25)
            if family == "repeated_subfunction":
                motif_storage.append(relative_resident >= 8)
    assert total == 559_104 and len(fast_affine) == len(motif_storage) == 2 and len(iid_guard) == 4
    receipt_path, = (path for path in names if path.endswith("/receipt.json"))
    receipt = json.loads(read(receipt_path))
    assert receipt["status"] == "passed" and len(receipt["checks"]) == 1
    check, = receipt["checks"]
    log = str(Path(receipt_path).with_name(Path(check["log_path"]).name))
    assert experiment.digest(read(log)) == check["log_sha256"]
    return dict(source=SOURCE, score_receipt=Path(receipt_path).parent.name, synthetic_slots=total, actual=actual,
                actual_encoded_bytes=sum(2 * len(doc.split(" PATH ")[1].split(" OUT ")[0].split())
                                         for cells in panel.values() for docs in cells.values() for doc in docs),
                affine_gate=all(fast_affine), general_gate=all(mixed_speed + iid_guard + motif_storage),
                independent_fallback_passes=sum(iid_guard), independent_fallback_total=len(iid_guard),
                motif_storage_gate=all(motif_storage), large=largest)


def verify(path, original):
    with ZipFile(path) as archive:
        assert archive.testzip() is None and len(archive.namelist()) == len(set(archive.namelist()))
        result = replay(archive.read, archive.namelist(), original)
        assert result == json.loads(archive.read("decision.json"))
    print(json.dumps(result))


def bundle(root, path, original):
    files = {name: root / name for name in (
        "compile_policy.py", "recount.py", "bench.yaml", "protocol.txt", "frozen.sha256",
        "benchmark.json", "verify.py", "argument.md",
    )}
    for receipt in (root / "receipts").glob("*/*/receipt.json"):
        for name in ("receipt.json", "check-1.log", "checks-config.yaml"):
            target = receipt.with_name(name)
            files[target.relative_to(root).as_posix()] = target
    result = replay(lambda name: files[name].read_bytes(), files, original)
    with ZipFile(path, "x", compression=ZIP_DEFLATED) as archive:
        for name, target in files.items():
            archive.write(target, name)
        archive.writestr("decision.json", json.dumps(result, indent=2) + "\n")
    verify(path, original)


if __name__ == "__main__":
    mode, *args = sys.argv[1:]
    {"bundle": bundle, "verify": verify}[mode](*map(Path, args))
