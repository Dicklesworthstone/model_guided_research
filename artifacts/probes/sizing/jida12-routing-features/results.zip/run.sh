#!/bin/sh
set -eu
export PATH="/home/ubuntu/.local/bin:$PATH"
export UV_PROJECT_ENVIRONMENT=/data/ssd/tmp/mgr-eval-ci.bevt3nLW/qualified-venv PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=2 MKL_NUM_THREADS=2
export DSR_REPOS_FILE="$MGR_FEATURES/campaign.yaml" DSR_QUALITY_LOG_DIR="$MGR_FEATURES/receipts"
cd "$MGR_FEATURES"
dsr quality --tool routing-feature-panel --work-dir "$MGR_FEATURES" --check-timeout 120
set -C
sha256sum panel.json > panel.sha256
dsr quality --tool routing-feature-transfer --work-dir "$MGR_FEATURES" --check-timeout 300
