"""Score and replay exact acquisition against the audited small-order inventory."""

import argparse
import json
from pathlib import Path
from time import process_time_ns
from zipfile import ZipFile

from check_catalogue import reference_catalogue

ARCHIVE = "artifacts/probes/sizing/group-solver-baseline/catalogue-source.zip"
INVENTORY = (6, 10, 12)
ARMS = ("square", "shortlist", "frontier", "gbs", "optimal")
ANCHORS = ("00", "01", "10", "11")
READ_PRICE = 16
MAX_WORK = 300_000
CAMPAIGN = "artifacts/campaigns/group-student"


def inventory(work):
    with ZipFile(work / ARCHIVE) as archive:
        catalogue = reference_catalogue(json.loads(archive.read("catalogue.json")))
    return {order: catalogue[order] for order in INVENTORY}


def opaque_names(n, slot, reverse):
    multiplier = 19 if reverse else 17
    shift = (7 * slot + 11) if reverse else (13 * slot + 7)
    salt = "B" if reverse else "A"
    return [f"state-{salt}-{(multiplier * i + shift) % n}" for i in range(n)]


def counts(words):
    return [len(words), sum(w.count("0") for w in words), sum(w.count("1") for w in words)]


def price(charges):
    reads, zeros, ones = charges
    return READ_PRICE * reads + zeros + ones


def acquire_case(acquire, graph, names, roster, policy):
    tape = []

    def ask(word):
        state = 0
        for symbol in word:
            state = graph[symbol][state]
        reply = names[state]
        tape.append([word, reply])
        return reply

    started = process_time_ns()
    action = acquire(roster, ask, catalogue=policy)
    return {
        "tape": tape,
        "root": action.root,
        "table": action.transitions,
        "terminal": action.terminal,
        "online_ns": process_time_ns() - started,
    }


def score(work, reverse):
    from nanochat import group_acquisition as acq

    if not Path(acq.__file__).resolve().is_relative_to(work.resolve()):
        raise ValueError("Acquisition code loaded outside the frozen checkout")
    output = {"reverse": reverse, "orders": {}}
    for n, graphs in inventory(work).items():
        started = process_time_ns()
        index = acq._prepare([tuple(zip(graph["0"].values(), graph["1"].values(), strict=True)) for graph in graphs])
        index_ns = process_time_ns() - started
        metadata = {}
        cases = [{} for _ in graphs]
        for arm in reversed(ARMS) if reverse else ARMS:
            started = process_time_ns()
            policy = None
            certificate = {}
            if arm in ("shortlist", "frontier"):
                policy = acq.compile_policy(index, exhaustive_frontier=arm == "frontier")
            if arm == "gbs":
                policy = acq.compile_gbs_policy(index, read_price=READ_PRICE)
            if arm == "optimal":
                try:
                    plan = acq.compile_optimal_policy(index, read_price=READ_PRICE, max_work=MAX_WORK)
                except acq.PlanningBudgetExceeded as error:
                    metadata[arm] = {"exhausted": str(error), "compile_ns": process_time_ns() - started}
                    continue
                policy = plan.policy
                certificate = {"work": plan.work, "cost": plan.total_cost}
            metadata[arm] = {"compile_ns": process_time_ns() - started, **certificate}
            slots = range(len(graphs) - 1, -1, -1) if reverse else range(len(graphs))
            for slot in slots:
                graph = graphs[slot]
                names = opaque_names(n, slot, reverse)
                roster = names[1:] + names[:1] if reverse else names[::-1]
                cases[slot][arm] = acquire_case(acq.acquire, graph, names, roster, policy)
        output["orders"][str(n)] = {"index_ns": index_ns, "arms": metadata, "cases": cases}
    return output


def verify(run, graphs_by_order, reverse):
    if run["reverse"] is not reverse or set(run["orders"]) != set(map(str, INVENTORY)):
        raise ValueError("Wrong replay arm or inventory")
    for n, graphs in graphs_by_order.items():
        entry = run["orders"][str(n)]
        if len(entry["cases"]) != len(graphs) or set(entry["arms"]) != set(ARMS):
            raise ValueError("Incomplete order panel")
        exhausted = "exhausted" in entry["arms"]["optimal"]
        if exhausted and entry["arms"]["optimal"]["exhausted"] != f"Optimal planning exhausted {MAX_WORK} work units":
            raise ValueError("Wrong exhaustion boundary")
        expected_arms = set(ARMS[:-1] if exhausted else ARMS)
        for slot, (case, graph) in enumerate(zip(entry["cases"], graphs, strict=True)):
            names = opaque_names(n, slot, reverse)
            expected = {names[state]: [names[graph["0"][state]], names[graph["1"][state]]] for state in range(n)}
            if set(case) != expected_arms:
                raise ValueError("Incomplete case arms")
            for arm, row in case.items():
                if row["root"] != names[0] or row["table"] != expected:
                    raise ValueError(f"Wrong action at order {n}, slot {slot}, arm {arm}")
                if row["terminal"] != ("square" if arm == "square" else "unique"):
                    raise ValueError("Unexpected terminal")
                words = [word for word, _ in row["tape"]]
                if (
                    words[:4] != list(ANCHORS)
                    or len(set(words)) != len(words)
                    or any(len(word) < 2 or set(word) - {"0", "1"} for word in words)
                ):
                    raise ValueError("Invalid paid query tape")
                for word, reply in row["tape"]:
                    target = row["root"]
                    for mark in word:
                        target = expected[target][int(mark)]
                    if reply != target:
                        raise ValueError("Incorrect endpoint on paid tape")
                row["words"] = words
                row["charges"] = counts(words)


def summary(work, forward, replay):
    graphs_by_order = inventory(work)
    verify(forward, graphs_by_order, False)
    verify(replay, graphs_by_order, True)
    with ZipFile(work / CAMPAIGN / "optimal-initial-results.zip") as archive:
        old_exact = json.loads(archive.read("verified.json"))["orders"]["6"]["arms"]["optimal"]["cost"]
    with ZipFile(work / CAMPAIGN / "classical-gbs-results.zip") as archive:
        prior = json.loads(archive.read("scored.json"))["orders"]
    with ZipFile(work / CAMPAIGN / "upper-budget-six-reply-bound.zip") as archive:
        naming = json.loads(archive.read("anchor-floors.json"))
    output = {"checked_acquisitions": 0, "matched_control_tapes": 0, "orders": {}, "preregistered_gap": False}
    primary_solved = True
    strict_gap = False
    for n, graphs in graphs_by_order.items():
        a, b = (run["orders"][str(n)] for run in (forward, replay))
        order = {
            "shapes": len(graphs),
            "index_ns": [a["index_ns"], b["index_ns"]],
            "arms": {},
            "optimal_vs": {},
        }
        output["orders"][str(n)] = order
        for arm in ARMS:
            left, right = a["arms"][arm], b["arms"][arm]
            for key in ("exhausted", "work", "cost"):
                if left.get(key) != right.get(key):
                    raise ValueError(f"Planning result changed on replay at order {n}, arm {arm}")
            result = {"compile_ns": [left["compile_ns"], right["compile_ns"]]}
            order["arms"][arm] = result
            if "exhausted" in left:
                result["exhausted"] = left["exhausted"]
                if n in INVENTORY[:2]:
                    primary_solved = False
                continue
            first = [case[arm] for case in a["cases"]]
            second = [case[arm] for case in b["cases"]]
            if [row["words"] for row in first] != [row["words"] for row in second]:
                raise ValueError(f"Paid policy changed on replay at order {n}, arm {arm}")
            if arm != "optimal":
                archived = [case[arm]["tape"] for case in prior[str(n)]["cases"]]
                if archived != [row["tape"] for row in first]:
                    raise ValueError(f"Control differs from its archived tape, order {n}, arm {arm}")
                output["matched_control_tapes"] += len(first)
            output["checked_acquisitions"] += len(first) + len(second)
            result["charges"] = list(map(sum, zip(*(row["charges"] for row in first), strict=True)))
            result["cost"] = price(result["charges"])
            result["online_ns"] = [sum(row["online_ns"] for row in rows) for rows in (first, second)]
            if arm == "optimal":
                if left["cost"] != result["cost"] or not 0 < left["work"] <= MAX_WORK:
                    raise ValueError("Planner objective differs from the independently recounted tapes")
                result["work"] = left["work"]
                if result["cost"] < naming[str(n)]["strongest_floor"]:
                    raise ValueError("Exact policy beat the multi-reply lower bound")
                if n == 6 and result["cost"] != old_exact:
                    raise ValueError("Order-six minimum changed")
        if "exhausted" in order["arms"]["optimal"]:
            continue
        for control in ARMS[:-1]:
            deltas = [price(case["optimal"]["charges"]) - price(case[control]["charges"]) for case in a["cases"]]
            order["optimal_vs"][control] = {
                "cost_delta": sum(deltas),
                "cheaper": sum(delta < 0 for delta in deltas),
                "tied": deltas.count(0),
                "dearer": sum(delta > 0 for delta in deltas),
                "reads_increased": sum(
                    case["optimal"]["charges"][0] > case[control]["charges"][0] for case in a["cases"]
                ),
                "commands_increased": sum(
                    sum(case["optimal"]["charges"][1:]) > sum(case[control]["charges"][1:]) for case in a["cases"]
                ),
            }
            if sum(deltas) > 0:
                raise ValueError(f"An exact optimum was exceeded by live {control} at order {n}")
            if n in INVENTORY[:2] and control in ("shortlist", "frontier") and sum(deltas) < 0:
                strict_gap = True
    output["preregistered_gap"] = primary_solved and strict_gap
    return output


def main():
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    run = sub.add_parser("score")
    run.add_argument("work", type=Path)
    run.add_argument("output", type=Path)
    run.add_argument("--reverse", action="store_true")
    check = sub.add_parser("summary")
    check.add_argument("work", type=Path)
    check.add_argument("forward", type=Path)
    check.add_argument("replay", type=Path)
    args = parser.parse_args()
    if args.command == "score":
        with args.output.open("x", encoding="utf-8") as out:
            json.dump(score(args.work, args.reverse), out, sort_keys=True, separators=(",", ":"))
    else:
        first = json.loads(args.forward.read_text(encoding="utf-8"))
        second = json.loads(args.replay.read_text(encoding="utf-8"))
        print(json.dumps(summary(args.work, first, second), indent=2))


if __name__ == "__main__":
    main()
