"""Construct alternatives from saved SAT models without solving or querying."""

import json
from itertools import product
from pathlib import Path

from verify import witness_endpoint


def first_unseen_word(model, unseen, size):
    for length in range(3, size + 3):
        for symbols in product("01", repeat=length):
            state = model["root"]
            for symbol in symbols:
                state = model["R" + symbol][state]
            if state in unseen:
                return "".join(symbols), state
    raise ValueError("No path from a public anchor to an unseen label")


def construct(case):
    initial = case["initial"]
    names = sorted(case["names"])
    event = case["arms"]["active"]["events"][0]
    model = event["first"]
    unseen = set(range(len(names))) - {names.index(name) for name in initial.values()}
    word, a = first_unseen_word(model, unseen, len(names))
    b = min(unseen - {a})
    swap = list(range(len(names)))
    swap[a], swap[b] = b, a
    other: dict[str, int | list[int]] = {"root": swap[model["root"]]}
    for key in ("R0", "R1", "L0", "L1"):
        other[key] = [swap[model[key][swap[state]]] for state in range(len(names))]
    first_endpoint = witness_endpoint(model, names, initial, word)
    other_endpoint = witness_endpoint(other, names, initial, word)
    if (first_endpoint, other_endpoint) != (names[a], names[b]) or word in initial:
        raise ValueError("The unseen-label swap did not distinguish the models")
    return {
        "case": case["family"],
        "word": word,
        "previous_solver_result": event["alternative"]["status"],
        "predictions": [first_endpoint, other_endpoint],
        "alternative": other,
    }


if __name__ == "__main__":
    record = json.loads(Path("scored.json").read_text(encoding="utf-8"))
    rows = [construct(case) for case in record["cases"] if not case["exhausted"]]
    if rows[-1]["previous_solver_result"] != "unknown":
        raise ValueError("Frozen exhausted alternative case is missing")
    print(json.dumps({"extra_oracle_reads": 0, "extra_solver_checks": 0, "witnesses": rows}, indent=2))
