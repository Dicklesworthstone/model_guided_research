import hashlib
import json
import sys
from zipfile import ZipFile


DEPTHS = {"in_range": 2, "held_out": 3, "terminal_change": 2}
SEEDS = {"in_range": (40, 41, 44), "held_out": (40, 41, 44), "terminal_change": (50, 51, 52)}
ARMS = ("detached", "joint")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def recount(rows, panel):
    positions, values, greedy = [], [], []
    for row, case in zip(rows, panel, strict=True):
        assert (row["seed"], row["pair_index"]) == (case["seed"], case["pair_index"])
        assert len(row["queries"]) == 2
        for index, query in enumerate(row["queries"]):
            actual, probe = query["actual_leaf"], query["predicted_leaf"]
            assert actual == case["labels"][index] and 0 <= probe < len(case["leaves"])
            assert query["actual_token_position"] == case["candidates"][actual]
            assert query["predicted_token_position"] == case["candidates"][probe]
            assert query["expected"] == case["leaves"][actual]["value"]
            assert query["position_value"] == case["leaves"][probe]["value"]
            expected = query["expected"].split()
            correct = query["greedy_reply"].split()[:len(expected)] == expected
            assert query["greedy_correct"] == correct
            positions.append(actual == probe)
            values.append(query["expected"] == query["position_value"])
            greedy.append(correct)
    return dict(
        pairs=len(rows),
        both_positions=sum(a and b for a, b in zip(positions[::2], positions[1::2], strict=True)),
        both_pointed_values=sum(a and b for a, b in zip(values[::2], values[1::2], strict=True)),
        both_greedy=sum(a and b for a, b in zip(greedy[::2], greedy[1::2], strict=True)),
        single_positions=sum(positions),
        single_greedy=sum(greedy),
    )


with ZipFile(sys.argv[1]) as archive:
    assert archive.testzip() is None
    names = archive.namelist()
    assert len(names) == len(set(names))
    assert not any(name.endswith((".pt", ".parquet", ".safetensors")) for name in names)

    def load(path):
        return json.loads(archive.read(path))

    decision = load("decision.json")
    assert decision["training_pairs"] == 3 and set(decision["per_seed"]) == {"30", "31", "32"}
    assert decision["panel_sha256"] == sha(archive.read("panel.json"))
    assert decision["script_sha256"] == sha(archive.read("replay/leaf_position.py"))
    assert decision["source_revision"] == "fb0fe89a34cddd43285903d497e0c9b0a4e4cdb1"
    tokenizer_hash = sha(archive.read("tokenizer.json"))
    panel = load("panel.json")
    assert set(panel) == set(DEPTHS)
    trees = set()
    panel_audit = {}
    for region, cases in panel.items():
        assert [(c["seed"], c["pair_index"]) for c in cases] == [(s, i) for s in SEEDS[region] for i in range(12)]
        first_leaf_both = 0
        for case in cases:
            first, second = [doc.split(" PATH ", 1) for doc in case["documents"]]
            tree = first[0]
            assert tree == second[0] and tree not in trees
            trees.add(tree)
            left, right = [case["leaves"][label] for label in case["labels"]]
            assert left["value"] != right["value"]
            assert f'{" ".join(left["path"])} OUT {left["value"]}' == first[1]
            assert f'{" ".join(right["path"])} OUT {right["value"]}' == second[1]
            assert len(left["path"]) == len(right["path"]) == DEPTHS[region]
            if region == "terminal_change":
                assert left["path"][0] == right["path"][0] and left["path"][1:] != right["path"][1:]
            else:
                assert left["path"][0] != right["path"][0] and left["path"][1:] == right["path"][1:]
            query_left, query_right = case["query"]
            assert query_left == query_right and all(position < query_left for position in case["candidates"])
            # Post-registration panel audit. This rule reads only the root key from the question.
            predicted = [
                next(index for index, leaf in enumerate(case["leaves"]) if leaf["path"][0] == query.split()[0])
                for query in (first[1], second[1])
            ]
            first_leaf_both += predicted == case["labels"]
        counts = [len(case["leaves"]) for case in cases]
        prompts = [case["query"][0] + 1 for case in cases]
        panel_audit[region] = dict(first_leaf_in_queried_root_branch_both=first_leaf_both,
                                   candidate_count_range=[min(counts), max(counts)],
                                   prompt_tokens_range=[min(prompts), max(prompts)])
    assert len(trees) == 108
    for seed, result in decision["per_seed"].items():
        prefix = f"seed-{seed}"
        preflight = load(f"{prefix}/preflight.json")
        assert preflight["unique_current_trees"] == 32108 and preflight["previous_eval_trees"] == 216
        assert preflight["oracle_both"] == dict.fromkeys(DEPTHS, 36)
        assert preflight["deterministic_shared_path_only_both"] == dict.fromkeys(DEPTHS, 0)
        trial = preflight["positive_control"]
        assert trial["causal_max_score_delta"] <= 1e-5
        assert trial["detached_hidden_grad_norm"] == 0 < trial["joint_hidden_grad_norm"]
        assert trial["identical_position_head_gradients"]
        assert preflight["tokenizer_sha256"] == tokenizer_hash
        for arm in ARMS:
            evaluated = load(f"{prefix}/evals/{arm}/summary.json")
            assert set(evaluated["regions"]) == set(DEPTHS)
            evidence = result["checkpoint_hashes"][arm]
            assert evidence["model_sha256"] == evaluated["weights_sha256"]
            assert evidence["head_sha256"] == evaluated["location_head_sha256"]
            for region, scored in evaluated["regions"].items():
                observed = recount(scored["rows"], panel[region])
                assert observed == {key: value for key, value in scored.items() if key != "rows"}
                assert observed == result["metrics"][arm][region]
        detached, joint = (result["metrics"][arm]["in_range"]["both_positions"] for arm in ARMS)
        assert result["criteria"] == dict(joint_at_least_18=joint >= 18, gain_at_least_9=joint - detached >= 9)
        assert result["pass_gate"] == all(result["criteria"].values())
        receipts = [name for name in names if name.startswith(f"{prefix}/receipts/") and name.endswith("/receipt.json")]
        assert len(receipts) == 4
        assert sorted(path.split("/")[-2] for path in receipts) == sorted(result["receipt_ids"])
        for receipt in receipts:
            report = load(receipt)
            assert report["status"] == "passed"
            for check in report["checks"]:
                log = receipt.removesuffix("receipt.json") + check["log_path"].rsplit("/", 1)[-1]
                assert sha(archive.read(log)) == check["log_sha256"]
    assert decision["replication_pass"] == all(seed["pass_gate"] for seed in decision["per_seed"].values())
    print(json.dumps(dict(decision=decision, post_registration_panel_audit=panel_audit)))
