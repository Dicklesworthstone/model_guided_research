"""Verify the inputs, recount all raw answers, and apply the registered screen."""
from collections import Counter
from math import ceil, isclose
from pathlib import Path
import json
import sys

sizing = Path(sys.argv[1])
source = "5dce958e2cb119015937e7ca756ebcdde8b347d2"
rows = []
for name, lr, layers, width, batch in (
    ("lr4x", .0024, 2, 64, 4), ("lr025x", .00015, 2, 64, 4),
    ("d128l4", .0006, 4, 128, 4), ("batch16", .0006, 2, 64, 16)
):
    stem = name + "-s0"
    run = json.loads((sizing / "copyops-lrprobe/nanochat" / stem / "summary.json").read_bytes())
    folder = sizing / "copyops-lrprobe-evals/evals/tasks" / stem
    ev = json.loads((folder / "summary.json").read_bytes())
    assert ev["schema_version"] == "mgr.evaltasks.v4" and ev["meta"]["checkpoint"]["lineage"]["run_id"] == stem
    assert ev["tasks"]["copyops"]["skipped_too_long"] == 0
    assert ev["meta"]["examples_per_seed"] == 48 and ev["meta"]["seeds"] == [0, 1, 2]
    for prov in (run["provenance"], ev["provenance"], ev["train_provenance"]):
        assert prov["git_sha"] == source and prov["tainted"] is False and prov["git_dirty"] is False
    cfg = run["config"]
    assert [cfg[k] for k in ("n_layer","n_embd","n_head","n_kv_head","sequence_len")] == [layers,width,4,2,64]
    assert run["budget"]["target_flops"] == 1e12 and run["budget"]["tokens_per_step_global"] == batch * 64
    assert run["hparams"]["learning_rate"] == lr and run["hparams"]["data_shuffle"] == "epoch"
    argv = run["meta"]["argv"]
    for arg, expected in (("--seed","0"),("--optimizer-type","adamw"),("--tokenizer","task")):
        assert argv[argv.index(arg) + 1] == expected
    records = [r for r in map(json.loads, (folder / "generations.jsonl").read_bytes().splitlines()) if r["mode"]=="greedy"]
    assert len(records) == 288
    result = dict(variant=name, training_seed=0, learning_rate=lr, layers=layers, width=width,
                  batch_size=batch, updates=run["budget"]["max_steps"])
    for region in ("in_range","held_out"):
        n = correct = prior = 0
        for seed in range(3):
            obs = [r for r in records if r["region"] == region and r["eval_seed"] == seed]
            assert {r["doc_index"] for r in obs} == set(range(48)) and len(obs) == 48
            for r in obs:
                expected = r["expected"].split()
                exact = r["got"].split()[:len(expected)] == expected
                assert exact == r["correct"]
                correct += exact
            n += len(obs)
            prior += max(Counter(r["expected"] for r in obs).values())
        task = ev["tasks"]["copyops"]
        assert isclose(correct/n, task["exact_match"]["greedy"][region]["mean"])
        assert isclose(prior/n, task["answer_prior"][region]["mean"])
        result[region] = dict(n=n, correct=correct, prior=prior)
    held = result["held_out"]
    needed = ceil(held["prior"] + 0.10 * held["n"])
    result.update(needed=needed, selected_candidate=held["correct"] >= needed)
    rows.append(result)
receipt = json.loads((sizing / "copyops-lrprobe/dsr-receipt.json").read_bytes())
assert receipt["total"] == receipt["executed"] == receipt["passed"] == 5 and receipt["status"] == "passed"
print(json.dumps(dict(source=source, rows=rows), indent=2))
