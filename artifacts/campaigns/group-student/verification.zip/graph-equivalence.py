"""Maintenance probe for launch overhead on the exact registered student model."""
import time
import torch
from scripts.group_student_probe import GPT, BATCH, TRAIN_WIDTH, config, schedule, state_digest

device = torch.device("cuda")
torch.manual_seed(551201)
x = torch.randint(0, 125, (96, BATCH, TRAIN_WIDTH), device=device)
y = torch.full_like(x, -1)
y[..., -1] = torch.randint(0, 60, (96, BATCH), device=device)
reference = None
for use_graph in (False, True):
    torch.manual_seed(551202)
    model = GPT(config())
    model.init_weights()
    model.to(device)
    optim = torch.optim.AdamW(model.parameters(), lr=0.001, weight_decay=0.01, fused=True)
    graph = torch.cuda.CUDAGraph() if use_graph else None
    gx, gy = torch.empty_like(x[0]), torch.empty_like(y[0])
    losses = []
    torch.cuda.synchronize()
    t0 = time.perf_counter()
    for step in range(len(x)):
        optim.param_groups[0]["lr"] = schedule(step)
        if graph is None or step < 3:
            optim.zero_grad(set_to_none=True)
            with torch.autocast("cuda", dtype=torch.bfloat16):
                loss = model(x[step], targets=y[step])
            loss.backward()
        else:
            gx.copy_(x[step])
            gy.copy_(y[step])
            if step == 3:
                optim.zero_grad(set_to_none=True)
                with torch.cuda.graph(graph):
                    with torch.autocast("cuda", dtype=torch.bfloat16):
                        graph_loss = model(gx, targets=gy)
                    graph_loss.backward()
            graph.replay()
            loss = graph_loss
        optim.step()
        losses.append(loss.detach().clone())
    torch.cuda.synchronize()
    seconds = time.perf_counter() - t0
    digest = state_digest(model)
    sequence = torch.stack(losses).cpu()
    print("graph", use_graph, "seconds", seconds, "state", digest, flush=True)
    if reference is not None:
        assert digest == reference[0] and torch.equal(sequence, reference[1])
    reference = (digest, sequence)
