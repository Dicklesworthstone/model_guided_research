# Route Observatory Report (`mgr.bench.routes.v2`)

- **Mechanism**: `tropical`
- **Task**: `hier`
- **Checkpoint**: `/private/tmp/mgr-jida44-consumer.x8L7T1AV/runs/joined/training/baseline/nanochat/native-23/checkpoints` (step `1`)
- **Samples**: `8` (seed `42`)
- **Brute-force cross-check verified**: `True`

## 1. Route Reuse & Consolidation

- **Route entropy (bits)**: `3.3278` (first `3.3278` -> last `3.3278`, delta `0.0000`)
- **Program reuse ratio**: `0.3125` (first `0.3125` -> last `0.3125`, delta `0.0000`)
- **Top-5 program share**: `0.6250`

## 2. Perturbation & Paraphrase Stability (`vdc.1` Probe Spec)

- **Probe spec**: `vdc.1-linf-embedding-v1` (`default_eps=0.05`)
- **Margin aggregation**: `min` (tightest decision along route)
- **Spearman rho(gamma_min, stability)**: `unavailable`
- **Unchanged perturbation draws**: 13 / 64
- **Mean perturbation stability**: `0.2031`
- **Mean paraphrase stability**: `0.9297` (8 measured)

## 3. Unsupervised Trace Clustering vs Attention-Entropy Baseline

- **Latent task classes (`K=2`)**: `['2', '3']`
- **Trace clustering ARI**: `-0.1429`
- **Attention-entropy baseline ARI**: `-0.1034`
- **Prompt-only control ARI**: `1.0000`
- **ARI gain (trace - baseline)**: `-0.0394`
