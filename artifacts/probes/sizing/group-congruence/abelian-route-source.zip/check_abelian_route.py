"""Freeze a new panel and verify exact lattice recovery from its paid tape."""

import argparse
import copy
import hashlib
import json
import random
from collections import Counter, deque
from itertools import product
from pathlib import Path

from check_short_certificate import action, checksum, elements, prior_ids, read, validate_tape

SIZE = 120
SEED = 251747
FAMILIES = ("c120", "c60xc2", "s5", "a5xc2")
ABELIAN = FAMILIES[:2]
LATTICES = [(w, s, SIZE // w) for w in range(1, SIZE + 1) if SIZE % w == 0 for s in range(w)]
ARMS = ("fallback", "edge", "short", "routed")


def c60_action(marks):
    states = [(0, 0)]
    indices = {(0, 0): 0}
    edges = []
    cursor = 0
    while cursor < len(states):
        row, col = states[cursor]
        targets = [((row + a) % 60, (col + b) % 2) for a, b in marks]
        for state in targets:
            if state not in indices:
                indices[state] = len(states)
                states.append(state)
        edges.append([indices[state] for state in targets])
        cursor += 1
    return edges


def family_graph(family, marks):
    return c60_action(marks) if family == "c60xc2" else action(family, marks)[0]


def excluded_ids(prior, earlier, latest):
    return prior_ids(prior, earlier) | {case["graph_sha"] for case in read(latest)["cases"]}


def cover(prior, earlier, latest, output):
    excluded = excluded_ids(prior, earlier, latest)
    rng = random.Random(SEED)
    cases = []
    for family in FAMILIES:
        pool = list(product(range(60), range(2))) if family == "c60xc2" else elements(family)
        count = 0
        for _ in range(10000):
            marks = (rng.choice(pool), rng.choice(pool))
            graph = family_graph(family, marks)
            digest = checksum(graph)
            if len(graph) != SIZE or digest in excluded:
                continue
            excluded.add(digest)
            cases.append(dict(family=family, marks=marks, graph=graph, graph_sha=digest))
            count += 1
            if count == 6:
                break
        if count != 6:
            raise ValueError(f"Insufficient fresh marked actions for {family}")
    with output.open("x", encoding="utf-8") as handle:
        json.dump(dict(seed=SEED, cases=cases), handle, sort_keys=True)
        handle.write("\n")


def endpoint(lattice, word):
    width, shift, height = lattice
    wraps, y = divmod(word.count("1"), height)
    return (word.count("0") - wraps * shift) % width, y


def reference_table(lattice):
    root = endpoint(lattice, "")
    queue = deque([""])
    index = {root: 0}
    result = []
    while queue:
        prefix = queue.popleft()
        row = []
        for mark in "01":
            word = prefix + mark
            target = endpoint(lattice, word)
            if target not in index:
                index[target] = len(index)
                queue.append(word)
            row.append(index[target])
        result.append(row)
    return result


def infer_from_tape(tape):
    if tape[0] != ["01", "10", True]:
        raise ValueError("No positive paid commutation reply")
    live = LATTICES
    for left, right, answer in tape:
        live = [item for item in live if (endpoint(item, left) == endpoint(item, right)) == answer]
    if len(live) != 1:
        raise ValueError("The equality tape does not identify one lattice")
    return live[0]


def untimed(record):
    result = copy.deepcopy(record)
    del result["common_cpu_ns"], result["short_cpu_ns"]
    for case in result["results"]:
        for arm in case["arms"].values():
            del arm["cpu_ns"]
    return result


def finite_census():
    from scripts.group_student_probe import _acquire_commuting_action

    shapes = set()
    max_calls = max_symbols = wrong = 0
    for expected in LATTICES:
        paid = [["01", "10", endpoint(expected, "01") == endpoint(expected, "10")]]

        def equal(left, right, target=expected, tape=paid):
            answer = endpoint(target, left) == endpoint(target, right)
            tape.append([left, right, answer])
            return answer

        result = _acquire_commuting_action(SIZE, equal)
        truth = reference_table(expected)
        if (infer_from_tape(paid) != expected or result["lattice"] != expected
                or list(map(list, result["right"])) != truth):
            raise ValueError("The direct learner disagrees with the complete abelian model")
        shapes.add(checksum(truth))
        max_calls = max(max_calls, len(paid))
        max_symbols = max(max_symbols, sum(len(a) + len(b) for a, b, _ in paid))
        w, s, h = expected
        for alternative in LATTICES:
            axioms = endpoint(alternative, "0" * w) == (0, 0) and endpoint(alternative, "0" * s + "1" * h) == (0, 0)
            if axioms != (alternative == expected):
                raise ValueError("The two lattice equations failed to distinguish a wrong shape")
            wrong += not axioms
    if len(shapes) != 360 or max_calls > 15:
        raise ValueError("Missing lattice forms or exceeded the finite call bound")
    return dict(shapes=len(shapes), maximum_calls=max_calls, maximum_symbols=max_symbols, wrong_certificates_rejected=wrong)


def audit_panel(coverage, prior, earlier, latest, scored, replay, default):
    manifest, current, repeat, old = map(read, (coverage, scored, replay, default))
    if untimed(current) != untimed(repeat):
        raise ValueError("The routed run changed outside timings on replay")
    former = untimed(current)
    for row in former["results"]:
        del row["arms"]["routed"]
    if former != untimed(old):
        raise ValueError("The default proposal command changed existing behavior")
    if (manifest["seed"] != SEED or [c["family"] for c in manifest["cases"]] != [f for f in FAMILIES for _ in range(6)]
            or current["coverage_sha256"] != hashlib.sha256(coverage.read_bytes()).hexdigest()):
        raise ValueError("Unexpected certification panel")

    banned = excluded_ids(prior, earlier, latest)
    totals = {family: {arm: Counter() for arm in ARMS} for family in FAMILIES}
    calls_by_case = []
    for case, row in zip(manifest["cases"], current["results"], strict=True):
        family = case["family"]
        graph = family_graph(family, case["marks"])
        identifier = checksum(graph)
        if (len(graph) != SIZE or graph != case["graph"] or identifier in banned
                or (identifier, family) != (row["graph_sha"], row["family"]) or identifier != case["graph_sha"]):
            raise ValueError("Wrong, repeated, or spent case")
        banned.add(identifier)
        arms = row["arms"]
        if set(arms) != set(ARMS):
            raise ValueError("Incomplete comparison")
        for arm, result in arms.items():
            if result["right"] != graph:
                raise ValueError("Wrong recovered action")
            validate_tape(graph, result["paid"])
            totals[family][arm].update(
                calls=len(result["paid"]), symbols=sum(len(a) + len(b) for a, b, _ in result["paid"]),
                cpu_ns=result["cpu_ns"],
            )
        routed = arms["routed"]
        paid = routed["paid"]
        if family in ABELIAN:
            hypothesis = infer_from_tape(paid)
            if list(hypothesis) != routed["lattice"] or reference_table(hypothesis) != graph or len(paid) > 15:
                raise ValueError("The charged tape did not prove the returned lattice")
        else:
            short = dict(arms["short"])
            del short["cpu_ns"]
            tail = dict(routed)
            del tail["cpu_ns"]
            tail["paid"] = paid[1:]
            if paid[0] != ["01", "10", False] or tail != short:
                raise ValueError("A negative commutation test changed the original short path")
        calls_by_case.append(dict(family=family, routed=len(paid), short=len(arms["short"]["paid"])))

    forged = copy.deepcopy(current["results"][0]["arms"]["routed"]["paid"])
    forged[0][2] = False
    try:
        infer_from_tape(forged)
    except ValueError:
        pass
    else:
        raise ValueError("The auditor accepted a forged commutation result")
    combined = {arm: sum(totals[family][arm]["calls"] for family in ABELIAN) for arm in ARMS}
    print(json.dumps({
        "exact_replay": True, "default_unchanged": True, "forged_commutation_rejected": True,
        "checked_transitions": 24 * SIZE * 2 * len(ARMS),
        "eighty_percent_gate": 5 * combined["routed"] <= combined["short"],
        "abelian_calls": combined, "totals": totals, "calls_by_case": calls_by_case,
        "census": finite_census(),
    }, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    modes = parser.add_subparsers(dest="mode", required=True)
    preflight = modes.add_parser("cover")
    audit = modes.add_parser("audit")
    for mode in (preflight, audit):
        for name in ("prior", "earlier", "latest", "coverage"):
            mode.add_argument(name, type=Path)
    for name in ("scored", "replay", "default"):
        audit.add_argument(name, type=Path)
    args = parser.parse_args()
    if args.mode == "cover":
        cover(args.prior, args.earlier, args.latest, args.coverage)
    else:
        audit_panel(args.coverage, args.prior, args.earlier, args.latest, args.scored, args.replay, args.default)
