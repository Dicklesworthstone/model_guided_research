import itertools
import json
import math
import platform
import statistics
import sys
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import project_policy as project
from compile_policy import digest

SOURCE = "08df1f383876f5a2ec1af6ea5e74d2c85d9da2fd"
MANIFEST = "572f7666afc97f5e528111893ee2d613e240e7088778fbdeb15fb27de62098ce"


def replay(read, names):
    raw = json.loads(read("project-benchmark.json"))
    assert raw["python"].startswith("3.13.") and raw["queries"] == 16384 and raw["samples"] == 7
    assert raw["controls"] == {"single_off_window_flip_rejected": True}
    lock = read("project.sha256")
    assert digest(lock) == MANIFEST
    for line in lock.decode().splitlines():
        sha, path = line.split()
        assert digest(read(path)) == sha
    grid = [(row["depth"], row["family"], row["seed"]) for row in raw["rows"]]
    assert grid == list(itertools.product(project.DEPTHS, project.FAMILIES, project.SEEDS))
    totals = 0
    contiguous_checks, large_checks, control_checks, summary = [], [], [], []
    runtime_match = (raw["host"], raw["machine"], raw["python"]) == (
        platform.node(), platform.machine(), platform.python_version()
    )
    for row in raw["rows"]:
        depth, family, seed = row["depth"], row["family"], row["seed"]
        f = project.synthesize(family, depth, seed)
        assert digest(f) == row["truth"]
        totals += len(f)
        actual_support = []
        for bit in range(depth):
            direction = 1 << bit
            if any(value != f[x ^ direction] for x, value in enumerate(f)):
                actual_support.append(bit)
        assert row["support"] == actual_support
        matched, active, prior, selected = project.compile_projection(f, depth)
        assert (active, prior, selected) == (actual_support, row["before"], row["selected"])
        assert {name: len(arm.wire()) for name, arm in matched.items()} == row["wire"]
        if runtime_match:
            assert {name: arm.resident() for name, arm in matched.items()} == row["resident"]
        samples = row["samples"]
        assert set(samples) == {"packed", "runs", "incumbent", "projected"}
        assert len(row["orders"]) == 7 and all(sorted(order) == sorted(samples) for order in row["orders"])
        assert all(len(series) == 7 and all(math.isfinite(t) and t > 0 for t in series) for series in samples.values())
        ratios = {name: statistics.median(t/u for t, u in zip(samples["projected"], samples[name], strict=True))
                  for name in ("packed", "runs", "incumbent")}
        assert ratios == row["ratios"]
        if family == "iid":
            assert len(active) == depth
        else:
            assert len(active) == 8
        if family in ("low", "middle", "high"):
            assert active == list(range(active[0], active[0] + 8))
            contiguous_checks.append(selected == "projection" and ratios["packed"] <= 1.60)
            if depth == 16:
                large_checks.append(row["wire"]["projected"] <= 40 and
                                    row["resident"]["packed"] >= 32 * row["resident"]["projected"] and
                                    ratios["incumbent"] <= (1 / 1.5))
            summary.append({k: row[k] for k in ("depth", "family", "seed", "wire", "resident", "ratios", "before")})
        else:
            assert active[0] == 0 and active[-1] == depth - 1
            control_checks.append(matched["incumbent"].wire() == matched["projected"].wire())
    assert totals == 696_320 and len(contiguous_checks) == 12 and len(large_checks) == 6 and len(control_checks) == 8
    path, = (path for path in names if path.endswith("/receipt.json"))
    receipt = json.loads(read(path))
    assert receipt["status"] == "passed" and len(receipt["checks"]) == 1
    check, = receipt["checks"]
    log = str(Path(path).with_name(Path(check["log_path"]).name))
    assert digest(read(log)) == check["log_sha256"]
    return dict(source=SOURCE, score_receipt=Path(path).parent.name, verified_slots=totals,
                gate=all(contiguous_checks + large_checks + control_checks), contiguous_pass=sum(contiguous_checks),
                large_pass=sum(large_checks), controls_pass=sum(control_checks), contiguous=summary)


def verify(path):
    with ZipFile(path) as archive:
        assert archive.testzip() is None and len(archive.namelist()) == len(set(archive.namelist()))
        result = replay(archive.read, archive.namelist())
        assert result == json.loads(archive.read("decision.json"))
    print(json.dumps(result))


def bundle(root, path):
    files = {name: root / name for name in (
        "compile_policy.py", "recount.py", "project_policy.py", "project.yaml", "project.sha256",
        "project-protocol.txt", "project-benchmark.json", "project_verify.py", "support.md",
    )}
    for receipt in (root / "project-receipts").glob("*/*/receipt.json"):
        for name in ("receipt.json", "check-1.log", "checks-config.yaml"):
            target = receipt.with_name(name)
            files[target.relative_to(root).as_posix()] = target
    result = replay(lambda name: files[name].read_bytes(), files.keys())
    with ZipFile(path, "x", compression=ZIP_DEFLATED) as archive:
        for name, target in files.items():
            archive.write(target, name)
        archive.writestr("decision.json", json.dumps(result, indent=2) + "\n")
    verify(path)


if __name__ == "__main__":
    mode, *args = sys.argv[1:]
    {"bundle": bundle, "verify": verify}[mode](*map(Path, args))
