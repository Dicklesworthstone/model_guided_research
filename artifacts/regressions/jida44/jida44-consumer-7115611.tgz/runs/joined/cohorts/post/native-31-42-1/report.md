# Route Observatory Report (`mgr.bench.routes.v2`)

- **Mechanism**: `tropical`
- **Task**: `hier`
- **Checkpoint**: `/private/tmp/mgr-jida44-consumer.x8L7T1AV/runs/joined/training/baseline/nanochat/native-31/checkpoints` (step `1`)
- **Samples**: `8` (seed `42`)
- **Brute-force cross-check verified**: `True`

## 1. Route Reuse & Consolidation

- **Route entropy (bits)**: `2.9528` (first `2.9528` -> last `2.9528`, delta `0.0000`)
- **Program reuse ratio**: `0.4375` (first `0.4375` -> last `0.4375`, delta `0.0000`)
- **Top-5 program share**: `0.7500`

## 2. Perturbation & Paraphrase Stability (`vdc.1` Probe Spec)

- **Probe spec**: `vdc.1-linf-embedding-v1` (`default_eps=0.05`)
- **Margin aggregation**: `min` (tightest decision along route)
- **Spearman rho(gamma_min, stability)**: `unavailable`
- **Unchanged perturbation draws**: 2 / 64
- **Mean perturbation stability**: `0.0312`
- **Mean paraphrase stability**: `0.9316` (8 measured)

## 3. Unsupervised Trace Clustering vs Attention-Entropy Baseline

- **Latent task classes (`K=2`)**: `['2', '3']`
- **Trace clustering ARI**: `-0.1429`
- **Attention-entropy baseline ARI**: `-0.1538`
- **Prompt-only control ARI**: `1.0000`
- **ARI gain (trace - baseline)**: `0.0110`
