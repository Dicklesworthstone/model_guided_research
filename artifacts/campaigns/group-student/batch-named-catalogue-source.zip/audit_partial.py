"""Exhaustively recheck compatibility and recount the live oracle costs."""

import json
import sys
from collections import Counter
from pathlib import Path

from check_replay import follow, independently_named, load, verify_exhaustion, without_timings

ARMS = ("scalar_tables", "batch_tables")


def table_rows(cases, arms):
    older, current = (arms[arm] for arm in ARMS)
    if current["witnesses"] != older["witnesses"] or current["actions"] != older["actions"]:
        raise ValueError("The live matching arms disagree")
    for i, case in enumerate(cases):
        rows = current["actions"][str(i)]
        catalogue = dict(witnesses=current["witnesses"][str(i)], distinct_named_actions=len(rows),
                         action=rows[0] if len(rows) == 1 else None)
        yield dict(index=i, order=case["label_count"], catalogue=catalogue)


def audit(cohort, library, prior, prior_partial, primary, replay):
    profile = [load(Path(cohort) / f"{i:02}.json") for i in range(24)]
    old, first, second = map(load, (prior, primary, replay))
    if without_timings(first) != without_timings(second):
        raise ValueError("Hash seed or arm order changed a non-timing field")
    rows = list(table_rows(profile, first["matching"]))
    for row, previous in zip(rows, old["results"], strict=True):
        if any(previous["catalogue"][k] != v for k, v in row["catalogue"].items()):
            raise ValueError("Historical compatibility changed")
    pairs = verify_exhaustion(load(library)[2], profile, rows)
    historical = load(prior_partial)
    totals = {arm: Counter() for arm in (*ARMS, "square")}
    evaluated = 0
    complete_reuse = 0
    for i, case in enumerate(profile):
        expected = list(independently_named(case))
        for arm in ARMS:
            sample = first["naming"][arm][i]
            if sample["index"] != i or sample["indexed"]["structures"] != 1:
                raise ValueError("An action was lost")
            if sample["indexed"].get("reused_complete"):
                complete_reuse += 1
                if len(first["matching"]["batch_tables"]["actions"][str(i)]) != 1 or sample["indexed"]["paid"]:
                    raise ValueError("Unsafe reuse of a complete labelled action")
            for lane, totals_key in (("indexed", arm), ("square", "square")):
                record = sample[lane]
                if record["action"] != expected:
                    raise ValueError("Exact action table changed")
                if lane == "square" and record["paid"] != case["arms"]["active"]["paid"]:
                    raise ValueError("Prior square tape changed")
                if lane == "indexed" and record["paid"] != historical["naming"]["partial"][i]["indexed"]["paid"]:
                    raise ValueError("The query-optimal tape changed")
                for word, label in record["paid"]:
                    if label != follow(expected, word):
                        raise ValueError("Oracle reply failed")
                    # Count square once. Both live rereads are checked.
                    if lane != "square" or arm == "batch_tables":
                        totals[totals_key].update(calls=1, symbols=len(word))
                totals[totals_key]["checked_transitions"] += 2 * len(expected[1])
            for split, answers in sample["indexed"]["answers"].items():
                if answers != [follow(expected, word) for word, _, _ in case[split]]:
                    raise ValueError("Wrong held-out endpoints")
                evaluated += len(answers)
    if (totals["batch_tables"]["calls"], totals["batch_tables"]["symbols"], totals["square"]["calls"]) != (165, 1551, 184):
        raise ValueError("Exact label and symbol floors did not reproduce")
    if complete_reuse != 13 or [root for root, _ in first["root_control"]] != ["0", "2"]:
        raise ValueError("Expected complete-action reuse or root distinction was missing")
    timing = []
    gates = []
    for sample in (first, second):
        sub = {}
        for arm in ARMS:
            saved = sample["naming"][arm]
            sub[arm] = dict(matching_cpu_ns=sample["matching"][arm]["cpu_ns"],
                            naming_cpu_ns=sum(row["indexed"]["cpu_ns"] for row in saved),
                            square_cpu_ns=sum(row["square"]["cpu_ns"] for row in saved),
                            control_cpu_ns=sample["controls"][arm]["cpu_ns"])
        before, after = (sub[arm]["matching_cpu_ns"] + sub[arm]["naming_cpu_ns"] for arm in ARMS)
        gates.append(5 * after <= 4 * before)
        timing.append(dict(arms=sub, combined_ratio=before / after, parsing_cpu_ns=sample["parsing_cpu_ns"]))
    control = first["controls"]
    if (len(control["batch_tables"]["witnesses"]) != 9
            or any(control["batch_tables"][key] != historical["controls"]["partial"][key] for key in ("witnesses", "actions"))):
        raise ValueError("Wrong controls")
    print(json.dumps(dict(
        cases=len(profile), combined_gate=all(gates), compatible_pairs=pairs, totals=totals,
        heldout_answers=evaluated, timing=timing, control_count=len(control["batch_tables"]["witnesses"]),
        complete_reuse=complete_reuse,
    ), sort_keys=True))


if __name__ == "__main__":
    audit(*sys.argv[1:])
