import json
import os
import platform
import random
import statistics
import sys
import time
from dataclasses import dataclass
from pathlib import Path

from compile_policy import QUERIES, SAMPLES, compile_all, decode, digest, make_packed

DEPTHS = (12, 16)
SEEDS = (91, 92)
FAMILIES = ("low", "middle", "high", "interleaved", "iid")


@dataclass(frozen=True, slots=True)
class Projected:
    data: bytes
    shift: int
    mask: int

    def lookup(self, address):
        index = (address >> self.shift) & self.mask
        return (self.data[index >> 3] >> (index & 7)) & 1

    def wire(self):
        return b"S" + bytes([self.shift, self.mask.bit_length()]) + self.data

    def resident(self):
        return sys.getsizeof(self) + sys.getsizeof(self.shift) + sys.getsizeof(self.mask) + sys.getsizeof(self.data)


def read_projected(wire):
    assert wire[0:1] == b"S"
    shift, width = wire[1:3]
    assert 1 <= width <= 16 and shift + width <= 16
    assert len(wire[3:]) == ((1 << width) + 7) // 8
    return Projected(wire[3:], shift, (1 << width) - 1)


def support(f, depth):
    active = []
    for bit in range(depth):
        stride = 1 << bit
        if any(f[i:i+stride] != f[i+stride:i+2*stride] for i in range(0, len(f), 2*stride)):
            active.append(bit)
    return active


def compile_projection(f, depth):
    active = support(f, depth)
    old, before = compile_all(f, depth)
    prior = old["adaptive"].wire()
    selected = before
    decoder = decode(prior)
    if active:
        first, last = active[0], active[-1]
        width = last - first + 1
        if width < depth:
            wire = Projected(make_packed(bytes(f[i << first] for i in range(1 << width))).data,
                             first, (1 << width) - 1).wire()
            if len(wire) < len(prior):
                decoder = read_projected(wire)
                selected = "projection"
    assert all(decoder.lookup(i) == val for i, val in enumerate(f))
    if selected != "projection":
        assert decoder.wire() == prior
    return dict(packed=old["packed"], runs=old["runs"], incumbent=old["adaptive"], projected=decoder), active, before, selected


def synthesize(family, depth, seed):
    rng = random.Random(71152 + depth * 1000 + seed)
    if family == "iid":
        return bytes(rng.getrandbits(1) for _ in range(1 << depth))
    first = {"low": 0, "middle": (depth - 8) // 2, "high": depth - 8}.get(family)
    motif = bytes([0, 0, 0, 1] + [rng.getrandbits(1) for _ in range(252)])
    if first is not None:
        return bytes(motif[(i >> first) & 255] for i in range(1 << depth))
    assert family == "interleaved"
    positions = [i * (depth - 1) // 7 for i in range(8)]
    return bytes(motif[sum(((i >> bit) & 1) << j for j, bit in enumerate(positions))] for i in range(1 << depth))


def paired_times(f, depth, seed, arms):
    rng = random.Random(92241 + depth * 100 + seed)
    queries = [rng.randrange(len(f)) for _ in range(QUERIES)]
    expected = sum(f[i] for i in queries)
    methods = {name: decoder.lookup for name, decoder in arms.items()}
    results = {name: [] for name in methods}
    for method in methods.values():
        assert sum(map(method, queries)) == expected
    orders = []
    for _ in range(SAMPLES):
        order = list(methods)
        rng.shuffle(order)
        orders.append(order)
        for arm in order:
            t0 = time.perf_counter_ns()
            value = sum(map(methods[arm], queries))
            results[arm].append((time.perf_counter_ns() - t0) / QUERIES)
            assert value == expected
    ratios = {name: statistics.median(t/u for t, u in zip(results["projected"], results[name], strict=True))
              for name in ("packed", "runs", "incumbent")}
    return dict(samples=results, orders=orders, ratios=ratios, checksum=expected)


def run(path):
    core = min(os.sched_getaffinity(0))
    os.sched_setaffinity(0, {core})
    full = []
    for depth in DEPTHS:
        for family in FAMILIES:
            for seed in SEEDS:
                data = synthesize(family, depth, seed)
                arms, active, before, selected = compile_projection(data, depth)
                full.append(dict(depth=depth, family=family, seed=seed, truth=digest(data), support=active,
                                 before=before, selected=selected,
                                 wire={name: len(decoder.wire()) for name, decoder in arms.items()},
                                 resident={name: decoder.resident() for name, decoder in arms.items()},
                                 **paired_times(data, depth, seed, arms)))
                print(f"{depth} bits {family} {seed}: {before} -> {selected}, support={active}", flush=True)
    # A single off-window exception invalidates the projected representation.
    original = synthesize("low", 12, 91)
    assert compile_projection(original, 12)[-1] == "projection"
    changed = bytearray(original)
    changed[1 << 11] ^= 1
    assert 11 in support(changed, 12) and compile_projection(changed, 12)[-1] != "projection"
    with path.open("x", encoding="utf-8") as stream:
        json.dump(dict(controls={"single_off_window_flip_rejected": True}, rows=full, core=core,
                       host=platform.node(), machine=platform.machine(), python=platform.python_version(),
                       samples=SAMPLES, queries=QUERIES), stream, allow_nan=False)


if __name__ == "__main__":
    run(Path(sys.argv[1]))
