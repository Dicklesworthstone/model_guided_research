"""Synthetic eligibility controls. Their numbers never enter the research registry."""
import json
import sys
from pathlib import Path

out = Path(sys.argv[1])
source = "8d51a4d275af1e1b33c9adb21dc8f6da53a50407"
for family in ("same-training", "incompatible-bos", "independent"):
    for mechanism, mean in (("standard",0.30), ("reversible",0.95)):
        for i in range(3):
            run = f"{mechanism}-{0 if family=='same-training' else i}"
            step = 100 + i if family=="same-training" else 100
            sv = 3 if family=="incompatible-bos" and (i==0 if mechanism=="standard" else i!=0) else 4
            provenance = dict(git_sha=source, git_dirty=False, tainted=False)
            data = dict(schema_version=f"mgr.evaltasks.v{sv}", kind="eval-tasks",
                control="Planted measurement for eligibility testing only",
                meta=dict(generated_at="2026-11-22T00:00:00Z", seeds=[10,11,12],
                          evaluator=dict(bos_prefixed=(sv>=4)),
                          checkpoint=dict(attention_type=mechanism, step=step,
                                          lineage=dict(run_id=run,parent_run_ids=[]),
                                          budget=dict(target_flops=1e12,max_steps=101,flops_per_step_est=1e10))),
                train_provenance=provenance, provenance=provenance,
                tasks={"copyops":{"exact_match":{"greedy":{"held_out":{"mean":mean,"per_seed":[mean]*3}}}}})
            folder = out / family / "evals/tasks" / f"{mechanism}-{i}"
            folder.mkdir(parents=True,exist_ok=True)
            (folder/"summary.json").write_text(json.dumps(data,indent=2)+"\n")
