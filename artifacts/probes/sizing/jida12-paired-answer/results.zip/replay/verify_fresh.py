import json
import sys
from pathlib import Path

def trees(panel):
    return {
        row["documents"][0].split(" PATH ", 1)[0]
        for pairs in panel.values()
        for row in pairs
    }

root, reference = map(Path, sys.argv[1:])
previous = trees(json.loads((reference / "panel.json").read_bytes())["evaluation"])
fresh = trees(json.loads((root / "panel.json").read_bytes()))
assert len(previous) == len(fresh) == 72
assert not previous.intersection(fresh)
print(json.dumps(dict(previous_panel_trees=len(previous), fresh_panel_trees=len(fresh), overlap=0)))
