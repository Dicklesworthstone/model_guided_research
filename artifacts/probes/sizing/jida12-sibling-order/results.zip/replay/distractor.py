import itertools
import sys
from pathlib import Path

from leaf_position import (
    LocationHead, SPEC, HuggingFaceTokenizer, _load_eval_checkpoint,
    digest, leaf_entries, pq, read, states, torch, tree_of, write,
)
from nanochat.diagnostics_data import _hier_serialize


def encode(tree, chosen, tokenizer):
    leaves = leaf_entries(tree)
    assert len(leaves) == len({value for _, value, _ in leaves}) == 9
    bos = tokenizer.get_bos_token_id()
    prefixes = [tokenizer.encode(tree[:end], prepend=bos) for _, _, end in leaves]
    rows = []
    for index, (path, value, _) in enumerate(leaves):
        if path not in chosen:
            continue
        doc = f"{tree} PATH {' '.join(path)} OUT {value}"
        assert SPEC.checker(doc) is True
        prompt, expected = SPEC.split_prompt(doc)
        ids = tokenizer.encode(prompt, prepend=bos)
        full = tokenizer.encode(doc, prepend=bos)
        assert expected == value and full[:len(ids)] == ids and len(ids) < len(full) <= 128
        assert all(ids[:len(prefix)] == prefix for prefix in prefixes)
        rows.append(dict(doc=doc, ids=ids, label=index, path=path, value=value))
    assert len(rows) == 4 and len({len(row["ids"]) for row in rows}) == 1
    return dict(tree=tree, candidates=[len(prefix) - 1 for prefix in prefixes], queries=rows,
                leaves=[dict(path=path, value=value) for path, value, _ in leaves])


def n_tokens(cell):
    return len(cell["queries"][0]["ids"])


def preflight(output, paths):
    reference, answer, pilot, rep, matched = paths
    previous = set()
    corpus = reference / "data" / "hier_paired"
    data = read(corpus / "manifest.json")
    for name, sha in data["sha256"].items():
        file = corpus / name
        assert digest(file) == sha
        docs = pq.read_table(file, columns=["text"]).column("text").to_pylist()
        previous.update(tree_of(doc) for doc in docs[::2])
    assert len(previous) == 32000
    for path in (reference / "panel.json", answer / "panel.json", pilot / "panel.json",
                 rep / "seed-30" / "panel.json"):
        panel = read(path)
        previous.update(tree_of(row["documents"][0]) for rows in panel.get("evaluation", panel).values()
                        for row in rows)
    assert len(previous) == 32324
    previous.update(block[slot]["tree"] for block in read(matched)["blocks"] for slot in ("a", "b"))
    assert len(previous) == 32396
    trained = rep / "seed-30" / "runs" / "joint" / "checkpoints" / "tokenizer"
    tokenizer = HuggingFaceTokenizer.from_directory(str(trained))
    lock = digest(trained / "tokenizer.json")
    assert lock == read(rep / "seed-30" / "preflight.json")["tokenizer_sha256"]
    blocks = []
    for seed in (61, 62, 63):
        docs = SPEC.generate(4800, seed, SPEC.resolve_dials(None))["train"]
        selected = 0
        for doc in docs[::2]:
            text = tree_of(doc)
            if text in previous:
                continue
            leaves = leaf_entries(text)
            if len(leaves) != 9 or len({value for _, value, _ in leaves}) != 9:
                continue
            tree = {}
            for path, value, _ in leaves:
                root, suffix = path
                tree.setdefault(root, {})[suffix] = value
            serialize = lambda node: "TASK hier TREE " + _hier_serialize(node)
            assert text == serialize(tree)
            root = f"k0x{selected % 3}"
            suffix = f"k1x{(selected // 3 + seed) % 3}"
            chosen = {(r, k) for r, branch in tree.items() if r != root for k in branch if k != suffix}
            if len(chosen) != 4:
                continue
            normal = encode(text, chosen, tokenizer)
            nested_branch = {"k1x0": {f"k2x{k[-1]}": value for k, value in tree[root].items()}}
            nested = encode(serialize({r: nested_branch if r == root else branch for r, branch in tree.items()}),
                            chosen, tokenizer)
            for zeros in range(1, 49):
                alias = f"{root[:-1]}{'0' * zeros}{root[-1]}"
                widened = serialize({alias if r == root else r: branch for r, branch in tree.items()})
                length_only = encode(widened, chosen, tokenizer)
                if n_tokens(length_only) == n_tokens(nested):
                    break
            else:
                raise ValueError("No exact match for distractor expansion")
            cases = (normal, length_only, nested)
            trees = {case["tree"] for case in cases}
            assert len(trees) == 3
            if previous.intersection(trees):
                continue
            assert len({tuple((tuple(row["path"]), row["label"], row["value"]) for row in case["queries"])
                        for case in cases}) == 1
            assert len({tuple(item["value"] for item in case["leaves"]) for case in cases}) == 1
            assert all(length_only["candidates"][row["label"]] == nested["candidates"][row["label"]]
                       for row in normal["queries"])
            blocks.append(dict(seed=seed, index=selected, root=root, omitted_suffix=suffix,
                               normal=normal, length_only=length_only, nested=nested))
            previous.update(trees)
            selected += 1
            if selected == 12:
                break
        assert selected == 12
    assert len(blocks) == 36 and len(previous) == 32504
    write(output, dict(tokenizer_sha256=lock, distinct_input_trees=len(previous), blocks=blocks))
    print({name: sorted({n_tokens(block[name]) for block in blocks}) for name in ("normal", "length_only", "nested")})


@torch.inference_mode()
def evaluate(panel_path, reference, output):
    panel = read(panel_path)
    device = torch.device("cpu")
    for seed, arm in itertools.product((30, 31, 32), ("detached", "joint")):
        root = reference / f"seed-{seed}"
        checkpoint = root / "runs" / arm / "checkpoints"
        original = read(root / "evals" / arm / "summary.json")
        training = read(root / "runs" / arm / "summary.json")
        assert not training["provenance"]["tainted"]
        assert original["source_revision"] == training["provenance"]["git_sha"] == "fb0fe89a34cddd43285903d497e0c9b0a4e4cdb1"
        model, meta, step = _load_eval_checkpoint(checkpoint, None, device, fingerprint_weights=True)
        assert step == 2047 and meta["weights_sha256"] == original["weights_sha256"]
        head_file = checkpoint / "location_head.pt"
        assert digest(head_file) == training["location_head_sha256"] == original["location_head_sha256"]
        assert digest(checkpoint / "tokenizer" / "tokenizer.json") == panel["tokenizer_sha256"]
        head = LocationHead().eval()
        head.load_state_dict(torch.load(head_file, weights_only=True))
        outcomes = []
        for block in panel["blocks"]:
            scores = {}
            for name in ("normal", "length_only", "nested"):
                case = block[name]
                tokens = torch.tensor([row["ids"] for row in case["queries"]])
                _, hidden = states(model, tokens)
                attention = head(hidden, torch.full((4,), tokens.shape[1] - 1),
                                 torch.tensor([case["candidates"]] * 4))
                assert bool(torch.isfinite(attention).all())
                scores[name] = attention.tolist()
            outcomes.append(scores)
        write(output / f"seed-{seed}-{arm}.json",
              dict(seed=seed, arm=arm, rows=outcomes, panel_sha256=digest(panel_path),
                   weights_sha256=meta["weights_sha256"], head_sha256=original["location_head_sha256"]))
        print(seed, arm, len(outcomes), flush=True)


if __name__ == "__main__":
    command, panel, *paths = sys.argv[1:]
    if command == "preflight":
        preflight(Path(panel), tuple(map(Path, paths)))
    elif command == "evaluate":
        evaluate(Path(panel), *map(Path, paths))
    else:
        raise ValueError(command)
