# Address precision and binding policy size

Suppose a parent address has h bits and its binding is the parity of
those bits, possibly with a fixed complement. For any omitted bit i,
the addresses x and x ⊕ 2ⁱ look identical after omission, but their
binding bits differ. A decoder that sees only the retained bits
therefore needs all h bits to resolve every address.

The same binding policy has a compact exact representation. An
affine Boolean function is determined by f(0) and the h values
f(2ⁱ) ⊕ f(0). These are its bias and mask. The compiler checks the
result against every source entry before accepting it. Evaluation
takes the parity of the address masked by those coefficients and
XORs the bias.

The ordered decision graph uses the same fixed address variable
order everywhere. At a prefix with a known partial parity, the
remaining function is one of only two states. Identical suffix
functions share a node. This is a linear-size graph for parity
even when no address bit can be skipped in an exact lookup.

The experiment measures exact policy storage conditional on access
to the parent address. It keeps the prior address-collision bound
intact. Ordered decision diagrams follow the standard construction
described by [Bryant](https://doi.org/10.1109/TC.1986.1676819).
