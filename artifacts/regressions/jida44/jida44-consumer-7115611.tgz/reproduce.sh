#!/usr/bin/env bash
set -eu
export J44_ROOT
J44_ROOT=$(cd "$(dirname "$0")" && pwd -P)
rev=711561125aa154a1404ad9a98d8ebb118655cda3
url=${J44_REPO:-https://github.com/Dicklesworthstone/model_guided_research.git}
cd "$J44_ROOT"
git clone --quiet --no-checkout "$url" consumer
git -C consumer -c advice.detachedHead=false checkout --quiet --detach "$rev"
git clone --quiet --shared consumer historical
git -C historical -c advice.detachedHead=false checkout --quiet --detach 4db6657e80d6cd657d8ca85ef86ca01380c2e9c0
git clone --quiet inputs/chronology.bundle chronology
for pair in retained-history:route-producers joined-history:joined-producer; do
    repo=${pair%:*}
    bundle=${pair#*:}
    git clone --quiet --shared consumer "$repo"
    git -C "$repo" fetch --quiet "$J44_ROOT/inputs/$bundle.bundle" HEAD
    git -C "$repo" -c advice.detachedHead=false checkout --quiet --detach FETCH_HEAD
done
if [ -z "${UV_PROJECT_ENVIRONMENT:-}" ]; then
    export UV_PROJECT_ENVIRONMENT="$J44_ROOT/venv"
    DSR_REPOS_FILE="$J44_ROOT/install.yaml" dsr --json quality --tool j44-locked-env --work-dir "$J44_ROOT/consumer"
fi
if [ "$#" -eq 0 ]; then set -- joined retained historical regions; fi
for lane do
    case "$lane" in
        joined) config=portable; tool=j44-portable-join ;;
        retained) config=quality; tool=j44-retained ;;
        historical) config=quality; tool=j44-historical ;;
        regions) config=region; tool=j44-regions ;;
        *) echo "Use joined, retained, historical or regions" >&2; exit 2 ;;
    esac
    DSR_REPOS_FILE="$J44_ROOT/$config.yaml" dsr --json quality --tool "$tool" --work-dir "$J44_ROOT/consumer"
done
