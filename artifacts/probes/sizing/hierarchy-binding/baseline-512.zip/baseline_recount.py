import hashlib
import json
import sys
from collections import Counter
from pathlib import Path

SOURCE = "aac00af89abfe2dcf1dfea5f75ceac2f0c1c1ac8"
PANEL_HASH = "50d42225c52ea0cfbc5f9e823f76d06708cb90cc6c2b49071187a039d4b6041b"
TRAIN_SEEDS = (8831, 8832, 8833)
EVAL_SEEDS = (3301, 3302, 3303)
REGIONS = ("in_range", "held_out")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def recount(root):
    panel_file = root / "baseline-panel.json"
    assert sha(panel_file) == PANEL_HASH
    panel = read(panel_file)
    artifacts = root / "baseline/artifacts/probes/sizing"
    receipts = {}
    for path in (root / "baseline-receipts" / "hierarchy-binding-baseline").glob("*/receipt.json"):
        receipt = read(path)
        assert receipt["status"] == "passed" and len(receipt["checks"]) == 2
        for check in receipt["checks"]:
            log = path.with_name(Path(check["log_path"]).name)
            assert sha(log) == check["log_sha256"]
        first_log = path.with_name(Path(receipt["checks"][0]["log_path"]).name).read_text()
        seed, = (seed for seed in TRAIN_SEEDS if f"hier-bind-{seed}" in first_log)
        assert seed not in receipts
        receipts[seed] = path.parent.name
    assert set(receipts) == set(TRAIN_SEEDS)
    outcomes = {}
    for seed in TRAIN_SEEDS:
        run = f"hier-bind-{seed}"
        train = read(artifacts / "baseline/nanochat" / run / "summary.json")
        eval_root = artifacts / "evals/tasks" / run
        score = read(eval_root / "summary.json")
        for record in (train["provenance"], score["provenance"], score["train_provenance"]):
            assert record["git_sha"] == SOURCE and not record["tainted"]
        checkpoint = score["meta"]["checkpoint"]
        assert score["meta"]["sizing_input"] and score["meta"]["seeds"] == list(EVAL_SEEDS)
        assert checkpoint["training_seed"] == seed and checkpoint["step"] == 511
        assert len(checkpoint["weights_sha256"]) == 64
        assert checkpoint["model_config"]["sequence_len"] == 192 and checkpoint["attention_type"] == "standard"
        assert train["budget"]["max_steps"] == 512 and train["budget"]["tokens_per_step_global"] == 768
        task = score["tasks"]["hier_bind"]
        results = {}
        observed = {}
        for line in (eval_root / "generations.jsonl").read_text().splitlines():
            row = json.loads(line)
            key = (row["region"], row["eval_seed"], row["doc_index"])
            assert row["task"] == "hier_bind" and row["mode"] == "greedy" and key not in observed
            observed[key] = row
        missing = 0
        for region in REGIONS:
            result = []
            for index, eval_seed in enumerate(EVAL_SEEDS):
                docs = panel[str(eval_seed)][region]
                assert len(docs) == 24
                expectations, flags = [], []
                for i, doc in enumerate(docs):
                    expected = doc.rsplit(" OUT ", 1)[1]
                    row = observed.pop((region, eval_seed, i), None)
                    if row is None:
                        flags.append(None)
                        missing += 1
                        continue
                    assert row["expected"] == expected
                    correct = row["got"].split()[:1] == [expected]
                    assert row["correct"] == correct
                    flags.append(correct)
                    expectations.append(expected)
                pairs = dict(incomplete=0, neither_correct=0, one_correct=0, both_correct=0)
                for a, b in zip(flags[::2], flags[1::2], strict=True):
                    if a is None or b is None:
                        pairs["incomplete"] += 1
                    else:
                        pairs[("neither_correct", "one_correct", "both_correct")[int(a) + int(b)]] += 1
                assert task["paired_exact_match"]["counts"][region][index] == dict(eval_seed=eval_seed, pairs=12, **pairs)
                records = len(expectations)
                assert records > 0
                prior = max(Counter(expectations).values())
                correct = sum(flag is True for flag in flags)
                assert task["answer_prior"][region]["per_seed"][index] == prior / records
                assert task["exact_match"]["greedy"][region]["per_seed"][index] == correct / records
                result.append(dict(eval_seed=eval_seed, individual_correct=correct, constant_answer_correct=prior,
                                   recorded=records, both_correct=pairs["both_correct"], incomplete=pairs["incomplete"]))
            results[region] = result
        assert not observed and missing == task["skipped_too_long"]
        totals = {region: dict(individual_correct=sum(row["individual_correct"] for row in results[region]),
                               both_correct=sum(row["both_correct"] for row in results[region]),
                               complete_pairs=36 - sum(row["incomplete"] for row in results[region]))
                  for region in REGIONS}
        screen = (missing == 0 and totals["in_range"]["both_correct"] >= 8 and totals["held_out"]["both_correct"] >= 5
                  and all(row["individual_correct"] > row["constant_answer_correct"] for rows in results.values()
                          for row in rows))
        outcomes[seed] = dict(checkpoint_sha256=checkpoint["weights_sha256"], terminal_receipt=receipts[seed],
                              budget=train["budget"], regions=results, totals=totals, screen_passed=screen)
    return dict(source=SOURCE, panel_sha256=PANEL_HASH, seeds=outcomes,
                screen_passed=all(outcome["screen_passed"] for outcome in outcomes.values()))


result = recount(Path(sys.argv[1]))
if len(sys.argv) > 2:
    with Path(sys.argv[2]).open("x", encoding="utf-8") as out:
        json.dump(result, out, indent=2)
print(json.dumps({seed: outcome["totals"] for seed, outcome in result["seeds"].items()}))
print(f"Fixed screen passed: {result['screen_passed']}")
