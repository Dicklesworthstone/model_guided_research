"""Resource-bounded, solver-selected endpoint acquisition on resettable rings."""

import argparse
import json
import random
import re
import resource
import subprocess
from collections import deque
from itertools import product
from pathlib import Path
from time import monotonic_ns, process_time_ns

from compare import SolverTeacher, visible_exploration

from scripts.group_rewrite_probe import teach_panel_case

ANCHORS = ("00", "01", "10", "11")
CASES = (
    ("planet", 4, False),
    ("ring5", 5, False),
    ("ring6", 6, False),
    ("ring5-exhausted", 5, True),
)
RESOURCES = 2_000_000


class BoundedModels(SolverTeacher):
    """Reuse the earlier finite permutation constraints with a pure work budget."""

    def initialize(self):
        super().initialize()
        self.commands = [
            command for command in self.commands
            if not command.startswith(("(set-option :timeout ", "(set-option :rlimit "))
        ]
        self.commands[1:1] = [
            f"(set-option :rlimit {1 if self.low_resource else RESOURCES})",
            "(set-option :smt.threads 1)",
        ]

    def check(self):
        status = self.exchange("(check-sat)")
        if status not in {"sat", "unsat", "unknown"}:
            raise ValueError(f"Unexpected solver result {status!r}")
        statistics = self.exchange("(get-info :all-statistics)")
        count = re.search(r":rlimit-count\s+(\d+)", statistics)
        if count is None:
            raise ValueError("Z3 omitted its solver resource count")
        reason = self.exchange("(get-info :reason-unknown)") if status == "unknown" else None
        return {"status": status, "resource_count": int(count[1]), "reason": reason}

    def alternative_right_table(self, model):
        differences = (
            f"(distinct vR{letter}x{index} {self.value(target)})"
            for letter in "01" for index, target in enumerate(model["R" + letter])
        )
        self.exchange("(push)", f"(assert (or {' '.join(differences)}))")
        result = self.check()
        other = self.witness() if result["status"] == "sat" else None
        self.exchange("(pop)")
        return result, other


def endpoint(model, word):
    state = model["root"]
    for mark in word:
        state = model["R" + mark][state]
    return state


def shortest_disagreement(first, second):
    """BFS needs only diagonal product states until the first disagreement."""
    queue = deque((word, endpoint(first, word)) for word in ANCHORS)
    visited = set()
    while queue:
        word, state = queue.popleft()
        if state in visited:
            continue
        visited.add(state)
        for mark in "01":
            left = first["R" + mark][state]
            right = second["R" + mark][state]
            if left != right:
                return word + mark
            queue.append((word + mark, left))
    raise ValueError("Distinct transitive right tables have no distinguishing word")


def active_learning(initial, names, ask, *, exhausted):
    solver = BoundedModels("z3", initial, sorted(names), ask, audit=True, low_resource=exhausted)
    observations = dict(initial)
    events = []
    termination = "query-cap"
    try:
        for _ in range(65):
            event = {"base": solver.check()}
            events.append(event)
            if event["base"]["status"] == "unknown":
                termination = "unknown-base"
                break
            if event["base"]["status"] != "sat":
                raise ValueError("The public oracle transcript is inconsistent")
            first = solver.witness()
            alternative, second = solver.alternative_right_table(first)
            event.update(first=first, alternative=alternative)
            if alternative["status"] == "unsat":
                right = {
                    mark: dict(zip(solver.names, (solver.names[i] for i in first["R" + mark]), strict=True))
                    for mark in "01"
                }
                return right, events, "unique-right-table"
            if alternative["status"] == "unknown":
                termination = "unknown-alternative"
                break
            if second is None:
                raise ValueError("SAT alternative supplied no model")
            word = shortest_disagreement(first, second)
            if word in observations:
                raise ValueError("Proposed a word already supplied by the oracle")
            answer = ask(word)
            event.update(second=second, word=word, answer=answer)
            observations[word] = answer
            solver.commands.append(solver.assert_endpoint(word, answer))
    finally:
        solver.close()
    closure, _ = teach_panel_case(observations, set(names), ask, squares=True)
    return {mark: closure.maps["R" + mark] for mark in "01"}, events, termination


def physical_chart(size, label_seed):
    chart = [(place, heading) for place, heading in product(range(size), (1, -1))]
    labels = [f"opaque{i:02d}" for i in range(len(chart))]
    random.Random(label_seed).shuffle(labels)
    return dict(zip(chart, labels, strict=True))


def run_case(family, size, exhausted, case_index):
    chart = physical_chart(size, 251124 + case_index)
    names = set(chart.values())

    def endpoint_oracle(word):
        pos, direction = 0, 1
        for mark in word:
            if mark == "0":
                pos = (pos + direction) % size
            elif mark == "1":
                direction = -direction
            else:
                raise ValueError(f"Unknown motion {mark!r}")
        return chart[pos, direction]

    initial = {word: endpoint_oracle(word) for word in ANCHORS}
    rows = {}
    arms = ("square", "visible", "active")
    offset = case_index % len(arms)
    for arm in arms[offset:] + arms[:offset]:
        tape = []

        def ask(word):
            answer = endpoint_oracle(word)
            tape.append([word, answer])
            return answer

        begin_cpu, begin_wall = process_time_ns(), monotonic_ns()
        resources = resource.getrusage(resource.RUSAGE_CHILDREN)
        if arm == "square":
            actions, _ = teach_panel_case(initial, names, ask, squares=True)
            right = {mark: actions.maps["R" + mark] for mark in "01"}
            events, terminal = [], "closure"
        elif arm == "visible":
            right, _ = visible_exploration(initial, names, ask)
            events, terminal = [], "exploration"
        else:
            right, events, terminal = active_learning(initial, names, ask, exhausted=exhausted)
        children = resource.getrusage(resource.RUSAGE_CHILDREN)
        cpu = process_time_ns() - begin_cpu + round(
            1e9 * (children.ru_utime + children.ru_stime - resources.ru_utime - resources.ru_stime)
        )
        rows[arm] = {
            "right": right, "paid": tape, "events": events, "terminal": terminal,
            "cpu_ns": cpu, "wall_ns": monotonic_ns() - begin_wall,
        }
    return {
        "family": family, "size": size, "exhausted": exhausted, "names": list(chart.values()),
        "arms": rows, "initial": initial,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    version = subprocess.check_output(["z3", "--version"], text=True).strip()
    if not version.startswith("Z3 version 4.15.4 "):
        raise ValueError(f"Unexpected Z3 version {version}")
    cases = []
    for i, spec in enumerate(CASES):
        case = run_case(*spec, i)
        print(f"{case['family']}: {case['arms']['active']['terminal']}", flush=True)
        cases.append(case)
    with args.output.open("x", encoding="utf-8") as handle:
        json.dump({"cases": cases, "z3": version, "rlimit": RESOURCES}, handle, sort_keys=True)
        handle.write("\n")


if __name__ == "__main__":
    main()
