#!/bin/bash
set -euo pipefail
export PATH="/home/ubuntu/.local/bin:$PATH"
export MGR_HOP=/data/ssd/tmp/mgr-one-hop.kyDg9iy9
export MGR_HOP_PRIOR=/data/ssd/tmp/mgr-sibling-order.2nI9WLzN
export DSR_REPOS_FILE="$MGR_HOP/campaign.yaml" DSR_QUALITY_LOG_DIR="$MGR_HOP/receipts"
export UV_PROJECT_ENVIRONMENT=/data/ssd/tmp/mgr-eval-ci.bevt3nLW/qualified-venv
export MGR_LEAF_TRAIN_SEED=32 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 PYTHONDONTWRITEBYTECODE=1
mkdir -p "$MGR_HOP/gate"
if [[ "$1" == prepare ]]; then
  dsr quality --tool hierarchy-one-hop-prepare --work-dir "$MGR_HOP/gate" --check-timeout 240
else
  export MGR_HOP_SHA="$1"
  dsr quality --tool hierarchy-one-hop-fit-evaluate --work-dir "$MGR_HOP/gate" --check-timeout 300
fi
