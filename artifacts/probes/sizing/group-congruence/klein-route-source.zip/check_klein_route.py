"""Independently construct and audit paid Klein-four quotient acquisition."""

import argparse
import hashlib
import json
import random
from collections import Counter
from itertools import permutations, product
from pathlib import Path

from check_alternating_route import PANEL, PRIOR, digests
from check_commutator_route import CONTROLS, TARGETS, graph_for, group, normalized
from check_short_certificate import action, answers, checksum, read, validate_tape, walk

SEED = 251763
TARGET = "s4xc5"
OUTSIDE = "d10xc12"
REPLAYS = (*CONTROLS, *TARGETS)
ARMS = ("fallback", "edge", "short", "routed", "extended", "commutator", "klein")


def arithmetic(family):
    if family in {"s4", "s4xc2"}:
        modulus = 1 if family == "s4" else 2
        pool = [p + (k,) for p, k in product(permutations(range(4)), range(modulus))]

        def multiply(left, right):
            return tuple(right[i] for i in left[:4]) + ((left[-1] + right[-1]) % modulus,)

        return pool, (0, 1, 2, 3, 0), multiply
    if family == OUTSIDE:
        def multiply(left, right):
            a, b, c = left
            d, e, f = right
            return (a + (-d if b else d)) % 5, (b + e) % 2, (c + f) % 12

        return list(product(range(5), range(2), range(12))), (0, 0, 0), multiply
    return group(family)


def make_panel(root):
    latest = read(root / PANEL / "commutator-route-coverage.json")
    historical = (*PRIOR, PANEL / "alternating-route-coverage.json")
    used = {identifier for path in historical for identifier in digests(read(root / path))} | set(digests(latest))
    rng = random.Random(SEED)
    cases = []
    for family, requested in ((TARGET, 8), (OUTSIDE, 6)):
        pool, identity, multiply = arithmetic(family)
        count = 0
        for _ in range(10_000):
            marks = rng.choice(pool), rng.choice(pool)
            graph = graph_for(marks, identity, multiply)
            identifier = checksum(graph)
            if len(graph) == 120 and identifier not in used:
                cases.append(dict(family=family, marks=list(map(list, marks)), graph=graph, graph_sha=identifier))
                used.add(identifier)
                count += 1
                if count == requested:
                    break
        if count != requested:
            raise ValueError(f"Not enough fresh marked actions for {family}")
    for family in REPLAYS:
        cases.extend([case for case in latest["cases"] if case["family"] == family][:2])
    return dict(seed=SEED, cases=cases)


def order(graph, word):
    return next(power for power in range(1, len(graph) + 1) if walk(graph, word * power) == 0)


def verify_rejection(graph, witness):
    reason = witness.get("rejected")
    if reason == "no_order_four_power" and all(order(graph, word) % 4 for word in ("0", "1", "01")):
        return
    if reason == "central_involution":
        d = witness["involution"]
        if order(graph, d) == 2 and all(answers(graph, (mark + d, d + mark)) for mark in "01"):
            return
    raise ValueError("Rejection did not have the expected obstruction")


def verify_lift(graph, witness):
    d, e = witness["basis"]
    kernel = ("", d, e, d + e)
    if any(order(graph, word) != 2 for word in kernel[1:]) or not answers(graph, (d + e, e + d)):
        raise ValueError("The claimed kernel does not contain two commuting involutions")
    if len({walk(graph, word) for word in kernel}) != 4 or any(
        not any(answers(graph, (mark + word, other + mark)) for other in kernel[1:]) for mark in "01" for word in (d, e)
    ):
        raise ValueError("The Klein subgroup is not normal")

    def coset(word):
        return frozenset(walk(graph, k + word) for k in kernel)

    reps = [""]
    ids = {coset(""): 0}
    quotient = []
    for rep in reps:
        row = []
        for mark in "01":
            new = rep + mark
            target = coset(new)
            if target not in ids:
                ids[target] = len(ids)
                reps.append(new)
            row.append(ids[target])
        quotient.append(row)
    if 4 * len(quotient) != len(graph) or [list(row) for row in witness["quotient"]] != quotient:
        raise ValueError("The reconstructed quotient is wrong")
    targets = {walk(graph, word + rep) for word, rep in product(kernel, reps)}
    if targets != set(range(len(graph))):
        raise ValueError("The normal forms are not bijective")
    for rep, row, lifts in zip(reps, quotient, witness["corrections"], strict=True):
        for mark, target, lift in zip("01", row, lifts, strict=True):
            if lift not in range(4) or not answers(graph, (rep + mark, kernel[lift] + reps[target])):
                raise ValueError("A lifted quotient edge does not hold")


def census():
    from scripts.group_student_probe import _try_klein_four_quotient, _try_order_three_commutator

    result = {}
    for family in ("s4", "s4xc2", "a4"):
        pool, identity, multiply = arithmetic(family)
        seen = set()
        count = maximum = 0
        for marks in product(pool, repeat=2):
            graph = graph_for(marks, identity, multiply)
            if len(graph) != len(pool):
                continue

            def exact(left, right, target=graph):
                return answers(target, (left, right))

            if exact("01", "10"):
                raise ValueError("The transfer case commuted unexpectedly")
            returned, previous = _try_order_three_commutator(len(pool), exact)
            if returned is not None:
                raise ValueError("The previous route accepted a transfer control")
            paid = 0

            def counted(left, right, ask=exact):
                nonlocal paid
                paid += 1
                return ask(left, right)

            recovered, witness = _try_klein_four_quotient(len(pool), counted, previous["orders"])
            if family == "a4":
                if recovered is not None:
                    raise ValueError("Outside subgroup search unexpectedly succeeded")
                verify_rejection(graph, witness)
            else:
                if recovered is None or list(map(list, recovered)) != graph:
                    raise ValueError("Small order recovery failed")
                verify_lift(graph, witness)
            count += 1
            maximum = max(maximum, paid)
            seen.add(checksum(graph))
        if not count:
            raise ValueError("Empty transfer family")
        result[family] = dict(order=len(pool), generating_pairs=count, markings=len(seen), maximum_branch_calls=maximum)
    return result


def audit(root, coverage, primary, repeat, baseline, previous):
    manifest, scored, replay, baseline, previous = map(read, (coverage, primary, repeat, baseline, previous))
    if manifest != make_panel(root) or scored["coverage_sha256"] != hashlib.sha256(coverage.read_bytes()).hexdigest():
        raise ValueError("Wrong frozen panel")
    current = normalized(scored)
    if current != normalized(replay):
        raise ValueError("Hash seed changed non-timing output")
    prior = {row["graph_sha"]: row["arms"]["commutator"] for row in normalized(previous)["results"]}
    counts = {family: {arm: Counter() for arm in ARMS} for family in (TARGET, OUTSIDE, *REPLAYS)}
    branches = []
    forged_checked = False
    for case, row, clean in zip(manifest["cases"], scored["results"], current["results"], strict=True):
        family = case["family"]
        if family in CONTROLS:
            graph = action(family, case["marks"])[0]
        else:
            _, identity, multiply = arithmetic(family)
            graph = graph_for(case["marks"], identity, multiply)
        identifier = checksum(graph)
        if graph != case["graph"] or identifier != case["graph_sha"] or (identifier, family) != (row["graph_sha"], row["family"]):
            raise ValueError("The independently reconstructed action differs")
        if set(row["arms"]) != set(ARMS):
            raise ValueError("Missing arm")
        for name, arm in row["arms"].items():
            validate_tape(graph, arm["paid"])
            if arm["right"] != graph:
                raise ValueError("Recovered action is wrong")
            counts[family][name].update(calls=len(arm["paid"]), symbols=sum(len(a) + len(b) for a, b, _ in arm["paid"]), cpu_ns=arm["cpu_ns"])
        candidate = clean["arms"].pop("klein")
        incumbent = clean["arms"]["commutator"]
        if family in REPLAYS:
            if candidate != incumbent or incumbent != prior[identifier]:
                raise ValueError("An already solved action changed")
            continue
        witness = candidate["klein"]
        tail = clean["arms"]["fallback"]["paid"]
        prefix = incumbent["paid"][:-len(tail)]
        if incumbent["paid"] != prefix + tail or candidate["paid"][:len(prefix)] != prefix:
            raise ValueError("The prior attempts or fallback changed")
        if family == OUTSIDE:
            verify_rejection(graph, witness)
            extra = len(candidate["paid"]) - len(incumbent["paid"])
            if candidate["paid"][-len(tail):] != tail or not 0 < extra <= 20:
                raise ValueError("Off-target query bound or fallback failed")
            branches.append(dict(family=family, branch_calls=extra, reason=witness["rejected"]))
        else:
            verify_lift(graph, witness)
            branches.append(dict(family=family, branch_calls=len(candidate["paid"]) - len(prefix), quotient=len(witness["quotient"])))
            if not forged_checked:
                corrections = [list(pair) for pair in witness["corrections"]]
                corrections[0][0] ^= 1
                try:
                    verify_lift(graph, dict(witness, corrections=corrections))
                except ValueError:
                    forged_checked = True
                else:
                    raise ValueError("A forged edge lift was accepted")
    if current != normalized(baseline):
        raise ValueError("The incumbent CLI changed")
    target = counts[TARGET]
    print(json.dumps(dict(
        exact=True, default_unchanged=True, forged_correction_rejected=forged_checked, checked_transitions=24 * 120 * 2 * len(ARMS),
        gate=10 * target["klein"]["calls"] <= 3 * target["commutator"]["calls"], totals=counts, branches=branches, census=census(),
    ), indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    modes = parser.add_subparsers(dest="mode", required=True)
    for name in ("cover", "audit"):
        mode = modes.add_parser(name)
        mode.add_argument("root", type=Path)
        mode.add_argument("coverage", type=Path)
    for name in ("primary", "repeat", "baseline", "previous"):
        mode.add_argument(name, type=Path)
    args = parser.parse_args()
    if args.mode == "cover":
        with args.coverage.open("x", encoding="utf-8") as file:
            json.dump(make_panel(args.root), file, sort_keys=True)
            file.write("\n")
    else:
        audit(args.root, args.coverage, args.primary, args.repeat, args.baseline, args.previous)
