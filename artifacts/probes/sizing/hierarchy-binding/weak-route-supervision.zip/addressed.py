import copy
import itertools
import json
import math
import sys
from pathlib import Path

import pyarrow.parquet as pq
import torch
from torch import nn
from torch.nn import functional as F

from binding_score import PANEL_HASH, WEIGHTS, load_model, sha
from cli import _eval_split_examples
from nanochat.diagnostics_data import TASKS, _hier_paths, _parse_hier_tree, hier_bind_answer

CORPUS = "e0bf1754ab8e0dc00b5f9b048496be258761f75496a01443112b5a3828d78e4c"
READOUT = "6b0c32483177b950544254b699bd6bd2fc908ad2319af153b3fce6ad49b6b85e"
PANEL_SEEDS = (5401, 5402, 5403)
CELLS = ("depth2", "depth3", "depth4")
FIT_ROWS, BATCH, EPOCHS = 1536, 16, 3


def leaf_map(doc):
    tree = doc.split(" BIND ", 1)[0]
    parsed = _parse_hier_tree(tree.split()[3:])
    assert parsed is not None
    return {tuple(int(key[-1]) for key in path): value for path, value in _hier_paths(parsed)}


def identity(doc):
    return tuple(sorted(leaf_map(doc).items()))


def write(path, data):
    with path.open("x", encoding="utf-8") as file:
        json.dump(data, file, allow_nan=False, separators=(",", ":"))
        file.write("\n")


def checked_corpus(prior):
    root = prior / "default/hier_bind"
    path = root / "manifest.json"
    assert sha(path) == CORPUS
    manifest = json.loads(path.read_bytes())
    for name, expected in manifest["sha256"].items():
        assert sha(root / name) == expected
    return root, manifest


def panel(prior, compared, target):
    spec = TASKS["hier_bind"]
    root, manifest = checked_corpus(prior)
    forbidden = set()

    def exclude(docs):
        ids = {identity(doc) for doc in docs}
        assert len(ids) == len(docs) // 2 and not ids.intersection(forbidden)
        forbidden.update(ids)

    for name in manifest["sha256"]:
        exclude(pq.read_table(root / name, columns=["text"]).column("text").to_pylist())
    older = prior / "baseline-panel.json"
    recent = compared / "readout-panel.json"
    assert sha(older) == PANEL_HASH and sha(recent) == READOUT
    for path in (older, recent):
        for cells in json.loads(path.read_bytes()).values():
            for rows in cells.values():
                exclude(rows)
    assert len(forbidden) == 2192

    result = {}
    for seed in PANEL_SEEDS:
        train, held, _ = _eval_split_examples(spec, n=24, seed=seed)
        _, deep, _ = _eval_split_examples(spec, n=24, seed=seed, dials={"depth": 3})
        result[seed] = dict(zip(CELLS, (train, held, deep), strict=True))
        for docs in result[seed].values():
            exclude(docs)
    assert len(forbidden) == 2300
    write(target, result)
    print("Locked 108 fresh trees across depths 2, 3 and 4", flush=True)


def parse(doc):
    prompt, answer = TASKS["hier_bind"].split_prompt(doc)
    assert hier_bind_answer(prompt) == answer
    bindings, query = prompt.split(" BIND ")[1].split(" PATH ")
    aliases = [int(token[-1]) for token in query.split()[:-1]]
    leaves = leaf_map(doc)
    gold, = [path for path, label in leaves.items() if label == answer]
    rows = {}
    for scope, a, k, b, j in (entry.split() for entry in bindings.split(" ; ")):
        pos = int("1" + scope[1:], 2) - 1
        assert pos not in rows
        rows[pos] = [[int(a[-1]), int(b[-1])], [int(k[-1]), int(j[-1])]]
    assert len(gold) == len(aliases) and set(rows) == set(range(2 ** len(gold) - 1))
    return aliases, [rows[i] for i in range(len(rows))], list(gold)


def tensors(docs):
    return tuple(torch.tensor(column) for column in zip(*(parse(doc) for doc in docs), strict=True))


def token_vectors(model, tok, values):
    with torch.no_grad():
        rows = [model._token_embedding().weight[tok.encode(" " + value)].mean(0).float() for value in values]
        out = F.normalize(torch.stack(rows), dim=-1) * 8
        assert out.shape == (2, 64) and not torch.equal(out[0], out[1])
        return out


class Binding(nn.Module):
    def __init__(self):
        super().__init__()
        self.query = nn.Linear(64, 8, bias=False)
        self.alias = nn.Linear(64, 8, bias=False)
        self.bound_key = nn.Linear(64, 8, bias=False)
        self.child = nn.Linear(64, 8, bias=False)

    def components(self, aliases, keys):
        scale = math.sqrt(8)
        return (self.query(aliases) @ self.alias(aliases).T / scale,
                self.bound_key(keys) @ self.child(keys).T / scale)

    def forward(self, aliases, keys, rows):
        alias, child = self.components(aliases, keys)
        alias_logp = F.log_softmax(alias[:, rows[..., 0, :]].movedim(0, -2), dim=-1)
        child_logp = F.log_softmax(child[rows[..., 1, :]], dim=-1)
        return torch.logsumexp(alias_logp[..., :, :, None] + child_logp[..., None, :, :], dim=-2)


def conditional_scores(logps, queries, sides, addressed):
    offsets = torch.arange(len(queries))
    parent = torch.zeros(len(queries), dtype=torch.long)
    scores = []
    for hop in range(queries.size(1)):
        if addressed:
            score = logps[offsets, parent, queries[:, hop]]
        else:
            lo = 2**hop - 1
            options = logps[offsets, lo:2*lo+1, queries[:, hop]]
            score = torch.logsumexp(options, dim=1) - math.log(lo + 1)
        scores.append(score)
        parent = 2 * parent + 1 + sides[:, hop]
    return torch.stack(scores, dim=1)


def fit(head, aliases, keys, data, order, addressed):
    queries, rows, sides = data
    opt = torch.optim.AdamW(head.parameters(), lr=.003, weight_decay=0)
    losses = []
    for batch in order:
        scores = conditional_scores(head(aliases, keys, rows[batch]), queries[batch], sides[batch], addressed)
        loss = F.nll_loss(scores.flatten(0, 1), sides[batch].flatten())
        opt.zero_grad(set_to_none=True)
        loss.backward()
        opt.step()
        losses.append(float(loss.detach()))
    steps = FIT_ROWS // BATCH
    assert len(losses) == steps * EPOCHS and all(map(math.isfinite, losses))
    return [sum(losses[:steps]) / steps, sum(losses[-steps:]) / steps]


@torch.inference_mode()
def evaluate(head, aliases, keys, data):
    cells = {}
    for region, (_queries, rows, _sides) in data.items():
        erased = rows.clone()
        erased[..., 1, :] = erased[..., 0, :]
        cells[region] = dict(rows=head(aliases, keys, rows).tolist(), erased=head(aliases, keys, erased).tolist())
    cases = torch.tensor([[[first, 1-first], [first ^ swap, (1-first) ^ swap]]
                          for first, swap in itertools.product((0, 1), repeat=2)])
    a, k = head.components(aliases, keys)
    return dict(cells=cells, exhaustive=head(aliases, keys, cases).tolist(),
                alias_scores=a.tolist(), key_scores=k.tolist())


def run(prior, panel_path, output, seed):
    root, _ = checked_corpus(prior)
    train_docs = pq.read_table(root / "train_000.parquet", columns=["text"]).column("text").to_pylist()[:FIT_ROWS]
    assert len(train_docs) == FIT_ROWS
    train = tensors(train_docs)
    raw_panel = json.loads(panel_path.read_bytes())
    evaluation = {cell: [doc for eval_seed in PANEL_SEEDS for doc in raw_panel[str(eval_seed)][cell]] for cell in CELLS}
    inputs = {cell: tensors(docs) for cell, docs in evaluation.items()}
    model, tok = load_model(prior, seed)
    lengths = {cell: sorted({len(tok.encode(doc, prepend=tok.get_bos_token_id())) for doc in docs})
               for cell, docs in evaluation.items()}
    aliases = token_vectors(model, tok, ("a0", "a1"))
    keys = token_vectors(model, tok, ("k0", "k1"))
    g = torch.Generator().manual_seed(seed + 41200)
    order = [batch for _ in range(EPOCHS) for batch in torch.randperm(FIT_ROWS, generator=g).split(BATCH)]
    torch.manual_seed(seed + 500)
    initial = Binding()
    outcomes = {}
    for arm in ("addressed", "pooled"):
        head = copy.deepcopy(initial)
        losses = fit(head, aliases, keys, train, order, arm == "addressed")
        outcomes[arm] = dict(epoch_loss=losses, **evaluate(head, aliases, keys, inputs))
        print(f"{seed} {arm}: first/last epoch losses {losses}", flush=True)
    write(output, dict(checkpoint=WEIGHTS[seed], panel_sha256=sha(panel_path), train_rows=FIT_ROWS,
                       updates=len(order), document_token_lengths=lengths, outcomes=outcomes))


if __name__ == "__main__":
    torch.set_num_threads(1)
    mode, *args = sys.argv[1:]
    if mode == "panel":
        panel(*map(Path, args))
    else:
        *paths, seed = args
        run(*map(Path, paths), int(seed))
