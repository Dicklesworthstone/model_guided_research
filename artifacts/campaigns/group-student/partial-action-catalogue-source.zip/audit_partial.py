"""Exhaustively recheck compatibility and recount the live oracle costs."""

import json
import sys
from collections import Counter
from pathlib import Path

from check_replay import follow, independently_named, load, verify_exhaustion, without_timings


def table_rows(cases, arms):
    current = arms["partial"]
    older = arms["batched"]
    if current["witnesses"] != older["witnesses"] or current["actions"] != older["actions"]:
        raise ValueError("The live matching arms disagree")
    for i, case in enumerate(cases):
        rows = current["actions"][str(i)]
        catalogue = dict(witnesses=current["witnesses"][str(i)], distinct_named_actions=len(rows),
                         action=rows[0] if len(rows) == 1 else None)
        yield dict(index=i, order=case["label_count"], catalogue=catalogue)


def audit(cohort, library, prior, prior_batched, primary, replay):
    profile = [load(Path(cohort) / f"{i:02}.json") for i in range(24)]
    old, first, second = map(load, (prior, primary, replay))
    if without_timings(first) != without_timings(second):
        raise ValueError("Hash seed or arm order changed a non-timing field")
    rows = list(table_rows(profile, first["matching"]))
    for row, previous in zip(rows, old["results"], strict=True):
        if any(previous["catalogue"][k] != v for k, v in row["catalogue"].items()):
            raise ValueError("Historical compatibility changed")
    pairs = verify_exhaustion(load(library)[2], profile, rows)
    historical = load(prior_batched)["cases"]
    totals = {arm: Counter() for arm in ("batched", "partial", "square")}
    evaluated = 0
    for i, case in enumerate(profile):
        expected = list(independently_named(case))
        for arm in ("batched", "partial"):
            sample = first["naming"][arm][i]
            if sample["index"] != i or sample["indexed"]["structures"] != 1:
                raise ValueError("An action was lost")
            for lane, totals_key in (("indexed", arm), ("square", "square")):
                record = sample[lane]
                if record["action"] != expected:
                    raise ValueError("Exact action table changed")
                if lane == "square" and record["paid"] != case["arms"]["active"]["paid"]:
                    raise ValueError("Prior square tape changed")
                if lane == "indexed" and record["paid"] != historical[i]["indexed"]["paid"]:
                    raise ValueError("Batched and partial naming tapes changed")
                for word, label in record["paid"]:
                    if label != follow(expected, word):
                        raise ValueError("Oracle reply failed")
                    # Count square once. Both live rereads are checked.
                    if lane != "square" or arm == "partial":
                        totals[totals_key].update(calls=1, symbols=len(word))
                totals[totals_key]["checked_transitions"] += 2 * len(expected[1])
            for split, answers in sample["indexed"]["answers"].items():
                if answers != [follow(expected, word) for word, _, _ in case[split]]:
                    raise ValueError("Wrong held-out endpoints")
                evaluated += len(answers)
    if (totals["partial"]["calls"], totals["partial"]["symbols"], totals["square"]["calls"]) != (165, 1551, 184):
        raise ValueError("Exact label and symbol floors did not reproduce")
    timing = []
    gates = []
    for sample in (first, second):
        sub = {}
        for arm in ("batched", "partial"):
            saved = sample["naming"][arm]
            sub[arm] = dict(matching_cpu_ns=sample["matching"][arm]["cpu_ns"],
                            naming_cpu_ns=sum(row["indexed"]["cpu_ns"] for row in saved),
                            square_cpu_ns=sum(row["square"]["cpu_ns"] for row in saved),
                            control_cpu_ns=sample["controls"][arm]["cpu_ns"])
        ratio = sub["batched"]["matching_cpu_ns"] / sub["partial"]["matching_cpu_ns"]
        gates.append(ratio >= 2)
        timing.append(dict(arms=sub, matching_ratio=ratio, parsing_cpu_ns=sample["parsing_cpu_ns"]))
    control = first["controls"]
    if (len(control["partial"]["witnesses"]) != 9
            or any(control["partial"][key] != control["batched"][key] for key in ("witnesses", "actions"))):
        raise ValueError("Wrong controls")
    e = control["partial"]["diagnostics"]["periods"]
    constants = first["matching"]["partial"]["diagnostics"]
    print(json.dumps(dict(
        cases=len(profile), matching_gate=all(gates), compatible_pairs=pairs, totals=totals,
        heldout_answers=evaluated, timing=timing, control_count=len(e),
        cycle_free_control=e["6"], period_case_pairs=constants["surviving_case_pair_slots"],
        exact_periods=sum(exact is not None for row in constants["periods"].values() for _, exact in row),
    ), sort_keys=True))


if __name__ == "__main__":
    audit(*sys.argv[1:])
