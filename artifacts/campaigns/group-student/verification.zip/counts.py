import json
import statistics
import sys
from collections import Counter
from pathlib import Path

data = Path(sys.argv[1])
score = json.loads(Path(sys.argv[2]).read_bytes())
arms = ("active", "random", "short_only")
overall = Counter()
cases = []
for r in score["results"]:
    c = json.loads((data / f"{r['index']:02}.json").read_bytes())
    row = {"index": r["index"], "group": r["group"], "primary": {}, "secondary": {}}
    for arm in arms:
        for section in ("primary", "secondary"):
            predicted = r["arms"][arm]["splits"][section]["answers"]
            for (word, label, lookup), answer in zip(c[section], predicted, strict=True):
                if str(answer) == label:
                    overall[(r["group"], arm, section, len(word) if section == "primary" else 0)] += 1
            row[section][arm] = r["arms"][arm]["splits"][section]["correct"]
    cases.append(row)
for g in ("s5", "a5"):
    outcomes = []
    for arm in arms:
        counts = [overall[(g, arm, "primary", n)] for n in (32,48,64)]
        outcomes.append((arm, counts, sum(counts), overall[(g, arm, "secondary", 0)]))
    print(g, outcomes)
print("delta",score["delta"],"floor",score["baseline_above_floor"],"verdict",score["verdict"])
print("sums", {arm: {part: sum(c[part][arm] for c in cases) for part in ("primary","secondary")} for arm in arms})
print("prior", sum(r["prior"] for r in score["results"]), "lookup", sum(r["lookup"] for r in score["results"]))
for arm in arms:
    values = [r["arms"][arm]["training"]["cuda_ms"] / 1000 for r in score["results"]]
    print(arm, f"timing {min(values):.3f}/{statistics.median(values):.3f}/{max(values):.3f}s")
print("paired win/tie/loss", dict(Counter((r["primary"]["active"] > r["primary"]["random"]) - (r["primary"]["active"] < r["primary"]["random"]) for r in cases)))
