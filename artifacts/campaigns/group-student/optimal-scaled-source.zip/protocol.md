# Exact planning with equivalent name histories merged

The initial frozen experiment at a765bfc solved order 6 in 24,889 work
units and exhausted 300,000 at orders 10 and 12. This is a successor
algorithm on the same published corpus. Keep the four arms, price, case
weights, work cap, replay, and original primary target fixed. Its separate
prediction is that the minimum at order 6 will match 1,917 and that the
same budget will now also solve order 10. Report order 12 and any failure.

The first solver cached states using the order in which names first appeared.
Simultaneously renumbering the known names across the compatible shapes
permutes the labels of the branches and preserves their possible queries
and costs. Canonicalize that order using the positions in the first
compatible shape. Memoize the best word and cost in that order. Build the
actual tree after choosing the optimal word, with branches using the
runtime's original reply ranks.

For a candidate word, the sum of the minimum residual naming costs of
its resulting shapes is a lower bound on the continuation. Per shape,
even a learner who knows the shape must still acquire at least all but
one of the unseen labels. Prune when the candidate's paid cost and that
lower bound reach the best full continuation already seen. Candidates
are tried in shortlex order, so a tie cannot replace the best word.

The DSR checks and comparison script are byte-identical to the initial
study. The manifest pins the new compiler and the initial verified result.
