import itertools
import json
import math
import random
import statistics
import sys
from pathlib import Path

import evidence
import mixture
import posterior as post
from address_fixtures import DIM, POOLS, encode, sha_json

SEEDS = (23211, 23212, 23213)
PHASES = (("train", 24), ("select", 12), ("test", 16))
BETA = tuple(i / 8 for i in range(9))
REGIMES = (("two_laws", ((2, 10), (6, 10))), ("one_law", ((4, 20),)))
UNIFORM = ((0, 20),)
ARMS = ("uniform", "single", "fixed", "pair", "selected", "oracle")
SELECT_GAIN = .05


def leaves_from_prior(rng, beta):
    log_z = evidence.log_partition(beta)

    def sample(size, path):
        if size == 0:
            yield path
            return
        log_weights = [log_z[left] + log_z[size - left - 1] for left in range(size)]
        top = max(log_weights)
        weights = [math.exp(value - top) for value in log_weights]
        remaining = rng.random() * math.fsum(weights)
        split = size - 1
        for i, weight in enumerate(weights[:-1]):
            remaining -= weight
            if remaining < 0.0:
                split = i
                break
        yield from sample(split, path + (0,))
        yield from sample(size - 1 - split, path + (1,))

    return set(sample(post.INTERNAL, ()))


def fresh():
    for seed in SEEDS:
        for law_id, (law, truth) in enumerate(REGIMES):
            for phase_id, (phase, count) in enumerate(PHASES):
                rng = random.Random(seed + 100151 + 1453 * law_id + 4627 * phase_id)
                for index in range(count):
                    draw = rng.randrange(20)
                    family = truth[0][0] if draw < truth[0][1] else truth[1][0]
                    leaf = leaves_from_prior(rng, BETA[family])
                    nodes = sorted({path[:i] for path in leaf for i in range(len(path) + 1)})
                    assert len(leaf) == 64 and len(nodes) == 127
                    namespace = tuple(rng.sample(range(DIM), DIM)), rng.randrange(1 << DIM)
                    keys = dict(zip(nodes, rng.sample(POOLS[1], len(nodes)), strict=True))
                    pointers = {path: encode(key, *namespace) for path, key in keys.items()}
                    rows = {keys[path]: () if path in leaf else (pointers[path + (0,)], pointers[path + (1,)])
                            for path in rng.sample(nodes, len(nodes))}
                    query = rng.choice(sorted(leaf))
                    yield seed, law, phase, index, rows, pointers[()], query, keys[query], family, namespace


def relative_evidence(versions):
    logs = [evidence.relative_log_likelihood(versions, beta) for beta in BETA]
    top = max(logs)
    return tuple(math.exp(x - top) for x in logs)


def objective(episodes, components):
    return statistics.mean(math.log(math.fsum(weights * row[index] for index, weights in components) / 20)
                           for row in episodes)


def estimate(masses):
    singleton = [(((i, 20),), objective(masses, ((i, 20),))) for i in range(len(BETA))]
    pair_grid = []
    for left, right in itertools.combinations(range(len(BETA)), 2):
        for weight in range(2, 20, 2):
            comp = ((left, weight), (right, 20 - weight))
            pair_grid.append((comp, objective(masses, comp)))
    one = max(singleton, key=lambda entry: entry[1])[0]
    two = max(pair_grid, key=lambda entry: entry[1])[0]
    fixed = mixture.fit([[row[i] for i in (0, 4, 8)] for row in masses])
    fixed_mix = tuple(zip((0, 4, 8), fixed["weights"], strict=True))
    return dict(single=one, pair=two, fixed=fixed_mix, single_grid=singleton, pair_grid=pair_grid,
                fixed_grid=fixed["grid"])


def posterior(versions, masses, law):
    terms = [count * masses[index] for index, count in law]
    total = math.fsum(terms)
    components = [post.probabilities(versions, BETA[index]) for index, _ in law]
    return {key: math.fsum(pdf[key] * (weight / total) for pdf, weight in zip(components, terms, strict=True))
            for key in components[0]}


def accuracy(documents, models):
    joint = [[] for _ in models]
    for doc in documents:
        masses = relative_evidence(doc["versions"])
        gold = doc["target"]
        for observations, law in zip(joint, models, strict=True):
            p = posterior(doc["versions"], masses, law)
            observations.append((-math.log(p[gold]),
                                 math.fsum((prob - (label == gold)) ** 2 for label, prob in p.items()),
                                 int(min(p, key=lambda label: (-p[label], label)) == gold),
                                 math.log(math.fsum(count * masses[index] for index, count in law) / 20)))
    return [dict(nll=statistics.mean(x[0] for x in rows), brier=statistics.mean(x[1] for x in rows),
                 correct=sum(x[2] for x in rows), log_evidence=statistics.mean(x[3] for x in rows)) for rows in joint]


def compare(rows):
    result = {}
    for seed in SEEDS:
        result[seed] = {}
        for name, truth in REGIMES:
            cohort = [doc for doc in rows if (doc["seed"], doc["regime"]) == (seed, name)]
            train, select, test = ([row for row in cohort if row["phase"] == phase] for phase, _ in PHASES)
            assert [len(train), len(select), len(test)] == [count for _, count in PHASES]
            fitted = estimate([relative_evidence(doc["versions"]) for doc in train])
            evidence_only = [relative_evidence(doc["versions"]) for doc in select]
            val_one = objective(evidence_only, fitted["single"])
            val_two = objective(evidence_only, fitted["pair"])
            choice = "pair" if val_two - val_one >= SELECT_GAIN else "single"
            models = (UNIFORM, fitted["single"], fitted["fixed"], fitted["pair"], fitted[choice], truth)
            scores = dict(zip(ARMS, accuracy(test, models), strict=True))
            result[seed][name] = dict(fit=fitted, selected=choice, val_gain=val_two-val_one, scores=scores)
    return result


def run(path):
    raw = []
    for seed, regime, phase, index, records, root, query, target, family, _ns in fresh():
        census = post.catalog(records, root, query)
        assert target in {leaf for leaf, _, _ in census["versions"]}
        raw.append(dict(seed=seed, regime=regime, phase=phase, index=index, target=target, family=family,
                        fixture=sha_json([records, root, query]), **census))
        if phase == "test" and index == 15:
            print(seed, regime, "completed 24 training, 12 selection and 16 held-out episodes", flush=True)
    assert len(raw) == 312
    with path.open("x", encoding="utf-8") as file:
        json.dump(dict(rows=raw, fits=compare(raw)), file, allow_nan=False, separators=(",", ":"))


if __name__ == "__main__":
    run(Path(sys.argv[1]))
