import json
import random
import sys
from collections import defaultdict
from functools import cache
from pathlib import Path

import posterior as post
from address_fixtures import DIM, POOLS, encode, sha_json
from topology import isometries

SEEDS = (25011, 25012, 25013)
FAMILIES = ("catalan", "yule")
CASES = 16
ARMS = ("random", "map_balance", "answer_greedy", "answer_lookahead")


def fresh():
    for seed in SEEDS:
        for salt, family in enumerate(FAMILIES):
            rng = random.Random(seed + 33091 + 1527 * salt)
            for index in range(CASES):
                leaves = post.generate_leaves(rng, family)
                nodes = sorted({leaf[:i] for leaf in leaves for i in range(len(leaf) + 1)})
                assert len(leaves) == 64 and len(nodes) == 127
                perm = tuple(rng.sample(range(DIM), DIM))
                signs = rng.randrange(1 << DIM)
                keys = dict(zip(nodes, rng.sample(POOLS[1], len(nodes)), strict=True))
                pointers = {path: encode(key, perm, signs) for path, key in keys.items()}
                rows = {keys[path]: () if path in leaves else (pointers[path + (0,)], pointers[path + (1,)])
                        for path in rng.sample(nodes, len(nodes))}
                query = rng.choice(sorted(leaves))
                yield seed, family, index, rows, pointers[()], query, keys[query], (perm, signs)


def versions(records, root, query):
    keys = set(records)
    pointers = {root, *(p for row in records.values() for p in row)}
    assert len(keys) == len(pointers) == 1 + sum(map(len, records.values())) == 127
    eligible = []
    examined = 0
    for lut, x0, p0 in isometries(keys, pointers, ()):
        examined += 1
        start = lut[root ^ p0] ^ x0
        node = start
        for alias in query:
            row = records[node]
            if not row:
                break
            node = lut[row[alias] ^ p0] ^ x0
        else:
            if records[node]:
                continue
            visited = [start]
            for key in visited:
                visited.extend(lut[ptr ^ p0] ^ x0 for ptr in records[key])
            if len(visited) == len(keys):
                order = tuple(lut[1 << j].bit_length() - 1 for j in range(DIM))
                eligible.append((order, node))
    assert examined == 40320 and eligible
    key_base, = set(POOLS[1]) - keys
    parity = min(pointers).bit_count() % 2
    ptr_base, = set(POOLS[parity]) - pointers
    return key_base, ptr_base, eligible


def partitions(keys, version_list, x0, p0):
    all_bits = (1 << len(version_list)) - 1
    cols = [[0] * DIM for _ in range(DIM)]
    for i, (perm, _) in enumerate(version_list):
        for bit, src in enumerate(perm):
            cols[bit][src] |= 1 << i
    seen = set()
    tests = []
    for key in sorted(keys):
        relative = key ^ x0
        for bit, sources in enumerate(cols):
            mask = sum(word for src, word in enumerate(sources) if (relative >> src) & 1)
            if (p0 >> bit) & 1:
                mask ^= all_bits
            canonical = min(mask, mask ^ all_bits)
            if canonical and canonical not in seen:
                seen.add(canonical)
                tests.append((key, bit, mask))
    return tests


def assess(answers, tests, truth_index, rng_seed):
    all_bits = (1 << len(answers)) - 1
    label_groups = defaultdict(int)
    for i, answer in enumerate(answers):
        label_groups[answer] |= 1 << i
    group = [label_groups[label] for label in answers]
    actual_bit = 1 << truth_index

    def certificate(state):
        return state != 0 and not (state & ~group[(state & -state).bit_length() - 1])

    def cert_mass(state):
        return state.bit_count() if certificate(state) else 0

    @cache
    def choices(state):
        seen = set()
        options = []
        for key, bit, test in tests:
            yes = state & test
            no = state ^ yes
            canonical = min(yes, no)
            if canonical and canonical not in seen:
                seen.add(canonical)
                options.append((key, bit, yes, no))
        return options

    def immediate(yes, no):
        return cert_mass(yes) + cert_mass(no)

    @cache
    def best_one(state):
        if certificate(state):
            return state.bit_count()
        return max((immediate(yes, no) for _, _, yes, no in choices(state)), default=0)

    @cache
    def pick(method, state, budget):
        available = choices(state)
        if not available or certificate(state):
            return None
        if method == "random":
            return random.Random(rng_seed + state + 11927 * budget).choice(available)

        def utility(option):
            _, _, yes, no = option
            balance = min(yes.bit_count(), no.bit_count())
            gain = immediate(yes, no)
            if method == "map_balance":
                return (balance,)
            if method == "answer_greedy" or budget == 1:
                return gain, balance
            assert method == "answer_lookahead" and budget == 2
            return best_one(yes) + best_one(no), gain, balance

        return max(available, key=utility)

    def mass(method, state, budget):
        option = pick(method, state, budget) if budget else None
        if option is None:
            return cert_mass(state)
        _, _, yes, no = option
        return mass(method, yes, budget - 1) + mass(method, no, budget - 1)

    result = {}
    for budget in (1, 2):
        cell = {}
        for method in ARMS:
            state = all_bits
            observed = []
            for left in range(budget, 0, -1):
                next_probe = pick(method, state, left)
                if next_probe is None:
                    break
                key, coordinate, yes, no = next_probe
                bit = bool(yes & actual_bit)
                observed.append([key, coordinate, int(bit)])
                state = yes if bit else no
                assert state & actual_bit
            cert = answers[(state & -state).bit_length() - 1] if certificate(state) else None
            assert cert is None or cert == answers[truth_index]
            cell[method] = dict(uniform_certified=mass(method, all_bits, budget), probes=observed,
                                answer=cert, surviving_maps=state.bit_count(),
                                surviving_answers=sum(bool(state & v) for v in label_groups.values()))
        result[str(budget)] = cell
    return result


def planted():
    toy = (0, 0, 0, 1, 1, 2, 2, 3)
    masks = (15, 3, 48, 32)
    return assess(toy, [(j, 0, mask) for j, mask in enumerate(masks)], 0, 10)


def run(output):
    rows = []
    for seed, family, index, records, root, query, target, namespace in fresh():
        x0, p0, book = versions(records, root, query)
        perm, signs = namespace
        assert encode(x0, perm, signs) == p0
        truth, = (i for i, (mapping, _) in enumerate(book) if mapping == perm)
        answers = [answer for _, answer in book]
        assert answers[truth] == target
        tests = partitions(records, book, x0, p0)
        policies = assess(answers, tests, truth, seed + 223 * index)
        for cell in policies.values():
            for out in cell.values():
                assert all((encode(key, perm, signs) >> coordinate) & 1 == bit
                           for key, coordinate, bit in out["probes"])
        rows.append(dict(seed=seed, family=family, index=index, fixture=sha_json([records, root, query]),
                        target=target, versions=book, base=[x0, p0], probes=len(tests), policies=policies))
        if index == CASES - 1:
            print(seed, family, CASES, flush=True)
    assert len(rows) == 96
    with output.open("x", encoding="utf-8") as file:
        json.dump(dict(rows=rows, planted=planted()), file, separators=(",", ":"))


if __name__ == "__main__":
    run(Path(sys.argv[1]))
