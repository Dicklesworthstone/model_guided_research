"""Isolate attention initialization and gain coordinates on held-out Python files."""

import argparse
import hashlib
import json
import math
import statistics
import sysconfig
from copy import deepcopy
from pathlib import Path
from time import perf_counter, process_time

import torch
import torch.nn.functional as F
from torch import nn

from nanochat.gpt import GPT, GPTConfig
from nanochat.surreal_torch import SurrealLayer

ARMS = ("dense_default", "dense_output", "dense_matched", "linear_gain", "log_gain")
PROJECTIONS = ("c_q", "c_k", "c_v", "c_proj")
LENGTH = 48
BATCH = 8
VOCAB = list(range(256))
RUNGS = (192, 384, 768)
PROBE_SEEDS = (91, 92, 93)
PAIR_SEEDS = tuple(range(300, 308))
PROBE_CORPUS = 90210
PAIR_CORPUS = 64019
WORTHWHILE = 0.10
OFF_FLOOR = 0.02
FILES = {
    PROBE_CORPUS: {
        "train": ("ast.py", "collections/__init__.py", "dataclasses.py", "dis.py", "functools.py", "tokenize.py"),
        "val": ("pprint.py", "textwrap.py"),
        "test": ("calendar.py",),
    },
    PAIR_CORPUS: {
        "train": ("argparse.py", "configparser.py", "contextlib.py", "enum.py", "random.py", "typing.py"),
        "val": ("inspect.py", "json/encoder.py"),
        "test": ("difflib.py", "string.py"),
    },
}


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


class LinearGain(nn.Module):
    def __init__(self, direction):
        super().__init__()
        self.direction = nn.Parameter(direction.clone())
        self.gain = nn.Parameter(torch.ones(direction.shape[0], 1))

    def forward(self, x):
        return F.linear(x, self.gain * F.normalize(self.direction, dim=1))


def dataset(seed):
    root = Path(sysconfig.get_path("stdlib"))
    generator = torch.Generator().manual_seed(seed)
    hashes = {}
    prefixes = {}
    for split, relative_paths in FILES[seed].items():
        rows = []
        for relative in relative_paths:
            raw = (root / relative).read_bytes()
            hashes[relative] = hashlib.sha256(raw).hexdigest()
            limit = 512 if split == "train" else 96
            width = LENGTH + 1
            count = len(raw) // width
            for index in torch.randperm(count, generator=generator)[:limit].tolist():
                rows.append(tuple(raw[index * width : index * width + width]))
        prefixes[split] = rows
    # Boilerplate can repeat across files. Discard exact train matches
    # from both eval sets and exact validation matches from the later test.
    train_rows = set(prefixes["train"])
    prefixes["val"] = [row for row in prefixes["val"] if row not in train_rows]
    earlier = train_rows | set(prefixes["val"])
    prefixes["test"] = [row for row in prefixes["test"] if row not in earlier]
    if any(len(rows) < 64 for rows in prefixes.values()):
        raise ValueError("Insufficient disjoint windows")
    packed = {key: torch.tensor(rows) for key, rows in prefixes.items()}
    train_counts = torch.bincount(packed["train"][:, 1:].reshape(-1), minlength=len(VOCAB)).double()
    prior = (train_counts + 1) / (train_counts.sum() + len(VOCAB))
    card = {
        "seed": seed,
        "vocab": VOCAB,
        "windows": {key: len(rows) for key, rows in prefixes.items()},
        "files": FILES[seed],
        "file_sha256": hashes,
        "hash": digest(prefixes),
        "unigram_nll": {key: float(-prior[packed[key][:, 1:]].log().mean()) for key in ("val", "test")},
    }
    return packed, card


def build(seed):
    torch.manual_seed(seed)
    base = GPT(GPTConfig(sequence_len=LENGTH, vocab_size=len(VOCAB), n_layer=2, n_head=2, n_kv_head=2, n_embd=64))
    base.init_weights()
    generator = torch.Generator().manual_seed(seed + 20_000)
    directions = [
        {name: torch.randn(getattr(block.attn, name).weight.shape, generator=generator) for name in PROJECTIONS}
        for block in base._blocks()
    ]
    return base, directions


def make_arm(base, directions, arm):
    model = deepcopy(base)
    with torch.no_grad():
        for block, weights in zip(model._blocks(), directions, strict=True):
            for name, direction in weights.items():
                if arm == "dense_matched" or (arm == "dense_output" and name == "c_proj"):
                    getattr(block.attn, name).weight.copy_(F.normalize(direction, dim=1))
                elif arm == "linear_gain":
                    setattr(block.attn, name, LinearGain(direction))
                elif arm == "log_gain":
                    projection = SurrealLayer(direction.shape[1], direction.shape[0], bias=False)
                    projection.weight_v.copy_(direction)
                    setattr(block.attn, name, projection)
    return model


@torch.no_grad()
def equal_projections(first, second):
    generator = torch.Generator().manual_seed(381)
    for a, b in zip(first._blocks(), second._blocks(), strict=True):
        for name in PROJECTIONS:
            x = torch.randn(17, 64, generator=generator)
            torch.testing.assert_close(getattr(a.attn, name)(x), getattr(b.attn, name)(x), rtol=1e-6, atol=1e-6)


def controls():
    base, directions = build(683)
    matched = make_arm(base, directions, "dense_matched")
    ordinary = make_arm(base, directions, "linear_gain")
    exponent = make_arm(base, directions, "log_gain")
    equal_projections(matched, ordinary)
    equal_projections(matched, exponent)
    with torch.no_grad():
        exponent._blocks()[0].attn.c_proj.weight_s[0, 0] += math.log(1.25)
    try:
        equal_projections(matched, exponent)
    except AssertionError:
        pass
    else:
        raise AssertionError("Projection control accepted a planted gain mismatch")
    net = build(683)[0]
    rows = torch.zeros(3, LENGTH + 1, dtype=torch.long)
    if abs(evaluate(net, rows) - math.log(len(VOCAB))) > 1e-6:
        raise AssertionError("Uniform model NLL disagrees with log vocabulary size")
    return {"matched_projection_checks": 16, "planted_gain_rejected": True, "uniform_nll": math.log(len(VOCAB))}


@torch.inference_mode()
def evaluate(model, rows):
    model.eval()
    total = 0.0
    for batch in rows.split(16):
        x, y = batch[:, :-1], batch[:, 1:].contiguous()
        total += float(model(x, y, loss_reduction="sum"))
    model.train()
    return total / (len(rows) * LENGTH)


def train(base, directions, arm, packed, seed, rungs):
    model = make_arm(base, directions, arm)
    optimizer = torch.optim.AdamW(model.parameters(), lr=0.004, betas=(0.8, 0.95), weight_decay=0.0)
    generator = torch.Generator().manual_seed(seed + 40_000)
    take = torch.randint(len(packed["train"]), (rungs[-1], BATCH), generator=generator)
    samples = {}
    cpu = elapsed = 0.0
    started_cpu, started_wall = process_time(), perf_counter()
    for step, indices in enumerate(take, 1):
        batch = packed["train"][indices]
        loss = model(batch[:, :-1], batch[:, 1:].contiguous())
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        optimizer.step()
        if step in rungs:
            cpu += process_time() - started_cpu
            elapsed += perf_counter() - started_wall
            if not bool(loss.isfinite()):
                raise ValueError(f"Nonfinite training loss for {arm}, seed {seed}")
            samples[str(step)] = {split: evaluate(model, packed[split]) for split in ("val", "test")}
            started_cpu, started_wall = process_time(), perf_counter()
    return {
        "rungs": samples,
        "cpu_s": cpu,
        "elapsed_s": elapsed,
        "batch_hash": digest(take.tolist()),
        "tokens": rungs[-1] * BATCH * LENGTH,
        "parameters": sum(parameter.numel() for parameter in model.parameters()),
    }


def sizing():
    checks = controls()
    packed, card = dataset(PROBE_CORPUS)
    observations = {}
    for seed in PROBE_SEEDS:
        base, directions = build(seed)
        observations[str(seed)] = train(base, directions, "dense_default", packed, seed, RUNGS)
    floor = card["unigram_nll"]["val"] - OFF_FLOOR
    chosen = next(
        (step for step in RUNGS if all(row["rungs"][str(step)]["val"] <= floor for row in observations.values())),
        None,
    )
    return {"corpus": card, "runs": observations, "selected_steps": chosen, "controls": checks}


def comparison(probe):
    step = probe["selected_steps"]
    if step is None:
        return {"selected_steps": None, "stop": "No sizing rung cleared the unigram gate"}
    if step not in RUNGS:
        raise ValueError("Comparison rung is outside the locked ladder")
    packed, card = dataset(PAIR_CORPUS)
    if probe["corpus"]["hash"] == card["hash"]:
        raise ValueError("Reused sizing corpus")
    runs = {}
    for index, seed in enumerate(PAIR_SEEDS):
        base, directions = build(seed)
        order = ARMS[index % len(ARMS) :] + ARMS[: index % len(ARMS)]
        if index % 2:
            order = order[::-1]
        cells = {arm: train(base, directions, arm, packed, seed, (step,)) for arm in order}
        if len({row["batch_hash"] for row in cells.values()}) != 1:
            raise ValueError("Paired training batches differ")
        runs[str(seed)] = cells
        print(f"Completed paired seed {seed}", flush=True)
    return {"selected_steps": step, "corpus": card, "runs": runs}


def summarize(data):
    step = data["selected_steps"]
    if step is None:
        return data
    rows = data["runs"]
    if set(rows) != set(map(str, PAIR_SEEDS)) or any(set(arms) != set(ARMS) for arms in rows.values()):
        raise ValueError("Incomplete fixed-seed comparison")
    metric = {arm: [row[arm]["rungs"][str(step)]["val"] for row in rows.values()] for arm in ARMS}
    contrasts = {}
    for left, right in (
        ("log_gain", "linear_gain"),
        ("log_gain", "dense_matched"),
        ("dense_matched", "dense_default"),
        ("dense_output", "dense_default"),
        ("log_gain", "dense_default"),
    ):
        diffs = [a - b for a, b in zip(metric[left], metric[right], strict=True)]
        mean = statistics.mean(diffs)
        sd = statistics.stdev(diffs)
        half = 2.364624251 * sd / math.sqrt(len(diffs))
        contrasts[f"{left}-minus-{right}"] = {"mean": mean, "ci95": [mean - half, mean + half], "sd": sd}
    primary = contrasts["log_gain-minus-linear_gain"]
    floor = data["corpus"]["unigram_nll"]["val"] - OFF_FLOOR
    floor_cleared = all(nll <= floor for nll in metric["dense_default"])
    return {
        "selected_steps": step,
        "paired_seeds": len(rows),
        "baseline_off_floor": floor_cleared,
        "corpus": data["corpus"],
        "means": {
            arm: {
                "val_nll": statistics.mean(metric[arm]),
                "test_nll": statistics.mean(row[arm]["rungs"][str(step)]["test"] for row in rows.values()),
                "cpu_s": statistics.mean(row[arm]["cpu_s"] for row in rows.values()),
                "elapsed_s": statistics.mean(row[arm]["elapsed_s"] for row in rows.values()),
                "tokens": next(iter(rows.values()))[arm]["tokens"],
                "parameters": next(iter(rows.values()))[arm]["parameters"],
            }
            for arm in ARMS
        },
        "paired_val_nll": contrasts,
        "worthwhile_gain_verified": floor_cleared and primary["ci95"][1] < -WORTHWHILE,
        "worthwhile_gain_excluded": floor_cleared and primary["ci95"][0] > -WORTHWHILE,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=("size", "compare", "summary"))
    parser.add_argument("output", type=argparse.FileType("x"))
    parser.add_argument("--input", type=argparse.FileType("r"))
    args = parser.parse_args()
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    if args.stage == "size":
        output = sizing()
    elif args.stage == "compare":
        output = comparison(json.load(args.input))
    else:
        output = summarize(json.load(args.input))
    with args.output:
        json.dump(output, args.output, indent=2, sort_keys=True, allow_nan=False)


if __name__ == "__main__":
    main()
