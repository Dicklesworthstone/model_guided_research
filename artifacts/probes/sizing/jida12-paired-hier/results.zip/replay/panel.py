import hashlib
import json
import sys
from pathlib import Path

import pyarrow.parquet as pq

sys.path.insert(0, str(Path.cwd()))
from cli import _eval_split_examples
from nanochat.diagnostics_data import TASKS
from nanochat.tokenizer import train_task_tokenizer

root = Path(sys.argv[1])
task_dir = root / "data" / "hier_paired"
spec = TASKS["hier_paired"]
observed = set()
panel = {"in_range": [], "held_out": []}
tokenizer = train_task_tokenizer([task_dir / "train_000.parquet"], 512)

def check_pairs(docs, depth):
    for left, right in zip(docs[::2], docs[1::2], strict=True):
        tree, first = left.split(" PATH ", 1)
        other_tree, second = right.split(" PATH ", 1)
        path1, answer1 = first.split(" OUT ", 1)
        path2, answer2 = second.split(" OUT ", 1)
        assert tree == other_tree and tree not in observed
        observed.add(tree)
        assert path1 != path2 and answer1 != answer2 and len(path1.split()) == len(path2.split()) == depth
        assert spec.checker(left) and spec.checker(right)
        yield tree, (answer1, answer2), (left, right)

splits = {}
for name, depth in (("train_000.parquet", 2), ("val_000.parquet", 2), ("heldout/test_000.parquet", 3)):
    docs = pq.read_table(task_dir / name, columns=["text"]).column("text").to_pylist()
    splits[name] = sum(1 for _ in check_pairs(docs, depth))

for seed in (0, 1, 2):
    in_range, held_out, _ = _eval_split_examples(spec, n=24, seed=seed)
    for region, docs, depth in (("in_range", in_range, 2), ("held_out", held_out, 3)):
        for index, (tree, answers, pair) in enumerate(check_pairs(docs, depth)):
            # Last displayed value uses only the shared tree.
            blind = next(word for word in reversed(tree.split()) if word.startswith("v"))
            lengths = [len(tokenizer.encode(doc, prepend=tokenizer.get_bos_token_id())) for doc in pair]
            assert max(lengths) <= 321, f"{region} pair exceeds the frozen context: {lengths}"
            panel[region].append({
                "eval_seed": seed, "pair_index": index, "documents": pair, "answers": answers,
                "full_doc_tokens": lengths, "exact_both": True,
                "query_blind_both": all(answer == blind for answer in answers),
            })
assert len(observed) == 32000 + 72
assert all(len(pairs) == 36 for pairs in panel.values())
assert all(not row["query_blind_both"] for pairs in panel.values() for row in pairs)
report = {
    "train_validation_test_tree_counts": splits, "evaluation": panel, "tokenizer_vocabulary": tokenizer.get_vocab_size(),
    "all_tree_count": len(observed), "train_context": 320,
}
out = root / "panel.json"
with out.open("x", encoding="utf-8") as handle:
    handle.write(json.dumps(report, indent=2) + "\n")
print(json.dumps({
    "corpus_trees": splits, "eval_pairs": {k: len(v) for k, v in panel.items()}, "unique_trees": len(observed),
    "max_tokens": {k: max(max(row["full_doc_tokens"]) for row in v) for k, v in panel.items()},
    "oracle_both": {k: sum(row["exact_both"] for row in v) for k, v in panel.items()},
    "blind_both": {k: sum(row["query_blind_both"] for row in v) for k, v in panel.items()},
}))
