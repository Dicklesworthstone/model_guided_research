"""Independently reconstruct the complete catalogue and audit every paid query."""

import hashlib
import json
import sys
from collections import Counter, deque
from itertools import product
from pathlib import Path

from check_replay import follow, group_is_valid, independently_named, load

ANCHORS = ("00", "01", "10", "11")
ARMS = ("square", "short", "length_first", "credit")
SHORT = tuple("".join(marks) for n in (2, 3, 4) for marks in product("01", repeat=n))


def rooted(table, a, b):
    states = [0]
    inverse = {0: 0}
    for source in states:
        for target in (table[source][a], table[source][b]):
            if target not in inverse:
                inverse[target] = len(states)
                states.append(target)
    if len(states) == len(table):
        return tuple((inverse[table[x][a]], inverse[table[x][b]]) for x in states)
    return None


def reconstruct(library):
    gap, package, tables = library
    sorted_ids = [(n, i) for n, count in ((60, 13), (120, 47)) for i in range(1, count + 1)]
    if (gap, package) != ("4.16.1", "1.7.0") or [tuple(t[:2]) for t in tables] != sorted_ids:
        raise ValueError("Incomplete catalogue inventory")
    by_order = {60: set(), 120: set()}
    for n, _, table in tables:
        if not group_is_valid(n, table):
            raise ValueError("An input table violated the group axioms")
        for a, b in product(range(n), repeat=2):
            shape = rooted(table, a, b)
            if shape is not None:
                by_order[n].add(shape)
    return {n: sorted(graphs) for n, graphs in by_order.items()}


def strip_timing(value):
    if isinstance(value, dict):
        return {k: strip_timing(v) for k, v in value.items() if not k.endswith("_ns")}
    if isinstance(value, list):
        return [strip_timing(v) for v in value]
    return value


def position(shape, word):
    state = 0
    for mark in word:
        state = shape[state][int(mark)]
    return state


def access(shape):
    # Independent multi-source search, seeded in shortlex order.
    queued = deque()
    seen = set()
    for word in ANCHORS:
        state = position(shape, word)
        if state not in seen:
            queued.append((state, word))
            seen.add(state)
    while queued:
        state, word = queued.popleft()
        yield state, word
        for mark, target in enumerate(shape[state]):
            if target not in seen:
                seen.add(target)
                queued.append((target, word + str(mark)))


def filter_shapes(fitting, word, answer):
    accepted = []
    for g, names, locations in fitting:
        state = position(g, word)
        if names.get(state, answer) == answer and locations.get(answer, state) == state:
            names[state] = answer
            locations[answer] = state
            accepted.append((g, names, locations))
    return accepted


def completion_difference(first, second, n):
    g, h = first[0], second[0]

    def completed(entry):
        known = {state: int(label) for state, label in entry[1].items()}
        spare = iter(sorted(set(range(n)).difference(known.values())))
        return [known[i] if i in known else next(spare) for i in range(n)]

    left, right = completed(first), completed(second)
    queue = deque((word, position(g, word), position(h, word)) for word in ANCHORS)
    visited = set()
    while queue:
        word, a, b = queue.popleft()
        if left[a] != right[b]:
            return word
        if (a, b) not in visited:
            visited.add((a, b))
            queue.extend((word + str(mark), g[a][mark], h[b][mark]) for mark in range(2))
    raise ValueError("Two catalogue actions gave identical completed observations")


def verify_choice(arm, fitting, seen, free, event, prepared, n):
    words = set(SHORT)
    words.update(word for _, word in prepared[id(fitting[0][0])])
    words.add(completion_difference(fitting[0], fitting[1], n))
    size = len(fitting)
    states = []
    for graph, labels, _ in fitting:
        depths = {state: len(word) for state, word in prepared[id(graph)]}
        unobserved = sorted((depth for state, depth in depths.items() if state not in labels), reverse=True) + [0, 0]
        states.append((graph, labels, depths, unobserved[0], unobserved[1]))

    choices = []
    for word in words.difference(seen):
        counts: Counter = Counter()
        debt = len(word) * size
        for graph, labels, depths, largest, second in states:
            value = position(graph, word)
            label = labels.get(value)
            counts[label] += 1
            if arm == "credit" and label is None:
                # Recompute the lower bound after observing this state.
                depth = depths[value]
                remaining_max = second if depth == largest else largest
                debt -= depth + remaining_max - largest
        fresh = counts.pop(None, 0)
        worst = max(fresh, max(counts.values(), default=0) * free)
        if worst < free * size:
            choices.append((debt, size - fresh if free > 1 else size, worst, len(word), word))
    if not choices:
        raise ValueError("The independent shortlist contains no valid probe")
    minimax = min(choice[2] for choice in choices)
    if arm == "credit":
        best = min(choice for choice in choices if choice[2] <= 2 * minimax)
    else:
        best = min(choices, key=lambda choice: (choice[3], choice[2], choice[4]))
    debt, wasted, worst, _, word = best
    if (event["word"], event["worst"], event["minimax"], event["movement_debt"], event["wasted_reads"]) != (
        word, worst, minimax, debt, wasted
    ):
        raise ValueError(f"The computed {arm} choice disagrees with the independent shortlist")


def verify_trace(arm, graphs, initial, result, n, cap, prepared):
    tape = result["tape"]
    events = result["events"]
    if len(events) > len(tape) or [[e["word"], e["answer"]] for e in events] != tape[:len(events)]:
        raise ValueError("Trace and paid tape disagree")
    fitting = [(graph, {}, {}) for graph in graphs]
    named = set(initial.values())
    seen_words = set(initial)
    expected_tail = None
    for word, answer in initial.items():
        fitting = filter_shapes(fitting, word, answer)
    for event in events:
        word, answer = event["word"], event["answer"]
        before = len(fitting)
        if before == 0 or word in seen_words or event["before"] != before:
            raise ValueError("Invalid version-space state")
        if event["phase"] == "structure":
            if before <= 1 or len(seen_words) >= cap or expected_tail is not None:
                raise ValueError("Wrong structural probe")
            buckets = Counter(names.get(position(graph, word)) for graph, names, _ in fitting)
            fresh = buckets.pop(None, 0)
            free = max(1, n - len(named))
            worst = max(fresh, free * max(buckets.values(), default=0))
            if event["worst"] != worst or worst >= before * free:
                raise ValueError("Probe failed its version-space reduction")
            if arm in {"credit", "length_first"}:
                verify_choice(arm, fitting, seen_words, free, event, prepared, n)
        elif event["phase"] == "naming":
            if before != 1:
                raise ValueError("Named states before determining the structure")
            if expected_tail is None:
                graph, names, _ = fitting[0]
                expected_tail = deque([w for state, w in access(graph) if state not in names][:-1])
            if not expected_tail or expected_tail.popleft() != word or answer in named:
                raise ValueError("Naming did not use the minimal unread access words")
        else:
            raise ValueError(f"Unrecognized phase in {arm}")
        fitting = filter_shapes(fitting, word, answer)
        named.add(answer)
        seen_words.add(word)
        if event["after"] != len(fitting):
            raise ValueError("Incorrect feasible-action count after oracle reply")
    terminal = result["terminal"]
    if terminal == "unique":
        if len(fitting) != 1 or len(named) < n - 1 or expected_tail or len(tape) != len(events):
            raise ValueError("Premature uniqueness or unpaid coverage")
    elif terminal != "cap" or len(fitting) <= 1 or len(seen_words) != cap or expected_tail is not None:
        raise ValueError("Incorrect fallback transition")


def outside_action(table, marks):
    order = len(table)
    names = [str((17 * x + 5) % order) for x in range(order)]
    rows = {names[x]: [names[table[x][mark]] for mark in marks] for x in range(order)}
    return [names[0], [rows[str(i)] for i in range(order)]]


def movement_floor(truth, initial):
    anchors = set(initial.values())
    distances = dict.fromkeys(anchors, 2)
    queue = deque(sorted(anchors))
    while queue:
        state = queue.popleft()
        for target in truth[1][int(state)]:
            if target not in distances:
                distances[target] = distances[state] + 1
                queue.append(target)
    if len(distances) != len(truth[1]):
        raise ValueError("An anchor did not reach the complete action")
    remaining = sorted(depth for name, depth in distances.items() if name not in anchors)
    return sum(map(len, initial)) + sum(remaining[:-1])


def audit(cohort, input_path, prior_path, prior_four, first_path, second_path):
    library, previous, before, first, second = map(load, (input_path, prior_path, prior_four, first_path, second_path))
    if strip_timing(first) != strip_timing(second):
        raise ValueError("Cross-seed replay changed a non-timing field")
    graphs = reconstruct(library)
    expected = hashlib.sha256(json.dumps(graphs, separators=(",", ":"), sort_keys=True).encode()).hexdigest()
    if first["shape_digest"] != expected or first["shape_counts"] != {str(n): len(v) for n, v in graphs.items()}:
        raise ValueError("A marked action was omitted or duplicated")
    prepared = {id(g): list(access(g)) for group in graphs.values() for g in group}
    tables = {(n, i): table for n, i, table in library[2]}
    counts = {panel: {arm: Counter() for arm in ARMS} for panel in ("historical", "outside")}
    maximum_excess = {arm: 0 for arm in ARMS}
    floors = {panel: Counter() for panel in counts}
    transitions = predictions = 0
    if len(first["rows"]) != 30:
        raise ValueError("Wrong number of cases")
    for i, row in enumerate(first["rows"]):
        n = row["order"]
        if row["index"] != i:
            raise ValueError("Cases were reordered")
        initial = row["anchors"]
        if i < 24:
            panel = "historical"
            source = load(Path(cohort) / f"{i:02}.json")
            truth = list(independently_named(source))
            heldout = [entry[:2] for split in ("primary", "secondary") for entry in source[split]]
            if row["control"] is not None:
                raise ValueError("A historical case was replaced")
        else:
            panel = "outside"
            number, a, b = previous["control_pairs"][str(i - 24)]
            if (n, row["control"]) != (60 if i < 27 else 120, [number, a, b]):
                raise ValueError("An outside control was replaced")
            truth = outside_action(tables[n, number], (a, b))
            heldout = []
        if n != len(truth[1]) or initial != {word: follow(truth, word) for word in ANCHORS}:
            raise ValueError("Wrong public anchors or action size")
        floor_reads = len(ANCHORS) + n - 1 - len(set(initial.values()))
        floor_symbols = movement_floor(truth, initial)
        floors[panel].update(reads=floor_reads, symbols=floor_symbols)
        for arm in ARMS:
            report = row["arms"][arm]
            if arm in {"square", "short"} and strip_timing(report) != strip_timing(before["rows"][i]["arms"][arm]):
                raise ValueError("The live incumbent's trace changed")
            paid = [*initial.items(), *report["tape"]]
            if len({word for word, _ in paid}) != len(paid) or len(paid) < floor_reads:
                raise ValueError("Duplicate payment or impossible naming cost")
            if report["action"] != truth or any(follow(truth, word) != label for word, label in paid):
                raise ValueError("Wrong exact result or recorded oracle reply")
            if any(follow(report["action"], word) != label for word, label in heldout):
                raise ValueError("Incorrect held-out observation")
            if arm != "square":
                verify_trace(arm, graphs[n], initial, report, n, n + 24, prepared)
            extra = len(paid) - floor_reads
            maximum_excess[arm] = max(maximum_excess[arm], extra)
            zero = sum(word.count("0") for word, _ in paid)
            one = sum(word.count("1") for word, _ in paid)
            if zero + one < floor_symbols:
                raise ValueError("Symbol cost fell below its exact lower bound")
            counts[panel][arm].update(reads=len(paid), symbols=zero + one, excess_reads=extra, zeros=zero, ones=one,
                                      excess_symbols=zero + one - floor_symbols,
                                      fallback=int(report["terminal"] == "cap"))
            transitions += 2 * n
            predictions += len(heldout)

    control = first["rows"][0]
    forced = first["fallback"]
    if forced["action"] != control["arms"]["square"]["action"] or forced["tape"] != control["arms"]["square"]["tape"]:
        raise ValueError("Forced fallback changed the live square policy")
    verify_trace("forced", graphs[control["order"]], control["anchors"], forced, control["order"], 4, prepared)
    timings = []
    for sample in (first, second):
        timing = {}
        for panel, rows in (("historical", sample["rows"][:24]), ("outside", sample["rows"][24:])):
            timing[panel] = {metric: {arm: sum(row["arms"][arm][metric] for row in rows) for arm in ARMS}
                             for metric in ("cpu_ns", "wall_ns")}
        timings.append(dict(**timing, build=sample["build"]))
    candidate, incumbent = (counts["historical"][arm] for arm in ("credit", "short"))
    print(json.dumps(dict(
        shapes=first["shape_counts"], indexed_words=first["word_counts"], counts=counts, floors=floors,
        max_excess=maximum_excess, timings=timings,
        symbol_gate=20 * candidate["excess_symbols"] <= 13 * incumbent["excess_symbols"],
        read_gate=candidate["reads"] <= incumbent["reads"] + 24,
        checked_transitions=transitions, heldout=predictions, forced_fallback=True,
    ), sort_keys=True))


if __name__ == "__main__":
    audit(*sys.argv[1:])
