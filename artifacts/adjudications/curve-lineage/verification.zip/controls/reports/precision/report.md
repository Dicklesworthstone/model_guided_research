# Adjudication — 2026-11-23

- policy: `ci-v12`
- artifacts indexed: 16 from ['/data/ssd/tmp/mgr-cong.g50qfshI/dqpo/control/test_checkpoint_sweeps_adjudic0/relocated']
- ledger entries appended: 0 (dry run)
- verdicts: supported: 1
- **1 supported, of which 1 survive FDR at q=0.1 (family: 1 adjudicated - PARTIAL run, not the whole ledger)**

| hypothesis | verdict | q | detail |
|---|---|---|---|
| hyp-curve-precision-control | supported | 4.15e-08 | ultrametric: effect=1 ci95=[0.9999,1] (n=2/0) power=100% |

BLOCKED rows are refusals, not adjudications: the engine declines to rule on weak, mismatched, or tainted evidence. UNDERPOWERED verdicts cleared their threshold at a test with under 50% power to detect the registered effect - an asterisk, not a clean verdict. See `verdicts.json` for machine-readable reasons, p-values, and q-values.
