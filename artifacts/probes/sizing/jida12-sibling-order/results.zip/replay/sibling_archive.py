import hashlib
import itertools
import json
import math
import sys
from collections import Counter
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


LOCK = "bf693da6a348b4227723b978e22c76d946047fffceefd6b94e4b31c36876db73"
REGISTRATION = "594fd4358a6820998ab16156d165041715b652ca"
SEEDS = (30, 31, 32)
ARMS = ("canonical", "augmented")
CELLS = {"normal": 104, "permuted": 104, "expanded": 110, "nested": 110}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_sha(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def replay_path(name):
    if "/" in name or name == "panel.json":
        return name
    return f"replay/{name}"


def canonical_ordinal(query):
    root, suffix = query["path"]
    return 3 * int(root[-1]) + int(suffix[-1])


def scores(rows, panel):
    counts = {cell: Counter() for cell in CELLS}
    for block, row in zip(panel, rows, strict=True):
        assert set(row) == set(CELLS)
        for cell, logits in row.items():
            queries = block[cell]["queries"]
            assert len(logits) == 4 and all(len(v) == 9 and all(map(math.isfinite, v)) for v in logits)
            picks = [max(range(9), key=v.__getitem__) for v in logits]
            correct = [pick == q["label"] for pick, q in zip(picks, queries, strict=True)]
            assert queries[0]["path"][0] == queries[1]["path"][0]
            assert queries[2]["path"][0] == queries[3]["path"][0] != queries[0]["path"][0]
            counts[cell]["all_four"] += all(correct)
            counts[cell]["individual"] += sum(correct)
            counts[cell]["same_root_pair"] += all(correct[:2]) + all(correct[2:])
            counts[cell]["fixed_ordinal_agreement"] += sum(
                pick == canonical_ordinal(q) for pick, q in zip(picks, queries, strict=True)
            )
    return {cell: dict(count) for cell, count in counts.items()}


def inspect_panel(panel):
    blocks = panel["blocks"]
    assert len(blocks) == 36 and panel["unique_contexts"] == 32648
    assert Counter(block["seed"] for block in blocks) == {71: 12, 72: 12, 73: 12}
    assert len({block[cell]["tree"] for block in blocks for cell in CELLS}) == 144
    for block in blocks:
        queries = {}
        for name, n in CELLS.items():
            cell = block[name]
            assert len(cell["leaves"]) == len(cell["candidates"]) == 9
            assert len({leaf["value"] for leaf in cell["leaves"]}) == 9
            assert len(cell["queries"]) == 4
            assert len({q["path"][0] for q in cell["queries"]}) == 2
            assert len({q["path"][1] for q in cell["queries"]}) == 2
            queries[name] = {}
            for q in cell["queries"]:
                assert len(q["path"]) == 2 and len(q["ids"]) == n
                assert q["path"][0] != block["root"] and q["path"][1] != block["omitted"]
                leaf = cell["leaves"][q["label"]]
                assert (leaf["path"], leaf["value"]) == (q["path"], q["value"])
                assert q["doc"] == f'{cell["tree"]} PATH {" ".join(q["path"])} OUT {q["value"]}'
                queries[name][tuple(q["path"])] = (q["value"], q["label"], cell["candidates"][q["label"]])
            assert len(queries[name]) == 4
        original = {tuple(leaf["path"]): leaf["value"] for leaf in block["normal"]["leaves"]}
        reordered = {tuple(leaf["path"]): leaf["value"] for leaf in block["permuted"]["leaves"]}
        assert original == reordered
        assert all(set(queries[cell]) == set(queries["normal"]) for cell in CELLS)
        assert any(queries["normal"][path][1] != queries["permuted"][path][1] for path in queries["normal"])
        assert queries["expanded"] == queries["nested"]
        for query, (value, label, _) in queries["normal"].items():
            assert queries["permuted"][query][0] == value
            assert queries["nested"][query][:2] == (value, label)


def receipts(names, read):
    receipts = sorted(name for name in names if name.endswith("/receipt.json"))
    assert len(receipts) == 10
    for name in receipts:
        record = json.loads(read(name))
        assert record["status"] == "passed" and len(record["checks"]) == 1
        check = record["checks"][0]
        log = name.removesuffix("receipt.json") + Path(check["log_path"]).name
        assert sha(read(log)) == check["log_sha256"]
    expected = {"hierarchy-sibling-order-prepare", "hierarchy-sibling-order-train", "hierarchy-sibling-order-eval"}
    for seed in SEEDS:
        kinds = [Path(name).parts[-3] for name in receipts if name.startswith(f"seed-{seed}/")]
        assert len(kinds) == 3 and set(kinds) == expected
    assert sum("hierarchy-sibling-order-panel" in name for name in receipts) == 1
    return {name: Path(name).parts[-2] for name in receipts}


def recount(read, names, lineage):
    assert sha(read("replay/frozen.sha256")) == LOCK
    for line in read("replay/frozen.sha256").decode().splitlines():
        expected, name = line.split()
        assert sha(read(replay_path(name))) == expected
    panel = json.loads(read("panel.json"))
    assert panel["tokenizer_sha256"] == sha(read("tokenizer.json")) == sha(lineage.read("tokenizer.json"))
    inspect_panel(panel)
    ordinal_audit = {
        cell: sum(all(canonical_ordinal(q) == q["label"] for q in block[cell]["queries"])
                  for block in panel["blocks"])
        for cell in CELLS
    }
    results = {}
    for seed in SEEDS:
        prefix = f"seed-{seed}"
        prep = json.loads(read(f"{prefix}/preflight.json"))
        previous = json.loads(lineage.read(f"{prefix}/runs/joint/summary.json"))
        assert prep["seed"] == seed
        assert prep["train_trees"] == 8192 and prep["selected_for_permutation"] == 6144
        assert prep["answer_targets_identical"] and prep["query_offsets_identical"]
        assert prep["base_sha256"] == previous["settings"]["schedule_sha256"]
        train = {arm: json.loads(read(f"{prefix}/runs/{arm}/summary.json")) for arm in ARMS}
        base, aug = (train[arm]["settings"] for arm in ARMS)
        assert base["schedule_sha256"] == prep["base_sha256"]
        assert aug["schedule_sha256"] == prep["permuted_sha256"] != prep["base_sha256"]
        assert all(value == aug[key] for key, value in base.items() if key not in {"run_id", "schedule_sha256"})
        assert base["seed"] == seed and base["steps"] == 2048 and base["batch"] == 8 and base["width"] == 128
        assert base["lr"] == .0006 and base["clip"] == 1 and base["location_gradient_multiplier"] == 1
        metrics = {}
        for arm in ARMS:
            trained = train[arm]
            assert trained["initial_parameters_sha256"] == previous["initial_parameters_sha256"]
            assert trained["model_flops_est"] == 13812614823936
            assert trained["provenance"]["git_sha"] == REGISTRATION and not trained["provenance"]["tainted"]
            meta = json.loads(read(f"{prefix}/runs/{arm}/checkpoints/meta_002047.json"))
            assert meta["seed"] == seed and meta["budget"]["max_steps"] == 2048
            assert meta["budget"]["target_flops"] == trained["model_flops_est"]
            evaluated = json.loads(read(f"{prefix}/evals/{arm}.json"))
            assert (evaluated["arm"], evaluated["seed"]) == (arm, seed)
            assert evaluated["panel_sha256"] == sha(read("panel.json"))
            assert trained["weights_sha256"] == evaluated["weights_sha256"]
            assert trained["location_head_sha256"] == evaluated["location_head_sha256"]
            metrics[arm] = scores(evaluated["rows"], panel["blocks"])
        native = metrics["canonical"]["normal"]["all_four"]
        permuted_before = metrics["canonical"]["permuted"]["all_four"]
        permuted_after = metrics["augmented"]["permuted"]["all_four"]
        native_after = metrics["augmented"]["normal"]["all_four"]
        criteria = dict(canonical_native_18=native >= 18, augmented_permuted_27=permuted_after >= 27,
                        permutation_gain_18=permuted_after - permuted_before >= 18, augmented_native_18=native_after >= 18)
        results[str(seed)] = dict(metrics=metrics, criteria=criteria, pass_gate=all(criteria.values()),
                                  exact_canonical_replay=train["canonical"]["final_parameters_sha256"] ==
                                  previous["final_parameters_sha256"])
    return dict(registration=REGISTRATION, manifest_sha256=LOCK,
                blocks_per_cell=36, queries_per_cell=144, pairs_per_cell=72,
                fixed_ordinal_all_four_panel_audit=ordinal_audit,
                per_seed=results, repeatable_in_predeclared_seeds=all(results[str(seed)]["pass_gate"] for seed in (31, 32)),
                dsr_receipts=receipts(names, read))


def bundle(root, lineage, original_root, output):
    frozen = root / "frozen.sha256"
    paths = {"replay/frozen.sha256": frozen, "replay/sibling_archive.py": root / "sibling_archive.py"}
    for entry in frozen.read_text().splitlines():
        expected, name = entry.split()
        assert file_sha(root / name) == expected
        paths[replay_path(name)] = root / name
    for seed in SEEDS:
        prefix = f"seed-{seed}"
        prep = json.loads((root / prefix / "preflight.json").read_bytes())
        assert file_sha(root / prefix / "permuted.pt") == prep["permuted_sha256"]
        assert file_sha(original_root / prefix / "schedule.pt") == prep["base_sha256"]
        for arm in ARMS:
            rel = f"{prefix}/runs/{arm}"
            checkpoint = root / rel / "checkpoints"
            summary = json.loads((root / rel / "summary.json").read_bytes())
            assert file_sha(checkpoint / "model_002047.pt") == summary["weights_sha256"]
            assert file_sha(checkpoint / "location_head.pt") == summary["location_head_sha256"]
            tokenizer = checkpoint / "tokenizer" / "tokenizer.json"
            assert file_sha(tokenizer) == prep["tokenizer_sha256"]
            paths.setdefault("tokenizer.json", tokenizer)
            for name in (f"{rel}/summary.json", f"{rel}/checkpoints/meta_002047.json", f"{prefix}/evals/{arm}.json"):
                paths[name] = root / name
    for receipt in itertools.chain((root / "receipts").glob("*/*/receipt.json"),
                                   root.glob("seed-*/receipts/*/*/receipt.json")):
        for filename in ("receipt.json", "check-1.log", "checks-config.yaml"):
            path = receipt.with_name(filename)
            paths[str(path.relative_to(root))] = path
    with ZipFile(lineage) as before:
        decision = recount(lambda name: paths[name].read_bytes(), paths, before)
    with ZipFile(output, "x", compression=ZIP_DEFLATED) as archive:
        for name, path in paths.items():
            archive.write(path, name)
        archive.writestr("decision.json", json.dumps(decision, indent=2) + "\n")


def verify(output, lineage):
    with ZipFile(output) as archive, ZipFile(lineage) as before:
        assert archive.testzip() is None
        names = archive.namelist()
        assert len(names) == len(set(names))
        assert not any(name.endswith((".pt", ".parquet", ".safetensors")) for name in names)
        decision = recount(archive.read, names, before)
        assert decision == json.loads(archive.read("decision.json"))
    print(json.dumps(decision))


if __name__ == "__main__":
    command, *paths = sys.argv[1:]
    {"bundle": bundle, "verify": verify}[command](*map(Path, paths))
