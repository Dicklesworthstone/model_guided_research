import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
consumer = root / "consumer"
published = "711561125aa154a1404ad9a98d8ebb118655cda3"
corpus = "4db6657e80d6cd657d8ca85ef86ca01380c2e9c0"
seeds = (11, 19, 23, 29, 31)
route_hyp = "hyp-routes-reuse-increases-with-training"
fixture_hyp = "hyp-j44-consumer-reuse"
env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", OMP_NUM_THREADS="1", MKL_NUM_THREADS="1",
           OPENBLAS_NUM_THREADS="1", VECLIB_MAXIMUM_THREADS="1", TOKENIZERS_PARALLELISM="false")

def run(args, cwd, require=True):
    result = subprocess.run([str(x) for x in args], cwd=cwd, env=env, text=True, capture_output=True)
    if require and result.returncode:
        raise RuntimeError(f"{args}\n{result.stdout}\n{result.stderr}")
    return result

def git(cwd, *args):
    return run(["git", "-c", "user.name=Cross-cutting verifier", "-c", "user.email=verifier@example.invalid",
                "-c", "commit.gpgsign=false", *args], cwd).stdout.strip()

def cli(cwd,*args, require=True):
    return run([sys.executable,consumer/"cli.py",*args],cwd,require)

def load(path):
    return json.loads(path.read_bytes())

def save(path, data):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(data,sort_keys=True,indent=2)+"\n")

def sha(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f,"sha256").hexdigest()

def rule(cwd,hyp,artifacts,output):
    cli(cwd,"adjudicate","--dry-run","-H",hyp,"--artifacts",artifacts,"--artifacts-dir",output.parent,"--run-id",output.name)
    row,=load(output.parent/"adjudications"/output.name/"verdicts.json")["verdicts"]
    return row

def overview(row):
    units = {m:v["n_candidate"] for m,v in (row.get("arms") or {}).items()}
    from collections import Counter
    return dict(verdict=row["verdict"],reason=row.get("reason_code"),units=units,
                anchor=row.get("registration_commit"),selected=len(row.get("artifacts",[])),
                excluded=dict(Counter(x["reason_code"] for x in row.get("excluded_evidence", []))))

assert git(consumer,"rev-parse","HEAD")==published
assert sys.version_info[:2]==(3,13)
