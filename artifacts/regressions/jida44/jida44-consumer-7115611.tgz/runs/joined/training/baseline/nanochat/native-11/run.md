# nanochat run (fixed FLOPs)

- Run ID: `native-11`
- Generated: 2026-11-23T01:24:11Z
- Artifacts: `baseline/nanochat/native-11`
- Commit: 5ba8c8949b90f5fd249615f4340b8ca266334f34
- Attention schedule: `tropical`

## Command

```bash
uv run python -m nanochat.train --device cpu --max-steps 6 --batch-size 2 --sequence-len 32 --n-layer 1 --n-head 2 --n-kv-head 2 --n-embd 16 --seed 11 --warmup-steps 0 --artifacts-dir /private/tmp/mgr-jida44-consumer.x8L7T1AV/runs/joined/training --run-id native-11 --checkpoint-interval 2 --save-initial-weights --attention-type tropical --tokenizer task --data-dir /private/tmp/mgr-jida44-consumer.x8L7T1AV/inputs/datasets/hier
```

## Budget

- steps: 6
- warmup_steps: 0
- tokens/step (global): 64
- FLOPs/token (est): 61,440
- FLOPs/step (est): 3,932,160
- planned_total_FLOPs (est): 23,592,960

## Compilation

- torch.compile: False
- compile_backend: 'inductor'
- compile_mode: None
- compile_fullgraph: False
- compile_dynamic: None
- compile_flex_attention: False

## Numerics (debug)

- check_numerics: False
- detect_anomaly: False

## Results (measured after warmup)

- measured_steps: 6
- measured_tokens: 384
- measured_time_s: 0.037
- tokens/s: 10,390
- TFLOP/s (est): 0.00
- peak_memory_allocated_gb: n/a
- final_train_ce: 5.7353
- val_interval: 0
- val_batches: n/a
- final_val_ce: n/a
- final_val_bpb: n/a (bits per byte; comparable across tokenizers)

See `summary.json` for full details.
