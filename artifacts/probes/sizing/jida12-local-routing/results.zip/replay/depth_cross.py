import itertools
import random
import sys
from pathlib import Path

from leaf_position import (
    LocationHead, SPEC, HuggingFaceTokenizer, _load_eval_checkpoint,
    digest, leaf_entries, pq, read, states, torch, tree_of, write,
)
from nanochat.diagnostics_data import _hier_paths, _hier_serialize


BLOCKS = 36
PANEL_SEED = 7019
WIDTH = 128
REPLICATION_SHA = "fb0fe89a34cddd43285903d497e0c9b0a4e4cdb1"


def topology(values, collapsed, middle, omitted):
    values = iter(values)
    tree = {}
    for root in range(3):
        key = f"k0x{root}"
        if root == collapsed:
            tree[key] = next(values)
            continue
        tree[key] = {
            f"k1x{level}": (
                {f"k2x{terminal}": next(values) for terminal in range(3) if terminal != omitted}
                if level == middle else next(values)
            )
            for level in range(3)
        }
    return tree


def pack(tree, tokenizer):
    text = "TASK hier TREE " + _hier_serialize(tree)
    parsed = leaf_entries(text)
    assert [(path, value) for path, value, _ in parsed] == _hier_paths(tree)
    assert len(parsed) == len({value for _, value, _ in parsed}) == 9
    bos = tokenizer.get_bos_token_id()
    leaf_prefixes = [tokenizer.encode(text[:end], prepend=bos) for _, _, end in parsed]
    candidates = [len(item) - 1 for item in leaf_prefixes]
    records = {2: [], 3: []}
    for index, (path, value, _) in enumerate(parsed):
        if len(path) == 1:
            continue
        doc = f"{text} PATH {' '.join(path)} OUT {value}"
        assert SPEC.checker(doc) is True
        prompt, expected = SPEC.split_prompt(doc)
        ids = tokenizer.encode(prompt, prepend=bos)
        full = tokenizer.encode(doc, prepend=bos)
        assert expected == value and full[:len(ids)] == ids and len(ids) < len(full)
        assert all(ids[:len(item)] == item for item in leaf_prefixes)
        records[len(path)].append(dict(document=doc, prompt_ids=ids, full_tokens=len(full), label=index,
                                       path=path, value=value))
    for depth, rows in records.items():
        assert len(rows) == 4
        assert len({len(row["prompt_ids"]) for row in rows}) == 1
        roots = {row["path"][0] for row in rows}
        suffixes = {row["path"][1:] for row in rows}
        assert len(roots) == len(suffixes) == 2
        assert {(row["path"][0], row["path"][1:]) for row in rows} == set(itertools.product(roots, suffixes))
        assert len({row["path"][1] for row in rows}) == (2 if depth == 2 else 1)
    return dict(tree=text, candidates=candidates, records=records,
                leaves=[dict(path=path, value=value) for path, value, _ in parsed])


def lengths(case, depth):
    return len(case["records"][depth][0]["prompt_ids"])


def preflight(output, reference, answer, pilot, replication):
    directory = reference / "data" / "hier_paired"
    manifest = read(directory / "manifest.json")
    previous = set()
    for name, expected_digest in manifest["sha256"].items():
        path = directory / name
        assert digest(path) == expected_digest
        docs = pq.read_table(path, columns=["text"]).column("text").to_pylist()
        for first, second in zip(docs[::2], docs[1::2], strict=True):
            tree = tree_of(first)
            assert tree == tree_of(second) and tree not in previous
            previous.add(tree)
    assert len(previous) == 32000
    panels = (
        read(reference / "panel.json")["evaluation"],
        read(answer / "panel.json"),
        read(pilot / "panel.json"),
        read(replication / "seed-30" / "panel.json"),
    )
    for panel in panels:
        for rows in panel.values():
            for row in rows:
                tree = tree_of(row["documents"][0])
                assert tree not in previous
                previous.add(tree)
    assert len(previous) == 32324
    tokenizer_dir = replication / "seed-30" / "runs" / "joint" / "checkpoints" / "tokenizer"
    tokenizer = HuggingFaceTokenizer.from_directory(str(tokenizer_dir))
    tokenizer_hash = digest(tokenizer_dir / "tokenizer.json")
    assert tokenizer_hash == read(replication / "seed-30" / "preflight.json")["tokenizer_sha256"]
    rng = random.Random(PANEL_SEED)
    layouts = list(itertools.product(range(3), repeat=3))
    layouts.extend((a, b, (a + b) % 3) for a, b in itertools.product(range(3), repeat=2))
    rng.shuffle(layouts)
    blocks = []
    for layout in layouts:
        for _ in range(128):
            tree = topology([f"v{n}" for n in rng.sample(range(100), 9)], *layout)
            b = pack(tree, tokenizer)
            if b["tree"] in previous:
                continue
            assert lengths(b, 2) < lengths(b, 3)
            collapsed = layout[0]
            for zeros in range(1, 49):
                expanded = {
                    f"k0x{'0' * zeros}{collapsed}" if key == f"k0x{collapsed}" else key: value
                    for key, value in tree.items()
                }
                a = pack(expanded, tokenizer)
                if lengths(a, 2) == lengths(b, 3):
                    break
            else:
                raise ValueError(f"No exact token alignment for layout {layout}")
            if a["tree"] in previous:
                continue
            assert max(row["full_tokens"] for case in (a, b) for rows in case["records"].values()
                       for row in rows) <= WIDTH
            break
        else:
            raise ValueError(f"Input-only feasibility failed at layout {layout}")
        assert a["tree"] != b["tree"]
        assert lengths(a, 2) == lengths(b, 3)
        for aa, bb in zip(a["leaves"], b["leaves"], strict=True):
            assert aa["value"] == bb["value"]
            if len(bb["path"]) > 1:
                assert aa["path"] == bb["path"]
        previous.update((a["tree"], b["tree"]))
        blocks.append(dict(layout=layout, a=a, b=b))
    assert len(blocks) == BLOCKS and len(previous) == 32324 + BLOCKS * 2
    write(output, dict(panel_seed=PANEL_SEED, tokenizer_sha256=tokenizer_hash, distinct_input_trees=len(previous),
                       blocks=blocks))
    print(dict(blocks=len(blocks), matched_prompt_lengths=sorted({lengths(block["a"], 2) for block in blocks}),
               tree_leaf_count=9, max_full_tokens=max(row["full_tokens"] for block in blocks for case in ("a", "b")
                                                     for rows in block[case]["records"].values() for row in rows)))


@torch.inference_mode()
def evaluate(panel_path, replication, output):
    panel = read(panel_path)
    for seed, arm in itertools.product((30, 31, 32), ("detached", "joint")):
        root = replication / f"seed-{seed}"
        checkpoint = root / "runs" / arm / "checkpoints"
        original = read(root / "evals" / arm / "summary.json")
        training = read(root / "runs" / arm / "summary.json")
        assert not training["provenance"]["tainted"] and original["source_revision"] == REPLICATION_SHA
        assert training["provenance"]["git_sha"] == REPLICATION_SHA
        device = torch.device("cpu")
        model, metadata, step = _load_eval_checkpoint(checkpoint, None, device, fingerprint_weights=True)
        assert step == 2047 and metadata["weights_sha256"] == original["weights_sha256"]
        head_file = checkpoint / "location_head.pt"
        assert digest(head_file) == original["location_head_sha256"] == training["location_head_sha256"]
        head = LocationHead().eval()
        head.load_state_dict(torch.load(head_file, weights_only=True))
        tokenizer = HuggingFaceTokenizer.from_directory(str(checkpoint / "tokenizer"))
        assert digest(checkpoint / "tokenizer" / "tokenizer.json") == panel["tokenizer_sha256"]
        layout_rows = []
        for block in panel["blocks"]:
            observations = {}
            for slot, depth in itertools.product(("a", "b"), ("2", "3")):
                case = block[slot]
                queries = case["records"][depth]
                tokens = torch.tensor([query["prompt_ids"] for query in queries])
                _, hidden = states(model, tokens)
                last = torch.full((len(queries),), tokens.shape[1] - 1)
                candidates = torch.tensor([case["candidates"]] * len(queries))
                scores = head(hidden, last, candidates)
                assert bool(torch.isfinite(scores).all())
                observations[f"{slot}{depth}"] = scores.tolist()
            layout_rows.append(observations)
        write(output / f"seed-{seed}-{arm}.json",
              dict(seed=seed, arm=arm, weights_sha256=original["weights_sha256"],
                   location_head_sha256=original["location_head_sha256"], panel_sha256=digest(panel_path),
                   rows=layout_rows))
        print(seed, arm, len(layout_rows), flush=True)


if __name__ == "__main__":
    command, *arguments = sys.argv[1:]
    if command == "preflight":
        preflight(*map(Path, arguments))
    elif command == "evaluate":
        evaluate(*map(Path, arguments))
    else:
        raise ValueError(command)
