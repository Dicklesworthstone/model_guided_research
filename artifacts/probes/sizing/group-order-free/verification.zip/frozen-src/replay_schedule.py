"""Replay bounded proposal scheduling using exact, previously audited Boolean tapes."""
import argparse
import itertools
import json
import random
from collections import Counter, defaultdict
from hashlib import sha256
from pathlib import Path

BASELINE_SHARE = 4


def pair(left, right):
    return min(left, right), max(left, right)


def advance(tape, cursor, answers):
    while cursor < len(tape):
        left, right, outcome = tape[cursor]
        key = pair(left, right)
        if key not in answers:
            break
        if answers[key] is not outcome:
            raise ValueError("The tapes disagree on an identical comparison")
        cursor += 1
    return cursor


def schedule(baseline, speculative, certified):
    tapes = (baseline, speculative)
    cursors = [0, 0]
    charges = [0, 0]
    symbols = [0, 0]
    answers = {}
    while True:
        cursors[0] = advance(baseline, cursors[0], answers)
        if cursors[0] == len(baseline):
            return "frontier", charges, symbols
        cursors[1] = advance(speculative, cursors[1], answers)
        pending = cursors[1] < len(speculative)
        if not pending and certified:
            return "certificate", charges, symbols
        owner = int(pending and BASELINE_SHARE * (charges[1] + 1) <= charges[0])
        left, right, outcome = tapes[owner][cursors[owner]]
        key = pair(left, right)
        if key in answers:
            raise ValueError("The scheduler attempted to charge a cached query")
        answers[key] = outcome
        charges[owner] += 1
        symbols[owner] += len(left) + len(right)


def check_bounds(baseline, speculative, certified, charges):
    frontier, proposal = charges
    assert proposal <= frontier // BASELINE_SHARE
    assert frontier <= len(baseline) and proposal <= len(speculative)
    total = sum(charges)
    assert total <= len(baseline) + len(baseline) // BASELINE_SHARE
    if certified:
        assert total <= (BASELINE_SHARE + 1) * len(speculative)


def stress():
    fixtures = [(f"{i:04b}", "", i % 2 == 0) for i in range(16)]
    simple = list(itertools.chain.from_iterable(itertools.permutations(fixtures[:5], n) for n in range(6)))
    tested = 0
    for base, speculation in itertools.product(simple, repeat=2):
        for accepted in (False, True):
            _, charges, _ = schedule(base, speculation, accepted)
            check_bounds(base, speculation, accepted, charges)
            tested += 1
    rng = random.Random(98296)
    both_paths = Counter()
    for _ in range(1024):
        base = [rng.choice(fixtures) for _ in range(rng.randrange(1, 30))]
        spec = [rng.choice(fixtures) for _ in range(rng.randrange(1, 30))]
        accepted = rng.choice((True, False))
        result, charges, _ = schedule(base, spec, accepted)
        check_bounds(base, spec, accepted, charges)
        both_paths[result] += 1
        tested += 1
    assert set(both_paths) == {"frontier", "certificate"}
    return tested


def replay(path):
    data = json.loads(path.read_bytes())
    counts = defaultdict(Counter)
    rows = []
    for case in data["results"]:
        baseline = case["baseline"]["paid"]
        treatment = case["treatment"]
        split = len(treatment["proposal"]["queries"])
        checked = sum(not row["reused"] for row in treatment["checks"])
        spec = treatment["paid"][:split+checked]
        result, charges, symbols = schedule(baseline, spec, treatment["accepted"])
        check_bounds(baseline, spec, treatment["accepted"], charges)
        record = dict(
            cases=1, baseline=len(baseline), proposal_first=len(treatment["paid"]), replay=sum(charges),
            baseline_symbols=sum(len(a)+len(b) for a,b,_ in baseline), replay_symbols=sum(symbols),
            baseline_share=charges[0], speculative_share=charges[1], certified=int(result=="certificate"),
        )
        counts[case["family"]].update(record)
        rows.append(dict(index=case["index"], family=case["family"], **record))
    s5 = counts["s5"]
    saved = 1 - s5["replay"] / s5["baseline"]
    assert len(rows) == 18 and s5["certified"] == 6
    evidence = dict(
        candidate_gate=(saved >= .90 and counts["c1"]["replay"] == counts["c1"]["baseline"]),
        restored_s5_savings=saved, synthetic_tapes=stress(), families=counts, cases=rows,
        source_sha256=sha256(path.read_bytes()).hexdigest(),
    )
    print(json.dumps(evidence, sort_keys=True))


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("transcript", type=Path)
    replay(cli.parse_args().transcript)
