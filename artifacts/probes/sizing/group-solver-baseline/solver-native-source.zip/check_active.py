"""Verify active acquisition without importing the producer or its query chooser."""

import argparse
import copy
import json
from itertools import product
from pathlib import Path

from verify import witness_endpoint

CASES = (("planet", 4, False), ("ring5", 5, False), ("ring6", 6, False), ("ring5-exhausted", 5, True))
ANCHORS = ("00", "01", "10", "11")


def physical_truth(size, names):
    # The state is an explicit permutation of the marked ring. Compose
    # rotation and reflection on the right of the current permutation.
    orbit = {
        tuple((position + sign * index) % size for index in range(size)): names[2 * position + direction]
        for position, (direction, sign) in product(range(size), enumerate((1, -1)))
    }
    steps = (tuple(range(1, size)) + (0,), tuple(-i % size for i in range(size)))
    return {
        str(i): {name: orbit[tuple(state[j] for j in mark)] for state, name in orbit.items()}
        for i, mark in enumerate(steps)
    }


def endpoint(table, name, word):
    for letter in word:
        name = table[letter][name]
    return name


def shortest_witness(names, first, second, maximum):
    tables = [
        {a: dict(zip(names, (names[i] for i in model["R" + a]), strict=True)) for a in "01"}
        for model in (first, second)
    ]
    for length in range(2, maximum + 1):
        for marks in product("01", repeat=length):
            if endpoint(tables[0], names[first["root"]], marks) != endpoint(tables[1], names[second["root"]], marks):
                return "".join(marks)
    return None


def check_solver(case, row):
    names = sorted(case["names"])
    public = dict(case["initial"])
    paid = []
    last_status = None
    for event in row["events"]:
        base = event["base"]
        if last_status is not None:
            raise ValueError("Solver continued after a terminal outcome")
        for check in (base, event.get("alternative")):
            if check is None:
                continue
            if check["resource_count"] <= 0:
                raise ValueError("Missing resource accounting")
            if check["status"] == "unknown" and not check["reason"]:
                raise ValueError("Unknown without a recorded cause")
        if base["status"] == "unknown":
            last_status = "unknown-base"
            continue
        if base["status"] != "sat":
            raise ValueError("Invalid base solver outcome")
        first = event["first"]
        witness_endpoint(first, names, public, "00")
        status = event["alternative"]["status"]
        if status == "unknown":
            last_status = "unknown-alternative"
            continue
        if status == "unsat":
            last_status = "unique-right-table"
            expected = {a: [row["right"][a][x] for x in names] for a in "01"}
            if any(expected[s] != [names[i] for i in first["R" + s]] for s in "01"):
                raise ValueError("Final model mismatches the recovered action")
            continue
        if status != "sat":
            raise ValueError("Unexpected alternative outcome")
        second, word = event["second"], event["word"]
        if not 3 <= len(word) <= len(names) + 2:
            raise ValueError("Candidate query outside its finite search bound")
        if witness_endpoint(second, names, public, word) == witness_endpoint(first, names, public, word):
            raise ValueError("Query does not eliminate either model")
        if word in public or word != shortest_witness(names, first, second, len(word)):
            raise ValueError("Query is not the shortest distinguishing word")
        public[word] = event["answer"]
        paid.append([word, event["answer"]])
    if row["terminal"] != (last_status or "query-cap") or row["paid"][:len(paid)] != paid:
        raise ValueError("Solver disposition conflicts with its query tape")
    if row["terminal"] == "unique-right-table" and row["paid"] != paid:
        raise ValueError("Extra paid calls after solver completion")
    return len(paid)


def check(record):
    observed = tuple((case["family"], case["size"], case["exhausted"]) for case in record["cases"])
    if observed != CASES or record["rlimit"] != 2_000_000 or not record["z3"].startswith("Z3 version 4.15.4 "):
        raise ValueError("Input violates the registered preflight")
    evidence = []
    for case in record["cases"]:
        names = case["names"]
        if sorted(names) != [f"opaque{i:02d}" for i in range(2 * case["size"])]:
            raise ValueError("Wrong named state set")
        truth = physical_truth(case["size"], names)
        initial = case["initial"]
        if initial != {w: endpoint(truth, names[0], w) for w in ANCHORS}:
            raise ValueError("The two-letter bootstrap differs from the oracle")
        if set(case["arms"]) != {"square", "visible", "active"}:
            raise ValueError("Missing or unexpected experimental arm")
        scores = {}
        for arm, row in case["arms"].items():
            if row["right"] != truth:
                raise ValueError("Incorrect right transition table")
            past = set(initial)
            for w, label in row["paid"]:
                if w in past or len(w) < 2 or label != endpoint(truth, names[0], w):
                    raise ValueError("Invalid paid oracle tape")
                past.add(w)
            scores[arm] = {
                "total_labels": len(initial) + len(row["paid"]),
                "moves": sum(map(len, initial)) + sum(len(w) for w, _ in row["paid"]),
                "cpu_ns": row["cpu_ns"],
                "terminal": row["terminal"],
            }
        solver_paid = check_solver(case, case["arms"]["active"])
        if case["exhausted"] and (solver_paid != 0 or scores["active"]["terminal"] != "unknown-base"
                                  or case["arms"]["active"]["paid"] != case["arms"]["square"]["paid"]):
            raise ValueError("Exhausted solver did not fall back safely")
        evidence.append({
            "family": case["family"], "scores": scores, "transitions_per_arm": len(names) * 2,
            "solver_selected_calls": solver_paid,
        })
    return evidence


def untimed(record):
    return {
        **record,
        "cases": [
            {**case, "arms": {
                kind: {key: value for key, value in row.items() if key not in {"cpu_ns", "wall_ns"}}
                for kind, row in case["arms"].items()
            }}
            for case in record["cases"]
        ],
    }


def reject_changed_solver_result(record):
    forged = copy.deepcopy(record)
    forged["cases"][-1]["arms"]["active"]["terminal"] = "unique-right-table"
    try:
        check(forged)
    except ValueError:
        return
    raise ValueError("Corrupted exhaustion witness passed")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("scored", type=Path)
    parser.add_argument("replay", type=Path)
    args = parser.parse_args()
    scored, replayed = (json.loads(p.read_text(encoding="utf-8")) for p in (args.scored, args.replay))
    rows = check(scored)
    check(replayed)
    if untimed(scored) != untimed(replayed):
        raise ValueError("Replayed solver choices or budgets differ")
    reject_changed_solver_result(scored)
    print(json.dumps({
        "exact_replay": True,
        "solver_completed": sum(row["scores"]["active"]["terminal"] == "unique-right-table" for row in rows[:-1]),
        "solver_required": len(rows) - 1,
        "forged_exhaustion_rejected": True,
        "cases": rows,
    }, indent=2))


if __name__ == "__main__":
    main()
