# eval-tasks — b5-s0

- checkpoint: `/data/ssd/tmp/mgr-hier-paired.Ji7EOJkO/artifacts/probes/sizing/jida12-paired-hier/runs/standard/b5-s0/checkpoints` @ step 593
- attention_type: standard
- n_params: 819,200
- seeds: [0, 1, 2] · examples/seed: 24 · decode: ['greedy']

| task | EM in-range | EM held-out | ppl in/held | slope held-out [CI95] | curve |
|---|---|---|---|---|---|
| hier_paired | 0.000 | 0.028 | 1.6/13.4 | - | [curve](curve_hier_paired.png) |

- hier_paired in_range: both answers correct on 0/36 pairs (0 incomplete)
- hier_paired held_out: both answers correct on 0/36 pairs (0 incomplete)

See `summary.json` (schema mgr.evaltasks.v5) for the full output and `generations.jsonl` for per-example receipts.
