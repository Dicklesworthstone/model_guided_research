#!/bin/bash
set -euo pipefail
export PATH="/home/ubuntu/.local/bin:$PATH"
export DSR_QUALITY_LOG_DIR=/data/ssd/tmp/mgr-hier-s320.hk5mLTED/receipts UV_PROJECT_ENVIRONMENT=/data/ssd/tmp/mgr-eval-ci.bevt3nLW/qualified-venv
export OMP_NUM_THREADS=4 MKL_NUM_THREADS=4
DSR_REPOS_FILE=/data/ssd/tmp/mgr-hier-s320.hk5mLTED/objective.yaml dsr quality --tool hierarchy-objective --work-dir /data/ssd/tmp/mgr-hier-s320.hk5mLTED/gate --check-timeout 1150
for run in objective-full-s17 objective-answer-s17; do
    export MGR_HIER_RUN="$run"
    DSR_REPOS_FILE=/data/ssd/tmp/mgr-hier-s320.hk5mLTED/sizing.yaml dsr quality --tool hierarchy-eval --work-dir /data/ssd/tmp/mgr-hier-s320.hk5mLTED/gate --check-timeout 240
    DSR_REPOS_FILE=/data/ssd/tmp/mgr-hier-s320.hk5mLTED/interaction.yaml dsr quality --tool hierarchy-interaction --work-dir /data/ssd/tmp/mgr-hier-s320.hk5mLTED/gate --check-timeout 120
done
