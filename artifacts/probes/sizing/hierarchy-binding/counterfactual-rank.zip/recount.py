import hashlib
import json
import math
import statistics
import sys
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

REGISTRATION = "b39dd0673052dd24f28416c3f23e2bbf50a17805"
PANEL = "50d42225c52ea0cfbc5f9e823f76d06708cb90cc6c2b49071187a039d4b6041b"
REPLAY = "a33ae81cbf760924d1d7d2d0594f3765bfae5168e9da0328a15207d00312fa62"
PRIOR = "242946b74774e2bbaac837e9426c80924e715b410d95a608d91019f2c093ea74"
TRAIN = ("8831", "8832", "8833")
REGIONS = ("in_range", "held_out")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def compare(scores, a, b):
    left, right = (scores[arm][a] - scores[arm][b] for arm in ("left", "right"))
    off_left, off_right = (scores[arm][a] - scores[arm][b] for arm in ("left_null", "right_null"))
    effect = left - right
    placebo = abs(left - off_left) + abs(right - off_right)
    return effect, placebo, effect > 1e-6, effect >= 0.05 and effect > placebo


def retriever(vector):
    return max(range(len(vector)), key=vector.__getitem__)


def recount(read, names, prior_zip):
    assert sha(read("binding_score.py")) == REPLAY and sha(read("baseline-panel.json")) == PANEL
    drawn = json.loads(read("scores.json"))
    panel = json.loads(read("baseline-panel.json"))
    assert drawn["panel_sha256"] == PANEL and set(drawn["results"]) == set(TRAIN)
    assert sha(prior_zip.read_bytes()) == PRIOR
    with ZipFile(prior_zip) as previous:
        assert previous.read("baseline-panel.json") == read("baseline-panel.json")
        prior = json.loads(previous.read("baseline-result.json"))["seeds"]
    assert drawn["checkpoint_sha256"] == {seed: prior[seed]["checkpoint_sha256"] for seed in TRAIN}
    test = dict(left=[0.0, -1.0], right=[-1.0, 0.0], left_null=[0.0, -1.0], right_null=[-1.0, 0.0])
    assert compare(test, 0, 1) == (2.0, 0.0, True, True)
    reversed_scores = dict(left=test["right"], right=test["left"],
                           left_null=test["right_null"], right_null=test["left_null"])
    assert compare(reversed_scores, 0, 1) == (-2.0, 0.0, False, False)
    output = {}
    for seed, rows in drawn["results"].items():
        assert len(rows) == 72
        assert {(row["eval_seed"], row["region"], row["index"]) for row in rows} == {
            (eval_seed, region, index) for eval_seed in (3301, 3302, 3303) for region in REGIONS for index in range(12)
        }
        summary = {}
        for region in REGIONS:
            totals = {arm: {"individual_correct": 0, "both_correct": 0}
                      for arm in ("raw", "calibrated", "neutral")}
            effects, placebos, scopes = [], [], {}
            positive, selective = 0, 0
            for row in (row for row in rows if row["region"] == region):
                docs = panel[str(row["eval_seed"])][region][2 * row["index"]:2 * row["index"] + 2]
                candidates = row["candidates"]
                left, right = [doc.rsplit(" OUT ", 1)[1] for doc in docs]
                assert row["answers"] == [left, right] and left != right and row["answer_tokens"] > 0
                assert 0 < row["prompt_tokens"] + row["answer_tokens"] <= 192
                labels = set(word for word in docs[0].split(" BIND ")[0].split() if word.startswith("v"))
                assert candidates == sorted(labels, key=lambda label: int(label[1:]))
                scores = row["scores"]
                assert set(scores) == {"left", "right", "neutral", "left_null", "right_null"}
                assert all(len(vector) == len(candidates) and all(math.isfinite(v) and v <= 0 for v in vector)
                           for vector in scores.values())
                a, b = candidates.index(left), candidates.index(right)
                anchors = scores["neutral"]
                assert a != b
                arms = dict(raw=[scores["left"], scores["right"]], neutral=[anchors, anchors],
                            calibrated=[[lp - ref for lp, ref in zip(scores[key], anchors, strict=True)]
                                        for key in ("left", "right")])
                for arm, (p, q) in arms.items():
                    correct = [retriever(p) == a, retriever(q) == b]
                    totals[arm]["individual_correct"] += sum(correct)
                    totals[arm]["both_correct"] += all(correct)
                effect, placebo, pos, sel = compare(scores, a, b)
                positive += pos
                selective += sel
                effects.append(effect)
                placebos.append(placebo)
                depth = len(row["changed_scope"])
                group = scopes.setdefault(depth, {"pairs": 0, "positive": 0, "selective": 0})
                group["pairs"] += 1
                group["positive"] += pos
                group["selective"] += sel
            assert len(effects) == 36 and totals["neutral"]["both_correct"] == 0
            summary[region] = dict(retrieval=totals, positive=positive, selective=selective,
                                   median_effect_nats=statistics.median(effects),
                                   median_abs_effect_nats=statistics.median(map(abs, effects)),
                                   median_placebo_nats=statistics.median(placebos),
                                   by_intervention_hop=scopes, preference_gate=positive >= 26 and selective >= 22)
        output[seed] = summary

    receipts = [name for name in names if name.endswith("receipt.json")]
    assert len(receipts) == 1
    receipt_path, = receipts
    receipt = json.loads(read(receipt_path))
    assert receipt["status"] == "passed" and len(receipt["checks"]) == 1
    check, = receipt["checks"]
    log = str(Path(receipt_path).with_name(Path(check["log_path"]).name))
    assert sha(read(log)) == check["log_sha256"]
    return dict(source=REGISTRATION, pairs_per_region=36, checkpoints=output, score_receipt=Path(receipt_path).parent.name,
                material_at_both_depths=all(region["preference_gate"] for seed in output.values() for region in seed.values()),
                retrieval_gates={arm: all(by_region["in_range"]["retrieval"][arm]["both_correct"] >= 8 and
                                          by_region["held_out"]["retrieval"][arm]["both_correct"] >= 5
                                          for by_region in output.values()) for arm in ("raw", "calibrated")})


def verify(path, prior):
    with ZipFile(path) as archive:
        assert archive.testzip() is None and len(archive.namelist()) == len(set(archive.namelist()))
        result = recount(archive.read, archive.namelist(), prior)
        assert json.dumps(result, sort_keys=True) == json.dumps(json.loads(archive.read("decision.json")), sort_keys=True)
    print(json.dumps(result))


def bundle(root, destination, prior):
    files = {name: root / name for name in ("binding_score.py", "scores.json", "baseline-panel.json", "score.yaml",
                                            "recount.py", "protocol.txt")}
    for receipt in (root / "receipts").glob("*/*/receipt.json"):
        for name in ("receipt.json", "check-1.log", "checks-config.yaml"):
            path = receipt.with_name(name)
            files[path.relative_to(root).as_posix()] = path
    result = recount(lambda name: files[name].read_bytes(), files, prior)
    with ZipFile(destination, "x", compression=ZIP_DEFLATED) as archive:
        for name, path in files.items():
            archive.write(path, name)
        archive.writestr("decision.json", json.dumps(result, indent=2) + "\n")
    verify(destination, prior)


if __name__ == "__main__":
    mode, *args = sys.argv[1:]
    {"bundle": bundle, "verify": verify}[mode](*map(Path, args))
