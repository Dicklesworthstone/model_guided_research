def stable: del(.cpu_ns,.solver_cpu_ns,.wall_ns) | .solver_events |= map(del(.models));
.[0].cases as $scored | .[1].cases as $audit |
{
  differences: [
    range(0; $scored|length) as $case |
    select(($scored[$case].arms.z3|stable) != ($audit[$case].arms.z3|stable)) |
    {case:($case+1), family:$scored[$case].family,
      events: [
        range(0; $scored[$case].arms.z3.solver_events|length) as $event |
        ($scored[$case].arms.z3.solver_events[$event]|del(.models)) as $first |
        ($audit[$case].arms.z3.solver_events[$event]|del(.models)) as $second |
        select($first != $second) |
        {word:$first.word, base:[$first.base,$second.base],
          alternative:[$first.alternative,$second.alternative],
          candidates:[$first.candidates,$second.candidates]}
      ]}
  ],
  square_exact_replay: all(range(0; $scored|length);
    . as $case | ($scored[$case].arms.square|stable) == ($audit[$case].arms.square|stable)),
  visible_exact_replay: all(range(0; $scored|length);
    . as $case | ($scored[$case].arms.visible|stable) == ($audit[$case].arms.visible|stable)),
  all_tables_and_paid_tapes_equal: all(range(0; $scored|length); . as $case |
    all(["square","visible","z3"][]; . as $arm |
      ($scored[$case].arms[$arm]|{right,paid}) == ($audit[$case].arms[$arm]|{right,paid})))
}
