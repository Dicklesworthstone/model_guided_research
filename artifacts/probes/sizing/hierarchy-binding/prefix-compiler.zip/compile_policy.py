import hashlib
import json
import os
import platform
import random
import statistics
import struct
import sys
import time
from array import array
from bisect import bisect_right
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from zipfile import ZipFile

from recount import parse

ARCHIVE = "94a8d7a97010089a771b5d6d6554ab7e08e297fc8748b9a5fe8647b740ccc75a"
NODE = struct.Struct("<BHH")
DEPTHS = (8, 12, 16)
SEEDS = (81, 82)
FAMILIES = ("affine", "repeated_subfunction", "regional", "iid")
SAMPLES, QUERIES = 7, 16384


def digest(data):
    return hashlib.sha256(data).hexdigest()


@dataclass(frozen=True, slots=True)
class Packed:
    data: bytes

    def lookup(self, address):
        return (self.data[address >> 3] >> (address & 7)) & 1

    def wire(self):
        return b"P" + self.data

    def resident(self):
        return sys.getsizeof(self) + sys.getsizeof(self.data)


@dataclass(frozen=True, slots=True)
class Runs:
    first: int
    changes: array

    def lookup(self, address):
        return self.first ^ (bisect_right(self.changes, address) & 1)

    def wire(self):
        changes = array("H", self.changes)
        if sys.byteorder != "little":
            changes.byteswap()
        return b"R" + bytes([self.first]) + changes.tobytes()

    def resident(self):
        return sys.getsizeof(self) + sys.getsizeof(self.changes) + sys.getsizeof(self.first)


@dataclass(frozen=True, slots=True)
class Affine:
    code: int

    def lookup(self, address):
        return (self.code >> 16) ^ ((self.code & address).bit_count() & 1)

    def wire(self):
        return b"A" + self.code.to_bytes(3, "little")

    def resident(self):
        return sys.getsizeof(self) + sys.getsizeof(self.code)


@dataclass(frozen=True, slots=True)
class Graph:
    root: int
    data: bytes

    def lookup(self, address):
        node = self.root
        while node > 1:
            bit, left, right = NODE.unpack_from(self.data, NODE.size * (node - 2))
            node = right if (address >> bit) & 1 else left
        return node

    def wire(self):
        return b"G" + self.root.to_bytes(2, "little") + self.data

    def resident(self):
        return sys.getsizeof(self) + sys.getsizeof(self.root) + sys.getsizeof(self.data)


def make_packed(f):
    data = bytearray((len(f) + 7) // 8)
    for i, bit in enumerate(f):
        data[i >> 3] |= bit << (i & 7)
    return Packed(bytes(data))


def make_runs(f):
    return Runs(f[0], array("H", (i for i in range(1, len(f)) if f[i] != f[i - 1])))


def make_affine(f, depth):
    bias = f[0]
    mask = sum((f[1 << bit] ^ bias) << bit for bit in range(depth))
    decoder = Affine(mask | (bias << 16))
    if all(decoder.lookup(i) == v for i, v in enumerate(f)):
        return decoder
    return None


def make_graph(f, depth):
    level = list(f)
    known = {}
    data = bytearray()
    for bit in range(depth):
        next_level = []
        for left, right in zip(level[::2], level[1::2], strict=True):
            if left == right:
                next_level.append(left)
                continue
            entry = (bit, left, right)
            node = known.get(entry)
            if node is None:
                node = len(known) + 2
                known[entry] = node
                data.extend(NODE.pack(*entry))
            next_level.append(node)
        level = next_level
    root, = level
    return Graph(root, bytes(data))


def decode(data):
    match data[0:1]:
        case b"P":
            return Packed(data[1:])
        case b"A":
            return Affine(int.from_bytes(data[1:], "little"))
        case b"G":
            return Graph(int.from_bytes(data[1:3], "little"), data[3:])
        case b"R":
            changes = array("H")
            changes.frombytes(data[2:])
            if sys.byteorder != "little":
                changes.byteswap()
            return Runs(data[1], changes)
        case _:
            raise ValueError("unknown policy encoding")


def compile_all(values, depth):
    assert len(values) == (1 << depth) and 0 <= depth <= 16 and set(values) <= {0, 1}
    arts = {"packed": make_packed(values), "runs": make_runs(values), "graph": make_graph(values, depth)}
    affine = make_affine(values, depth)
    if affine is not None:
        arts["affine"] = affine
    # Primary objective is stored size. Packed wins any tie in encoded length.
    encoded = {name: decoder.wire() for name, decoder in arts.items()}
    selected = min(encoded, key=lambda name: len(encoded[name]))
    encoded["adaptive"] = encoded[selected]
    arts = {name: decode(wire) for name, wire in encoded.items()}
    for name, decoder in arts.items():
        assert decoder.wire() == encoded[name]
        assert all(decoder.lookup(i) == v for i, v in enumerate(values))
    return arts, selected


def synthesize(family, depth, seed):
    rng = random.Random(seed + depth * 100)
    count = 1 << depth
    if family == "affine":
        bias = rng.getrandbits(1)
        return bytes((i.bit_count() & 1) ^ bias for i in range(count))
    if family == "repeated_subfunction":
        # Eight low digits select the same non-affine block under each high prefix.
        motif = bytes([0, 0, 0, 1] + [rng.getrandbits(1) for _ in range(252)])
        return motif * (count // len(motif))
    if family == "regional":
        prefix = [rng.getrandbits(1) for _ in range(8)]
        data = bytearray(prefix[i >> (depth - 3)] for i in range(count))
        for i in rng.sample(range(count), count // 256):
            data[i] ^= 1
        return bytes(data)
    assert family == "iid"
    return bytes(rng.getrandbits(1) for _ in range(count))


def latency(arts, seed, depth, values):
    rng = random.Random(72100 + seed + depth)
    addresses = [rng.randrange(1 << depth) for _ in range(QUERIES)]
    expected = sum(values[i] for i in addresses)
    methods = {name: arts[name].lookup for name in ("packed", "runs", "graph", "adaptive")}
    raw = {name: [] for name in methods}
    for method in methods.values():
        assert sum(map(method, addresses)) == expected
    orders = []
    for _ in range(SAMPLES):
        order = list(methods)
        rng.shuffle(order)
        orders.append(order)
        for name in order:
            start = time.perf_counter_ns()
            total = sum(map(methods[name], addresses))
            raw[name].append((time.perf_counter_ns() - start) / QUERIES)
            assert total == expected
    return dict(paired_ns_per_lookup=raw, orders=orders, checksum=expected,
                ratios={name: statistics.median(a / b for a, b in zip(raw["adaptive"], raw[name], strict=True))
                        for name in ("packed", "runs")})


def load_panel(path):
    assert digest(path.read_bytes()) == ARCHIVE
    with ZipFile(path) as archive:
        assert json.loads(archive.read("decision.json"))["fixed_gate"]
        return json.loads(archive.read("panel.json"))


def actual(panel):
    counts = Counter()
    for cells in panel.values():
        for docs in cells.values():
            for doc in docs:
                query, gold, rows, _ = parse(doc)
                levels = []
                for k in range(len(query)):
                    bits = [a ^ v for path, (a, v, b, w) in sorted(rows.items()) if len(path) == k]
                    assert len(bits) == 2**k
                    arts, selected = compile_all(bits, k)
                    counts[selected] += 1
                    levels.append(arts["adaptive"])
                address = 0
                for k, (alias, expected) in enumerate(zip(query, gold, strict=True)):
                    child = alias ^ levels[k].lookup(address)
                    assert child == expected
                    address = 2 * address + child
    return dict(documents=216, exact_slots=1800, tables=sum(counts.values()), selected=dict(counts))


def controls():
    # Small parity is sensitive to every digit, but its truth table has a compact affine form.
    truth = synthesize("affine", 8, 81)
    witness = [next(i for i in range(256) if truth[i] != truth[i ^ (1 << bit)]) for bit in range(8)]
    transform = make_affine(truth, 8)
    assert transform is not None
    broken = bytearray(truth)
    broken[3] ^= 1
    assert make_affine(broken, 8) is None
    graph = make_graph(broken, 8)
    assert all(graph.lookup(i) == bit for i, bit in enumerate(broken))
    # Exhaust every two-variable Boolean function, including all-zero/all-one terminals.
    for code in range(16):
        compile_all([(code >> i) & 1 for i in range(4)], 2)
    return dict(parity_address_witnesses=witness, single_flip_rejected=True, binary_truth_tables=16)


def run(archive, destination):
    pinned = min(os.sched_getaffinity(0))
    os.sched_setaffinity(0, {pinned})
    assert array("H").itemsize == 2
    panel = actual(load_panel(archive))
    control = controls()
    workloads = []
    for depth in DEPTHS:
        for family in FAMILIES:
            for seed in SEEDS:
                f = synthesize(family, depth, seed)
                arts, selected = compile_all(f, depth)
                row = dict(depth=depth, family=family, seed=seed, selected=selected, truth_sha256=digest(f),
                           encoded={name: len(impl.wire()) for name, impl in arts.items()},
                           resident={name: impl.resident() for name, impl in arts.items()},
                           **latency(arts, seed, depth, f))
                workloads.append(row)
                print(f"{depth} bits {family} {seed}: {selected}", flush=True)
    with destination.open("x", encoding="utf-8") as file:
        json.dump(dict(python=platform.python_version(), machine=platform.machine(), host=platform.node(),
                       logical_cpu=pinned, actual=panel, controls=control, synthetic=workloads,
                       input=ARCHIVE, queries=QUERIES, samples=SAMPLES), file, allow_nan=False)


if __name__ == "__main__":
    run(*map(Path, sys.argv[1:]))
