"""Batch exact catalogue matching and check all transports to one rooted action."""

from collections import defaultdict
from itertools import groupby

import numpy as np
from catalogue_replay import WORDS, Labelled, named_action, reach
from label_floor import name_action, rooted_action

PREFIX = 12


def first_occurrences(labels):
    first = {}
    return tuple(first.setdefault(label, i) for i, label in enumerate(labels))


def prefix_index(pattern):
    return sum(position << (4 * i) for i, position in enumerate(pattern[:PREFIX]))


def prefix_batch(table):
    """Encode the complete partition of the 12 words in twelve distinct nibbles."""
    n = len(table)
    marks = np.divmod(np.arange(n * n), n)
    states = [np.zeros(n * n, dtype=np.intp), *marks]
    packed = np.zeros(n * n, dtype=np.uint64)
    for i in range(PREFIX):
        node = i + 3
        moved = table[states[(node - 1) // 2], marks[(node - 1) % 2]]
        states.append(moved)
        first = np.full(n * n, i, dtype=np.uint64)
        for j in range(i - 1, -1, -1):
            first[moved == states[j + 3]] = j
        packed |= first << (4 * i)
    return states, packed


def check_partition(table, prefix, positions, pattern):
    """The first word for each label must reach a previously unused state."""
    states = [row[positions] for row in prefix]
    owned = np.zeros((len(table), len(positions)), dtype=np.bool_)
    columns = np.arange(len(positions))
    for i, first in enumerate(pattern[:PREFIX]):
        if i == first:
            owned[states[i + 3], columns] = True
    for end in (31, 63, 127, 255, 511):
        valid = np.ones(len(positions), dtype=np.bool_)
        columns = np.arange(len(positions))
        for node in range(len(states), end):
            moved = table[states[(node - 1) // 2], states[1 + (node - 1) % 2]]
            first = pattern[node - 3] + 3
            if first == node:
                valid &= ~owned[moved, columns]
                owned[moved, columns] = True
            else:
                valid &= moved == states[first]
            states.append(moved)
        if not valid.any():
            return positions[:0], []
        if not valid.all():
            positions = positions[valid]
            states = [row[valid] for row in states]
            owned = owned[:, valid]
    return positions, states


def indexed_matches(tables, observations):
    profiles: dict[int, dict[int, dict[tuple[int, ...], list[int]]]] = defaultdict(
        lambda: defaultdict(lambda: defaultdict(list))
    )
    labels = {i: tuple(observed[word] for word in WORDS) for i, (_, observed) in observations.items()}
    for i, (n, _) in observations.items():
        pattern = first_occurrences(labels[i])
        profiles[n][prefix_index(pattern)][pattern].append(i)
    matches: dict[int, list[tuple[int, int, int]]] = {i: [] for i in observations}
    actions: dict[int, set[Labelled]] = {i: set() for i in observations}
    stats = []
    for n, index, table in tables:
        arrays = np.asarray(table, dtype=np.intp)
        prefix, packed = prefix_batch(arrays)
        surviving_prefix = generating = 0
        for code, patterns in profiles[n].items():
            positions = np.flatnonzero(packed == code)
            surviving_prefix += len(positions)
            if not len(positions):
                continue
            for pattern, cases in patterns.items():
                firsts = [i for i, first in enumerate(pattern) if i == first]
                survivors, states = check_partition(arrays, prefix, positions, pattern)
                for column, position in enumerate(survivors):
                    a, b = divmod(int(position), n)
                    # A proper subgroup has index at least two.
                    if 2 * len(firsts) <= n and reach(table, a, b) != n:
                        continue
                    generating += 1
                    for i in cases:
                        matches[i].append((index, a, b))
                        if len(firsts) < n - 1:
                            continue
                        names = {int(states[j + 3][column]): labels[i][j] for j in firsts}
                        candidate = named_action(table, a, b, names)
                        if candidate is not None:
                            actions[i].add(candidate)
        stats.append(dict(order=n, index=index, ordered_pairs=n * n, prefix=surviving_prefix, fitting_generating=generating))
    return matches, actions, stats


def one_structure(tables, witnesses):
    index, a, b = witnesses[0]
    edges, representatives = rooted_action(tables[index], a, b)
    sources = {word: i for i, word in enumerate(representatives)}
    step = [(sources[w[:-1]], int(w[-1])) for w in representatives[1:]]
    destinations = np.asarray(edges, dtype=np.intp)
    for i, group in groupby(sorted(witnesses), key=lambda pair: pair[0]):
        marks = np.asarray([pair[1:] for pair in group], dtype=np.intp).T
        table = np.asarray(tables[i], dtype=np.intp)
        transport = np.zeros((len(edges), marks.shape[1]), dtype=np.intp)
        for state, (parent, mark) in enumerate(step, 1):
            transport[state] = table[transport[parent], marks[mark]]
        if any(not np.array_equal(table[transport, marks[j]], transport[destinations[:, j]]) for j in range(2)):
            return False
    # All target pairs generate. A root-preserving equivariant map is onto,
    # and the two state counts are equal.
    return True


def indexed_naming(initial, roster, tables, witnesses, ask):
    if witnesses and one_structure(tables, witnesses):
        witnesses = witnesses[:1]
    return name_action(initial, roster, tables, witnesses, ask)
