# nanochat run (fixed FLOPs)

- Run ID: `b5-s0`
- Generated: 2026-11-23T23:14:42Z
- Artifacts: `runs/standard/b5-s0`
- Commit: 3ff468d9475dd34f8112081906f981b2c22a1e8e
- Attention schedule: `standard`

## Command

```bash
uv run python -m nanochat.train --device cpu --seed 0 --batch-size 4 --sequence-len 320 --n-layer 4 --n-head 8 --n-kv-head 4 --n-embd 128 --learning-rate 0.0006 --optimizer-type adamw --scheduler-type none --tokenizer task --tokenizer-vocab-size 512 --data-shuffle epoch --warmup-steps 0 --log-interval 50 --val-interval 0 --attention-type standard --target-flops 5e12 --checkpoint-interval 1000000 --checkpoint-keep 0 --data-dir /data/ssd/tmp/mgr-hier-paired.Ji7EOJkO/artifacts/probes/sizing/jida12-paired-hier/data/hier_paired --min-parquet-files 2 --artifacts-dir /data/ssd/tmp/mgr-hier-paired.Ji7EOJkO/artifacts/probes/sizing/jida12-paired-hier --artifacts-kind runs --artifacts-topic standard --run-id b5-s0 --check-numerics
```

## Budget

- steps: 594
- warmup_steps: 0
- tokens/step (global): 1,280
- FLOPs/token (est): 6,586,368
- FLOPs/step (est): 8,430,551,040
- planned_total_FLOPs (est): 5,007,747,317,760

## Compilation

- torch.compile: False
- compile_backend: 'inductor'
- compile_mode: None
- compile_fullgraph: False
- compile_dynamic: None
- compile_flex_attention: False

## Numerics (debug)

- check_numerics: True
- detect_anomaly: False

## Results (measured after warmup)

- measured_steps: 594
- measured_tokens: 760,320
- measured_time_s: 63.152
- tokens/s: 12,040
- TFLOP/s (est): 0.08
- peak_memory_allocated_gb: n/a
- final_train_ce: 0.4857
- val_interval: 0
- val_batches: n/a
- final_val_ce: n/a
- final_val_bpb: n/a (bits per byte; comparable across tokenizers)

See `summary.json` for full details.
