# eval-tasks — objective-answer-s17

- checkpoint: `/data/ssd/tmp/mgr-hier-s320.hk5mLTED/artifacts/probes/sizing/jida12-hier-s320/runs/standard/objective-answer-s17/checkpoints` @ step 2047
- attention_type: standard
- n_params: 819,200
- seeds: [0, 1, 2] · examples/seed: 24 · decode: ['greedy']

| task | EM in-range | EM held-out | ppl in/held | slope held-out [CI95] | curve |
|---|---|---|---|---|---|
| hier | 0.000 | 0.000 | 50631.2/47347.4 | +0.0000 [+0.0000,+0.0000] | [curve](curve_hier.png) |

See `summary.json` (schema mgr.evaltasks.v4) for the full contract output and `generations.jsonl` for per-example receipts.
