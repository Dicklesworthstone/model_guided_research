"""Audit order-free frontier closure and proof-carrying action proposals."""
import argparse
import json
import random
from collections import Counter, defaultdict
from copy import deepcopy
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile

from audit_compact import build_catalog, cancelled, check_closure, check_transport, digest, pointwise, replay_family
from size_free import check_normal_closure

HISTORY = Path("artifacts/probes/sizing")
MANIFESTS = (
    HISTORY / "group-congruence/coverage.json",
    HISTORY / "group-congruence/proposal-coverage.json",
    HISTORY / "group-certificate/coverage.json",
)
ARCHIVE = HISTORY / "group-certificate/verification.zip"
FAMILIES = ["s5"] * 6 + ["s4"] * 4 + ["a6"] * 4 + ["c1"] + ["c2"] * 3
ORDERS = {"s5": 120, "s4": 24, "a6": 360, "c1": 1, "c2": 2}


def audit_frontier(data, evaluate):
    reps = [""]
    known = {evaluate("")}
    columns = [set(), set()]
    memo = {("", ""): True}
    table = []
    calls = []
    tally = Counter()
    trace = iter(data["trace"])
    for source in reps:
        row = []
        for digit in range(2):
            word = source + str(digit)
            entry = next(trace)
            assert entry["word"] == word and "normal_form" not in entry
            trials = entry["trials"]

            def distance(index):
                differences = [abs(word.count(ch) - reps[index].count(ch)) for ch in "01"]
                return sum(d % 2 for d in differences) * 144 + sum(differences), index

            eligible = sorted(set(range(len(reps))) - columns[digit], key=distance)
            destination = None
            for index, (option, channel, answer) in enumerate(trials):
                assert option == eligible[index]
                ref = reps[option]
                key = cancelled(word, ref)
                correct = evaluate(word) == evaluate(ref)
                assert answer is correct
                if key in memo:
                    assert channel == "cache" and memo[key] is correct
                else:
                    assert channel == "oracle"
                    memo[key] = correct
                    calls.append([word, ref, correct])
                tally[channel + ("_equal" if correct else "_different")] += 1
                if correct:
                    assert index == len(trials) - 1
                    destination = option
            if destination is None:
                assert len(trials) == len(eligible)
                value = evaluate(word)
                assert value not in known
                known.add(value)
                destination = len(reps)
                reps.append(word)
                tally["new"] += 1
            assert destination == entry["target"] and destination not in columns[digit]
            columns[digit].add(destination)
            row.append(destination)
        table.append(row)
    assert next(trace, None) is None and len(table) == len(reps)
    assert all(column == set(range(len(reps))) for column in columns)
    assert data["representatives"] == reps and data["edges"] == table
    assert data["counts"] == dict(tally)
    assert data["memo_entries"] == len(memo)
    assert data["memo_symbols"] == sum(len(left) + len(right) for left, right in memo)
    return table, calls


def checked_prior_library():
    with ZipFile(ARCHIVE) as archive:
        old = json.loads(archive.read("run.json"))
        check_normal_closure(json.loads(archive.read("normal-closure.json")))
    check_closure(old["closure"])
    catalog = build_catalog()
    assert set(catalog) == set(old["transports"]) and len(catalog) == 57
    proof = {}
    for key, witness in old["transports"].items():
        positive = [(left, right, True) for left, right in check_transport(witness, key)]
        first, second = witness["forward"][:2]
        left, right = sorted((first + second, second + first))
        assert left != right
        proof[key] = [*positive, (left, right, False)]
    return catalog, proof


def audit_arm(data, treatment, truth, evaluate, catalog, proof):
    selection_calls, verify_calls, fallback_calls = [], [], []
    if treatment:
        proposed = data["proposal"]
        key = proposed["marked_class"]
        replay_family({**proposed, "seconds": 0, "oracle_seconds": 0}, catalog, evaluate, key)
        selection_calls = [[*item["pair"], item["answer"]] for item in proposed["queries"]]
        memo = {tuple(row[:2]): row[2] for row in selection_calls}
        assert len(memo) == len(selection_calls)
        steps = data["checks"]
        expected = proof[key]
        assert 0 < len(steps) <= len(expected)
        accepted = False
        for i, step in enumerate(steps):
            left, right, expected_answer = expected[i]
            answer = evaluate(left) == evaluate(right)
            assert step["pair"] == [left, right] and step["expected"] is expected_answer
            assert step["answer"] is answer and step["reused"] is ((left, right) in memo)
            if step["reused"]:
                assert memo[left, right] is answer
            else:
                verify_calls.append([left, right, answer])
            if answer != expected_answer:
                assert i == len(steps) - 1
                break
        else:
            assert len(steps) == len(expected)
            accepted = True
        assert data["accepted"] is accepted
    else:
        assert data["proposal"] is None and data["accepted"] is False and not data["checks"]
        accepted = False
    if accepted:
        assert data["acquisition"] is None
        assert catalog[key][0] == truth
    else:
        table, fallback_calls = audit_frontier(data["acquisition"], evaluate)
        assert table == truth
    paid = selection_calls + verify_calls + fallback_calls
    assert data["paid"] == paid and len(paid) <= 150_000
    assert 0 <= data["oracle_seconds"] <= data["seconds"]
    portions = zip(("selection", "certificate", "frontier"), (selection_calls, verify_calls, fallback_calls), strict=True)
    stats = dict(cases=1, accepted=int(accepted), checks=len(paid), symbols=sum(len(a)+len(b) for a,b,_ in paid))
    for name, calls in portions:
        stats[f"{name}_checks"] = len(calls)
        stats[f"{name}_symbols"] = sum(len(a)+len(b) for a,b,_ in calls)
    return stats, fallback_calls


def reject_mutation(check, mutated):
    try:
        check(mutated)
    except (AssertionError, IndexError, StopIteration):
        return
    raise AssertionError("Mutated evidence passed the verifier")


def run_audit(coverage, output, producer):
    manifest = json.loads(coverage.read_bytes())
    transcript = json.loads(output.read_bytes())
    previous, *later = [json.loads(path.read_bytes()) for path in MANIFESTS]
    seen = set(previous["spent"]) | {row["graph_sha"] for row in previous["presentations"]}
    seen.update(row["graph_sha"] for earlier in later for row in earlier["cases"])
    assert manifest["seed"] == 2026112323 and manifest["call_limit"] == 150_000
    assert manifest["producer"] == sha256(producer.read_bytes()).hexdigest()
    assert manifest["prior"] == [sha256(path.read_bytes()).hexdigest() for path in MANIFESTS]
    assert manifest["library"] == sha256(ARCHIVE.read_bytes()).hexdigest()
    assert transcript["coverage_sha256"] == sha256(coverage.read_bytes()).hexdigest()
    catalog, proof = checked_prior_library()
    assert transcript["catalog"] == len(catalog)
    assert len(FAMILIES) == len(transcript["results"]) == len(manifest["cases"])
    totals = defaultdict(lambda: defaultdict(Counter))
    cases = []
    maximum_extra = 0
    audited_edges = 0
    mutations = set()
    for i, (family, case, logged) in enumerate(zip(FAMILIES, manifest["cases"], transcript["results"], strict=True)):
        assert family == case["family"] and i == logged["index"]
        assert all(logged[key] == value for key,value in case.items())
        truth, _, evaluate, ids = pointwise("permutation", case["generators"])
        fingerprint = digest(truth)
        assert fingerprint == case["graph_sha"] and len(truth) == ORDERS[family]
        assert (fingerprint in catalog) is (family == "s5")
        if i < 14:
            assert case["fresh"] is True and fingerprint not in seen
        else:
            assert case["fresh"] is False
        seen.add(fingerprint)
        observed = dict()
        for arm_name in ("baseline", "treatment"):
            arm = logged[arm_name]
            trial = arm_name == "treatment"
            stats, frontier_calls = audit_arm(arm, trial, truth, evaluate, catalog, proof)
            assert bool(stats["accepted"]) is (trial and family == "s5")
            totals[family][arm_name].update(stats)
            observed[arm_name] = stats
            if not trial:
                baseline_calls = frontier_calls
                if "truncated_frontier" not in mutations:
                    damaged = deepcopy(arm["acquisition"])
                    damaged["trace"].pop()
                    reject_mutation(lambda data: audit_frontier(data, evaluate), damaged)
                    mutations.add("truncated_frontier")
            elif family != "s5":
                assert frontier_calls == baseline_calls
                maximum_extra = max(maximum_extra, stats["checks"] - len(baseline_calls))
            elif "forged_kernel_check" not in mutations:
                damaged = deepcopy(arm)
                damaged["checks"][-1]["answer"] = True
                reject_mutation(lambda data: audit_arm(data, True, truth, evaluate, catalog, proof), damaged)
                mutations.add("forged_kernel_check")
        if "incorrect_paid_answer" not in mutations:
            damaged = deepcopy(logged["baseline"])
            damaged["paid"][0][2] = not damaged["paid"][0][2]
            reject_mutation(lambda data: audit_arm(data, False, truth, evaluate, catalog, proof), damaged)
            mutations.add("incorrect_paid_answer")
        words = logged["samples"]
        assert Counter(len(w) for w,_ in words) == {16:48, 32:48, 64:48, 128:48}
        rng = random.Random(98290 + i)
        drawn = {}
        for block, n in enumerate((16, 32, 64, 128), start=1):
            while len(drawn) < 48 * block:
                word = format(rng.getrandbits(n), f"0{n}b")
                drawn[word] = ids[evaluate(word)]
        assert words == [[word, target] for word, target in drawn.items()]
        audited_edges += 4*len(truth)
        cases.append(dict(index=i, family=family, order=len(truth), **observed))
    assert len({row["graph_sha"] for row in manifest["cases"]}) == 18 and len(mutations) == 3
    assert sum(t["treatment"]["accepted"] for t in totals.values()) == 6
    s5 = totals["s5"]
    saved_calls = 1 - s5["treatment"]["checks"] / s5["baseline"]["checks"]
    saved_symbols = 1 - s5["treatment"]["symbols"] / s5["baseline"]["symbols"]
    print(json.dumps(dict(
        gate_passed=(saved_calls >= .95 and saved_symbols >= .95 and maximum_extra <= 24),
        saved_calls=saved_calls, saved_symbols=saved_symbols, max_control_extra_calls=maximum_extra,
        audited_edges=audited_edges, held_out_words=18*192, mutations=sorted(mutations), totals=totals, cases=cases,
    ), sort_keys=True))


if __name__ == "__main__":
    args = argparse.ArgumentParser(description=__doc__)
    args.add_argument("coverage", type=Path)
    args.add_argument("report", type=Path)
    args.add_argument("producer", type=Path)
    params = args.parse_args()
    run_audit(params.coverage, params.report, params.producer)
