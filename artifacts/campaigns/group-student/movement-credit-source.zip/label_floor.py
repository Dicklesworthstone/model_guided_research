"""Name a uniquely identified rooted action at its fixed-root oracle floor."""

import json
import sys
import time
from collections import deque
from pathlib import Path

from catalogue_replay import labelled_prediction, read

from scripts.group_rewrite_probe import teach_panel_case


def rooted_action(table, a, b):
    names = {0: 0}
    order = [0]
    representatives = [""]
    edges = []
    for state, word in zip(order, representatives):
        row = []
        for mark, target in enumerate((table[state][a], table[state][b])):
            if target not in names:
                names[target] = len(names)
                order.append(target)
                representatives.append(word + str(mark))
            row.append(names[target])
        edges.append(tuple(row))
    if len(edges) != len(table):
        raise ValueError("A certified pair no longer generates its group")
    return tuple(edges), representatives


def walk(edges, word):
    state = 0
    for mark in word:
        state = edges[state][int(mark)]
    return state


def name_action(initial, roster, tables, witnesses, ask):
    structures = {}
    for i, a, b in witnesses:
        edges, words = rooted_action(tables[i], a, b)
        structures[edges] = words
    if len(structures) != 1:
        return dict(structures=len(structures), action=None)
    ((edges, words),) = structures.items()
    known = {walk(edges, word): label for word, label in initial.items()}
    unknown = [i for i in range(len(edges)) if i not in known]
    available = roster.difference(known.values())
    if len(available) != len(unknown):
        raise ValueError("Short labels do not give a partial bijection")
    for state in unknown[:-1]:
        label = ask(words[state])
        if label not in available:
            raise ValueError("Oracle reused an opaque name")
        available.remove(label)
        known[state] = label
    if unknown:
        (last,) = available
        known[unknown[-1]] = last
    by_name = {known[i]: tuple(known[t] for t in row) for i, row in enumerate(edges)}
    return dict(structures=1, action=(known[0], tuple(by_name[str(i)] for i in range(len(edges)))))


def oracle(case):
    marks, names = case["generator_pair"], case["opaque_names"]
    identity = tuple(range(5))
    indices = {identity: 0}
    queue = deque([identity])
    while queue:
        state = queue.popleft()
        for mark in marks:
            target = tuple(mark[point] for point in state)
            if target not in indices:
                indices[target] = len(indices)
                queue.append(target)

    def reply(word):
        # Evaluate this word pointwise, independently of the learner's table.
        final = []
        for point in identity:
            for symbol in word:
                point = marks[int(symbol)][point]
            final.append(point)
        return names[indices[tuple(final)]]

    return reply


def run(cohort, catalogue, parent, output):
    def must_not_ask(word):
        raise ValueError(f"A query escaped the ambiguity control: {word}")

    cycle = [[0, 1, 2], [1, 2, 0], [2, 0, 1]]
    ambiguity = name_action({}, {"0", "1", "2"}, {1: cycle}, [(1, 0, 1), (1, 1, 0)], must_not_ask)
    if ambiguity != dict(structures=2, action=None):
        raise ValueError("The distinct structures were conflated")
    tables = {(n, i): table for n, i, table in read(catalogue)[2]}
    results = []
    for row in read(parent)["results"]:
        case = read(cohort / f'{row["index"]:02}.json')
        initial = dict(case["arms"]["short_only"]["rows"])
        n = row["order"]
        roster = set(map(str, range(n)))
        teacher = oracle(case)
        paid = []

        def ask(word, tape=paid, exact=teacher):
            label = exact(word)
            tape.append((word, label))
            return label

        started = time.process_time_ns()
        candidate = name_action(initial, roster, {i: tables[n, i] for i, _, _ in row["catalogue"]["witnesses"]},
                                row["catalogue"]["witnesses"], ask)
        candidate.update(paid=paid, cpu_ns=time.process_time_ns() - started)
        action = candidate["action"]
        candidate["answers"] = {
            split: [None if action is None else labelled_prediction(action, word) for word, _, _ in case[split]]
            for split in ("primary", "secondary")
        }
        started = time.process_time_ns()
        full, square_paid = teach_panel_case(initial, roster, teacher, squares=True)
        root = full.maps["r0"][full.maps["r0"][initial["00"]]]
        square = dict(action=(root, [tuple(full.maps["R" + mark][str(i)] for mark in "01") for i in range(n)]),
                      paid=square_paid, cpu_ns=time.process_time_ns() - started)
        results.append(dict(index=row["index"], order=n, observed=row["seen"], catalogue=candidate, square=square))
    with output.open("x", encoding="utf-8") as file:
        json.dump(results, file, sort_keys=True)
        file.write("\n")


if __name__ == "__main__":
    run(*map(Path, sys.argv[1:]))
