# Prefix-address precision for a binary binding table

At parent depth h, write the root-to-parent child bits as c₀,…,cₕ₋₁.
The parent address is Σⱼ cⱼ2ʲ. Keeping k binary digits means reduction
modulo 2ᵏ, which retains the first min(h,k) root-path bits. The bank
is indexed by depth as well as this residue. Each parent supplies one
fixed swap bit b, and an alias q selects child q ⊕ b.

For a fixed table, two parents that share an observed address and have
opposite swap bits require different children for either same alias.
A deterministic function of the table, depth, residue, and alias
returns one child for both. If a bucket has n₀ zero bits and n₁ one
bits, its best possible local accuracy under uniform parent queries
is max(n₀,n₁)/(n₀+n₁). This holds separately for each query alias.
Choosing the majority swap bit attains that bound. The greedy
root-to-leaf counts in the audit use that policy at every visited scope.

When the swap bits are independent fair bits and the bucket size is
m, the expected local ceiling is 1/2 + C(m−1, floor((m−1)/2))/2ᵐ.
For m=1 the ceiling is one. The remaining bucket sizes here are even,
so write m=2n. Let X count the ones. The excess above 1/2 is
E[|X−n|]/(2n). The binomial distribution is symmetric, and
(j−n) C(2n,j) = n [C(2n−1,j−1) − C(2n−1,j)].
Summing the positive half j=n+1,…,2n telescopes to n C(2n−1,n).
Substitution gives the stated ceiling.

This argument concerns a fixed prefix-address encoder and local
queries. A traversal carrying the exact parent pointer already
possesses the information that the truncated-address decoder omits.
