import hashlib
import json
import math
import statistics
import sys
from collections import Counter, defaultdict
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import evidence
import mixture as trial
import posterior as post
from address_fixtures import sha_json
from posterior_replay import independent_catalog, oracle_fixture

SOURCE = "5bed98bcf41edf74f6e9d3517d011f6dcf77f45d"
LOCK = "921a4aed8623aa57f48e38ece64833014970df19ca94f6f9a035b7406af55235"
SHADOW = "03c66dc47b91756fd082ed775d56f9ed741b7b434f887fdd4a1c46a2a1471793"
RAW = "c8f087f860fbfb7958aec27891302df3b6f3b5cf6328af08ce8e1857f89557a9"
FILES = ("address_fixtures.py", "topology.py", "posterior.py", "posterior_replay.py", "evidence.py",
         "mixture.py", "mixture.yaml", "frozen.sha256", "protocol.txt", "mixture-raw.json",
         "mixture_replay.py", "argument.md", "replay.yaml", "replay-repair.txt",
         *(f"replay-failure/{name}" for name in ("mixture_replay.py", "decision.json", "receipt.json",
                                                 "check-1.log", "checks-config.yaml")))


def digest(data):
    return hashlib.sha256(data).hexdigest()


def receipt_id(read, files):
    path, = (name for name in files if name.startswith("receipts/") and name.endswith("/receipt.json"))
    receipt = json.loads(read(path))
    assert receipt["tool"] == "hierarchy-shape-mixture" and receipt["status"] == "passed"
    assert receipt["passed"] == receipt["executed"] == receipt["total"] == 1
    assert not receipt["dry_run"] and not receipt["skipped"]
    check, = receipt["checks"]
    assert check["passed"] and check["executed"] and check["exit_code"] == 0
    log = Path(path).with_name(Path(check["log_path"]).name).as_posix()
    assert digest(read(log)) == check["log_sha256"]
    config = Path(path).with_name("checks-config.yaml").as_posix()
    assert read(config) == read("mixture.yaml")
    assert digest(read(config)) == receipt["config_sha256"] == receipt["config_sha256_after"]
    return Path(path).parent.name


def direct_normalizers():
    result = []
    for _, beta in trial.COMPONENTS:
        z = [1.]
        for m in range(1, post.INTERNAL + 1):
            z.append(m ** -beta * math.fsum(z[i] * z[m-i-1] for i in range(m)))
        assert math.isclose(math.log(z[-1]), evidence.log_partition(beta)[-1], abs_tol=1e-12, rel_tol=0)
        result.append(z[-1])
    return result


def direct_masses(versions, normalizers):
    masses = []
    for (_, beta), z in zip(trial.COMPONENTS, normalizers, strict=True):
        answers = defaultdict(list)
        for leaf, hooks, count in versions:
            answers[leaf].append(count * hooks ** -beta / z)
        masses.append({leaf: math.fsum(values) for leaf, values in answers.items()})
    return tuple(masses)


def check_fit(train, fit, normalizers):
    logs = []
    for row in train:
        masses = [math.fsum(mass.values()) for mass in direct_masses(row["versions"], normalizers)]
        logs.append([value / max(masses) for value in masses])
    grid = fit["grid"]
    assert len(grid) == len({tuple(weights) for weights, _ in grid}) == 171
    assert all(sum(weights) == 20 and min(weights) >= 1 for weights, _ in grid)
    for weights, observed in grid:
        reference = statistics.mean(math.log(math.fsum(a * b for a, b in zip(weights, row, strict=True)) / 20)
                                    for row in logs)
        assert math.isclose(reference, observed, abs_tol=1e-12, rel_tol=0)
    assert fit["best"] == max(score for _, score in grid)
    # Relabeling every terminal in the feasible catalogs cannot change the training evidence.
    erased = [[(0, hooks, count) for _, hooks, count in row["versions"]] for row in train]
    stripped = trial.fit([trial.likelihood(versions) for versions in erased])
    assert all(stripped[key] == fit[key] for key in ("weights", "best", "grid"))


def check_prediction(row, current, stale, proportion, normalizers):
    direct = direct_masses(row["versions"], normalizers)
    totals = [math.fsum(mass.values()) for mass in direct]
    assert all(isinstance(p, float) and p > 0 for p in totals)
    assert all(math.isclose(a, b/max(totals), abs_tol=2e-13, rel_tol=0) for a, b in
               zip(trial.likelihood(row["versions"]), totals, strict=True))
    predictions = trial.verdicts(current, stale, proportion, row)
    for name, prior in (("adaptive", current["weights"]), ("oracle", proportion), ("stale", stale["weights"])):
        scaled = [component * mass for component, mass in zip(prior, totals, strict=True)]
        denominator = math.fsum(scaled)
        answer, mixture = predictions[name]
        assert math.isclose(math.fsum(answer.values()), 1, abs_tol=1e-14, rel_tol=0)
        assert all(math.isclose(value, weight / denominator, abs_tol=1e-13, rel_tol=0)
                   for value, weight in zip(mixture, scaled, strict=True))
        for leaf, probability in answer.items():
            weight = math.fsum(a * pdf[leaf] for a, pdf in zip(prior, direct, strict=True))
            assert math.isclose(probability, weight / denominator, abs_tol=1e-13, rel_tol=0)


def replay(read, names, validate_catalogs=False):
    lock = read("frozen.sha256")
    assert digest(lock) == LOCK
    for line in lock.decode().splitlines():
        sha, path = line.split()
        assert digest(read(path)) == sha
    assert digest(read("posterior_replay.py")) == SHADOW
    assert digest(read("mixture-raw.json")) == RAW
    normalizers = direct_normalizers()
    raw = json.loads(read("mixture-raw.json"))
    rows = raw["rows"]
    assert len(rows) == len({row["fixture"] for row in rows}) == 240
    selected = defaultdict(list)
    audit = []
    for measured, spec in zip(rows, trial.fresh(), strict=True):
        seed, regime, phase, index, records, root, query, gold, origin, namespace = spec
        assert (measured["seed"], measured["regime"], measured["phase"], measured["index"]) == (seed, regime, phase, index)
        assert measured["fixture"] == sha_json([records, root, query])
        assert (measured["target"], measured["component"]) == (gold, origin)
        oracle_fixture(records, root, query, gold, namespace)
        assert measured["bank_maps"] == 40320
        versions = measured["versions"]
        assert gold in {key for key, _, _ in versions}
        assert 1 <= sum(count for _, _, count in versions) <= measured["rooted_maps"] <= 40320
        assert all(hooks > 0 and count > 0 and not records[key] for key, hooks, count in versions)
        if phase == "test" and index == 0:
            audit.append([seed, regime])
            if validate_catalogs:
                direct = independent_catalog(records, root, query)
                assert all(measured[key] == value for key, value in direct.items())
        selected[seed, regime, phase].append(measured)
    assert len(audit) == 6
    fits = trial.compare(rows)
    assert json.loads(json.dumps(fits)) == raw["fits"]
    pooled = {}
    gates = {}
    for regime_index, (regime, proportions) in enumerate(trial.REGIMES):
        batches = [fits[seed][regime] for seed in trial.SEEDS]
        for seed, batch in zip(trial.SEEDS, batches, strict=True):
            train, test = (selected[seed, regime, phase] for phase in trial.PHASES)
            assert len(train) == len(test) == 20
            opposite = fits[seed][trial.REGIMES[1 - regime_index][0]]["fit"]
            check_fit(train, batch["fit"], normalizers)
            for row in test:
                check_prediction(row, batch["fit"], opposite, proportions, normalizers)
        scores = {arm: {
            metric: sum(batch["test"][arm][metric] for batch in batches) if metric.endswith("correct")
            else statistics.mean(batch["test"][arm][metric] for batch in batches)
            for metric in batches[0]["test"][arm]} for arm in trial.ARMS}
        tv = statistics.mean(sum(abs(a - b) for a, b in zip(batch["fit"]["weights"], proportions, strict=True)) / 40
                             for batch in batches)
        train_counts, test_counts = (Counter(row["component"] for seed in trial.SEEDS
                                             for row in selected[seed, regime, phase])
                                     for phase in trial.PHASES)
        assert sum(train_counts.values()) == sum(test_counts.values()) == 60
        pooled[regime] = dict(cases=60, weights=[list(batch["fit"]["weights"]) for batch in batches],
                              avg_total_variation=tv, scores=scores,
                              component_train=[train_counts[i] for i in range(3)],
                              component_test=[test_counts[i] for i in range(3)],
                              ambiguous=sum(len({leaf for leaf, _, _ in row["versions"]}) > 1 for seed in trial.SEEDS
                                            for row in selected[seed, regime, "test"]))
        proposed = scores["adaptive"]["nll"]
        gates[regime] = dict(
            uniform_gain=scores["uniform"]["nll"] - proposed >= .10,
            static_gain=scores["static"]["nll"] - proposed >= .10,
            oracle_gap=proposed - scores["oracle"]["nll"] <= .15,
            prevalence_error=tv <= .25,
        )
    return dict(source=SOURCE, receipt=receipt_id(read, names), train=120, test=120, audit_cases=audit,
                gates=gates, pass_all=all(all(group.values()) for group in gates.values()), pooled=pooled)


def verify_failed_replay(read, decision):
    receipt = json.loads(read("replay-failure/receipt.json"))
    check, = receipt["checks"]
    assert receipt["status"] == "failed" and check["exit_code"] == 1
    log = read("replay-failure/check-1.log")
    assert digest(log) == check["log_sha256"]
    assert b'assert decision == json.loads(archive.read("decision.json"))' in log and b"AssertionError" in log
    assert digest(read("replay-failure/mixture_replay.py")) == "31447dbfb8e361c6e6fa9fa21650977bde1f5f060afcaff5929dc7905bb1a798"
    assert read("replay-failure/checks-config.yaml") == read("replay.yaml")
    assert decision == json.loads(read("replay-failure/decision.json"))


def verify(bundle):
    with ZipFile(bundle) as archive:
        names = archive.namelist()
        assert archive.testzip() is None and len(names) == len(set(names))
        decision = replay(archive.read, names, validate_catalogs=True)
        assert decision == json.loads(archive.read("decision.json"))
        verify_failed_replay(archive.read, decision)
    print(json.dumps(decision))


def build(root, bundle):
    files = {name: root / name for name in FILES}
    receipt, = (root / "receipts").glob("*/*/receipt.json")
    for name in ("receipt.json", "check-1.log", "checks-config.yaml"):
        path = receipt.with_name(name)
        files[path.relative_to(root).as_posix()] = path
    result = replay(lambda name: files[name].read_bytes(), files.keys())
    with ZipFile(bundle, "x", compression=ZIP_DEFLATED) as archive:
        for name, path in files.items():
            archive.write(path, name)
        archive.writestr("decision.json", json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    action, *paths = sys.argv[1:]
    {"build": build, "verify": verify}[action](*map(Path, paths))
