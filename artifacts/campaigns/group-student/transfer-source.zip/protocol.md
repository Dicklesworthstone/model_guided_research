# Transfer of exact endpoint acquisition to three held-out orders

Bead `model_guided_research-vokn`. The shortest-tier learner and live square
closure are the exact source from `ed9cda5` and its checkout. Both complete a
deterministic finite group action from public order, public roster and four
paid endpoints for `00`, `01`, `10` and `11`. Nothing in the learner or query
policy is fitted to the new orders. The shortlist, tie breaks, fallback cap,
and naming rules are frozen. The catalogue is the one additional resource.

## Inventory and charging

- Use all 151, 503 and 1,799 distinct rooted regular marked actions of orders
  32, 64 and 128 in the earlier complete anchor study. That study selected all
  rank-one and rank-two groups from GAP 4.16.1 and SmallGrp 1.7.0 and enumerated
  their generating pairs. The stored action set anchors the verifier and gives
  it an independent method of detecting a missing or extra shape. The new
  runner builds its own inventories from the fixed exported multiplication
  tables by conjugacy orbits and direct abelian lattices.
- For each order, separately time parsing its exported tables, building its
  exact inventory, indexing endpoints and preparing tiers. Charge these four
  stages only to the tiered arm, once per order. Square closure does not use
  any of the preparation. Charge every word including the four shared initial
  anchors as one reset/read, and every `0` and `1` in it as a symbol. Host time
  begins after the common anchors in each timed online invocation. Measure
  process CPU and elapsed, with the in-process oracle included. The cold sum
  includes all staged preparation and acquisitions on that order. Earlier GAP
  export time and physical setup, reset, read and movement latency are outside
  the host measurement.
- Use the two released deterministic affine relabelings, with hash seeds `0`
  and `991`. Alternate arm order by slot and reverse the order on the second
  pass. Both runs use every shape exactly once. There is no learned accuracy
  floor, population inference or sample-size calculation for this exhaustive
  comparison. The relabeling is a reproducibility and timing check. It is not
  an independent sample of group actions.

## Validity and stopping rule

Require equality of the live inventory fingerprint with the earlier exhaustive
inventory sorted in canonical order. Verify each named row and paid reply,
exact terminal transitions, naming and movement lower bounds, and canonical
paid tape and trace parity across relabelings. Independently recompute the
selected score and compatible shape count at each structural step in the
primary run by tracking equality partitions of observed words. Verify the
shortest remaining naming sequence. Check that a forged selected score is
rejected. In each run also force cap fallback on an ambiguous case, verify
the square tape it takes, and reject a reused label at singleton naming.

The pre-evidence transfer prediction requires strict aggregate improvement in
**reads, symbols and cold process CPU at each order in both runs**. Preserve and
report the three components individually in all six run-by-order cells, even
when the joint prediction fails. Also report warm CPU and elapsed, setup stage
times, both symbol counts, per-shape read and symbol regressions, and aggregate
costs on the anchor-certified abelian and nonabelian subgroups. Compare one
prepared catalogue against square closure at the same order and state the cost
of preparing it for a cold call. Stop after the two complete runs, regardless
of the outcomes. The execution and correctness check can pass when the
quantitative prediction fails. The raw census makes both facts auditable.

This experiment tests symbolic finite-census transfer only. It has no new
transformer training, external population inference or physical-device claim.
