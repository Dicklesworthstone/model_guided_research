# Model reuse and temporary rank ordering

This preregistration fixes the synthetic experiment for Beads `jqc4.3` and `jqc4.4`. The first factor reuses a fitting model after a paid observation. The second orders unseen labels by reachability rank while getting a base model. The four factor combinations share the exact conjugation learner from `0083c26`. Run the existing square-closure learner on the same cases.

## Frozen panel

| Marked action | Two primitives or primitive words | States |
| --- | --- | ---: |
| Pentagon | T, F | 10 |
| Hexagon | T, FT | 12 |
| Octagon | T, FT | 16 |
| Nonagon | T, F | 18 |
| 2×4 torus | F, F | 8 |
| 3×4 torus | F, F | 12 |
| Tetrahedral rotations | T, T | 12 |
| Forced exhaustion on a separate 2×4 relabeling | F, F | 8 |

The rings distinguish generator order and marking from prior tests. Each torus uses the positive unit translations on its two axes. The tetrahedral action is the right regular action of A4 with a 3-cycle and a double transposition that generate A4. The seven ordinary actions are held out relative to earlier marked-action results. The last row tests fallback and is excluded from ordinary performance totals. Shuffle each opaque roster with Python's local PRNG and seed `251431 + case_index`. Freeze the order above and rotate the arm order by case index. Each arm receives the same vocabulary and four paid length-two endpoint replies. Each additional word costs one reset and endpoint read plus its primitive motion count. Only the oracle knows the identity and generator maps.

## Interventions

After a paid answer, retain the first or second fitting model in that order. If neither predicts the answer and both the answer and one candidate prediction are unseen, take the first such model and conjugate both action tables and the root by the corresponding transposition. Check every retained witness against the enlarged transcript. Queue every paid constraint as in the frozen solver and flush before the next real solver query.

For a base check with at least two unseen labels, add a temporary strict chain on the ranks of those labels in lexical order. Every fitting action has a representative in that scope. Root a spanning tree at the identity and assign distinct integer ranks along a parent-first enumeration. Relabel unseen names to put those ranks in lexical order, transporting the action tables, root and predecessor map. That permutation fixes every observed endpoint. Extract the fitting model before popping the scope. The subsequent alternative search quantifies over all fitting tables through the original formula with a single right-table blocking clause.

## Fixed execution and interpretation

Use Z3 4.15.4, one SMT thread, seed zero, two million deterministic internal resources per check and no per-check wall timeout. The forced exhaustion control has one resource unit per check. Each arm stops solver acquisition at the first UNKNOWN, an unscoped UNSAT alternative, or 65 rounds. On UNKNOWN or cap it finishes via square closure from the accumulated transcript. The outer DSR deadline is a harness failure if reached. Run each arm once, then run the whole panel in fresh processes with a different Python hash seed. Exact comparison drops process and wall timings only. This is an exhaustive report on the frozen cases. Independent population inference would require a powered design and a separate target population. There is no early success stop.

Independently rebuild each generator table and verify all 192 labeled transitions per arm including the control, every oracle reply, every witness, the shortest distinguishing words, fallback, reuse provenance, and the exact transmitted scope operations of the three new arms. Attempt to reject a missing scope pop and forged reuse method. If reuse never occurs, report the latter control as unexercised. Retain the actual Z3 statuses and work counts. The SMT results are replayed on the same solver version.

- Completion improves only if the ordinary unscoped-UNSAT set strictly contains the conjugation-only completion set. Report any lost cases.
- Reuse succeeds on the base-check criterion if reuse alone halves the real base-check count without losing any conjugation-only completions. Apply the same criterion to the combined arm separately. Report alternative checks and total CPU as secondary observations.
- The rank intervention clears its first-witness criterion if rank alone gets an initial SAT on at least one baseline initial UNKNOWN. Also report this for the combined arm and whether each rescued case eventually completes.
- Report paid reads, resets, turns, advances and CPU for all five arms. Do not score a physical cost improvement until independent prices exist. Report the scope of any engineering result and keep all negative outcomes.
