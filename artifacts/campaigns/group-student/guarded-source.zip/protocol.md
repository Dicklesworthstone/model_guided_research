# Guarded switches between exact query policies

Bead `model_guided_research-uj8l`. The bundled shortlist is the incumbent
and the globally shortest frontier is the alternative. Both are already
compiled and start with the same paid observations.

## Pointwise guarantee

If the two live continuations next request the same word, pay it once and
partition the remaining hypotheses by first-seen reply rank. Each resulting
branch contains exactly those audited marked shapes which would reach that
history. Inductively a live action in the declared catalogue follows the
same shared prefix as the simulated action for its shape. Changing opaque
label spellings or roster order preserves these equality ranks. The original
compiled policies already use ranks to select their paths.

At the first differing word the prefix has the same charge under either
choice, so each shape's full tape cost difference equals the difference
between its two remaining tails. Continue with the frontier only when no
compatible shape costs more and at least one costs strictly less. Otherwise
continue with the shortlist. One switch selects one existing subtree for the
rest of the acquisition. Each possible complete paid tape therefore belongs
to one of the unchanged policies. The exact named table and the existing
validated naming and fallback paths are retained.

The componentwise guard applies that condition independently to reset/read
counts, zero commands, and one commands. It protects every nonnegative
price vector on that catalogue. The priced guard applies it to the dot
product with a specified triple. Both guarantees concern paid oracle work.
They assume an exact stable oracle and a complete audited catalogue and
exclude policy preparation and host time. Compilation derives each tape
cost by running both policies on the known shapes. Archived comparison
tapes are used only by the independent post-run audit.

## Comparison fixed before scoring

- Use all 151, 503 and 1,799 distinct rooted marked actions at orders 32,
  64 and 128. Run live square closure, bundled shortlist, exhaustive frontier,
  componentwise guard and priced guard in the same invocation. Rotate arm
  order by slot. Reverse it and the roster order in the second execution.
  Use the two published affine endpoint relabelings and hash seeds 0 and 991.
  Measure process CPU and wall, and report bundle load, frontier preparation
  and both guard preparations separately.
- The illustrative price triple is fixed at **16 read units, 1 per zero,
  and 1 per one**. This tests a regime where observing a result costs more
  than either command. It does not estimate physical prices. The priced
  utility gate requires one or more strict savings at each order in both
  runs. The unknown-price utility gate requires at least one strict
  componentwise savings somewhere in each complete run. Report empty
  switches and ties. Stop after the two predetermined executions.
- Independently decode the audited graphs to ground the oracle and all
  named transition results. Recount paid costs from archived exact words
  matched to the hash of each live tape. Require all three incumbent tapes
  to match their published versions. Each guarded tape and terminal state
  must match one of its two allowed continuations. Recheck both guards
  pointwise, and compare the canonical guarded word hashes across the two
  relabelings. The per-case raw file retains timings and canonical digest
  receipts. The fully matching tapes are already archived.
- Both exactness and pointwise protection are DSR validity checks. The two
  utility predicates are recorded separately from execution. This is an
  exhaustive finite symbolic evaluation. Training rungs, seed power,
  untested group laws and physical pricing are outside the experiment.
