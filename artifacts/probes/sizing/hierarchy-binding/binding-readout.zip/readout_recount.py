import hashlib
import json
import math
import sys
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

SOURCE = "3fc4230d9a4993dc90996edd72af662bad0006c9"
MANIFEST = "a5c8f192236235f726683dbfcf2d7d37e337a9640f0f5ccee94647f48158564a"
PRIOR = "242946b74774e2bbaac837e9426c80924e715b410d95a608d91019f2c093ea74"
TRAIN = ("8831", "8832", "8833")
EVAL = ("4301", "4302", "4303")
REGIONS = ("in_range", "held_out")
ARMS = ("frozen", "joint")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def structural(doc):
    tree_text, query_and_bind = doc.split(" BIND ")
    records, query_and_target = query_and_bind.split(" PATH ")
    query, want = query_and_target.split(" OUT ")
    leaves, stack = {}, []
    words = iter(tree_text.split()[3:])
    for word in words:
        if word == "(":
            stack.append(int(next(words)[-1]))
        elif word == ")":
            stack.pop()
        else:
            leaves[tuple(stack)] = word
    assert not stack
    bindings = {scope: {a: int(k[-1]), b: int(j[-1])} for scope, a, k, b, j
                in (row.split() for row in records.split(" ; "))}
    route, scope = [], "r"
    for alias in query.split():
        side = bindings[scope][alias]
        route.append(side)
        scope += str(side)
    assert leaves[tuple(route)] == want
    return route, bindings


def route_scores(matrix, path):
    predicted, gold_local = [], []
    node, parent = 0, 0
    for scores, gold in zip(matrix, path, strict=True):
        choice = int(scores[2 * node + 2] > scores[2 * node + 1])
        predicted.append(choice)
        node = 2 * node + 1 + choice
        gold_choice = int(scores[2 * parent + 2] > scores[2 * parent + 1])
        gold_local.append(gold_choice == gold)
        parent = 2 * parent + 1 + gold
    return predicted == path, gold_local


def assess(rows, cell):
    assert len(rows) == len(cell["answer_paths"]) == len(cell["scores"]) == 72
    assert len(cell["edited_hops"]) == 36
    depth = len(cell["answer_paths"][0])
    totals = dict(individual=0, both_paths=0, both_at_edited_hop=0, pairs=36, gold_parent_correct=[0] * depth)
    by_hop = {}
    for i, moved_hop in enumerate(cell["edited_hops"]):
        left, right = 2 * i, 2 * i + 1
        p, bindings = structural(rows[left])
        q, other = structural(rows[right])
        changed, = [key for key in bindings if bindings[key] != other[key]]
        assert p != q and p[:moved_hop] == q[:moved_hop] and p[moved_hop] != q[moved_hop]
        assert changed == "r" + "".join(map(str, p[:moved_hop]))
        observed, local = [], []
        for index, path in ((left, p), (right, q)):
            assert cell["answer_paths"][index] == path and len(path) == depth
            matrix = cell["scores"][index]
            assert all(len(row) == 2 ** (depth + 1) - 1 and all(map(math.isfinite, row)) for row in matrix)
            correct, gold = route_scores(matrix, path)
            observed.append(correct)
            local.append(gold[moved_hop])
            totals["individual"] += correct
            for g, passed in enumerate(gold):
                totals["gold_parent_correct"][g] += passed
        totals["both_paths"] += all(observed)
        totals["both_at_edited_hop"] += all(local)
        hop = by_hop.setdefault(moved_hop + 1, dict(pairs=0, both_at_edited_hop=0, both_paths=0))
        hop["pairs"] += 1
        hop["both_at_edited_hop"] += all(local)
        hop["both_paths"] += all(observed)
    return dict(**totals, by_edited_hop=by_hop)


def recount(read, names, prior):
    lock = read("readout-frozen.sha256")
    assert sha(lock) == MANIFEST
    for entry in lock.decode().splitlines():
        digest, filename = entry.split()
        assert sha(read(filename)) == digest
    panel_data = read("readout-panel.json")
    expected_panel = read("readout-panel.sha256").decode().split()[0]
    assert sha(panel_data) == expected_panel
    panel = json.loads(panel_data)
    assert set(panel) == set(EVAL)
    assert sha(prior.read_bytes()) == PRIOR
    with ZipFile(prior) as baseline:
        origins = json.loads(baseline.read("baseline-result.json"))["seeds"]
    assert route_scores([[0, 1, 0], [0, 0, 0, 0, 1]], [0, 1]) == (True, [True, True])
    assert route_scores([[0, 0, 1], [0, 0, 0, 0, 1, 0, 0]], [0, 1]) == (False, [False, True])
    results = {}
    for seed in TRAIN:
        raw = json.loads(read(f"readout-{seed}.json"))
        assert raw["checkpoint"] == origins[seed]["checkpoint_sha256"] and raw["panel_sha256"] == expected_panel
        assert raw["fit_rows"] == 1536 and raw["updates"] == 288 and set(raw["arms"]) == set(ARMS)
        results[seed] = {}
        for arm, fit in raw["arms"].items():
            assert len(fit["training_epoch_loss"]) == 2 and all(map(math.isfinite, fit["training_epoch_loss"]))
            regions = {}
            for region in REGIONS:
                docs = [doc for panel_seed in EVAL for doc in panel[panel_seed][region]]
                regions[region] = assess(docs, fit["results"][region])
            results[seed][arm] = dict(losses=fit["training_epoch_loss"], regions=regions)

    receipts = [name for name in names if name.endswith("/receipt.json")]
    assert len(receipts) == 4
    counts = dict(panel=0, fit=0)
    for name in receipts:
        receipt = json.loads(read(name))
        assert receipt["status"] == "passed" and len(receipt["checks"]) == 1
        check, = receipt["checks"]
        log = str(Path(name).with_name(Path(check["log_path"]).name))
        assert sha(read(log)) == check["log_sha256"]
        counts[name.split("/")[1].rsplit("-", 1)[1]] += 1
    assert counts == dict(panel=1, fit=3)
    gates = {arm: {} for arm in ARMS}
    for arm in ARMS:
        for region, path_min, hop_min in (("in_range", 8, 26), ("held_out", 5, 22)):
            cells = (fit[arm]["regions"][region] for fit in results.values())
            gates[arm][region] = all(c["both_paths"] >= path_min and c["both_at_edited_hop"] >= hop_min for c in cells)
    return dict(source=SOURCE, panel_sha256=expected_panel, results=results, gates=gates,
                receipts=sorted(Path(name).parent.name for name in receipts))


def verify(path, prior):
    with ZipFile(path) as archive:
        assert archive.testzip() is None and len(archive.namelist()) == len(set(archive.namelist()))
        result = recount(archive.read, archive.namelist(), prior)
        assert json.dumps(result, sort_keys=True) == json.dumps(json.loads(archive.read("decision.json")), sort_keys=True)
    print(json.dumps(result))


def bundle(root, destination, prior):
    files = {name: root / name for name in (
        "binding_readout.py", "binding_score.py", "readout.yaml", "readout-frozen.sha256", "readout-protocol.txt",
        "readout-panel.json", "readout-panel.sha256", "readout-8831.json", "readout-8832.json", "readout-8833.json",
        "readout_recount.py",
    )}
    for receipt in (root / "readout-receipts").glob("*/*/receipt.json"):
        for name in ("receipt.json", "check-1.log", "checks-config.yaml"):
            path = receipt.with_name(name)
            files[path.relative_to(root).as_posix()] = path
    result = recount(lambda name: files[name].read_bytes(), files, prior)
    with ZipFile(destination, "x", compression=ZIP_DEFLATED) as archive:
        for name, path in files.items():
            archive.write(path, name)
        archive.writestr("decision.json", json.dumps(result, indent=2) + "\n")
    verify(destination, prior)


if __name__ == "__main__":
    mode, *args = sys.argv[1:]
    {"bundle": bundle, "verify": verify}[mode](*map(Path, args))
