Independent software acceptance fixture for model_guided_research-jida.44

Extract the archive into a new directory and run bash reproduce.sh there.
For only the end-to-end route/chronology test use bash reproduce.sh joined.
The full replay adds retained checkpoint/trace measurements, a 14-case planted
chronology fixture, the historical comparison, and tropical-region controls.
Each command runs through DSR and uv against Git commit 711561125aa154a1404ad9a98d8ebb118655cda3.
The default checkout source is the public project. For an existing full clone,
set J44_REPO to its path. An existing locked uv Python 3.13 environment can be
supplied as UV_PROJECT_ENVIRONMENT. With no override DSR runs uv sync --frozen
into a new local environment. Native CPU remeasurement was tested on macOS arm64.

inputs/ contains original route/region stores, five independently trained
checkpoint sets, task data, chronology examples, and supplemental Git bundles.
runs/joined/ contains six newly trained model lineages: one predates the
diagnostic registration and five follow it. Its threshold of 0.10 and minimum
of five training seeds match the published reuse specification. Original test
controls live outside the project's artifacts directory.

From each trace store the consumer recreates reports via the public routes
command. It passes the regenerated summary files to adjudicate --dry-run.
Source commit order and frozen initial/selected weight digests are preserved.
Stored absolute checkpoint names are original display metadata. Native
re-execution uses the relocated weights and compares measured results.

The retained historical route weights and trace stores were made on the
scratch producer commits 404ef985 and b9a788ff; their supplemental Git DAG
is required to establish chronology. Public repository history alone refuses
all seven with unknown_revision. The historical scan indexed 526 of 933
tracked summary.json files at 4db6657. The four human holds remain active.

The generated region cohort, the planted chronological evaluator fixture and
the historical dry-run are independent checks. The complete joined test uses
the same native checkpoint observations for the store replays and rulings.
All generated cohorts serve as software controls.
