"""Audit the reuse of a paid central-involution proof and exact extension recovery."""

import argparse
import hashlib
import json
import random
from collections import Counter
from itertools import product
from pathlib import Path

from check_alternating_route import PANEL, PRIOR, digests, key
from check_commutator_route import CONTROLS, graph_for, normalized
from check_involution_route import ARMS as PREVIOUS_ARMS
from check_involution_route import REPLAYS as OLDER_REPLAYS
from check_involution_route import model as earlier_model
from check_klein_route import order
from check_short_certificate import action, answers, checksum, read, validate_tape, walk

SEED = 251773
TARGETS, OUTSIDE = ("d8xc15", "q8xc15"), "d30xc4"
REPLAYS = (*OLDER_REPLAYS, "a4xc10")
ARMS = (*PREVIOUS_ARMS, "central_involution")
CENTRAL = ARMS[-1]


def model(family):
    if family in {"q8", "q8xc15"}:
        modulus = 1 if family == "q8" else 15

        def multiply(left, right):
            x, negative, c = left
            y, other_negative, d = right
            flip = x != 0 and y != 0 and (x, y) not in ((1, 2), (2, 3), (3, 1))
            return x ^ y, (negative + other_negative + flip) % 2, (c + d) % modulus

        return list(product(range(4), range(2), range(modulus))), (0, 0, 0), multiply
    if family in {OUTSIDE, "d16", "c8-by-c2"}:
        rotations, modulus, multiplier = {OUTSIDE: (15, 4, -1), "d16": (8, 1, -1), "c8-by-c2": (8, 1, 5)}[family]

        def multiply(left, right):
            a, b, c = left
            d, e, f = right
            return (a + (multiplier if b else 1) * d) % rotations, (b + e) % 2, (c + f) % modulus

        return list(product(range(rotations), range(2), range(modulus))), (0, 0, 0), multiply
    return earlier_model(family)


def make_panel(root):
    latest = read(root / PANEL / "involution-route-coverage.json")
    history = (*PRIOR, *(PANEL / f"{name}-route-coverage.json" for name in ("alternating", "commutator", "klein", "fifth-power")))
    used = {identifier for path in history for identifier in digests(read(root / path))} | set(digests(latest))
    rng = random.Random(SEED)
    cases = []
    for family in (*TARGETS, OUTSIDE):
        pool, identity, multiply = model(family)
        found = 0
        for _ in range(10_000):
            marks = rng.choice(pool), rng.choice(pool)
            graph = graph_for(marks, identity, multiply)
            identifier = checksum(graph)
            if len(graph) == 120 and identifier not in used:
                cases.append(dict(family=family, marks=list(map(list, marks)), graph=graph, graph_sha=identifier))
                used.add(identifier)
                found += 1
                if found == 6:
                    break
        if found != 6:
            raise ValueError(f"Insufficient fresh marked actions for {family}")
    for family in REPLAYS:
        cases.extend([case for case in latest["cases"] if case["family"] == family][:2])
    return dict(seed=SEED, cases=cases)


def verify_extension(graph, witness, c):
    if order(graph, c) != 2 or not all(answers(graph, pair) for pair in (("01", c + "10"), ("0" + c, c + "0"), ("1" + c, c + "1"))):
        raise ValueError("Missing the exact central commutator")
    w, s, h = witness["lattice"]
    r, t = witness["powers"]
    if w <= 0 or h <= 0 or not 0 <= s < w or 2 * w * h != len(graph) or r not in (0, 1) or t not in (0, 1):
        raise ValueError("Wrong quotient lattice or lift bits")
    if not answers(graph, ("0" * w, c * r)) or not answers(graph, ("0" * s + "1" * h, c * t)):
        raise ValueError("Wrong lift equation")
    forms = {walk(graph, c * k + "0" * x + "1" * y) for k, x, y in product(range(2), range(w), range(h))}
    if forms != set(range(len(graph))) or not witness["quotient_queries"]:
        raise ValueError("Normal forms or quotient trace are incomplete")
    for left, right, answer in witness["quotient_queries"]:
        expected = any(answers(graph, (left, c * k + right)) for k in (0, 1))
        if answer is not expected:
            raise ValueError("A quotient reply disagrees with the actual cosets")


def census():
    from scripts.group_student_probe import _recover_central_involution, _try_klein_four_quotient

    result = {}
    for family in ("d8", "q8", "c8-by-c2", "d16"):
        pool, identity, multiply = model(family)
        count = maximum = 0
        lifts = set()
        for marks in product(pool, repeat=2):
            graph = graph_for(marks, identity, multiply)
            if len(graph) != len(pool):
                continue
            calls = 0

            def equal(left, right, target=graph):
                nonlocal calls
                calls += 1
                return answers(target, (left, right))

            if equal("01", "10"):
                raise ValueError("Unexpected abelian fixture")
            order_a, order_b = (next(k for k in range(1, len(pool) + 1) if equal(mark * k, "")) for mark in "01")
            c = "01" + "0" * (order_a - 1) + "1" * (order_b - 1)
            _, proof = _try_klein_four_quotient(len(pool), equal, (order_a, order_b), commutator=c)
            if family == "d16":
                if proof.get("rejected") != "commutator_order" or order(graph, c) != 4:
                    raise ValueError("The order-four commutator did not refuse")
            else:
                if proof.get("rejected") != "central_involution" or proof.get("involution") != c:
                    raise ValueError("Centrality proof failed")
                calls = 0
                recovered, witness = _recover_central_involution(len(pool), equal, c)
                if [list(row) for row in recovered] != graph:
                    raise ValueError("Small-order exact recovery failed")
                verify_extension(graph, witness, c)
                maximum = max(maximum, calls)
                lifts.add(tuple(witness["powers"]))
            count += 1
        if count == 0:
            raise ValueError("Empty transfer family")
        result[family] = dict(order=len(pool), generating_pairs=count, maximum_recovery_calls=maximum, lift_patterns=sorted(lifts))
    return result


def audit(root, coverage, primary, repeat, baseline, previous):
    manifest, scored, replay, baseline, previous = map(read, (coverage, primary, repeat, baseline, previous))
    if manifest != make_panel(root) or scored["coverage_sha256"] != hashlib.sha256(coverage.read_bytes()).hexdigest():
        raise ValueError("Wrong frozen coverage")
    current = normalized(scored)
    if current != normalized(replay):
        raise ValueError("Hash seed changed the non-timing result")
    prior = {row["graph_sha"]: row["arms"]["involution"] for row in normalized(previous)["results"]}
    counts = {family: {arm: Counter() for arm in ARMS} for family in (*TARGETS, OUTSIDE, *REPLAYS)}
    branches = []
    forged_checked = False
    for case, row, clean in zip(manifest["cases"], scored["results"], current["results"], strict=True):
        family = case["family"]
        if family in CONTROLS:
            graph = action(family, case["marks"])[0]
        else:
            _, identity, multiply = model(family)
            graph = graph_for(case["marks"], identity, multiply)
        identifier = checksum(graph)
        if graph != case["graph"] or identifier != case["graph_sha"] or (identifier, family) != (row["graph_sha"], row["family"]):
            raise ValueError("Independent action does not match the frozen record")
        if set(row["arms"]) != set(ARMS):
            raise ValueError("Missing matched arm")
        for name, arm in row["arms"].items():
            validate_tape(graph, arm["paid"])
            if arm["right"] != graph:
                raise ValueError("Wrong recovered action")
            counts[family][name].update(calls=len(arm["paid"]), symbols=sum(len(a) + len(b) for a, b, _ in arm["paid"]), cpu_ns=arm["cpu_ns"])
        candidate = clean["arms"].pop(CENTRAL)
        incumbent = clean["arms"]["involution"]
        if family in REPLAYS:
            if candidate != incumbent or incumbent != prior[identifier]:
                raise ValueError("An already solved control changed")
            continue
        if family == OUTSIDE:
            if candidate != incumbent or order(graph, candidate["commutator"]["word"]) != 15:
                raise ValueError("Outside control paid extra or had the wrong commutator order")
            continue

        c = candidate["commutator"]["word"]
        if candidate["involution"] != {"rejected": "central_involution", "involution": c}:
            raise ValueError("Recovery did not inherit the centrality proof")
        tail = clean["arms"]["fallback"]["paid"]
        prefix = incumbent["paid"][:-len(tail)]
        if incumbent["paid"] != prefix + tail or candidate["paid"][:len(prefix)] != prefix:
            raise ValueError("The prior paid prefix or generic incumbent fallback differs")
        observed = {key(a, b): answer for a, b, answer in prefix}
        if observed.get(key("01", "10")) is not False or any(observed.get(key(a, b)) is not True for a, b in (
            (c * 2, ""), ("0" + c, c + "0"), ("1" + c, c + "1"),
        )):
            raise ValueError("The prefix did not already pay for the complete centrality proof")
        witness = candidate[CENTRAL]
        verify_extension(graph, witness, c)
        branches.append(dict(family=family, branch_calls=len(candidate["paid"]) - len(prefix), powers=witness["powers"],
                             quotient_queries=len(witness["quotient_queries"])))
        if not forged_checked:
            try:
                verify_extension(graph, dict(witness, powers=[1 ^ witness["powers"][0], witness["powers"][1]]), c)
            except ValueError:
                forged_checked = True
            else:
                raise ValueError("Forged power lift accepted")

    if current != normalized(baseline):
        raise ValueError("Incumbent CLI changed")
    before, after = (sum(counts[family][arm]["calls"] for family in TARGETS) for arm in ("involution", CENTRAL))
    print(json.dumps(dict(
        exact=True, default_unchanged=True, forged_lift_rejected=forged_checked, checked_transitions=36 * 120 * 2 * len(ARMS),
        gate=5 * after <= before, incumbent_calls=before, central_calls=after, totals=counts, branches=branches, census=census(),
    ), indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    modes = parser.add_subparsers(dest="mode", required=True)
    for name in ("cover", "audit"):
        mode = modes.add_parser(name)
        mode.add_argument("root", type=Path)
        mode.add_argument("coverage", type=Path)
    for name in ("primary", "repeat", "baseline", "previous"):
        mode.add_argument(name, type=Path)
    args = parser.parse_args()
    if args.mode == "cover":
        with args.coverage.open("x", encoding="utf-8") as file:
            json.dump(make_panel(args.root), file, sort_keys=True)
            file.write("\n")
    else:
        audit(args.root, args.coverage, args.primary, args.repeat, args.baseline, args.previous)
