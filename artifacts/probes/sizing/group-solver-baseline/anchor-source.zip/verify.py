"""Check oracle tapes, witness models, and tables using explicit permutations."""

import argparse
import copy
import json
from collections import defaultdict
from itertools import product
from pathlib import Path

FAMILIES = (("d14", 3), ("q16", 3), ("f21", 5), ("s4", 5))
ARMS = ("square", "z3", "visible")


def compose(left, right):
    return tuple(map(left.__getitem__, right))


def marked_permutations(family, generators):
    if family in {"s3", "s4"}:
        return tuple(map(tuple, generators))
    if family == "q16":
        # Act on signed phases indexed by 2 * phase + side. The reflection
        # squares to the half-turn instead of the identity.
        rotation = tuple((j + 2) % 16 for j in range(16))
        reflection = tuple(2 * ((-a + 4 * b) % 8) + 1 - b for a, b in product(range(8), range(2)))
        matrices = [tuple(range(16))]
        for _ in range(7):
            matrices.append(compose(rotation, matrices[-1]))
        return tuple(compose(matrices[a], reflection if b else matrices[0]) for a, b in generators)
    modulus, unit = {"c5": (5, 1), "d14": (7, -1), "f21": (7, 2)}[family]
    return tuple(tuple((a + unit**b * j) % modulus for j in range(modulus)) for a, b in generators)


def explicit_action(family, generators, labels):
    marks = marked_permutations(family, generators)
    identity = tuple(range(len(marks[0])))
    known = [identity]
    which = {identity: 0}
    table = {}
    graph = []
    for i, point in enumerate(known):
        row = []
        for s, mark in zip("01", marks, strict=True):
            target = compose(point, mark)
            if target not in which:
                which[target] = len(known)
                known.append(target)
            table[labels[i], s] = labels[which[target]]
            row.append(which[target])
        graph.append(tuple(row))
    if len(known) != len(labels):
        raise ValueError("True action does not exhaust the advertised names")
    return labels[0], table, tuple(graph)


def walk(root, table, word):
    if any(s not in "01" for s in word):
        raise ValueError("Non-binary oracle input")
    for s in word:
        root = table[root, s]
    return root


def witness_endpoint(model, names, observations, word):
    size = len(names)
    values = list(range(size))
    root = model["root"]
    if root not in values:
        raise ValueError("Out-of-domain witness root")
    right = {s: model["R" + s] for s in "01"}
    left = {s: model["L" + s] for s in "01"}
    if set(model) != {"root", "R0", "R1", "L0", "L1"}:
        raise ValueError("Malformed witness fields")
    for s in "01":
        if sorted(right[s]) != values or sorted(left[s]) != values or left[s][root] != right[s][root]:
            raise ValueError("Witness maps fail permutation or identity agreement")
        for t in "01":
            if any(left[s][right[t][x]] != right[t][left[s][x]] for x in values):
                raise ValueError("Witness maps fail commutation")
    table = {(x, s): right[s][x] for x, s in product(values, "01")}
    reachable = {root}
    frontier = [root]
    for state in frontier:
        for s in "01":
            target = table[state, s]
            if target not in reachable:
                reachable.add(target)
                frontier.append(target)
    if len(reachable) != size:
        raise ValueError("Witness has disconnected states")
    if any(names[walk(root, table, w)] != answer for w, answer in observations.items()):
        raise ValueError("Witness violates a paid observation")
    return names[walk(root, table, word)]


def verify_case(case, depth, audit):
    names = case["labels_bfs"]
    n = len(names)
    if sorted(names) != [f"u{i:02d}" for i in range(n)]:
        raise ValueError("Incorrect public opaque vocabulary")
    root, table, graph = explicit_action(case["family"], case["generators"], names)
    initial = case["initial"]
    required = {
        "".join(xs) for length in range(2, depth + 1) for xs in product("01", repeat=length)
    }
    if set(initial) != required or any(walk(root, table, word) != answer for word, answer in initial.items()):
        raise ValueError("Wrong common bootstrap")
    all_stats = {}
    for arm in ARMS:
        claim = case["arms"][arm]
        expected = {s: {label: table[label, s] for label in names} for s in "01"}
        if claim["right"] != expected:
            raise ValueError("Wrong reconstructed action")
        proposals = claim["proposals"]
        seen = set(initial)
        for word, answer in proposals:
            if len(word) < 3 or word in seen or walk(root, table, word) != answer:
                raise ValueError("Incorrect or repeated oracle proposal")
            seen.add(word)
        observations = dict(initial)
        paid = []
        unknowns = 0
        forced = 0
        if arm != "z3":
            if claim["solver_events"] or claim["solver_cpu_ns"] or claim["solver_started"]:
                raise ValueError("Non-SMT arm recorded solver use")
            paid = proposals
        else:
            for (word, answer), event in zip(proposals, claim["solver_events"], strict=True):
                if (word, answer) != (event["word"], event["label"]):
                    raise ValueError("Solver ledger does not match proposals")
                start, alternative = event["base"], event["alternative"]
                endpoints = event["candidates"]
                if audit and endpoints != [
                    witness_endpoint(m, sorted(names), observations, word) for m in event["models"]
                ]:
                    raise ValueError("SAT endpoints differ from full witnesses")
                if not audit and event["models"]:
                    raise ValueError("Unexpected full model in scored arm")
                if any(label not in names for label in endpoints):
                    raise ValueError("SAT endpoint is outside the public vocabulary")
                match start, alternative, endpoints:
                    case "sat", "sat", [first, second] if first != second:
                        pass
                    case "sat", "unsat", [first] if first == answer:
                        forced += 1
                        continue
                    case ("unknown", None, []) | ("sat", "unknown", [_]):
                        unknowns += 1
                    case _:
                        raise ValueError("Invalid solver status or witness")
                observations[word] = answer
                paid.append([word, answer])
            if claim["solver_started"] != bool(proposals):
                raise ValueError("Unexpected eager start or unrecorded solver use")
        if paid != claim["paid"]:
            raise ValueError("Paid transcript does not match accounting")
        if not 0 <= claim["solver_cpu_ns"] <= claim["cpu_ns"] or claim["wall_ns"] <= 0:
            raise ValueError("Bad timing fields")
        all_stats[arm] = {
            "edges": 2 * n,
            "anchors": 4,
            "initial_labels": len(initial),
            "extra_labels": len(paid),
            "total_labels": len(initial) + len(paid),
            "symbols": sum(map(len, initial)) + sum(len(word) for word, _ in paid),
            "unknown": unknowns,
            "forced": forced,
            "cpu_ns": claim["cpu_ns"],
            "solver_cpu_ns": claim["solver_cpu_ns"],
            "wall_ns": claim["wall_ns"],
        }
    if case["arms"]["square"]["proposals"] != case["arms"]["z3"]["proposals"]:
        raise ValueError("Shared policy must see precisely the same proposals and answers")
    return graph, all_stats


def summary(record):
    development = record["development"]
    expected = ["c5", "s3"] if development else [name for name, count in FAMILIES for _ in range(count)]
    if [case["family"] for case in record["cases"]] != expected:
        raise ValueError("Wrong fixed panel")
    if not record["z3_version"].startswith("Z3 version 4.15.4 "):
        raise ValueError("Wrong solver version")
    totals = {arm: defaultdict(int) for arm in ARMS}
    panel = []
    graphs = set()
    for i, case in enumerate(record["cases"]):
        offset = i % len(ARMS)
        order = list(ARMS[offset:] + ARMS[:offset])
        if case["order"] != order:
            raise ValueError("Arm order differs from registration")
        size = {"c5": 5, "s3": 6, "d14": 14, "q16": 16, "f21": 21, "s4": 24}[case["family"]]
        if len(case["labels_bfs"]) != size:
            raise ValueError("Wrong order for family")
        depth = 8 if record["control"] == "full" else 2 if development else 4
        graph, result = verify_case(case, depth, record["audit"])
        if graph in graphs:
            raise ValueError("Repeated rooted action")
        graphs.add(graph)
        panel.append({"family": case["family"], "result": result})
        for arm, fields in result.items():
            for key, value in fields.items():
                totals[arm][key] += value
    if not development and any(totals[arm]["edges"] != 630 for arm in ARMS):
        raise ValueError("Incorrect transition denominator")
    outcome = "development" if development else "tie or trade-off within the registered thresholds"
    visible_outcome = "development" if development else "tie or trade-off within the registered thresholds"
    if not development and totals["z3"]["unknown"]:
        outcome = "inconclusive: solver unknown"
    elif not development:
        local, external = (totals[arm] for arm in ("square", "z3"))
        if 10 * external["total_labels"] <= 9 * local["total_labels"]:
            outcome = "z3 material label saving"
        if 5 * local["cpu_ns"] <= external["cpu_ns"] and local["total_labels"] == external["total_labels"]:
            outcome = "square material compute saving at equal label cost"
    if not development:
        for a, b in (("square", "visible"), ("visible", "square")):
            first, other = totals[a], totals[b]
            if 10 * first["total_labels"] <= 9 * other["total_labels"] and 4 * first["cpu_ns"] <= 5 * other["cpu_ns"]:
                visible_outcome = f"{a} material overall saving"
    return {"result": outcome, "visible_result": visible_outcome, "cases": panel, "totals": totals}


def controls(record):
    valid = summary(record)
    if valid["totals"]["z3"]["extra_labels"] < 1 or valid["totals"]["z3"]["forced"] < 1:
        raise ValueError("Development failed to witness both acquisition branches")
    wrong_reply, wrong_table, wrong_model = (copy.deepcopy(record) for _ in range(3))
    changed_reply = next(c["arms"]["square"]["proposals"][0] for c in wrong_reply["cases"] if c["arms"]["square"]["proposals"])
    changed_reply[1] = "forged-reply"
    right = wrong_table["cases"][0]["arms"]["z3"]["right"]["0"]
    right[next(iter(right))] = "forged-transition"
    model = next(
        event["models"][0] for c in wrong_model["cases"] for event in c["arms"]["z3"]["solver_events"] if event["models"]
    )
    model["root"] = 99
    for changed in (wrong_reply, wrong_table, wrong_model):
        try:
            summary(changed)
        except ValueError:
            continue
        raise ValueError("Accepted an adversarial mutation")
    return {"malformed_transcripts_rejected": 3}


def untimed(record):
    record.pop("audit")
    for case in record["cases"]:
        for fields in case["arms"].values():
            for key in ("cpu_ns", "solver_cpu_ns", "wall_ns"):
                fields.pop(key)
            for event in fields["solver_events"]:
                event.pop("models")
    return record


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("scored", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--replay", type=Path)
    parser.add_argument("--control", action="store_true")
    parser.add_argument("--unknown", type=Path)
    parser.add_argument("--full", type=Path)
    args = parser.parse_args()
    record = json.loads(args.scored.read_text())
    result = summary(record)
    if args.control:
        result["controls"] = controls(record)
    if args.unknown:
        unknown_data = json.loads(args.unknown.read_text())
        verified = summary(unknown_data)
        if verified["totals"]["z3"]["unknown"] == 0 or verified["totals"]["z3"]["forced"] != 0:
            raise ValueError("Forced answers admitted in the exhausted solver control")
        result["controls"]["unknown_queries_paid"] = verified["totals"]["z3"]["unknown"]
    if args.full:
        saturated_record = json.loads(args.full.read_text())
        saturated = summary(saturated_record)
        if any(arm["extra_labels"] for arm in saturated["totals"].values()):
            raise ValueError("Queried an oracle after a saturated bootstrap")
        if any(case["arms"]["z3"]["solver_started"] for case in saturated_record["cases"]):
            raise ValueError("Started Z3 needlessly on fully known data")
        result["controls"]["known_cases_without_solver_or_oracle"] = len(saturated_record["cases"])
    if args.replay:
        replay = json.loads(args.replay.read_text())
        if not replay["audit"]:
            raise ValueError("Replay omitted full SAT witnesses")
        summary(replay)
        if untimed(record) != untimed(replay):
            raise ValueError("Nontiming evidence failed exact replay")
        result["replay"] = "same proposal, decision, endpoint, and action tapes with independently checked SAT witnesses"
    with args.output.open("x") as handle:
        json.dump(result, handle, indent=2, sort_keys=True)
        handle.write("\n")


if __name__ == "__main__":
    main()
