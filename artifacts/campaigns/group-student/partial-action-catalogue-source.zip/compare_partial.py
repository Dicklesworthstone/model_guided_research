"""Run exact live partial-action and word-partition matching side by side."""

import json
import sys
import time
from pathlib import Path

from benchmark_indexed import control_observations, solve_panel
from catalogue_replay import WORDS, read
from indexed_catalogue import indexed_matches
from partial_match import partial_matches

MATCHERS = {"batched": indexed_matches, "partial": partial_matches}


def match(tables, observations, order):
    arms = {}
    for arm in order:
        start = time.process_time_ns()
        witnesses, actions, diagnostics = MATCHERS[arm](tables, observations)
        cpu = time.process_time_ns() - start
        arms[arm] = dict(
            cpu_ns=cpu,
            diagnostics=diagnostics,
            witnesses=witnesses,
            actions={i: sorted(actions[i]) for i in actions},
        )
    a, b = (arms[label] for label in order)
    if a["witnesses"] != b["witnesses"] or a["actions"] != b["actions"]:
        raise ValueError("Period or partial-action constraints changed the exact version space")
    return arms


def run(cohort, catalogue, prior, output, reverse):
    start = time.process_time_ns()
    _, _, tables = read(catalogue)
    parsing_cpu_ns = time.process_time_ns() - start
    cases = [read(cohort / f"{i:02}.json") for i in range(24)]
    observations = {i: (c["label_count"], dict(c["arms"]["short_only"]["rows"])) for i, c in enumerate(cases)}
    controls, control_pairs = control_observations(tables, read(prior), observations[0])
    controls[6] = (120, {word: str(sum(int(mark) + 1 for mark in word)) for word in WORDS})

    order = ("partial", "batched") if reverse else ("batched", "partial")
    matching = match(tables, observations, order)
    naming = {
        arm: solve_panel(tables, cases, observations, {"arms": {"indexed": matching[arm]}}, ("indexed",))
        for arm in order
    }
    outside = match(tables, controls, order)
    checked = outside["partial"]["witnesses"]
    cyclic_periods = outside["partial"]["diagnostics"]["periods"][6]
    if (checked[-1] or checked[-2] or not checked[6]
            or any(pair not in checked[i] for i, pair in control_pairs.items())
            or cyclic_periods is None or any(exact is not None for _, exact in cyclic_periods)):
        raise ValueError("The outside census failed a valid or invalid control")
    with output.open("x", encoding="utf-8") as file:
        json.dump(dict(parsing_cpu_ns=parsing_cpu_ns, matching=matching, naming=naming,
                       controls=outside, control_pairs=control_pairs), file, sort_keys=True)
        file.write("\n")


if __name__ == "__main__":
    run(*map(Path, sys.argv[1:5]), reverse=sys.argv[5] == "reverse")
