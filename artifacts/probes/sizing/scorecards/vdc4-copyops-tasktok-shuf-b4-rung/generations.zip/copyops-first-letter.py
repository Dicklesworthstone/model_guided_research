"""Paired source-letter edits on original copy-operation evaluation prompts."""
from collections import Counter, defaultdict
from hashlib import sha256
import json
from pathlib import Path
from string import ascii_lowercase
import sys
from zipfile import ZipFile

import torch
from cli import _eval_score_doc, _load_eval_checkpoint
from nanochat.diagnostics_data import TASKS
from nanochat.tokenizer import checkpoint_tokenizer

root, checkpoint_root, out = map(Path, sys.argv[1:])
spec = TASKS["copyops"]
rows = []
device = torch.device("cpu")

def edit(doc, index):
    prompt, expected = spec.split_prompt(doc)
    head, sequence = prompt.split(" SEQ ", 1)
    letters = sequence.split()[:-1]
    assert sequence.split()[-1] == "OUT"
    operation = head.split()[-1]
    offset = (int(operation[3:]) if operation.startswith("ROT") else 0) % len(letters)
    first = len(letters) - 1 if operation == "REV" else offset
    assert letters[first] == expected.split()[0]
    changed = (first + index) % len(letters)
    letters[changed] = ascii_lowercase[(ascii_lowercase.index(letters[changed]) + 1) % 26]
    answer = (letters[::-1] if operation == "REV" else letters[offset:] + letters[:offset])
    revised = f"{head} SEQ {' '.join(letters)} OUT {' '.join(answer)}"
    assert spec.checker(revised) and len(letters) > 1
    assert (answer[0] == expected.split()[0]) == (index == 1)
    return revised

with ZipFile(root / "generations.zip") as archive, torch.inference_mode():
    for seed in range(3):
        evaldir = Path(f"evals/tasks/eval-b0-copyops-standard-s{seed}")
        meta = json.loads((root / evaldir / "summary.json").read_bytes())["meta"]
        reference = {(r["region"], r["eval_seed"], r["doc_index"]): r for r in
                     map(json.loads, archive.read(str(evaldir / "generations.jsonl")).splitlines())
                     if r["mode"] == "greedy"}
        assert len(reference) == 288
        ckpt = checkpoint_root / f"runs/budget_0/copyops/standard/seed_{seed}/checkpoints"
        step = meta["checkpoint"]["step"]
        model, ckmeta, _ = _load_eval_checkpoint(ckpt, step, device)
        tokenizer = checkpoint_tokenizer(ckpt, ckmeta)
        def first_word(doc):
            scored = _eval_score_doc(model, tokenizer, spec, doc, device=device, temperature=0, seed=0)
            assert scored is not None
            _, answer, got = scored
            return next(iter(got.split()), ""), answer.split()[0]
        counts = defaultdict(lambda: defaultdict(Counter))
        observations = []
        for eval_seed in (0, 1, 2):
            splits = spec.generate(480, eval_seed, spec.resolve_dials(None))
            for split, region in (("train", "in_range"), ("test", "held_out")):
                for index, doc in enumerate(splits[split][:48]):
                    ref = reference[region, eval_seed, index]
                    opt = doc.split()[3]
                    operation = "ROT" if opt.startswith("ROT") else opt
                    docs = [doc, edit(doc, 0), edit(doc, 1)]
                    answers = [first_word(item) for item in docs]
                    assert answers[0][1] == ref["expected"].split()[0]
                    assert answers[0][0] == next(iter(ref["got"].split()), "")
                    correct = [pred == gold for pred, gold in answers]
                    for label in ("all", operation):
                        c = counts[region][label]
                        c.update(cases=1, original=int(correct[0]), source_edit=int(correct[1]),
                                 distractor_edit=int(correct[2]), all_three=int(all(correct)))
                    observations.append(dict(region=region, evaluation_seed=eval_seed, index=index,
                                             operation=operation, words=answers))
        assert all(counts[region]["all"]["cases"] == 144 for region in counts)
        rows.append(dict(training_seed=seed, step=step,
                         sha256=sha256((ckpt / f"model_{step:06d}.pt").read_bytes()).hexdigest(),
                         counts=counts, observations=observations))
out.write_text(json.dumps(dict(scorecard=root.name, conditions=["original", "source_edit", "distractor_edit"],
                               words=["predicted", "expected"], rows=rows), indent=2) + "\n")
