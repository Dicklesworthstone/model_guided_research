import hashlib
import json
import sys
from pathlib import Path

import pyarrow.parquet as parquet

sys.path.insert(0, str(Path.cwd()))
from cli import _eval_split_examples
from nanochat.diagnostics_data import TASKS
from nanochat.tokenizer import HuggingFaceTokenizer

root = Path("/data/ssd/tmp/mgr-hier-s320.hk5mLTED/artifacts/probes/sizing/jida12-hier-s320")
task_dir = root / "data" / "hier"
reference = Path("artifacts/probes/sizing/scorecards/vdc4-bag-rel-hier-tasktok-shuf-b10-s256-rung/data/hier/manifest.json")
manifest = json.loads((task_dir / "manifest.json").read_bytes())
previous = json.loads(reference.read_bytes())
assert manifest["content_sha256"] == previous["content_sha256"], "Corpus changed"
spec = TASKS["hier"]
rows = []
for seed in (0, 1, 2):
    in_range, held_out, _ = _eval_split_examples(spec, n=24, seed=seed)
    rows.extend((seed, split, docs) for split, docs in (("in_range", in_range), ("held_out", held_out)))

if len(sys.argv) == 1:
    evaluation_prompts = {
        spec.split_prompt(doc)[0] for _, split, docs in rows if split == "in_range" for doc in docs
    }
    assert len(evaluation_prompts) == 72, "In-range panel contains repeated prompts"
    checks = {}
    for file in ("train_000.parquet", "val_000.parquet"):
        docs = parquet.read_table(task_dir / file, columns=["text"]).column("text").to_pylist()
        overlaps = sum(spec.split_prompt(doc)[0] in evaluation_prompts for doc in docs)
        checks[file] = {"documents": len(docs), "shared_exact_prompts": overlaps}
        assert not overlaps, "Evaluation prompt occurs in the corpus"
    report = {"in_range_prompts": len(evaluation_prompts), "corpus": checks, "content_sha256": manifest["content_sha256"]}
    destination = root / "prompt-disjointness.json"
else:
    run = sys.argv[1]
    tokenizer_dir = root / "runs" / "standard" / run / "checkpoints" / "tokenizer"
    tokenizer = HuggingFaceTokenizer.from_directory(str(tokenizer_dir))
    splits = {}
    for seed, split, docs in rows:
        lengths = [len(tokenizer.encode(doc, prepend=tokenizer.get_bos_token_id())) for doc in docs]
        splits.setdefault(split, {})[str(seed)] = lengths
    report = {
        "run_id": run,
        "tokenizer_sha256": hashlib.sha256((tokenizer_dir / "tokenizer.json").read_bytes()).hexdigest(),
        "full_doc_tokens_including_bos": splits,
        "window_tokens": 321,
    }
    assert max(max(lengths) for lengths in splits["in_range"].values()) <= 321, "In-range document exceeds window"
    destination = root / "runs" / "standard" / run / "tokenizer-coverage.json"

with destination.open("x", encoding="utf-8") as output:
    json.dump(report, output, indent=2)
    output.write("\n")
print(json.dumps(report))
