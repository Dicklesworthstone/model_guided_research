# Solver-selected endpoint acquisition preflight

This is the development gate for Bead `jqc4`. The previous panel
exposed solver decisions that changed between scoring and replay.
The present preflight tests the solver's own independent query policy
on three new finite actions and one exhaustion control.

## Workload and observable costs

Adapt the Little Prince ring from Rivest and Schapire, section 4.6.1,
to full endpoint readout. A reset starts the robot at position zero
facing clockwise. Symbol 0 advances one position in the current
direction. Symbol 1 reverses orientation. Rings of four, five and six
positions have eight, ten and twelve observable position-orientation
pairs. The historical benchmark uses partial senses. This study gives
each pair a distinct shuffled opaque name and lets the learner reset.
The simulated oracle counts one reset and endpoint read per word and
one movement command per symbol. This choice gives meaningful units
for comparing actuator workloads. Physical reset and read prices
remain to be measured.
[Rivest and Schapire, 1994](https://www.schapire.net/papers/diversity-based-inference.pdf)

Every arm knows the same two-symbol alphabet, complete name set and
the four length-two anchors. Charge all anchors. No arm receives the
size of the ring, orientation, symmetry class or ground-truth table.
Run the shipped square learner, the earlier visible-state explorer,
and the new Z3 policy on the same oracle.

## Independent query policy

Use the earlier finite group encoding with one Z3 process per case.
For each round obtain one model and block its right-transition table.
If another table exists, find the shortest distinguishing reset word
in lexicographic order. Breadth-first search starts at the four public
anchors. Until disagreement, both endpoints have the same label,
so the queue needs only the shared state. The search terminates
because agreement at every reachable successor would equate the two
right tables. Every state is reachable from any anchor in a finite
transitive permutation action, since each inverse is a positive power.

The two proposed endpoint answers differ, so each paid answer excludes
at least one of the models. If the table block is UNSAT, report the
first table as unique under the encoded observations. The verifier
independently validates the fitted SAT witnesses, brute-checks the
shortest-word claims, and reconstructs every transition from natural
permutations of the ring. UNSAT remains a solver-reported result.

## Freeze and stopping rule

Pin Z3 4.15.4, one solver thread, seed zero and a resource limit of
2,000,000 per check. The solver has no wall-clock decision timeout.
DSR's task deadline aborts the run without an experimental result.
Record the Z3 resource counter for every check and the returned reason
for UNKNOWN. Any UNKNOWN triggers exact square-closure continuation
using all labels acquired so far. A cap of 65 rounds also falls back.
The forced-exhaustion control uses the five-position ring with a
fresh opaque relabeling and a one-unit limit and must call the fallback
without inferring a label. [Z3 resource parameters](https://microsoft.github.io/z3guide/programming/Parameters/)

Use label seeds 251124 through 251127 in the frozen order planet,
ring5, ring6 and ring5-exhausted. All cases and outcomes are retained.
Rotate arm execution order by case index. Keep CPU and elapsed time
as observations, and include model extraction and child CPU.
Replay in a fresh process with a different Python hash seed and
require all untimed fields to match, including solver resource and
reason fields. Reject a forged terminal outcome.

The execution gate passes when every table, query and witness checks,
the untimed replay is exact, and the exhaustion control falls back.
The solver viability gate separately requires all three ordinary
cases to terminate by uniqueness. Report total endpoint reads and
commands separately, including the common labels. The study is
development-only, so gains inform the next experiment. A claim about
a physical system needs measured reset, read and move prices.
