"""Replay the comparison with independent Cayley tables and trace checks."""

import argparse
import copy
import json
from collections import Counter
from itertools import product
from pathlib import Path
from zipfile import ZipFile

from check_base_study import expected_action, verify_new_arm
from check_study import ANCHORS, rooted, untimed, walk

EXPECTED = (
    ("two-by-seven-torus", "torus", (2, 7), ("F", "F")),
    ("decagon-mirrors", "ring", (10,), ("T", "FT")),
    ("dodecagon-turn-first", "ring", (12,), ("T", "F")),
    ("two-by-three-torus", "torus", (2, 3), ("F", "F")),
    ("two-by-five-torus", "torus", (2, 5), ("F", "F")),
    ("two-by-six-torus", "torus", (2, 6), ("F", "F")),
    ("four-by-four-torus", "torus", (4, 4), ("F", "F")),
    ("symmetric-four", "s4", (), ("T", "T")),
)
INVENTORY = ((6, 2), (10, 2), (12, 5), (14, 2), (16, 14), (20, 5), (24, 15))


def read_json(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        raise ValueError(f"Invalid JSON input {path}") from error


def reference_catalogue(raw):
    expected_ids = [(n, i) for n, count in INVENTORY for i in range(1, count + 1)]
    if raw[:2] != ["4.16.1", "1.7.0"] or [tuple(row[:2]) for row in raw[2]] != expected_ids:
        raise ValueError("Incomplete GAP export or wrong version")
    forms = {n: set() for n, _ in INVENTORY}
    for n, _, mult in raw[2]:
        positions = list(range(n))
        if (
            len(mult) != n or mult[0] != positions or [r[0] for r in mult] != positions
            or any(sorted(row) != positions for row in mult)
            or any(sorted(col) != positions for col in zip(*mult, strict=True))
            or any(mult[mult[a][b]][c] != mult[a][mult[b][c]] for a, b, c in product(positions, repeat=3))
        ):
            raise ValueError("GAP table fails exact group law checks")
        group_shapes = set()
        for g0, g1 in product(positions, repeat=2):
            transitions = {
                "0": {x: mult[x][g0] for x in positions},
                "1": {x: mult[x][g1] for x in positions},
            }
            graph = rooted(transitions, 0)
            if len(graph) == n:
                group_shapes.add(graph)
        if forms[n] & group_shapes:
            raise ValueError("Duplicate two-generated group in export")
        forms[n].update(group_shapes)
    # Dictionary rows give a different walk path from the producer's indexed rows.
    return {
        n: [{mark: {i: row[int(mark)] for i, row in enumerate(graph)} for mark in "01"}
            for graph in sorted(graphs)]
        for n, graphs in forms.items()
    }


def reference_truth(spec, labels):
    if spec[1] != "s4":
        return expected_action((*spec, False), labels)
    permutations = [p for p in product(range(4), repeat=4) if len(set(p)) == 4]
    names = dict(zip(permutations, labels, strict=True))
    return {
        "0": {name: names[b, c, d, a] for (a, b, c, d), name in names.items()},
        "1": {name: names[b, a, c, d] for (a, b, c, d), name in names.items()},
    }


def historical_shapes(directory):
    graphs = set()
    for name in ("results", "solver-native-results", "conjugation-results", "base-solver-results"):
        with ZipFile(directory / f"{name}.zip") as archive:
            previous = json.loads(archive.read("scored.json"))
        for row in previous["cases"]:
            labels = row.get("labels") or row.get("names") or row["labels_bfs"]
            graphs.add(rooted(row["arms"]["square"]["right"], labels[0]))
    return graphs


def matching_shapes(forms, facts):
    viable = []
    for shape in forms:
        bindings = {(walk(0, shape, word), label) for word, label in facts.items()}
        if len(bindings) == len({x for x, _ in bindings}) == len({y for _, y in bindings}):
            viable.append((shape, dict(bindings)))
    return viable


def verify_catalogue(row, initial, names, forms):
    facts = dict(initial)
    events = row["events"]
    if [[e["word"], e["answer"]] for e in events] != row["paid"][:len(events)] or row["trace"] is not None:
        raise ValueError("Catalogue tape differs from declared queries")
    for event in events:
        viable = matching_shapes(forms, facts)
        unnamed = len(names) - len(set(facts.values()))
        word = event["word"]
        buckets = Counter(mapping.get(walk(0, shape, word)) for shape, mapping in viable)
        missing = buckets.pop(None, 0)
        worst = max([missing, *(count * max(1, unnamed) for count in buckets.values())])
        if (len(viable) != event["shapes"] or event["worst"] != worst
                or worst >= max(1, unnamed) * len(viable) or not 3 <= len(word) <= len(names) + 2):
            raise ValueError("Wrong hypothesis count or non-informative query")
        facts[word] = event["answer"]
        forms = [shape for shape, _ in viable]
    viable = matching_shapes(forms, facts)
    if row["terminal"] == "query-cap":
        if len(events) != 65 or not viable:
            raise ValueError("Wrong catalogue fallback")
        return
    if (row["terminal"] != "unique-catalogue" or len(row["paid"]) != len(events)
            or len(viable) != 1 or len(set(facts.values())) < len(names) - 1):
        raise ValueError("Catalogue claims uniqueness without enough information")
    shape, labels = viable[0]
    for state in set(range(len(names))) - labels.keys():
        labels[state] = (names - labels.values()).pop()
    for mark in "01":
        if {labels[i]: labels[j] for i, j in shape[mark].items()} != row["right"][mark]:
            raise ValueError("Unique action disagrees with its labels")


def verify(record, shapes, prior):
    specs = tuple((name, kind, tuple(dims), tuple(marks)) for name, kind, dims, marks in
                  (case["spec"] for case in record["cases"]))
    if (specs != EXPECTED or not record["z3"].startswith("Z3 version 4.15.4 ")
            or record["sizes"] != {str(n): len(forms) for n, forms in shapes.items()}):
        raise ValueError("Wrong panel, solver version or canonical shape count")
    results, graphs = [], set(prior)
    for case, spec in zip(record["cases"], specs, strict=True):
        labels = case["labels"]
        names = set(labels)
        truth = reference_truth(spec, labels)
        root = labels[0]
        graph = rooted(truth, root)
        initial = {word: walk(root, truth, word) for word in ANCHORS}
        if (graph in graphs or names != {f"opaque{i:02d}" for i in range(len(labels))}
                or len(graph) != len(labels) or case["initial"] != initial
                or set(case["arms"]) != {"square", "reuse", "catalogue"}):
            raise ValueError("Malformed or duplicate action, anchors, or arms")
        graphs.add(graph)
        floor = len(ANCHORS) + len(names) - 1 - len(set(initial.values()))
        results.append({"name": spec[0], "edges": 2 * len(names), "read_floor": floor, "arms": {}})
        for arm, row in case["arms"].items():
            if row["right"] != truth:
                raise ValueError("Recovered table differs from oracle")
            words = set(initial)
            for word, answer in row["paid"]:
                if word in words or len(word) < 2 or walk(root, truth, word) != answer:
                    raise ValueError("Wrong or repeated paid query")
                words.add(word)
            if arm == "catalogue":
                verify_catalogue(row, initial, names, shapes[len(names)])
            elif arm == "reuse":
                verify_new_arm(row, sorted(names), initial, "reuse", exhausted=False)
            elif row["events"] or row["trace"] is not None or row["terminal"] != "closure":
                raise ValueError("Unexpected square arm outcome")
            commands = "".join(spec[3][int(mark)] for word in sorted(words) for mark in word)
            results[-1]["arms"][arm] = {
                "reads": len(words), "turns": commands.count("T"), "advances": commands.count("F"),
                "cpu_ns": row["cpu_ns"], "wall_ns": row["wall_ns"], "terminal": row["terminal"],
            }
    return results


def reject_corruption(library, score, shapes, prior):
    partial = copy.deepcopy(library)
    partial[2].pop()
    try:
        reference_catalogue(partial)
    except ValueError:
        pass
    else:
        raise ValueError("The checker accepted an omitted group")
    fake = copy.deepcopy(score)
    arm = fake["cases"][0]["arms"]["catalogue"]
    arm["events"].clear()
    arm["paid"].clear()
    arm["terminal"] = "unique-catalogue"
    try:
        verify(fake, shapes, prior)
    except ValueError:
        return {"omitted_group": True, "premature_uniqueness": True}
    raise ValueError("The checker accepted a fabricated early completion")


def summarize(rows):
    fields = ("reads", "turns", "advances", "cpu_ns", "wall_ns")
    totals = {arm: {f: sum(row["arms"][arm][f] for row in rows) for f in fields}
              for arm in ("square", "reuse", "catalogue")}
    complete = {
        arm: [row["name"] for row in rows if row["arms"][arm]["terminal"] == terminal]
        for arm, terminal in (("catalogue", "unique-catalogue"), ("reuse", "unique-right-table"))
    }
    cat, reuse = totals["catalogue"], totals["reuse"]
    return {
        "edges_per_arm": sum(row["edges"] for row in rows),
        "read_floor": sum(row["read_floor"] for row in rows),
        "matched_or_better_oracle_cost_and_stricter_completion": (
            set(complete["reuse"]) < set(complete["catalogue"])
            and cat["reads"] <= reuse["reads"]
            and cat["turns"] + cat["advances"] <= reuse["turns"] + reuse["advances"]
        ),
        "complete": complete,
        "totals": totals,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("catalogue", type=Path)
    parser.add_argument("score", type=Path)
    parser.add_argument("replay", type=Path)
    parser.add_argument("previous_artifacts", type=Path)
    args = parser.parse_args()
    raw, score, replay = (read_json(path) for path in (args.catalogue, args.score, args.replay))
    shapes = reference_catalogue(raw)
    prior = historical_shapes(args.previous_artifacts)
    rows = verify(score, shapes, prior)
    verify(replay, shapes, prior)
    clean_score, clean_replay = untimed(score), untimed(replay)
    del clean_score["offline_cpu_ns"], clean_replay["offline_cpu_ns"]
    if clean_score != clean_replay:
        raise ValueError("A non-timing replay field changed")
    print(json.dumps({
        "exact_replay": True, "rejected": reject_corruption(raw, score, shapes, prior),
        "historical_shapes": len(prior), "decision": summarize(rows), "rows": rows,
    }, indent=2))


if __name__ == "__main__":
    main()
