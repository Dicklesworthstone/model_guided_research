"""Post-run diagnosis of first divergent prefixes, independent of the guard."""

import json
import sys
from collections import defaultdict
from fractions import Fraction
from pathlib import Path
from zipfile import ZipFile


def read(path, member):
    with ZipFile(path) as archive:
        return json.loads(archive.read(member))


def charges(tape):
    return len(tape), sum(word.count("0") for word, _ in tape), sum(word.count("1") for word, _ in tape)


def supported_prices(deltas):
    """Intersect the normalized price triangle with every no-increase inequality."""
    polygon = [tuple(Fraction(axis == vertex) for axis in range(3)) for vertex in range(3)]
    for delta in sorted(set(deltas)):
        updated = []
        for a, b in zip(polygon[-1:] + polygon[:-1], polygon, strict=True):
            lhs, rhs = (sum(price * change for price, change in zip(vertex, delta, strict=True)) for vertex in (a, b))
            if (lhs <= 0) != (rhs <= 0):
                proportion = lhs / (lhs - rhs)
                updated.append(tuple(x + proportion * (y - x) for x, y in zip(a, b, strict=True)))
            if rhs <= 0:
                updated.append(b)
        polygon = list(dict.fromkeys(updated))
        if not polygon:
            return None
    mean = tuple(sum(vertex[axis] for vertex in polygon) / len(polygon) for axis in range(3))
    if any(sum(price * change for price, change in zip(mean, delta, strict=True)) < 0 for delta in deltas):
        return mean
    return None


def diagnose(directory, member):
    shortlist_data = read(directory / "transfer-results.zip", member)["rows"]
    frontier_data = read(directory / "frontier-results.zip", member)["orders"]
    partitions = defaultdict(lambda: defaultdict(list))
    for row in shortlist_data:
        n, slot = row["order"], row["slot"]
        incumbent = [list(pair) for pair in row["anchors"].items()] + row["arms"]["tiered"]["tape"]
        alternative = frontier_data[str(n)]["cases"][slot]["frontier"]["tape"]
        if incumbent == alternative:
            continue
        shared = []
        names = {}
        for old, new in zip(incumbent, alternative):
            if old != new:
                if old[0] == new[0]:
                    raise ValueError("Same query received different labels")
                break
            word, label = old
            shared.append((word, names.setdefault(label, len(names))))
        delta = tuple(b - a for a, b in zip(charges(incumbent), charges(alternative), strict=True))
        partitions[str(n)][tuple(shared)].append(delta)
    results = {}
    for n, groups in partitions.items():
        priced = [[16 * reads + zeros + ones for reads, zeros, ones in cases] for cases in groups.values()]
        components = list(groups.values())
        possible = [supported_prices(cases) for cases in components]
        results[n] = dict(
            divergence_groups=len(groups),
            divergent_actions=sum(map(len, priced)),
            priced_winners=sum(value < 0 for costs in priced for value in costs),
            priced_losers=sum(value > 0 for costs in priced for value in costs),
            priced_groups_with_savings=sum(min(costs) < 0 for costs in priced),
            priced_groups_with_mixed_signs=sum(min(costs) < 0 < max(costs) for costs in priced),
            component_winners=sum(max(delta) <= 0 and min(delta) < 0 for cases in components for delta in cases),
            component_groups_with_winners=sum(any(max(delta) <= 0 and min(delta) < 0 for delta in cases)
                                              for cases in components),
            component_safe_groups=sum(max(value for delta in cases for value in delta) <= 0
                                      and min(value for delta in cases for value in delta) < 0 for cases in components),
            any_price_safe_groups=sum(price is not None for price in possible),
            strictly_positive_price_groups=sum(price is not None and all(price) for price in possible),
            first_positive_witness=next(([str(item) for item in price] for price in possible if price and all(price)), None),
        )
    return results


if __name__ == "__main__":
    assert supported_prices([(-1, 0, 0), (1, 0, 0)]) is None
    assert supported_prices([(0, -1, 0)]) == (Fraction(1, 3),) * 3
    assert supported_prices([(1, 1, 1)]) is None
    directory = Path(sys.argv[1])
    primary = diagnose(directory, "scored.json")
    replay = diagnose(directory, "replay.json")
    if replay != primary:
        raise ValueError("The first-divergence diagnosis depended on the naming permutation")
    print(json.dumps(primary, sort_keys=True))
