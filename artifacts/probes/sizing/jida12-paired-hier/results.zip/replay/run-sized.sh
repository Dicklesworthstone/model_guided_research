#!/bin/bash
set -euo pipefail
export MGR_HIER_SHA="$1"
export PATH="/home/ubuntu/.local/bin:$PATH"
export DSR_REPOS_FILE=/data/ssd/tmp/mgr-hier-paired.Ji7EOJkO/sizing.yaml DSR_QUALITY_LOG_DIR=/data/ssd/tmp/mgr-hier-paired.Ji7EOJkO/receipts UV_PROJECT_ENVIRONMENT=/data/ssd/tmp/mgr-eval-ci.bevt3nLW/qualified-venv
export OMP_NUM_THREADS=4 MKL_NUM_THREADS=4
work=/data/ssd/tmp/mgr-hier-paired.Ji7EOJkO/gate
dsr quality --tool paired-hierarchy-corpus --work-dir "$work" --check-timeout 180
for setting in b5:5e12 b30:3e13; do
    rung="${setting%:*}"
    export MGR_HIER_BUDGET="${setting##*:}"
    for seed in 0 1 2; do
        export MGR_HIER_SEED="$seed" MGR_HIER_RUN="$rung-s$seed"
        dsr quality --tool paired-hierarchy-train --work-dir "$work" --check-timeout 1800
        dsr quality --tool paired-hierarchy-eval --work-dir "$work" --check-timeout 240
        if ! jq -e '.passes' "/data/ssd/tmp/mgr-hier-paired.Ji7EOJkO/artifacts/probes/sizing/jida12-paired-hier/evals/tasks/$MGR_HIER_RUN/recount.json"; then
            echo "$MGR_HIER_RUN missed the paired hierarchy floor"
            break
        fi
        if [ "$seed" -eq 2 ]; then
            echo "$rung clears paired hierarchy sizing on all three training seeds"
            exit 0
        fi
    done
done
echo "The frozen paired hierarchy sizing ladder found no clearing rung"
