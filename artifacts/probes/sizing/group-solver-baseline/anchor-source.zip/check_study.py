"""Check solver witnesses, minimum words, actions, and costs independently."""

import argparse
import copy
import json
from itertools import product
from pathlib import Path

from verify import witness_endpoint

ANCHORS = ("00", "01", "10", "11")
SPECS = (
    ("square-mirrors", "ring", 4, ("T", "FT"), False),
    ("pentagon-mirrors", "ring", 5, ("T", "FT"), False),
    ("hexagon-turn-first", "ring", 6, ("T", "F"), False),
    ("octagon-turn-first", "ring", 8, ("T", "F"), False),
    ("quaternion-units", "quaternion", 8, ("T", "T"), False),
    ("two-axis-torus", "torus", 3, ("F", "F"), False),
    ("square-mirrors-exhausted", "ring", 4, ("T", "FT"), True),
)


def action_truth(spec, labels):
    _, kind, scale, commands, _ = spec
    if kind == "quaternion":
        units = [tuple(sign if j == i else 0 for j in range(4)) for sign, i in product((1, -1), range(4))]
        targets = {unit: name for unit, name in zip(units, labels, strict=True)}
        return {
            "0": {name: targets[-b, a, d, -c] for (a, b, c, d), name in targets.items()},
            "1": {name: targets[-c, -d, a, b] for (a, b, c, d), name in targets.items()},
        }
    if kind == "torus":
        grid = dict(zip(product(range(scale), repeat=2), labels, strict=True))
        return {
            "0": {name: grid[(x + 1) % scale, y] for (x, y), name in grid.items()},
            "1": {name: grid[x, (y + 1) % scale] for (x, y), name in grid.items()},
        }
    ring = range(scale)
    permutations = [tuple((x + h * j) % scale for j in ring) for x, h in product(ring, (1, -1))]
    names = dict(zip(permutations, labels, strict=True))
    generators = {"F": tuple(range(1, scale)) + (0,), "T": tuple(-i % scale for i in ring)}
    truth = {}
    for letter, command in zip("01", commands, strict=True):
        truth[letter] = {}
        for perm, name in names.items():
            moved = perm
            for primitive in command:
                moved = tuple(moved[j] for j in generators[primitive])
            truth[letter][name] = names[moved]
    return truth


def walk(start, table, word):
    for mark in word:
        start = table[mark][start]
    return start


def model_endpoint(model, word):
    state = model["root"]
    for a in word:
        state = model["R" + a][state]
    return state


def shortest_word(predicate, cap):
    for length in range(2, cap + 1):
        for letters in product("01", repeat=length):
            if predicate(letters):
                return "".join(letters)
    raise ValueError("Witness word exceeds its asserted minimum length")


def validate_check(check):
    if check["status"] not in {"sat", "unsat", "unknown"} or check["resource_count"] <= 0:
        raise ValueError("Malformed solver accounting")
    if bool(check["reason"]) != (check["status"] == "unknown"):
        raise ValueError("Missing or unexpected UNKNOWN cause")
    return check["status"]


def verify_selection(row, names, initial, *, can_swap):
    paid = []
    exposed = dict(initial)
    terminal = None
    swaps = alt_checks = 0
    for event in row["events"]:
        if terminal is not None:
            raise ValueError("Solver selected queries after stopping")
        base = validate_check(event["base"])
        if base == "unknown":
            terminal = "unknown-base"
            continue
        if base != "sat":
            raise ValueError("Base formula is inconsistent")
        first = event["first"]
        witness_endpoint(first, names, exposed, "00")
        unseen = {i for i, name in enumerate(names) if name not in exposed.values()}
        if "swap" in event:
            if not can_swap or "alternative" in event:
                raise ValueError("Conjugation used outside its scheduled arm")
            swapped = event["swap"]
            a, b = swapped
            if a == b or a not in unseen or b != min(unseen - {a}, default=None):
                raise ValueError("The naming witness swapped an exposed state or used the wrong tie break")
            switch = {a: b, b: a}
            second = event["second"]
            checks = [second["root"] == switch.get(first["root"], first["root"])]
            for key in ("R0", "R1", "L0", "L1"):
                for index, dest in enumerate(first[key]):
                    checks.append(second[key][switch.get(index, index)] == switch.get(dest, dest))
            if not all(checks):
                raise ValueError("The second model is not the prescribed conjugation")
            if event["word"] != shortest_word(lambda word: model_endpoint(first, word) in unseen, len(event["word"])):
                raise ValueError("The naming witness is not the first access to an unseen name")
            if model_endpoint(first, event["word"]) != a:
                raise ValueError("The naming witness queries the wrong swapped label")
            swaps += 1
        else:
            if can_swap and len(unseen) >= 2:
                raise ValueError("SMT alternative check ran despite an available transposition")
            alt_checks += 1
            alternative = validate_check(event["alternative"])
            if alternative == "unknown":
                terminal = "unknown-alternative"
                continue
            if alternative == "unsat":
                terminal = "unique-right-table"
                for key in "01":
                    if [row["right"][key][name] for name in names] != [names[i] for i in first["R" + key]]:
                        raise ValueError("Claimed final table differs from the first witness")
                continue
        second, word = event["second"], event["word"]
        if word in exposed or not 3 <= len(word) <= len(names) + 2:
            raise ValueError("Proposed a known or out-of-range word")
        self_label = witness_endpoint(first, names, exposed, word)
        other_label = witness_endpoint(second, names, exposed, word)
        if self_label == other_label:
            raise ValueError("The candidate witnesses do not disagree")
        if shortest_word(lambda w: model_endpoint(first, w) != model_endpoint(second, w), len(word)) != word:
            raise ValueError("An earlier distinguishing word exists")
        paid.append([word, event["answer"]])
        exposed[word] = event["answer"]
    terminal = terminal or "query-cap"
    if terminal != row["terminal"] or row["paid"][:len(paid)] != paid:
        raise ValueError("Solver decisions disagree with the paid tape")
    if terminal == "unique-right-table" and len(row["paid"]) != len(paid):
        raise ValueError("Extra labels after a uniqueness result")
    return {
        "base_checks": len(row["events"]), "alt_checks": alt_checks, "swaps": swaps,
        "native_reads": len(paid), "fallback_reads": len(row["paid"]) - len(paid),
    }


def rooted(table, root):
    names = [root]
    index = {root: 0}
    graph = []
    for name in names:
        row = []
        for a in "01":
            target = table[a][name]
            if target not in index:
                index[target] = len(names)
                names.append(target)
            row.append(index[target])
        graph.append(tuple(row))
    return tuple(graph)


def verify(record):
    manifest = tuple((c["case"], c["kind"], c["scale"], tuple(c["primitives"]), c["exhausted"]) for c in record["cases"])
    if manifest != SPECS or record["rlimit"] != 2_000_000 or not record["z3"].startswith("Z3 version 4.15.4 "):
        raise ValueError("Incorrect case manifest or solver budget")
    rows, seen_graphs = [], set()
    for case, spec in zip(record["cases"], SPECS, strict=True):
        names = case["labels"]
        if sorted(names) != [f"opaque{i:02d}" for i in range(len(names))]:
            raise ValueError("Malformed opaque label set")
        truth = action_truth(spec, names)
        root = names[0]
        graph = rooted(truth, root)
        if len(graph) != len(names) or (graph in seen_graphs and not case["exhausted"]):
            raise ValueError("Incomplete or duplicate marked action")
        seen_graphs.add(graph)
        initial = {w: walk(root, truth, w) for w in ANCHORS}
        if case["initial"] != initial or set(case["arms"]) != {"square", "visible", "native", "conjugation"}:
            raise ValueError("Changed bootstrap or arm set")
        results = {}
        for kind, row in case["arms"].items():
            if truth != row["right"]:
                raise ValueError("The recovered table conflicts with direct oracle truth")
            words = list(initial)
            for w, label in row["paid"]:
                if w in words or len(w) < 2 or walk(root, truth, w) != label:
                    raise ValueError("Invalid paid oracle request or reply")
                words.append(w)
            actions = "".join(spec[3][int(a)] for w in words for a in w)
            counts = {
                "reads": len(words), "turns": actions.count("T"), "advances": actions.count("F"),
                "symbols": sum(map(len, words)), "cpu_ns": row["cpu_ns"], "terminal": row["terminal"],
            }
            if kind in {"native", "conjugation"}:
                counts.update(verify_selection(row, sorted(names), initial, can_swap=kind == "conjugation"))
                if case["exhausted"] and (row["terminal"] != "unknown-base" or row["paid"] != case["arms"]["square"]["paid"]):
                    raise ValueError("Resource exhaustion failed to preserve square fallback")
            results[kind] = counts
        rows.append({"case": case["case"], "edges": 2 * len(names), "arms": results})
    return rows


def untimed(record):
    result = copy.deepcopy(record)
    for case in result["cases"]:
        for arm in case["arms"].values():
            del arm["cpu_ns"], arm["wall_ns"]
    return result


def reject_bad_swap(record):
    forged = copy.deepcopy(record)
    for case in forged["cases"]:
        for event in case["arms"]["conjugation"]["events"]:
            if "swap" in event:
                event["swap"][0] = sorted(case["labels"]).index(case["initial"]["00"])
                try:
                    verify(forged)
                except ValueError:
                    return
                raise ValueError("Checker accepted a transposition of an observed name")
    raise ValueError("No constructive transposition was exercised")


def decision(rows):
    primary = rows[:-1]
    finished = {
        arm: {item["case"] for item in primary if item["arms"][arm]["terminal"] == "unique-right-table"}
        for arm in ("native", "conjugation")
    }
    totals = {
        arm: {
            key: sum(row["arms"][arm].get(key, 0) for row in primary)
            for key in ("reads", "symbols", "turns", "advances", "cpu_ns", "base_checks", "alt_checks", "swaps",
                        "native_reads", "fallback_reads")
        }
        for arm in ("native", "conjugation", "square", "visible")
    }
    proposed, old, square = (totals[a] for a in ("conjugation", "native", "square"))
    return {
        "edges_per_arm": sum(row["edges"] for row in rows),
        "completed": {arm: sorted(cases) for arm, cases in finished.items()},
        "improved_completion": finished["native"] < finished["conjugation"],
        "halved_alt_calls_without_coverage_loss": (
            old["alt_checks"] > 0 and 2 * proposed["alt_checks"] <= old["alt_checks"]
            and finished["native"] <= finished["conjugation"]
        ),
        "oracle_cost_gate": (
            10 * proposed["reads"] <= 9 * square["reads"]
            and proposed["turns"] + proposed["advances"] <= square["turns"] + square["advances"]
        ),
        "totals": totals,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("scored", type=Path)
    parser.add_argument("replay", type=Path)
    args = parser.parse_args()
    scored, replayed = (json.loads(p.read_text(encoding="utf-8")) for p in (args.scored, args.replay))
    rows = verify(scored)
    verify(replayed)
    if untimed(scored) != untimed(replayed):
        raise ValueError("Resource, witness, or label tapes changed on replay")
    reject_bad_swap(scored)
    print(json.dumps({"exact_replay": True, "forgery_rejected": True, "decision": decision(rows), "rows": rows}, indent=2))


if __name__ == "__main__":
    main()
