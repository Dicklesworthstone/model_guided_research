# probe-charges — charge-1e12-train3-fit2

- checkpoint: `/Volumes/SANDISK_SSD/scratch/mgr-fixes-20261122.E905R8/charge-measurement/artifacts/campaigns/charges-group-1e12/rmatrix-s3/checkpoints` @ step 4780
- task: group · examples: 240 · seed: 2
- features: per-head charge observables `<v, t(theta_k) v>` of the final braid layer

| category | n | classes | floor | linear test | mlp test | decodable@2x |
|---|---|---|---|---|---|---|
| a5 | 46 | 25 | 0.111 | 0.222 | 0.222 | True |
| s3 | 51 | 6 | 0.300 | 0.000 | 0.300 | False |
| s5 | 59 | 32 | 0.182 | 0.000 | 0.273 | False |
| z60 | 45 | 26 | 0.333 | 0.000 | 0.333 | False |

Both halves of the protected-memory story are required: conservation (certify: braid.rmatrix_mass_partition_charge_conserved) AND decodability (this probe). If conservation holds but decodability fails, the conclusion is that the integrable structure conserves the wrong quantities for this task - a result, not a bug.
