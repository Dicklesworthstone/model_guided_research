# Direct recovery after a paid commutation check

Add an opt-in arm to the normal proposal command on exact equality
oracles for two-generated regular group actions of order 120. Pay
`01 = 10` first. A negative result continues through the existing
short S5 certificate and cancellation fallback with the exact same
tape once this first comparison is removed.

For a positive result, a and b commute and generate an abelian group.
Find the order w of a by removing prime factors from the known
size n whenever the corresponding power of a is the identity. Try
primes in descending order. The quotient by a is cyclic, generated
by the image of b, with known order h = n/w. There is one residue
s modulo w with a^s b^h = 1. Refine the known residue modulo D to
modulo Dp by testing its lifts. With m = w/(Dp), the equality
a^(r m) b^(h m) = 1 holds precisely for the correct residue r
modulo Dp. Use the shorter of the positive equation and the equivalent
comparison b^(h m) = a^(-r m mod w). Charge both query operands.
Test candidates in ascending total symbol count, breaking ties by
residue. Infer the last residue if all others are false.

The two lattice vectors (w,0) and (s,h) then lie in the kernel
of Z² onto the marked group. They span a lattice of index wh = n.
Since the true kernel also has index n, the lattices coincide.
Use the unique rectangle of representatives to recover canonical
right transitions. No prebuilt list is needed by the learner. The
auditor independently enumerates the complete lattice catalogue.
For n=120 there are 360 distinct marked graphs. The prime tests
cost at most five calls for the order and nine for the residue.
Including commutation, the direct route has a bound of 15 calls.

Freeze six distinct marked actions each from C120, C60 times C2,
S5 and A5 times C2. Sample with seed 251747. Exclude all marked
graphs from the earlier congruence, proposal and short-certificate
manifests, including their archived exclusions. These are new
acquisition cases. The earlier known-family S5 census covered the
whole S5 catalogue for a different task.

Run cancellation, edge certificates, short S5 certificates and
the routed arm together with the same exact equality oracle. The
primary gate requires exact tables, at most 15 paid calls per
commuting case, and at least 80% fewer pooled commuting calls
than the live short-S5 comparator. Require exactly one extra call
and identical continuation on each noncommuting case. Record all
paid symbols and online CPU, including any losses. The measured
panel shares the existing proposal setup across applicable arms.

Independently reconstruct all 24 input actions, verify every paid
reply and table, and require the abelian transcripts to select
a single member of the complete 360-action lattice set. Re-run the
commuting decoder on all 360 exact arithmetic oracles. Check both
binding relations against all 129,240 wrong lattice pairings.
Reject a forged commutation reply. Run the normal proposal CLI at
two Python hash seeds, with all non-timing fields identical, and
confirm the normal default still reproduces the three baseline
arms on the frozen panel. No physical latency assumption or
population claim enters this finite experiment.
