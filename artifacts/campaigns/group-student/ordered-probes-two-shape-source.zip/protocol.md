# Exact two-shape acquisition closure

Keep the oracle, prices, mandatory anchors, 300,000 work units per order,
all five arms, and both relabelings from the preceding tests. Solve orders
6 and 10 for the main prediction and attempt order 12 as stress. Compare
every verified table and paid tape to the original controls. Keep the
shortcut only if it reproduces the known order-6 minimum in less work than
24,889 units and solves all audited two-shape anchor classes. Any lower
bound and final policy price must agree where each makes an exact claim.

An observed name pairs one state position in each of the two shapes.
Before the first split, each nonredundant query adds a disjoint pair.
The splitting query either reaches an old name in exactly one shape
or reaches two distinct old names. In both cases at least one named pair
conflicts with the splitting word's endpoint pair. If that conflicting
pair came from the history before this state, the split can be asked
immediately. Otherwise retain a single prefix query that names a
conflicting pair. Postpone all the other prefix queries until after that
first split, at identical cost in every shape, or replace them with
cheaper access words during final naming. The two shapes are now
distinguished, so none of the moved queries is needed for identification.
An optimum therefore exists with at most two queries before identification.

For one-query splits consider every reachable endpoint vector at its
shortest spelling. For two-query splits both words have to be uniformly
novel at the start. They split the shapes precisely when their endpoint
vectors share one coordinate. Index earlier words by that coordinate.
Distinct representatives cannot share both coordinates. Test the
shortlex order of each novel pair since the two orders cost the same.
Do not alter the work meter for expanded states, discovered endpoint
vectors, or candidate evaluations. Charge every tested pair. The
candidate uses the original exact algorithm for larger version spaces.

For the focused comparison enumerate every anchor pattern containing
exactly two shapes across all three orders. Standalone compilation for
each such pattern is admissible because the fixed anchors establish
that pattern before any differing query. Compile with the unmodified
original solver at 78d873f and the specialized solver under the same
per-invocation cap. Verify all returned named tables, independently
recount cost and require equal objectives wherever both solve. The
focused run is distinct from the full-catalogue budget criterion.
