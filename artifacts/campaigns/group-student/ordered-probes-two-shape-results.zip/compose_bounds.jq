def certified_class($order):
  . as $old
  | ($old.signature | map(tostring) | join("")) as $signature
  | $pairs[0].cases[$order + "-" + $signature].specialized.cost as $new
  | if $new != null and ($new < $old.strongest_floor or $new > $old.gbs) then
      error("Exact cost outside the prior class interval")
    elif $new != null and $old.exact != null and $new != $old.exact then
      error("Independent exact class costs disagree")
    else
      ($new // $old.exact) as $exact
      | {signature, shapes, lower: ($exact // $old.strongest_floor), upper: ($exact // $old.gbs)}
    end;

$floors[0] | to_entries | map(
  .key as $order
  | .value as $old
  | ($old.classes | map(certified_class($order))) as $classes
  | ($classes | map(.lower) | add) as $lower
  | ($classes | map(.upper) | add) as $upper
  | {
      key: $order,
      value: {
        lower: $lower,
        upper: $upper,
        width: ($upper - $lower),
        published_gbs: $old.gbs,
        maximum_savings_from_upper_pct: (100 * ($upper - $lower) / $upper),
        classes: $classes
      }
    }
) | from_entries
