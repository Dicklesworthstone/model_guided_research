"""Audit query and symbol lower bounds independently of acquisition."""

import json
import sys
from collections import Counter
from pathlib import Path

from check_replay import follow, independently_named, load, without_timings


def matches_structure(table, a, b, expected):
    root, rows = expected
    matching = {0: root}
    pending = [0]
    while pending:
        state = pending.pop()
        for proposed, label in zip((table[state][a], table[state][b]), rows[int(matching[state])], strict=True):
            if proposed not in matching:
                matching[proposed] = label
                pending.append(proposed)
            elif matching[proposed] != label:
                return False
    return len(set(matching.values())) == len(matching) == len(rows)


def audit(cohort, library, parent, primary, repeat):
    result = load(primary)
    if without_timings(result) != without_timings(load(repeat)) or len(result) != 24:
        raise ValueError("Missing or nondeterministic floor comparison")
    totals = Counter()
    per_case = []
    tables = {(n, index): table for n, index, table in load(library)[2]}
    exhaustive = load(parent)["results"]
    for i, row in enumerate(result):
        case = load(Path(cohort) / f"{i:02}.json")
        root, edges = independently_named(case)
        n = len(edges)
        if (n, i) != (row["order"], row["index"]):
            raise ValueError("Wrong case")
        expected = [root, edges]
        witnesses = exhaustive[i]["catalogue"]["witnesses"]
        if not witnesses or any(not matches_structure(tables[n, index], a, b, expected) for index, a, b in witnesses):
            raise ValueError("A compatible pair has a different rooted structure")
        distances = {root: 0}
        layer = {root}
        depth = 0
        while layer:
            depth += 1
            layer = {target for source in layer for target in edges[int(source)]}.difference(distances)
            distances.update(dict.fromkeys(layer, depth))
        seen = {label for _, label in case["arms"]["short_only"]["rows"]}
        unseen = distances.keys() - seen
        word_lengths = sorted(distances[name] for name in unseen)
        floor = word_lengths[:-1]
        target = row["catalogue"]
        if target["structures"] != 1 or target["action"] is None:
            raise ValueError("The frozen constraints did not uniquely identify a rooted structure")
        if any(row[arm]["action"] != expected for arm in ("square", "catalogue")):
            raise ValueError("Incorrect recovered labelled table")
        for arm in ("square", "catalogue"):
            tape = row[arm]["paid"]
            if any(follow(expected, word) != label for word, label in tape):
                raise ValueError("Incorrect live oracle reply")
            totals[f"{arm}_labels"] += len(tape)
            totals[f"{arm}_symbols"] += sum(len(word) for word, _ in tape)
        tape = target["paid"]
        if (sorted(len(word) for word, _ in tape) != floor
                or len({label for _, label in tape}) != len(floor)
                or any(label not in unseen or len(word) != distances[label] for word, label in tape)):
            raise ValueError("A naming call exceeded the fixed-root lower bound")
        if row["square"]["paid"] != case["arms"]["active"]["paid"]:
            raise ValueError("The live square arm diverged from its frozen tape")
        for split in ("primary", "secondary"):
            answers = [label for _, label, _ in case[split]]
            if target["answers"][split] != answers:
                raise ValueError("Incorrect held-out endpoints")
            totals[split] += len(answers)
        totals["transitions"] += 4 * n
        per_case.append(dict(index=i, order=n, observed=len(seen), additional_labels=len(floor),
                             additional_symbols=sum(floor), square_labels=len(row["square"]["paid"])))
    print(json.dumps(dict(totals, cases=per_case), sort_keys=True))


if __name__ == "__main__":
    audit(*sys.argv[1:])
