# Exact projection onto a contiguous span of address bits

An address bit is inactive when flipping it leaves the truth table
unchanged at every address. For each candidate bit, its two half
blocks at every aligned interval are precisely the pairs of inputs
that differ only in that bit. Equality of all the half blocks proves
inactivity. A disagreement supplies an explicit sensitivity witness.

After finding the lowest and highest active bits, the encoder may
set all bits outside that span to zero. Successively clearing those
inactive bits leaves the value unchanged at each step. The remaining
bit span indexes a compact packed table in one lookup. The replay
also checks equality at every original address.

When active bits stretch across the whole address, this contiguous
projection keeps the earlier encoding. It can retain inactive bits
between active ones. Its serialized form includes the selected
offset and span width. Production integration would need workload
evidence at address sizes beyond the archived hierarchy panels.
