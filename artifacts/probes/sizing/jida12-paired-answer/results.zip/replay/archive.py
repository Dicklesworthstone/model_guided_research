import hashlib
import json
import sys
import zipfile
from pathlib import Path

campaign, root, destination = map(Path, sys.argv[1:])
arms = ("answer-ce", "answer-swap")
preflight = json.loads((root / "preflight.json").read_bytes())
train = {}
contrast = {}
for arm in arms:
    train[arm] = json.loads((root / "runs" / arm / "summary.json").read_bytes())
    contrast[arm] = json.loads((root / "evals" / "tasks" / arm / "contrast-recount.json").read_bytes())

base, added = (train[arm] for arm in arms)
assert base["initial_parameters_sha256"] == added["initial_parameters_sha256"]
assert base["options"]["schedule_sha256"] == added["options"]["schedule_sha256"] == preflight["schedule_sha256"]
assert (base["options"]["contrast_coefficient"], added["options"]["contrast_coefficient"]) == (0.0, 1.0)
assert base["model_flops_est"] == added["model_flops_est"]
skip = {"run_id", "contrast_coefficient"}
assert all(base["options"][key] == value for key, value in added["options"].items() if key not in skip)
metrics = {
    arm: {split: {key: value for key, value in stats.items() if key != "rows"}
          for split, stats in contrast[arm]["regions"].items()}
    for arm in arms
}
control, swap = (metrics[arm]["in_range"] for arm in arms)
criteria = {
    "greedy_at_least_6": swap["both_greedy"] >= 6,
    "greedy_gain_at_least_4": swap["both_greedy"] - control["both_greedy"] >= 4,
    "two_choice_at_least_18": swap["both_forced"] >= 18,
    "two_choice_gain_at_least_6": swap["both_forced"] - control["both_forced"] >= 6,
}
decision = {
    "scope": "quarantined sizing screen", "model_flops_per_arm": base["model_flops_est"],
    "training_pairs": 1, "metrics": metrics, "criteria": criteria, "advance": all(criteria.values()),
}
with zipfile.ZipFile(destination, "x", compression=zipfile.ZIP_DEFLATED) as archive:
    for file in ("experiment.py", "archive.py", "campaign.yaml", "run.sh", "fresh.yaml", "verify_fresh.py"):
        archive.write(campaign / file, f"replay/{file}")
    for file in ("manifest.json", "panel.json", "preflight.json"):
        archive.write(root / file, file)
    for arm in arms:
        for directory, files in (
            (root / "runs" / arm, ("summary.json", "checkpoints/meta_002047.json")),
            (root / "evals" / "tasks" / arm, ("summary.json", "run.md", "generations.jsonl", "contrast-recount.json")),
        ):
            for file in files:
                path = directory / file
                archive.write(path, str(path.relative_to(root)))
    tokenizer = root / "runs" / "answer-ce" / "checkpoints" / "tokenizer" / "tokenizer.json"
    assert hashlib.sha256(tokenizer.read_bytes()).hexdigest() == preflight["tokenizer_sha256"]
    archive.write(tokenizer, "tokenizer.json")
    archive.writestr("decision.json", json.dumps(decision, indent=2) + "\n")
    for receipt in sorted((campaign / "receipts").glob("*/*/receipt.json")):
        data = json.loads(receipt.read_bytes())
        assert data["status"] == "passed"
        for check in data["checks"]:
            path = Path(check["log_path"])
            assert hashlib.sha256(path.read_bytes()).hexdigest() == check["log_sha256"]
            archive.write(path, str(path.relative_to(campaign)))
        archive.write(receipt, str(receipt.relative_to(campaign)))
        snapshot = receipt.with_name("checks-config.yaml")
        archive.write(snapshot, str(snapshot.relative_to(campaign)))
print(json.dumps(decision, indent=2))
