"""Compare the globally shortest frontier with live released exact learners."""

import argparse
import json
from functools import partial
from pathlib import Path
from time import monotonic_ns, process_time_ns
from zipfile import ZipFile

import released_acquisition as released

from nanochat import group_acquisition as current

ORDERS = {32: 151, 64: 503, 128: 1799}
MODES = ("square", "shortlist", "frontier")


def timed(function, *args, **kwargs):
    cpu, wall = process_time_ns(), monotonic_ns()
    result = function(*args, **kwargs)
    return result, {"cpu_ns": process_time_ns() - cpu, "wall_ns": monotonic_ns() - wall}


def read_zip(archive, member):
    with ZipFile(archive) as source:
        return json.loads(source.read(member))


def decode_catalogue(archive):
    result = {}
    for row in read_zip(archive, "scored.json")["orders"]:
        shapes = []
        for profile in row["profiles"].values():
            for packed in profile["full"]:
                value = bytes.fromhex(packed)
                shapes.append(tuple(zip(value[::2], value[1::2], strict=True)))
        if len(set(shapes)) != ORDERS[row["order"]] or len(shapes) != ORDERS[row["order"]]:
            raise ValueError("Unexpected marked inventory")
        result[row["order"]] = sorted(shapes)
    if set(result) != set(ORDERS):
        raise ValueError("Incomplete marked inventory")
    return result


def labels_for(n, slot, reverse):
    multiplier, offset = (19, 7 * slot + 11) if reverse else (17, 13 * slot + 7)
    return [str((multiplier * state + offset) % n) for state in range(n)]


def measure_one(learner, roster, graph, labels, expected, anchors, mode):
    tape = []

    def oracle(word):
        state = 0
        for mark in word:
            state = graph[state][int(mark)]
        reply = labels[state]
        tape.append((word, reply))
        return reply

    result, cost = timed(learner, roster, oracle)
    root, edges = expected["action"]
    truth = {str(i): tuple(edge) for i, edge in enumerate(edges)}
    if (result.root, result.transitions) != (root, truth):
        raise ValueError(f"{mode} changed an archived named action")
    archived_tape = [*anchors.items(), *map(tuple, expected["tape"])]
    shared_tape = tape == archived_tape
    terminal = "square" if mode == "square" else expected["terminal"]
    if mode != "frontier" and (not shared_tape or result.terminal != terminal):
        raise ValueError(f"{mode} changed an archived paid tape")
    zeros = sum(word.count("0") for word, _ in tape)
    ones = sum(word.count("1") for word, _ in tape)
    charges = dict(**cost, calls=len(tape), symbols=zeros + ones, zeros=zeros, ones=ones, terminal=result.terminal)
    if mode == "frontier":
        charges.update(tape=tape, shares_shortlist=shared_tape)
    return charges


def run(work, output, reverse):
    if not Path(current.__file__).resolve().is_relative_to(work):
        raise ValueError("The candidate comes from a different checkout")
    archive = work / "artifacts/probes/sizing/group-solver-baseline/anchor-results.zip"
    history = work / "artifacts/campaigns/group-student/transfer-results.zip"
    actual = decode_catalogue(archive)
    published = read_zip(history, "replay.json" if reverse else "scored.json")["rows"]
    rows = {(row["order"], row["slot"]): row for row in published}
    if len(rows) != sum(ORDERS.values()) or len(rows) != len(published):
        raise ValueError("Missing or duplicate archived tape")
    measured = {}
    for n, shapes in actual.items():
        if reverse:
            index, catalogue_load = timed(current.load_catalogue, archive, n)
            policy, compilation = timed(current.compile_policy, index, exhaustive_frontier=True)
            baseline, baseline_load = timed(released.load_bundled_policy, n)
        else:
            baseline, baseline_load = timed(released.load_bundled_policy, n)
            index, catalogue_load = timed(current.load_catalogue, archive, n)
            policy, compilation = timed(current.compile_policy, index, exhaustive_frontier=True)
        setup = {"shortlist_load": baseline_load, "frontier_load": catalogue_load, "frontier_compile": compilation}
        learners = {
            "square": released.acquire,
            "shortlist": partial(released.acquire, catalogue=baseline),
            "frontier": partial(current.acquire, catalogue=policy),
        }
        roster = list(map(str, range(n)))
        if reverse:
            roster.reverse()
        scores = []
        for slot, graph in enumerate(shapes):
            rotation = slot % len(MODES)
            order = MODES[rotation:] + MODES[:rotation]
            if reverse:
                order = tuple(reversed(order))
            labels = labels_for(n, slot, reverse)
            archived = rows[n, slot]
            expected_edges = {label: [labels[a], labels[b]] for label, (a, b) in zip(labels, graph, strict=True)}
            expected_table = [labels[0], [expected_edges[str(i)] for i in range(n)]]
            if any(result["action"] != expected_table for result in archived["arms"].values()):
                raise ValueError(f"Wrong marked truth for order {n}, slot {slot}")
            sampled = {}
            for mode in order:
                expected = archived["arms"]["square" if mode == "square" else "tiered"]
                sampled[mode] = measure_one(learners[mode], roster, graph, labels, expected, archived["anchors"], mode)
            scores.append(sampled)
        measured[n] = {"setup": setup, "cases": scores}
        print(f"Order {n}: {len(scores)} exact cases scored", flush=True)
    with output.open("x", encoding="utf-8") as handle:
        json.dump({"reverse": reverse, "orders": measured}, handle, separators=(",", ":"), sort_keys=True)
        handle.write("\n")


def summarize(first_path, second_path):
    samples = [json.loads(path.read_text(encoding="utf-8")) for path in (first_path, second_path)]
    if [sample["reverse"] for sample in samples] != [False, True]:
        raise ValueError("Expected both preregistered replay directions")
    comparisons = {}
    for n in ORDERS:
        first, second = (sample["orders"][str(n)]["cases"] for sample in samples)
        paired = []
        for forward, reverse in zip(first, second, strict=True):
            a, b = (row["frontier"] for row in (forward, reverse))
            if ([w for w, _ in a["tape"]] != [w for w, _ in b["tape"]]
                    or a["terminal"] != b["terminal"] or a["shares_shortlist"] != b["shares_shortlist"]):
                raise ValueError("The frontier changed under the second endpoint labeling")
            paired.append((forward["shortlist"]["calls"] - a["calls"],
                           forward["shortlist"]["symbols"] - a["symbols"], a["shares_shortlist"]))
        comparisons[n] = dict(
            changed_tapes=sum(not shared for _, _, shared in paired),
            extra_reads=sum(reads < 0 for reads, _, _ in paired),
            extra_symbols=sum(symbols < 0 for _, symbols, _ in paired),
            saved_both_or_tied=sum(reads >= 0 and symbols >= 0 and reads + symbols > 0 for reads, symbols, _ in paired),
            exact_ties=sum(reads == symbols == 0 for reads, symbols, _ in paired),
        )
    totals = []
    checked = 0
    for sample in samples:
        per_order = {}
        for n, cells in sample["orders"].items():
            if len(cells["cases"]) != ORDERS[int(n)]:
                raise ValueError("Incomplete acquisition census")
            checked += sum(len(row) for row in cells["cases"])
            arms = {
                mode: {measure: sum(row[mode][measure] for row in cells["cases"])
                       for measure in ("cpu_ns", "wall_ns", "calls", "symbols", "zeros", "ones")}
                for mode in MODES
            }
            setup = cells["setup"]
            per_order[n] = dict(
                arms=arms, setup=setup,
                no_extra_reads=arms["frontier"]["calls"] <= arms["shortlist"]["calls"],
                fewer_symbols=arms["frontier"]["symbols"] < arms["shortlist"]["symbols"],
            )
        if set(map(int, per_order)) != set(ORDERS):
            raise ValueError("An order was omitted")
        totals.append(per_order)
    passed = all(row["no_extra_reads"] and row["fewer_symbols"] for run in totals for row in run.values())
    print(json.dumps({"orders": totals, "cost_prediction_passed": passed, "checked_acquisitions": checked,
                      "comparisons": comparisons},
                     sort_keys=True))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(required=True, dest="operation")
    score = commands.add_parser("score")
    score.add_argument("work", type=Path)
    score.add_argument("output", type=Path)
    score.add_argument("--reverse", action="store_true")
    summary = commands.add_parser("summary")
    summary.add_argument("first", type=Path)
    summary.add_argument("second", type=Path)
    args = parser.parse_args()
    if args.operation == "score":
        run(args.work, args.output, args.reverse)
    else:
        summarize(args.first, args.second)
