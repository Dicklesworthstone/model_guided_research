"""Exact acquisition with a shortlex order for exchangeable naming probes."""

from dataclasses import dataclass
from functools import cache
from itertools import count, product

from nanochat.group_acquisition import (
    ANCHORS,
    SYMBOLS,
    Catalogue,
    CompiledPolicy,
    PlanningBudgetExceeded,
    _Determined,
    _endpoint,
    _PlanningState,
    _PolicyNode,
    _Probe,
    compile_gbs_policy,
)

type SearchKey = tuple[_PlanningState, str]


@dataclass(frozen=True)
class OrderedPlan:
    policy: CompiledPolicy
    total_cost: int
    work: int
    seed_work: int
    skipped_orders: int


def partition(state, endpoints):
    groups = {}
    for (row, names), endpoint in zip(state, endpoints, strict=True):
        if endpoint in names:
            rank = names.index(endpoint)
        else:
            rank = len(names)
            names = (*names, endpoint)
        groups.setdefault(rank, []).append((row, names))
    return {rank: tuple(rows) for rank, rows in groups.items()}


def canonical(state: _PlanningState, previous: str) -> SearchKey:
    _, names = state[0]
    # Keep the preceding uniform query's reply last so it can be forgotten
    # when checking whether a proposed action was also uniformly novel.
    ranks = sorted(range(len(names) - bool(previous)), key=names.__getitem__)
    if previous:
        ranks.append(len(names) - 1)
    return tuple((row, tuple(labels[rank] for rank in ranks)) for row, labels in state), previous


def inverted(word, previous, groups, seen):
    return bool(previous) and (len(word), word) < (len(previous), previous) and min(groups) >= seen - 1


def compile_ordered(catalogue: Catalogue, *, read_price: int, max_work: int) -> OrderedPlan:
    shapes = catalogue.shapes
    size = len(shapes[0])
    work = seed_work = skipped_orders = 0

    def spend(amount=1):
        nonlocal work
        if work + amount > max_work:
            raise PlanningBudgetExceeded(f"Optimal planning exhausted {max_work} work units")
        work += amount

    def seed_spend(amount):
        nonlocal seed_work
        spend(amount)
        seed_work += amount

    @cache
    def probes(rows):
        seen = set()
        available = []
        expanded = 0

        def remember(word, endpoints):
            if endpoints not in seen:
                spend()
                seen.add(endpoints)
                available.append((word, endpoints))

        for word in ANCHORS:
            remember(word, tuple(_endpoint(shapes[row], word) for row in rows))

        def candidate(slot):
            nonlocal expanded
            while slot >= len(available) and expanded < len(available):
                word, endpoints = available[expanded]
                expanded += 1
                for mark, symbol in enumerate(SYMBOLS):
                    remember(
                        word + symbol,
                        tuple(shapes[row][point][mark] for row, point in zip(rows, endpoints, strict=True)),
                    )
            return available[slot] if slot < len(available) else None

        return candidate

    @cache
    def per_shape_floor(row, seen):
        missing = [read_price + len(word) for word, endpoint in catalogue.naming[row] if endpoint not in seen]
        return sum(missing[:-1]), sum(missing[:-2])

    @cache
    def naming(state):
        floors = [per_shape_floor(row, frozenset(names)) for row, names in state]
        return sum(current for current, _ in floors), sum(after for _, after in floors)

    optimal: dict[SearchKey, tuple[int, str]] = {}
    infeasible: dict[SearchKey, int] = {}

    def solve(key, ceiling):
        nonlocal skipped_orders
        if key in optimal:
            cost, _ = optimal[key]
            return cost if cost <= ceiling else None
        state, previous = key
        current, after_one_reply = naming(state)
        if ceiling < current or ceiling <= infeasible.get(key, -1):
            return None
        spend()
        if len(state) == 1:
            optimal[key] = current, ""
            return current

        original_ceiling = ceiling
        best = None
        find_candidate = probes(tuple(row for row, _ in state))
        for index in count():
            item = find_candidate(index)
            if item is None:
                break
            spend()
            word, endpoints = item
            total = len(state) * (read_price + len(word))
            if total + after_one_reply > ceiling:
                break
            groups = partition(state, endpoints)
            uniform = len(groups) == 1
            if uniform:
                rank, child = next(iter(groups.items()))
                if child == state or rank == size - 1:
                    continue
            if inverted(word, previous, groups, len(state[0][1])):
                skipped_orders += 1
                continue
            children = []
            for child in groups.values():
                child_key = canonical(child, word if uniform else "")
                children.append((child_key, naming(child_key[0])[0]))
            children.sort(key=lambda item: -len(item[0][0]))
            unpaid = sum(floor for _, floor in children)
            if total + unpaid > ceiling:
                continue
            for child_key, floor in children:
                unpaid -= floor
                subcost = solve(child_key, ceiling - total - unpaid)
                if subcost is None:
                    break
                total += subcost
            else:
                optimal[key] = total, word
                best = total
                if total == current:
                    break
                ceiling = total - 1
        if best is None:
            infeasible[key] = original_ceiling
        return best

    def emit(state, previous):
        _, word = optimal[canonical(state, previous)]
        if not word:
            row, names = state[0]
            return _Determined(row, names)
        groups = partition(state, tuple(_endpoint(shapes[row], word) for row, _ in state))
        next_previous = word if len(groups) == 1 else ""
        return _Probe(word, {rank: emit(child, next_previous) for rank, child in groups.items()})

    menu = set(catalogue.word_rows)
    menu.update("".join(word) for length in range(2, 7) for word in product(SYMBOLS, repeat=length))
    seed_spend(len(menu))
    seed = compile_gbs_policy(catalogue, read_price=read_price)

    def charge_seed(node, depth):
        if node is None:
            raise ValueError("The seed did not determine the action")
        if isinstance(node, _Determined):
            seed_spend(1)
        else:
            if depth >= len(ANCHORS):
                seed_spend(3 + len(menu))
                if node.word not in menu:
                    seed_spend(2 * (len(ANCHORS) + 2 * (size + 1)))
            for child in node.branches.values():
                charge_seed(child, depth + 1)

    def seed_cost(state, node):
        if isinstance(node, _Determined):
            return naming(state)[0]
        if node is None:
            raise ValueError("The seed did not determine the action")
        endpoints = tuple(_endpoint(shapes[row], node.word) for row, _ in state)
        return len(state) * (read_price + len(node.word)) + sum(
            seed_cost(child, node.branches[rank]) for rank, child in partition(state, endpoints).items()
        )

    def anchor(state: _PlanningState, depth: int, node: _PolicyNode):
        if depth == len(ANCHORS):
            upper = seed_cost(state, node)
            below = solve(canonical(state, ""), upper - 1)
            return (upper, node) if below is None else (below, emit(state, ""))
        if not isinstance(node, _Probe):
            raise ValueError("The seed did not query all anchors")
        word = ANCHORS[depth]
        endpoints = tuple(_endpoint(shapes[row], word) for row, _ in state)
        total = len(state) * (read_price + len(word))
        branches = {}
        for rank, child in partition(state, endpoints).items():
            cost, branches[rank] = anchor(child, depth + 1, node.branches[rank])
            total += cost
        return total, _Probe(word, branches)

    charge_seed(seed._root, 0)
    total, root = anchor(tuple((row, ()) for row in range(len(shapes))), 0, seed._root)
    return OrderedPlan(CompiledPolicy(shapes, catalogue.naming, root), total, work, seed_work, skipped_orders)
