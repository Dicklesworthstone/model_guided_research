"""Freeze fresh proposal cases and audit their equality tapes independently."""

import argparse
import copy
import hashlib
import json
import random
from collections import Counter
from itertools import permutations, product
from pathlib import Path

SEED = 251711
FAMILIES = ("s5", "c120", "a5xc2", "s3xc20")
ARMS = ("fallback", "edge", "short")


def read(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        raise ValueError(f"Invalid input {path}") from error


def checksum(value):
    return hashlib.sha256(json.dumps(value).encode()).hexdigest()


def elements(family):
    if family == "s5":
        return list(permutations(range(5)))
    if family == "c120":
        return [(i,) for i in range(120)]
    if family == "s3xc20":
        return [p + (j,) for p, j in product(permutations(range(3)), range(20))]
    return [
        p + (j,) for p in permutations(range(5))
        if sum(p[a] > p[b] for a in range(5) for b in range(a + 1, 5)) % 2 == 0
        for j in range(2)
    ]


def action(family, marks):
    degree = {"s5": 5, "c120": 0, "a5xc2": 5, "s3xc20": 3}[family]
    modulus = {"s5": 0, "c120": 120, "a5xc2": 2, "s3xc20": 20}[family]
    identity = tuple(range(degree)) + ((0,) if modulus else ())
    states, ids, words, edges = [identity], {identity: 0}, [""], []
    index = 0
    while index < len(states):
        state = states[index]
        row = []
        for letter, generator in zip("01", marks, strict=True):
            reached = tuple(generator[i] for i in state[:degree])
            if modulus:
                reached += ((state[-1] + generator[-1]) % modulus,)
            if reached not in ids:
                ids[reached] = len(states)
                states.append(reached)
                words.append(words[index] + letter)
            row.append(ids[reached])
        edges.append(row)
        index += 1
    return edges, words


def prior_ids(congruence, proposal):
    previous = read(congruence)
    return set(previous["spent"]) | {
        row["graph_sha"] for row in previous["presentations"] + read(proposal)["cases"]
    }


def preflight(congruence, proposal, output):
    excluded = prior_ids(congruence, proposal)
    randomizer = random.Random(SEED)
    cases = []
    for family in FAMILIES:
        pool = elements(family)
        kept = 0
        for _ in range(10000):
            marks = randomizer.choice(pool), randomizer.choice(pool)
            graph, _ = action(family, marks)
            identifier = checksum(graph)
            if len(graph) != 120 or identifier in excluded:
                continue
            cases.append(dict(family=family, marks=marks, graph=graph, graph_sha=identifier))
            excluded.add(identifier)
            kept += 1
            if kept == 6:
                break
        if kept != 6:
            raise ValueError(f"Insufficient distinct marked actions for {family}")
    with output.open("x", encoding="utf-8") as handle:
        json.dump(dict(seed=SEED, cases=cases), handle, sort_keys=True)
        handle.write("\n")


def walk(graph, word):
    state = 0
    for mark in word:
        state = graph[state][ord(mark) - ord("0")]
    return state


def answers(graph, pair):
    left, right = pair
    if set(left + right) - {"0", "1"}:
        raise ValueError("Unsupported comparison alphabet")
    return walk(graph, left) == walk(graph, right)


def key(pair):
    return tuple(sorted(pair))


def audit_selection(actual, selected, catalog):
    remains = set(catalog)
    paid = []
    memo = {}
    for row in selected["queries"]:
        pair = row["pair"]
        yes = {c for c in remains if answers(catalog[c], pair)}
        reply = answers(actual, pair)
        if not yes or yes == remains or (row["answer"], row["candidates"], row["predicted_yes"]) != (
            reply, len(remains), len(yes)
        ):
            raise ValueError("Invalid selection split or reply")
        remains = yes if reply else remains - yes
        paid.append([*pair, reply])
        memo[key(pair)] = reply
    if remains != {selected["marked_class"]} or len(paid) > 6:
        raise ValueError("Proposal selection did not reach a legal tree leaf")
    return paid, memo


def edge_questions(graph, words):
    return sorted({
        key((words[i] + str(mark), words[dst]))
        for i, row in enumerate(graph) for mark, dst in enumerate(row)
        if words[i] + str(mark) != words[dst]
    })


def validate_tape(graph, tape):
    for a, b, answer in tape:
        if answer is not answers(graph, (a, b)):
            raise ValueError("Paid oracle response is false")


def audit_proposal(graph, arm, questions, fallback, catalog):
    paid, memo = audit_selection(graph, arm["proposal"], catalog)
    checked = []
    for pair in questions:
        owned = key(pair) in memo
        answer = memo[key(pair)] if owned else answers(graph, pair)
        checked.append(dict(pair=list(pair), answer=answer, reused=owned))
        if not owned:
            paid.append([*pair, answer])
        if not answer:
            break
    if not checked or arm["checks"] != checked or arm["accepted"] is not checked[-1]["answer"]:
        raise ValueError("Certificate trace skipped or misrepresented a check")
    if not arm["accepted"]:
        paid.extend(fallback)
    if arm["paid"] != paid:
        raise ValueError("The paid trace does not match selection, verification and exact fallback")


def plain(record):
    result = copy.deepcopy(record)
    del result["common_cpu_ns"], result["short_cpu_ns"]
    for case in result["results"]:
        for arm in case["arms"].values():
            del arm["cpu_ns"]
    return result


def without_old_timings(value):
    if isinstance(value, dict):
        return {k: without_old_timings(v) for k, v in value.items() if k not in {
            "seconds", "oracle_seconds", "catalog_seconds",
        }}
    if isinstance(value, list):
        return [without_old_timings(item) for item in value]
    return value


def audit(coverage, prior, earlier, full, replay):
    manifest, scored, repeated = map(read, (coverage, full, replay))
    if plain(scored) != plain(repeated) or scored["coverage_sha256"] != hashlib.sha256(coverage.read_bytes()).hexdigest():
        raise ValueError("Wrong frozen panel or nondeterministic replay")
    pool = elements("s5")
    catalog, words = {}, {}
    for pair in product(pool, repeat=2):
        graph, reps = action("s5", pair)
        if len(graph) == 120:
            identifier = checksum(graph)
            catalog[identifier] = graph
            words[identifier] = reps
    certificates = scored["certificates"]
    if len(catalog) != 57 or set(certificates) != set(catalog):
        raise ValueError("The independent S5 catalogue disagrees with the proposed certificates")
    for identifier, queries in certificates.items():
        if not 1 <= len(queries) <= 7 or len({key(pair) for pair in queries}) != len(queries):
            raise ValueError("Wrong certificate size or duplicate equality")
        for target, graph in catalog.items():
            if all(answers(graph, pair) for pair in queries) != (target == identifier):
                raise ValueError("A certificate accepted the wrong S5 marking or rejected its own")

    excluded = prior_ids(prior, earlier)
    cases = manifest["cases"]
    if manifest["seed"] != SEED or [case["family"] for case in cases] != [name for name in FAMILIES for _ in range(6)]:
        raise ValueError("Incorrect matched panel")
    totals = {family: {arm: Counter() for arm in ARMS} for family in FAMILIES}
    negative_certificates = 0
    for case, output in zip(cases, scored["results"], strict=True):
        graph, _ = action(case["family"], case["marks"])
        digest = checksum(graph)
        if (len(graph) != 120 or digest in excluded or digest != case["graph_sha"] or graph != case["graph"]
                or output["graph_sha"] != digest or output["family"] != case["family"]):
            raise ValueError("Wrong, duplicate, or previously used action")
        excluded.add(digest)
        if case["family"] != "s5":
            for queries in certificates.values():
                if all(answers(graph, pair) for pair in queries):
                    raise ValueError("A certificate accepted an out-of-family action")
                negative_certificates += 1

        arms = output["arms"]
        if set(arms) != set(ARMS):
            raise ValueError("Missing matched arm")
        fallback = arms["fallback"]["paid"]
        validate_tape(graph, fallback)
        for arm, record in arms.items():
            if record["right"] != graph:
                raise ValueError("A recorded action differs from permutation truth")
            paid = record["paid"]
            if arm != "fallback":
                selected = record["proposal"]["marked_class"]
                questions = certificates[selected] if arm == "short" else edge_questions(catalog[selected], words[selected])
                audit_proposal(graph, record, questions, fallback, catalog)
                if record["accepted"] != (case["family"] == "s5"):
                    raise ValueError("The proposal branch accepted the wrong family")
            if arm == "short" and len(paid) - (0 if record["accepted"] else len(fallback)) > 13:
                raise ValueError("The short branch exceeded its fixed paid bound")
            totals[case["family"]][arm].update(
                calls=len(paid), symbols=sum(len(a) + len(b) for a, b, _ in paid), cpu_ns=record["cpu_ns"],
            )
    first_result = scored["results"][0]["arms"]["short"]["paid"]
    forged = copy.deepcopy(first_result)
    forged[0][2] = not forged[0][2]
    try:
        validate_tape(cases[0]["graph"], forged)
    except ValueError:
        pass
    else:
        raise ValueError("The tape auditor accepted a corrupted oracle reply")
    primary = totals["s5"]
    print(json.dumps({
        "exact_replay": True, "forged_reply_rejected": True,
        "short_vs_edge_eighty_percent_gate": 5 * primary["short"]["calls"] <= primary["edge"]["calls"],
        "checked_transitions": 24 * 120 * 2 * len(ARMS),
        "wrong_s5_certificates_rejected": 57 * 56,
        "outside_certificates_rejected": negative_certificates,
        "totals": totals,
        "setup_ns": {key: scored[key] for key in ("common_cpu_ns", "short_cpu_ns")},
    }, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    modes = parser.add_subparsers(dest="mode", required=True)
    cover = modes.add_parser("cover")
    check = modes.add_parser("check")
    for mode in (cover, check):
        mode.add_argument("prior", type=Path)
        mode.add_argument("earlier", type=Path)
        mode.add_argument("coverage", type=Path)
    check.add_argument("scored", type=Path)
    check.add_argument("replay", type=Path)
    regression = modes.add_parser("regression")
    regression.add_argument("before", type=Path)
    regression.add_argument("after", type=Path)
    args = parser.parse_args()
    if args.mode == "cover":
        preflight(args.prior, args.earlier, args.coverage)
    elif args.mode == "check":
        audit(args.coverage, args.prior, args.earlier, args.scored, args.replay)
    else:
        before, after = map(read, (args.before, args.after))
        if len(after["results"]) != 18 or without_old_timings(before) != without_old_timings(after):
            raise ValueError("The original congruence CLI replay changed")
        print("All 18 original congruence rows match outside timing fields.")
