"""Compare the live known-family policies and audit the normal CLI."""

import argparse
import copy
import importlib.util
import json
from pathlib import Path
from time import process_time_ns

from scripts import group_student_probe as candidate


def read(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        raise ValueError(f"Invalid input {path}") from error


def load_incumbent(path):
    spec = importlib.util.spec_from_file_location("frozen_group_student", path)
    if spec is None or spec.loader is None:
        raise ValueError("Unable to load the frozen incumbent")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def timed(function, *args):
    start = process_time_ns()
    result = function(*args)
    return result, process_time_ns() - start


def endpoint(word, graph):
    return endpoint_indices(tuple(map(int, word)), graph)


def endpoint_indices(marks, graph):
    state = 0
    for mark in marks:
        state = graph[state][mark]
    return state


def verify_tape(target, result, catalog):
    live = set(catalog)
    for step in result["queries"]:
        left, right = step["pair"]
        if left == right or set(left + right) - {"0", "1"}:
            raise ValueError("Illegal equality query")
        yes = {mark for mark in live if endpoint(left, catalog[mark]) == endpoint(right, catalog[mark])}
        if not yes or yes == live or step["candidates"] != len(live) or step["predicted_yes"] != len(yes):
            raise ValueError("A paid question did not split the actual live set")
        if step["answer"] is not (target in yes):
            raise ValueError("The recorded answer differs from the independent oracle")
        live = yes if step["answer"] else live - yes
    if live != {target} or result["marked_class"] != target:
        raise ValueError("Wrong or unresolved marked action")


def score(incumbent, output, *, reverse):
    previous = load_incumbent(incumbent)
    cold = {}
    builds = (("legacy", previous.s5_catalog), ("current", candidate.s5_catalog))
    for name, builder in reversed(builds) if reverse else builds:
        cold[name] = timed(builder)
    catalog, build_ns = cold["current"]
    original, legacy_build_ns = cold["legacy"]
    if len(catalog) != 57 or catalog != original or tuple(catalog) != tuple(original):
        raise ValueError("Conjugation changed the exact S5 catalogue")
    tree, compile_ns = timed(candidate.compile_known_family, catalog)
    rows, online_ns = [], {"greedy": 0, "optimal": 0}
    for target, graph in sorted(catalog.items()):
        def equal(a, b, action=graph):
            return endpoint(a, action) == endpoint(b, action)

        result = {}
        order = ("optimal", "greedy") if reverse else ("greedy", "optimal")
        for policy in order:
            if policy == "greedy":
                answer, elapsed = timed(previous.identify_known_family, original, equal)
            else:
                answer, elapsed = timed(candidate._run_equality_plan, candidate.plan_compiled_family(tree), equal)
            online_ns[policy] += elapsed
            verify_tape(target, answer, catalog)
            result[policy] = answer
        rows.append({"target": target, "arms": result})
    forged = copy.deepcopy(rows[0]["arms"]["optimal"])
    first = forged["queries"][0]
    first["answer"] = not first["answer"]
    try:
        verify_tape(rows[0]["target"], forged, catalog)
    except ValueError:
        pass
    else:
        raise ValueError("Independent tape auditor accepted a fabricated reply")

    totals = {}
    for policy in ("greedy", "optimal"):
        tapes = [row["arms"][policy]["queries"] for row in rows]
        totals[policy] = {
            "maximum_calls": max(map(len, tapes)),
            "total_calls": sum(map(len, tapes)),
            "symbols": sum(len(word) for tape in tapes for step in tape for word in step["pair"]),
            "histogram": {n: sum(len(tape) == n for tape in tapes) for n in sorted(set(map(len, tapes)))},
        }
    if (totals["optimal"]["maximum_calls"], totals["optimal"]["total_calls"]) != (6, 335):
        raise ValueError("The constructed tree did not attain both binary lower bounds")
    payload = {
        "catalogue_size": len(catalog), "rows": rows, "totals": totals, "forged_reply_rejected": True,
        "timings": {
            "legacy_catalogue_cpu_ns": legacy_build_ns, "current_catalogue_cpu_ns": build_ns,
            "compile_cpu_ns": compile_ns, "online_cpu_ns": online_ns,
        },
    }
    with output.open("x", encoding="utf-8") as handle:
        json.dump(payload, handle, sort_keys=True)
        handle.write("\n")
    print(json.dumps({key: payload[key] for key in ("catalogue_size", "totals", "timings")}))


def untimed(data):
    if isinstance(data, dict):
        return {key: untimed(value) for key, value in data.items()
                if key not in {"seconds", "oracle_seconds", "catalog_seconds", "family_compile_seconds"}}
    if isinstance(data, list):
        return [untimed(value) for value in data]
    return data


def verify_cli(legacy_path, default_path, optimal_path, scored_path, replay_path):
    scored, replay = read(scored_path), read(replay_path)
    timings = [record.pop("timings") for record in (scored, replay)]
    if scored != replay:
        raise ValueError("Full-catalogue tapes changed across hash seeds")
    legacy, default, optimal = map(read, (legacy_path, default_path, optimal_path))
    if untimed(legacy) != untimed(default) or legacy["catalog_size"] != 57 or len(legacy["results"]) != 18:
        raise ValueError("The default congruence entry point changed a legacy result")
    if optimal.pop("known_family_policy", None) != "optimal" or "family_compile_seconds" not in optimal:
        raise ValueError("The normal CLI did not execute the compiled policy")
    known = []
    by_graph = {row["target"]: row["arms"]["optimal"] for row in scored["rows"]}
    for older, newer in zip(legacy["results"], optimal["results"], strict=True):
        old_family = older.pop("family")
        new_family = newer.pop("family")
        if untimed(older) != untimed(newer):
            raise ValueError("The selected policy changed a different experiment arm")
        if old_family is None:
            if new_family is not None:
                raise ValueError("The compiled tree ran outside its known family")
            continue
        if untimed(new_family) != by_graph[older["graph_sha"]]:
            raise ValueError("CLI produced a different result from the audited tree")
        known.append({
            "graph_sha": older["graph_sha"], "greedy_calls": len(old_family["queries"]),
            "optimal_calls": len(new_family["queries"]),
        })
    if len(known) != 6:
        raise ValueError("The CLI did not exercise all six S5 presentations")
    print(json.dumps({
        "catalogue_size": scored["catalogue_size"], "all_targets": scored["totals"],
        "legacy_default_exact": True, "untimed_replay_exact": True,
        "forged_reply_rejected": scored["forged_reply_rejected"], "cli_known_family": known,
        "both_execution_timings": timings,
    }, indent=2))


def main():
    parser = argparse.ArgumentParser()
    modes = parser.add_subparsers(dest="mode", required=True)
    census = modes.add_parser("score")
    census.add_argument("incumbent", type=Path)
    census.add_argument("output", type=Path)
    census.add_argument("--reverse", action="store_true")
    check = modes.add_parser("verify-cli")
    for argument in ("legacy", "default", "optimal", "scored", "replay"):
        check.add_argument(argument, type=Path)
    args = parser.parse_args()
    if args.mode == "score":
        score(args.incumbent, args.output, reverse=args.reverse)
    else:
        verify_cli(args.legacy, args.default, args.optimal, args.scored, args.replay)


if __name__ == "__main__":
    main()
