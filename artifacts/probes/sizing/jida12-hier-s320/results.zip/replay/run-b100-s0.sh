#!/bin/bash
set -euo pipefail
export PATH="/home/ubuntu/.local/bin:$PATH"
export DSR_QUALITY_LOG_DIR=/data/ssd/tmp/mgr-hier-s320.hk5mLTED/receipts UV_PROJECT_ENVIRONMENT=/data/ssd/tmp/mgr-eval-ci.bevt3nLW/qualified-venv
export OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 MGR_HIER_SEED=0 MGR_HIER_BUDGET=1e14 MGR_HIER_RUN=b100-s0
DSR_REPOS_FILE=/data/ssd/tmp/mgr-hier-s320.hk5mLTED/sizing.yaml dsr quality --tool hierarchy-train --work-dir /data/ssd/tmp/mgr-hier-s320.hk5mLTED/gate --check-timeout 1800
DSR_REPOS_FILE=/data/ssd/tmp/mgr-hier-s320.hk5mLTED/sizing.yaml dsr quality --tool hierarchy-eval --work-dir /data/ssd/tmp/mgr-hier-s320.hk5mLTED/gate --check-timeout 240
DSR_REPOS_FILE=/data/ssd/tmp/mgr-hier-s320.hk5mLTED/interaction.yaml dsr quality --tool hierarchy-interaction --work-dir /data/ssd/tmp/mgr-hier-s320.hk5mLTED/gate --check-timeout 120
