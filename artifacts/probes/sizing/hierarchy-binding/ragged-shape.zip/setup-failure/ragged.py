import itertools
import json
import random
import sys
from collections import Counter
from functools import cache
from pathlib import Path

from address_fixtures import DIM, POOLS, encode, sha_json
from topology import isometries

SEEDS = (15011, 15012, 15013)
FAMILIES = ("perfect", "regrafted", "grown")
ARMS = ("tree", "height", "profile")
N = 127


def tree_leaves(rng, family):
    if family == "grown":
        leaves = {()}
        for _ in range(63):
            node = rng.choice(sorted(leaves))
            leaves.remove(node)
            leaves.update((node + (0,), node + (1,)))
        return leaves
    leaves = set(itertools.product((0, 1), repeat=6))
    if family == "regrafted":
        for _ in range(4):
            donors = {leaf[:-1] for leaf in leaves if len(leaf) == 6 and leaf[:-1] + (1 - leaf[-1],) in leaves}
            down = rng.choice(sorted(donors))
            leaves.difference_update((down + (0,), down + (1,)))
            up = rng.choice(sorted(leaf for leaf in leaves if len(leaf) == 6))
            leaves.remove(up)
            leaves.update((up + (0,), up + (1,)))
    return leaves


def fixture(rng, family, namespace, index):
    leaves = tree_leaves(rng, family)
    nodes = sorted({leaf[:n] for leaf in leaves for n in range(len(leaf) + 1)})
    assert len(leaves) == 64 and len(nodes) == N
    internal = [node for node in nodes if node not in leaves]
    switches = {node: rng.randrange(2) for node in internal}
    keys = dict(zip(nodes, rng.sample(POOLS[1], N), strict=True))
    order = rng.sample(nodes, N)
    out = {node: encode(key, *namespace) for node, key in keys.items()}

    @cache
    def suffixes(node):
        if node in leaves:
            return {()}
        return {(alias, *rest) for alias in (0, 1)
                for rest in suffixes(node + (alias ^ switches[node],))}

    choices = [(node, tail) for node in internal
               for tail in sorted(suffixes(node + (0,)) & suffixes(node + (1,)))]
    nonterminal = [entry for entry in choices if entry[1]]
    pivot, tail = rng.choice(nonterminal if index % 2 == 0 and nonterminal else choices)
    query = tuple(side ^ switches[pivot[:i]] for i, side in enumerate(pivot)) + (rng.randrange(2), *tail)

    def view():
        trace = [()]
        for alias in query:
            node = trace[-1]
            trace.append(node + (alias ^ switches[node],))
        assert trace[-1] in leaves
        records = {keys[node]: [] if node in leaves else
                   [out[node + (alias ^ switches[node],)] for alias in (0, 1)] for node in order}
        return dict(records=records, gold=[keys[node] for node in trace])

    depths = Counter(map(len, nodes))
    profile = [depths[i] for i in range(max(depths) + 1)]
    left = view()
    switches[pivot] ^= 1
    right = view()
    assert left["gold"][-1] != right["gold"][-1]
    return dict(root=out[()], query=query, profile=profile, edit_hop=len(pivot), orientations=[left, right])


def fresh():
    known = set()
    for seed in SEEDS:
        for label, family in enumerate(FAMILIES):
            rng = random.Random(seed + 60980 + 121 * label)
            for index in range(8):
                while True:
                    namespace = tuple(rng.sample(range(DIM), DIM)), rng.randrange(1 << DIM)
                    if namespace not in known:
                        known.add(namespace)
                        break
                yield seed, family, index, namespace, fixture(rng, family, namespace, index)


def process(records, root, query, expected_profile):
    keys = set(records[0])
    pointer_slots = [root, *(ptr for row in records[0].values() for ptr in row)]
    pointers = set(pointer_slots)
    assert len(pointer_slots) == len(pointers) == len(keys) == N
    assert all(table.keys() == keys and all(len(row) in (0, 2) for row in table.values()) for table in records)
    assert all(all(sorted(table[key]) == sorted(records[0][key]) for key in keys) for table in records)
    assert sum(expected_profile) == N
    full = 0
    bank = 0
    traces = [{arm: Counter() for arm in ARMS} for _ in records]
    for lut, x0, p0 in isometries(keys, pointers, ()):
        bank += 1
        row = lut[root ^ p0] ^ x0
        pending = [row]
        profile = []
        while pending:
            profile.append(len(pending))
            pending = [lut[ptr ^ p0] ^ x0 for node in pending for ptr in records[0][node]]
        if sum(profile) != N:
            continue
        full += 1
        accepted = ["tree"]
        if len(profile) == len(expected_profile):
            accepted.append("height")
            if profile == expected_profile:
                accepted.append("profile")
        for table, log in zip(records, traces, strict=True):
            route = [row]
            for alias in query:
                links = table[route[-1]]
                if not links:
                    break
                route.append(lut[links[alias] ^ p0] ^ x0)
            if len(route) == len(query) + 1 and not table[route[-1]]:
                for arm in accepted:
                    log[arm][tuple(route)] += 1
    return dict(bank_maps=bank, connected_maps=full, arms={arm: [
        dict(query_maps=sum(log[arm].values()), routes=[[path, count] for path, count in sorted(log[arm].items())])
        for log in traces] for arm in ARMS})


def run(output):
    rows = []
    for seed, family, index, namespace, case in fresh():
        observed = [view["records"] for view in case["orientations"]]
        result = process(observed, case["root"], case["query"], case["profile"])
        for arm in ARMS:
            for view, outcome in zip(case["orientations"], result["arms"][arm], strict=True):
                assert tuple(view["gold"]) in [path for path, _ in outcome["routes"]]
        rows.append(dict(seed=seed, family=family, index=index, fixture=sha_json(case), **result))
    assert len(rows) == 72
    with output.open("x", encoding="utf-8") as out:
        json.dump(rows, out, separators=(",", ":"))
    print("Enumerated all bank-compatible encodings for 72 fresh query pairs.", flush=True)


if __name__ == "__main__":
    run(Path(sys.argv[1]))
