#!/bin/bash
set -euo pipefail
export PATH="/home/ubuntu/.local/bin:$PATH"
export MGR_SIB=/data/ssd/tmp/mgr-sibling-order.2nI9WLzN
export MGR_SIB_REF=/data/ssd/tmp/mgr-hier-paired.Ji7EOJkO/artifacts/probes/sizing/jida12-paired-hier
export MGR_SIB_ORIGINAL=/data/ssd/tmp/mgr-leaf-replication.1ZSTXLXL/artifacts/probes/sizing/jida12-leaf-replication
export DSR_REPOS_FILE="$MGR_SIB/campaign.yaml"
export UV_PROJECT_ENVIRONMENT=/data/ssd/tmp/mgr-eval-ci.bevt3nLW/qualified-venv
export OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 PYTHONDONTWRITEBYTECODE=1
case "$1" in
  panel)
    export MGR_LEAF_TRAIN_SEED=30 DSR_QUALITY_LOG_DIR="$MGR_SIB/receipts"
    mkdir -p "$MGR_SIB/gate"
    dsr quality --tool hierarchy-sibling-order-panel --work-dir "$MGR_SIB/gate" --check-timeout 180
    ;;
  prepare|evaluate)
    export MGR_LEAF_TRAIN_SEED="$2"
    export DSR_QUALITY_LOG_DIR="$MGR_SIB/seed-$2/receipts"
    gate="$MGR_SIB/seed-$2/gate"
    mkdir -p "$gate"
    if [[ "$1" == prepare ]]; then
      dsr quality --tool hierarchy-sibling-order-prepare --work-dir "$gate" --check-timeout 240
    else
      export MGR_SIB_SHA="$3"
      dsr quality --tool hierarchy-sibling-order-train --work-dir "$gate" --check-timeout 1200
      dsr quality --tool hierarchy-sibling-order-eval --work-dir "$gate" --check-timeout 240
    fi
    ;;
  *) exit 2 ;;
esac
