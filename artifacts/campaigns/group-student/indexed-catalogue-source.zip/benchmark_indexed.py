"""Compare the scalar and vectorized learners against the same oracle."""

import json
import sys
import time
from itertools import product
from pathlib import Path

from catalogue_replay import WORDS, catalogue_matches, labelled_prediction, reach, read
from indexed_catalogue import indexed_matches, indexed_naming
from label_floor import name_action, oracle

from scripts.group_rewrite_probe import teach_panel_case

MATCHERS = {"scalar": catalogue_matches, "indexed": indexed_matches}
NAMERS = {"scalar": name_action, "indexed": indexed_naming}
SPLITS = ("primary", "secondary")


def control_observations(tables, prior, first):
    existing = {60: set(), 120: set()}
    for row in prior["results"]:
        existing[row["order"]].update(pair[0] for pair in row["catalogue"]["witnesses"])
    controls = {}
    exact_pairs = {}
    frequencies = {60: 0, 120: 0}
    for n, index, table in tables:
        if index in existing[n] or frequencies[n] == 3:
            continue
        pair = next(((a, b) for a, b in product(range(n), repeat=2) if reach(table, a, b) == n), None)
        if pair is None:
            continue
        labels = {}
        for word in WORDS:
            state = 0
            for letter in word:
                state = table[state][pair[int(letter)]]
            labels[word] = str((17 * state + 5) % n)
        i = len(controls)
        controls[i] = (n, labels)
        exact_pairs[i] = (index, *pair)
        frequencies[n] += 1
    if frequencies != {60: 3, 120: 3}:
        raise ValueError("Missing catalogue controls")
    n, labels = first
    contradictory = dict(labels, **{"01": labels["00"]})
    if contradictory["10"] == contradictory["00"]:
        raise ValueError("The planted contradiction is ineffective")
    controls[-1] = (n, contradictory)
    controls[-2] = (60, dict.fromkeys(WORDS, "0"))
    return controls, exact_pairs


def match_panel(tables, observations, order):
    matched = {}
    timings = {}
    for arm in order:
        started = time.process_time_ns()
        matched[arm] = MATCHERS[arm](tables, observations)
        timings[arm] = time.process_time_ns() - started
    if matched["scalar"] != matched["indexed"]:
        raise ValueError("Batched search changed the exact version space or full named actions")
    return dict(
        cpu_ns=timings,
        arms={
            arm: dict(
                stats=stats,
                witnesses=witnesses,
                actions={i: sorted(tables) for i, tables in actions.items()},
            )
            for arm, (witnesses, actions, stats) in matched.items()
        },
    )


def solve_panel(tables, cases, observations, matching, order):
    lookups = {(n, i): table for n, i, table in tables}
    rows = []
    for i, case in enumerate(cases):
        n, labels = observations[i]
        roster = set(map(str, range(n)))
        teacher = oracle(case)
        named = {}
        for arm in order:
            paid = []

            def ask(word, tape=paid, evaluate=teacher):
                label = evaluate(word)
                tape.append((word, label))
                return label

            witnesses = matching["arms"][arm]["witnesses"][i]
            started = time.process_time_ns()
            result = NAMERS[arm](labels, roster, {j: lookups[n, j] for j, _, _ in witnesses}, witnesses, ask)
            result.update(cpu_ns=time.process_time_ns() - started, paid=paid)
            if result["action"] is None:
                raise ValueError("The replayed singleton action was lost")
            result["answers"] = {
                split: [labelled_prediction(result["action"], word) for word, _, _ in case[split]]
                for split in SPLITS
            }
            named[arm] = result
        start_square = time.process_time_ns()
        learner, tape = teach_panel_case(labels, roster, teacher, squares=True)
        root = learner.maps["r0"][learner.maps["r0"][labels["00"]]]
        edges = [tuple(learner.maps["R" + mark][str(j)] for mark in "01") for j in range(n)]
        square = dict(action=(root, edges), paid=tape, cpu_ns=time.process_time_ns() - start_square)
        rows.append(dict(index=i, order=n, observed=len(set(labels.values())), square=square, **named))
    return rows


def run(cohort, library, prior, output, reverse):
    started = time.process_time_ns()
    _, _, tables = read(library)
    common_cpu_ns = time.process_time_ns() - started
    cases = [read(cohort / f"{i:02}.json") for i in range(24)]
    observations = {i: (c["label_count"], dict(c["arms"]["short_only"]["rows"])) for i, c in enumerate(cases)}
    controls, exact_pairs = control_observations(tables, read(prior), observations[0])

    order = ("indexed", "scalar") if reverse else ("scalar", "indexed")
    primary = match_panel(tables, observations, order)
    rows = solve_panel(tables, cases, observations, primary, order)
    conformance = match_panel(tables, controls, order)
    checked = conformance["arms"]["indexed"]["witnesses"]
    if checked[-1] or checked[-2] or any(pair not in checked[i] for i, pair in exact_pairs.items()):
        raise ValueError("Outside action or invalid subgroup was misclassified")

    def never_ask(word):
        raise ValueError(f"Ambiguity allowed a paid call: {word}")

    cycle = [[0, 1, 2], [1, 2, 0], [2, 0, 1]]
    ambiguous = indexed_naming({}, {"0", "1", "2"}, {1: cycle}, [(1, 0, 1), (1, 1, 0)], never_ask)
    if ambiguous != dict(structures=2, action=None):
        raise ValueError("Distinct actions were collapsed")
    with output.open("x", encoding="utf-8") as file:
        json.dump(dict(common_cpu_ns=common_cpu_ns, matching=primary, cases=rows, controls=conformance,
                       control_pairs=exact_pairs, ambiguous_refused=True), file, sort_keys=True)
        file.write("\n")


if __name__ == "__main__":
    run(*map(Path, sys.argv[1:5]), reverse=sys.argv[5] == "reverse")
