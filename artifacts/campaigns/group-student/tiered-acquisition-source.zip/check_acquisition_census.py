"""Check the exact census and compare charges across deterministic relabelings."""

import hashlib
import json
import sys
from collections import Counter

import numpy as np
from check_four_anchor import ANCHORS, access, movement_floor, position, reconstruct, strip_timing
from check_replay import load

ARMS = ("square", "legacy", "tiered")


class Columns:
    """Independent endpoint partitions for checking structural handoff."""

    def __init__(self, shapes):
        self.edges = np.asarray(shapes, dtype=np.uint8)
        self.cases = np.arange(len(shapes))
        self.cached = {"": np.zeros(len(shapes), dtype=np.uint8)}

    def word(self, value):
        if value not in self.cached:
            for i, mark in enumerate(value):
                prefix = value[:i + 1]
                if prefix not in self.cached:
                    self.cached[prefix] = self.edges[self.cases, self.cached[value[:i]], int(mark)]
        return self.cached[value]

    def survivors(self, paid):
        refs: dict[int, str] = {}
        live = self.cases
        for word, label in paid:
            current = self.word(word)[live]
            if label in refs:
                keep = current == self.word(refs[label])[live]
            else:
                keep = np.ones(len(live), dtype=np.bool_)
                for reference in refs.values():
                    keep &= current != self.word(reference)[live]
                refs[label] = word
            live = live[keep]
            if not len(live):
                break
        return live.tolist()

    def selected_score(self, paid, word, free):
        live = self.survivors(paid)
        references = {state: reference for reference, state in paid}
        endpoint = self.word(word)[live]
        known_counts = [int(np.count_nonzero(endpoint == self.word(ref)[live])) for ref in references.values()]
        unnamed = len(live) - sum(known_counts)
        return dict(before=len(live), worst=max(unnamed, free * max(known_counts)),
                    movement_debt=len(word) * len(live), wasted_reads=len(live) - unnamed if free > 1 else len(live))


def naming_check(result, words, initial, graph, n, slot, columns):
    events = result["events"]
    if [(e["word"], e["answer"]) for e in events] != [(w, label) for w, label in result["tape"][:len(events)]]:
        raise ValueError("Trace does not match its paid oracle calls")
    structure = []
    naming = []
    for event, (word, state) in zip(events, words):
        if event["phase"] == "structure" and not naming:
            paid = initial + structure
            free = max(1, n - len({label for _, label in paid}))
            score = columns.selected_score(paid, word, free)
            if (any(event[key] != value for key, value in score.items()) or score["worst"] >= score["before"] * free
                    or event["after"] != len(columns.survivors([*paid, (word, state)]))):
                raise ValueError("Incorrect version-space count or selected probe score")
            structure.append((word, state))
        elif event["phase"] == "naming":
            naming.append((word, state))
        else:
            raise ValueError("Wrong structure-to-naming order")
    before_naming = initial + structure
    survivors = columns.survivors(before_naming)
    if result["terminal"] == "cap":
        if len(survivors) < 2 or slot not in survivors or len(before_naming) != n + 24 or naming:
            raise ValueError("Fallback occurred at the wrong version-space boundary")
        return
    if result["terminal"] != "unique" or survivors != [slot] or len(words) != len(events):
        raise ValueError("Incorrect uniqueness at naming handoff")
    named = {state for _, state in before_naming}
    expected_naming = [(word, state) for state, word in access(graph) if state not in named][:-1]
    if naming != expected_naming:
        raise ValueError("Incorrect shortest naming suffix")


def run_names(n, slot, renamed):
    multiplier = 19 if renamed else 17
    intercept = 7 * slot + 11 if renamed else 13 * slot + 7
    labels = [str((i * multiplier + intercept) % n) for i in range(n)]
    if len(set(labels)) != n:
        raise ValueError("A replay did not use a naming permutation")
    return labels


def verify_row(row, graph, renamed, columns):
    n, slot = row["order"], row["slot"]
    names = run_names(n, slot, renamed)
    invert = {name: state for state, name in enumerate(names)}
    anchors = {word: names[position(graph, word)] for word in ANCHORS}
    if row["anchors"] != anchors or set(row["arms"]) != set(ARMS):
        raise ValueError("Wrong anchors or study arms")
    labelled = [None] * n
    for state, (a, b) in enumerate(graph):
        labelled[int(names[state])] = [names[a], names[b]]
    truth = [names[0], labelled]
    read_floor = n + 3 - len(set(anchors.values()))
    symbol_floor = movement_floor(truth, anchors)
    canonical_anchors = [(word, invert[name]) for word, name in anchors.items()]
    normalized = {}
    costs = {}
    for arm, result in row["arms"].items():
        tape = result["tape"]
        paid = [*anchors.items(), *tape]
        if (result["action"] != truth or len(paid) < read_floor or len({word for word, _ in paid}) != len(paid)
                or any(len(word) < 2 or names[position(graph, word)] != value for word, value in paid)):
            raise ValueError("An exact action, oracle answer, or read floor failed")
        words = [(word, invert[value]) for word, value in tape]
        if arm == "tiered" and columns is not None:
            naming_check(result, words, canonical_anchors, graph, n, slot, columns)
        zeros = sum(word.count("0") for word, _ in paid)
        ones = sum(word.count("1") for word, _ in paid)
        if zeros + ones < symbol_floor:
            raise ValueError("A tape undershot the exact movement floor")
        costs[arm] = dict(reads=len(paid), zeros=zeros, ones=ones, symbols=zeros + ones,
                          fallback=int(result["terminal"] == "cap"), cpu_ns=result["cpu_ns"], wall_ns=result["wall_ns"])
        if arm == "tiered":
            scored = [event["compared"] for event in result["events"] if event["phase"] == "structure"]
            if any(type(count) is not int or count < 1 for count in scored):
                raise ValueError("Invalid tier scoring count")
            costs[arm].update(scored_words=sum(scored), structure_steps=len(scored))
        events = [dict(e, answer=invert[e["answer"]]) for e in result["events"]]
        # Keep all decision telemetry. The legacy arm scored longer words only to report minimax.
        for event in events:
            if event["phase"] == "structure":
                event.pop("minimax", None)
                event.pop("compared", None)
        normalized[arm] = dict(tape=words, terminal=result["terminal"],
                               events=events)
    return normalized, costs, read_floor, symbol_floor, canonical_anchors


def check_controls(sample):
    fallback = sample["fallback"]
    (target,) = (row for row in sample["rows"] if (row["order"], row["slot"]) == (fallback["order"], fallback["slot"]))
    result = fallback["result"]
    square = target["arms"]["square"]
    if (result["terminal"] != "cap" or result["events"] or target["arms"]["tiered"]["events"][0]["phase"] != "structure"
            or any(result[key] != square[key] for key in ("tape", "action")) or sample["duplicate_rejected"] is not True):
        raise ValueError("Forced fallback or invalid naming control failed")
    return dict(order=fallback["order"], slot=fallback["slot"], duplicate_rejected=True)


def audit(library_path, previous_path, first_path, replay_path):
    library, previous, first, second = map(load, (library_path, previous_path, first_path, replay_path))
    shapes = reconstruct(library)
    independent = hashlib.sha256(json.dumps(shapes, separators=(",", ":"), sort_keys=True).encode()).hexdigest()
    expected_count = {str(n): len(s) for n, s in shapes.items()}
    if first["renamed"] or not second["renamed"]:
        raise ValueError("The naming permutation replay was skipped")
    for sample in (previous, first, second):
        if (sample["shape_digest"] != independent or sample["shape_counts"] != expected_count
                or len(sample["rows"]) != sum(expected_count.values())):
            raise ValueError("The complete marked census is missing or has duplicates")
    groups = [{str(n): {arm: Counter() for arm in ARMS} for n in shapes} for _ in range(2)]
    floors = Counter()
    relation_rows = zip(previous["rows"], first["rows"], second["rows"], strict=True)
    transitions = 0
    for n, forms in shapes.items():
        partitions = Columns(forms)
        for slot, graph in enumerate(forms):
            historical, original, renamed = next(relation_rows)
            if any((row["order"], row["slot"]) != (n, slot) for row in (historical, original, renamed)):
                raise ValueError("The complete census was reordered")
            if historical["anchors"] != original["anchors"] or any(
                strip_timing(historical["arms"][old]) != strip_timing(original["arms"][new])
                for old, new in (("length", "legacy"), ("square", "square"))
            ):
                raise ValueError("Live comparator diverged from the released census")
            norm, costs, read_floor, symbol_floor, anchors = verify_row(original, graph, False, partitions)
            replay, replay_costs, _, _, permutation = verify_row(renamed, graph, True, None)
            if norm != replay or anchors != permutation:
                raise ValueError("A renamed case gave a different canonical tape or terminal state")
            if norm["tiered"] != norm["legacy"]:
                raise ValueError("The optimized arm changed a paid tape or decision")
            for run, charges in zip(groups, (costs, replay_costs), strict=True):
                for arm, charge in charges.items():
                    run[str(n)][arm].update(charge)
            floors.update(reads=read_floor, symbols=symbol_floor)
            transitions += 2 * n * len(ARMS) * 2
    aggregates = []
    for run in groups:
        total = {arm: Counter() for arm in ARMS}
        for order in run.values():
            for arm, counts in order.items():
                total[arm].update(counts)
        aggregates.append(total)
    gates = [2 * total["tiered"]["cpu_ns"] <= total["legacy"]["cpu_ns"] for total in aggregates]
    print(json.dumps(dict(
        groups=groups, all=aggregates, gates=gates, passed=all(gates), floors=floors,
        shape_counts=expected_count, checked_transitions=transitions,
        controls=[check_controls(sample) for sample in (first, second)],
        build=[{k: sample[k] for k in ("builder", "preparation", "tier_setup")} for sample in (first, second)],
    ), sort_keys=True))


if __name__ == "__main__":
    audit(*sys.argv[1:])
