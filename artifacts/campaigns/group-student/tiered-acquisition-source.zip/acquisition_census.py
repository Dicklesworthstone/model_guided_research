"""Compare exact shortest-tier acquisition over the complete marked inventory."""

import json
import sys
from pathlib import Path
from time import monotonic_ns, process_time_ns

from catalogue_replay import read
from catalogue_study import ANCHORS, endpoint
from cold_catalogue import reduced_shapes
from four_anchor import digest, measure, prepare, prepare_tiers
from incumbent.four_anchor import measure as measure_square
from released.four_anchor import measure as measure_legacy

ARMS = ("square", "legacy", "tiered")


def labelled_roster(n, slot, reverse):
    slope, offset = (19, 7 * slot + 11) if reverse else (17, 13 * slot + 7)
    return [str((slope * i + offset) % n) for i in range(n)]


def run(library, output, reverse):
    started_cpu, started_wall = process_time_ns(), monotonic_ns()
    raw = read(library)
    shapes, counts, _ = reduced_shapes(raw, lattices=True)
    builder = dict(cpu_ns=process_time_ns() - started_cpu, wall_ns=monotonic_ns() - started_wall)
    started_cpu, started_wall = process_time_ns(), monotonic_ns()
    indices = {n: prepare(forms) for n, forms in shapes.items()}
    preparation = dict(cpu_ns=process_time_ns() - started_cpu, wall_ns=monotonic_ns() - started_wall)
    started_cpu, started_wall = process_time_ns(), monotonic_ns()
    plans = {n: prepare_tiers(index) for n, index in indices.items()}
    tier_setup = dict(cpu_ns=process_time_ns() - started_cpu, wall_ns=monotonic_ns() - started_wall)

    rows = []
    fallback = None
    duplicate_rejected = False
    for n, forms in shapes.items():
        index = indices[n]
        for slot, action in enumerate(forms):
            names = labelled_roster(n, slot, reverse)

            def evaluate(word, graph=action, labels=names):
                return labels[endpoint(graph, word)]

            start_cpu, start_wall = process_time_ns(), monotonic_ns()
            anchors = {word: evaluate(word) for word in ANCHORS}
            initial = dict(cpu_ns=process_time_ns() - start_cpu, wall_ns=monotonic_ns() - start_wall)
            offset = slot % len(ARMS)
            order = ARMS[offset:] + ARMS[:offset]
            if reverse:
                order = tuple(reversed(order))
            arms = {}
            for arm in order:
                if arm == "square":
                    arms[arm] = measure_square(n, evaluate, index, anchors, "square")
                elif arm == "legacy":
                    arms[arm] = measure_legacy(n, evaluate, index, anchors, distances=None)
                else:
                    arms[arm] = measure(n, evaluate, index, anchors, distances=None, plan=plans[n])
            events = arms["tiered"]["events"]
            if fallback is None and events and events[0]["phase"] == "structure":
                stopped = measure(n, evaluate, index, anchors, distances=None, plan=plans[n], cap=4)
                fallback = dict(order=n, slot=slot, result=stopped)
            naming_word = next((e["word"] for e in events if e["phase"] == "naming"), None)
            if not duplicate_rejected and naming_word is not None:
                def duplicate(word, target=naming_word, existing=anchors["00"], teacher=evaluate):
                    return existing if word == target else teacher(word)

                try:
                    measure(n, duplicate, index, anchors, distances=None, plan=plans[n])
                except ValueError as error:
                    if str(error) != "The oracle reused a name in the determined action":
                        raise
                    duplicate_rejected = True
            rows.append(dict(order=n, slot=slot, anchors=anchors, initial=initial, arms=arms))
        print(f"Finished order {n}, {len(forms)} exact marked actions scored.", flush=True)
    if fallback is None or not duplicate_rejected:
        raise ValueError("The forced fallback or duplicate-label control did not run")
    with output.open("x", encoding="utf-8") as file:
        json.dump(dict(
            rows=rows, renamed=reverse, shape_digest=digest(shapes), builder=builder, preparation=preparation,
            tier_setup=tier_setup, fallback=fallback, duplicate_rejected=duplicate_rejected,
            shape_counts={n: len(forms) for n, forms in shapes.items()},
            traversals=sum(row["traversals"] for row in counts),
        ), separators=(",", ":"), sort_keys=True, fp=file)
        file.write("\n")


if __name__ == "__main__":
    run(Path(sys.argv[1]), Path(sys.argv[2]), reverse=sys.argv[3] == "reverse")
