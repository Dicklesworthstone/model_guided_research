"""Check exact order-fifteen quotient acquisition against independent arithmetic."""

import argparse
import hashlib
import json
import math
import random
from collections import Counter
from itertools import product
from pathlib import Path

from check_alternating_route import PANEL, PRIOR, digests, key
from check_central_route import ARMS as PREVIOUS_ARMS
from check_central_route import REPLAYS as OLDER_REPLAYS
from check_central_route import TARGETS as CENTRAL_TARGETS
from check_central_route import model as earlier_model
from check_commutator_route import CONTROLS, graph_for, normalized
from check_klein_route import order
from check_short_certificate import action, answers, checksum, read, validate_tape, walk

SEED = 251779
TARGETS = ("c15-by-c8-inversion", "c15-by-c8-order4")
OUTSIDE, REPLAY_TARGET = "d40xc3", "d30xc4"
REPLAYS = (*OLDER_REPLAYS, *CENTRAL_TARGETS)
ARMS = (*PREVIOUS_ARMS, "order_fifteen")
INCUMBENT, CANDIDATE = ARMS[-2:]


def model(family):
    shapes = {
        "c15-by-c8-inversion": (15, 8, 1, -1), "c15-by-c8-order4": (15, 8, 1, 2),
        "c15-by-c4": (15, 4, 1, 2), "d30": (15, 2, 1, -1), "d30xc3": (15, 2, 3, -1), OUTSIDE: (20, 2, 3, -1),
    }
    if family not in shapes:
        return earlier_model(family)
    rotations, complement, modulus, multiplier = shapes[family]

    def multiply(left, right):
        x, y, z = left
        a, b, c = right
        return (x + pow(multiplier, y, rotations) * a) % rotations, (y + b) % complement, (z + c) % modulus

    return list(product(range(rotations), range(complement), range(modulus))), (0, 0, 0), multiply


def make_panel(root):
    latest = read(root / PANEL / "central-route-coverage.json")
    names = ("alternating", "commutator", "klein", "fifth-power", "involution")
    history = (*PRIOR, *(PANEL / f"{name}-route-coverage.json" for name in names))
    used = {identifier for path in history for identifier in digests(read(root / path))} | set(digests(latest))
    rng = random.Random(SEED)
    cases = []
    for family in (*TARGETS, OUTSIDE):
        pool, identity, multiply = model(family)
        found = 0
        for _ in range(10_000):
            marks = rng.choice(pool), rng.choice(pool)
            graph = graph_for(marks, identity, multiply)
            identifier = checksum(graph)
            if len(graph) == 120 and identifier not in used:
                cases.append(dict(family=family, marks=list(map(list, marks)), graph=graph, graph_sha=identifier))
                used.add(identifier)
                found += 1
                if found == 6:
                    break
        if found != 6:
            raise ValueError(f"Insufficient fresh cases for {family}")
    cases.extend(case for case in latest["cases"] if case["family"] == REPLAY_TARGET)
    cases.extend(next(case for case in latest["cases"] if case["family"] == family) for family in REPLAYS)
    return dict(seed=SEED, cases=cases)


def verify_extension(graph, witness, c, orders):
    if orders != tuple(order(graph, mark) for mark in "01") or not answers(graph, ("01", c + "10")) or order(graph, c) != 15:
        raise ValueError("Wrong verified commutator or generator orders")
    w, s, h = witness["lattice"]
    if w <= 0 or h <= 0 or not 0 <= s < w or 15 * w * h != len(graph):
        raise ValueError("Wrong lattice dimensions")
    for mark, exponent, mode in zip("01", witness["actions"], witness["conjugation_modes"], strict=True):
        if math.gcd(exponent, 15) != 1 or not answers(graph, (mark + c, c * exponent + mark)):
            raise ValueError("Wrong recombined conjugation exponent")
        if mode != ("direct" if exponent in (1, 14) else "prime_projections"):
            raise ValueError("Wrong conjugation proof path")
        for factor in (3, 5):
            power = 15 // factor
            if not answers(graph, (mark + c * power, c * (power * (exponent % factor)) + mark)):
                raise ValueError("Wrong prime conjugation projection")
    for word, exponent in zip(("0" * w, "0" * s + "1" * h), witness["powers"], strict=True):
        if exponent not in range(15) or not answers(graph, (word, c * exponent)):
            raise ValueError("Wrong recombined lift exponent")
        for factor in (3, 5):
            power = 15 // factor
            if not answers(graph, (word * power, c * (power * (exponent % factor)))):
                raise ValueError("Wrong prime lift projection")
    forms = {walk(graph, c * k + "0" * x + "1" * y) for k, x, y in product(range(15), range(w), range(h))}
    if forms != set(range(len(graph))):
        raise ValueError("Normal forms are not bijective")
    coprime = math.gcd(w * h, 15) == 1
    if witness["quotient_oracle"] != ("fifteenth_power" if coprime else "cosets") or not witness["quotient_queries"]:
        raise ValueError("Invalid quotient mode or missing comparisons")
    for left, right, reply in witness["quotient_queries"]:
        expected = any(answers(graph, (left, c * k + right)) for k in range(15))
        if reply is not expected:
            raise ValueError("Wrong quotient equality")
        if coprime:
            inverse = "".join(mark * (orders[int(mark)] - 1) for mark in reversed(right))
            if (walk(graph, (left + inverse) * 15) == 0) != expected:
                raise ValueError("The power shortcut disagrees with explicit cosets")


def census():
    from scripts.group_student_probe import _try_order_fifteen_commutator

    result = {}
    for family in ("d30", "c15-by-c4", "d30xc3"):
        pool, identity, multiply = model(family)
        pairs = list(product(pool, repeat=2))
        if family == "d30xc3":
            random.Random(SEED + 1).shuffle(pairs)
        count = maximum = false_matches = 0
        action_exponents = set()
        for marks in pairs:
            graph = graph_for(marks, identity, multiply)
            if len(graph) != len(pool):
                continue
            calls = 0

            def equal(left, right, target=graph):
                nonlocal calls
                calls += 1
                return answers(target, (left, right))

            order_a, order_b = (next(k for k in range(1, len(pool) + 1) if equal(mark * k, "")) for mark in "01")
            c = "01" + "0" * (order_a - 1) + "1" * (order_b - 1)
            if equal("01", "10") or equal(c * 3, "") or equal(c * 5, ""):
                raise ValueError("The required negative comparisons did not hold")
            calls = 0
            recovered, witness = _try_order_fifteen_commutator(len(pool), equal, (order_a, order_b), c)
            if recovered is None or [list(row) for row in recovered] != graph:
                raise ValueError("A transfer action did not recover exactly")
            verify_extension(graph, witness, c, (order_a, order_b))
            if family == "d30xc3":
                mark = str(next(i for i, value in enumerate(marks) if value[-1]))
                word = mark * 2
                if walk(graph, word * 15) != 0 or any(answers(graph, (word, c * k)) for k in range(15)):
                    raise ValueError("Missing a noncoprime power-test counterexample")
                false_matches += 1
            action_exponents.update(witness["actions"])
            maximum = max(maximum, calls)
            count += 1
            if family == "d30xc3" and count == 12:
                break
        if not count or (family == "d30xc3" and count != 12):
            raise ValueError("Incomplete transfer coverage")
        result[family] = dict(order=len(pool), generating_pairs=count, maximum_branch_calls=maximum,
                              conjugation_exponents=sorted(action_exponents), invalid_power_matches=false_matches)
    return result


def audit(root, coverage, primary, repeat, baseline, previous):
    manifest, scored, replay, baseline, previous = map(read, (coverage, primary, repeat, baseline, previous))
    if manifest != make_panel(root) or scored["coverage_sha256"] != hashlib.sha256(coverage.read_bytes()).hexdigest():
        raise ValueError("The wrong frozen panel was scored")
    current = normalized(scored)
    if current != normalized(replay):
        raise ValueError("Hash seed changed non-timing data")
    prior = {row["graph_sha"]: row["arms"][INCUMBENT] for row in normalized(previous)["results"]}
    counts = {family: {arm: Counter() for arm in ARMS} for family in (*TARGETS, OUTSIDE, REPLAY_TARGET, *REPLAYS)}
    branches = []
    forged = False
    for case, row, clean in zip(manifest["cases"], scored["results"], current["results"], strict=True):
        family = case["family"]
        if family in CONTROLS:
            graph = action(family, case["marks"])[0]
        else:
            _, identity, multiply = model(family)
            graph = graph_for(case["marks"], identity, multiply)
        identifier = checksum(graph)
        if graph != case["graph"] or identifier != case["graph_sha"] or (identifier, family) != (row["graph_sha"], row["family"]):
            raise ValueError("Independent group reconstruction disagrees")
        if set(row["arms"]) != set(ARMS):
            raise ValueError("Missing comparison arm")
        for name, arm in row["arms"].items():
            validate_tape(graph, arm["paid"])
            if arm["right"] != graph:
                raise ValueError("Recovered action differs")
            counts[family][name].update(calls=len(arm["paid"]), symbols=sum(len(a) + len(b) for a, b, _ in arm["paid"]), cpu_ns=arm["cpu_ns"])
        candidate = clean["arms"].pop(CANDIDATE)
        incumbent = clean["arms"][INCUMBENT]
        if family in REPLAYS:
            if candidate != incumbent or incumbent != prior[identifier]:
                raise ValueError("Previously solved action changed")
            continue
        if family == REPLAY_TARGET and incumbent != prior[identifier]:
            raise ValueError("The replayed target's incumbent changed")
        tail = clean["arms"]["fallback"]["paid"]
        prefix = incumbent["paid"][:-len(tail)]
        if incumbent["paid"] != prefix + tail or candidate["paid"][:len(prefix)] != prefix:
            raise ValueError("The paid prefix or generic fallback changed")
        c = candidate["commutator"]["word"]
        proof = {key(a, b): answer for a, b, answer in prefix}
        if proof.get(key(c * 3, "")) is not False or proof.get(key(c * 5, "")) is not False:
            raise ValueError("Order proof repeated or failed to inherit a prerequisite")
        witness = candidate[CANDIDATE]
        if family == OUTSIDE:
            added = len(candidate["paid"]) - len(incumbent["paid"])
            if witness != {"rejected": "commutator_order"} or order(graph, c) != 10 or added != 1 or candidate["paid"][-len(tail):] != tail:
                raise ValueError("Outside rejection changed the fallback or its cost")
            branches.append(dict(family=family, branch_calls=added, rejected=True))
        else:
            orders = tuple(candidate["commutator"]["orders"])
            verify_extension(graph, witness, c, orders)
            if family.endswith("order4") and "prime_projections" not in witness["conjugation_modes"]:
                raise ValueError("Order-four action did not exercise the prime projections")
            branches.append(dict(family=family, branch_calls=len(candidate["paid"]) - len(prefix), actions=witness["actions"],
                                 quotient_queries=len(witness["quotient_queries"]), powers=witness["powers"]))
            if not forged:
                wrong = [(witness["powers"][0] + 1) % 15, witness["powers"][1]]
                try:
                    verify_extension(graph, dict(witness, powers=wrong), c, orders)
                except ValueError:
                    forged = True
                else:
                    raise ValueError("Forged lift accepted")

    if current != normalized(baseline):
        raise ValueError("Previous normal CLI changed")
    before, after = (sum(counts[family][arm]["calls"] for family in TARGETS) for arm in (INCUMBENT, CANDIDATE))
    print(json.dumps(dict(
        exact=True, default_unchanged=True, forged_lift_rejected=forged, checked_transitions=35 * 120 * 2 * len(ARMS),
        gate=5 * after <= before, incumbent_calls=before, order_fifteen_calls=after, totals=counts, branches=branches, census=census(),
    ), indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    modes = parser.add_subparsers(dest="mode", required=True)
    for name in ("cover", "audit"):
        mode = modes.add_parser(name)
        mode.add_argument("root", type=Path)
        mode.add_argument("coverage", type=Path)
    for name in ("primary", "repeat", "baseline", "previous"):
        mode.add_argument(name, type=Path)
    args = parser.parse_args()
    if args.mode == "cover":
        with args.coverage.open("x", encoding="utf-8") as file:
            json.dump(make_panel(args.root), file, sort_keys=True)
            file.write("\n")
    else:
        audit(args.root, args.coverage, args.primary, args.repeat, args.baseline, args.previous)
