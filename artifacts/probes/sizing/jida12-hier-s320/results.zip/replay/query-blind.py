import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path.cwd()))
from cli import _eval_split_examples
from interaction import leaves
from nanochat.diagnostics_data import TASKS

spec = TASKS["hier"]
rows = []
for seed in (0, 1, 2):
    in_range, held_out, _ = _eval_split_examples(spec, n=24, seed=seed)
    for split, documents in (("in_range", in_range), ("held_out", held_out)):
        oracle_correct = blind_correct = path_matches = 0
        for document in documents:
            prompt, expected = spec.split_prompt(document)
            tree, path = prompt.removeprefix("TASK hier TREE ").split(" PATH ")
            query = tuple(path.removesuffix(" OUT").split())
            candidates = list(leaves(tree))
            table = dict(candidates)
            _, (shortcut, guess) = max(enumerate(candidates), key=lambda row: (len(row[1][0]), row[0]))
            oracle_correct += table[query] == expected
            blind_correct += guess == expected
            path_matches += shortcut == query
        assert oracle_correct == len(documents)
        rows.append({
            "seed": seed, "split": split, "documents": len(documents), "query_oracle_correct": oracle_correct,
            "query_blind_correct": blind_correct, "query_blind_path_matches": path_matches,
        })
with Path(sys.argv[1]).open("x", encoding="utf-8") as output:
    output.write(json.dumps(rows, indent=2) + "\n")
print(json.dumps(rows))
