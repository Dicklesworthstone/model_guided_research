import json
import sys
from pathlib import Path

import pyarrow.parquet as pq

from cli import _eval_split_examples
from nanochat.diagnostics_data import TASKS, _hier_paths, _parse_hier_tree
from nanochat.tokenizer import TASK_TOKENIZER_DEFAULT_VOCAB, train_task_tokenizer


def semantic_tree(doc):
    tree = _parse_hier_tree(doc.split(" BIND ", 1)[0].split()[3:])
    assert tree is not None
    return tuple(sorted(_hier_paths(tree)))


root = Path(sys.argv[1])
train_data = root / "default" / "hier_bind"
tokenizer = train_task_tokenizer([train_data / "train_000.parquet"], TASK_TOKENIZER_DEFAULT_VOCAB)
known = set()
for name in ("train_000.parquet", "val_000.parquet", "heldout/test_000.parquet"):
    docs = pq.read_table(train_data / name, columns=["text"]).column("text").to_pylist()
    identities = {semantic_tree(doc) for doc in docs}
    assert len(identities) == len(docs) // 2 and not known.intersection(identities)
    known.update(identities)
configured_corpus_tree_count = len(known)

panel, lengths = {}, {}
for seed in (3301, 3302, 3303):
    in_range, held_out, _ = _eval_split_examples(TASKS["hier_bind"], n=24, seed=seed)
    panel[seed] = {"in_range": in_range, "held_out": held_out}
    lengths[seed] = {}
    for split, docs in panel[seed].items():
        identities = {semantic_tree(doc) for doc in docs}
        assert len(docs) == 24 and len(identities) == 12 and not known.intersection(identities)
        known.update(identities)
        bos = tokenizer.get_bos_token_id()
        lengths[seed][split] = max(len(tokenizer.encode(doc, prepend=bos)) for doc in docs)
        assert lengths[seed][split] <= 192
assert configured_corpus_tree_count == 2048 and len(known) == 2120
with (root / "baseline-panel.json").open("x", encoding="utf-8") as output:
    json.dump(panel, output, indent=2)
print(json.dumps(dict(corpus_semantic_trees=configured_corpus_tree_count, evaluation_semantic_trees=72,
                      document_lengths=lengths, context=192)))
