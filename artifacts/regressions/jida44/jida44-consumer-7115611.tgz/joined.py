from common import *
from collections import Counter
import shutil

p = root / "producer"
out = root / "runs" / "joined"
data = root / "inputs" / "datasets" / "hier"
out.mkdir(parents=True)
code = ("cli.py","nanochat/train.py","nanochat/gpt.py")
assert git(p,"rev-parse","HEAD")==published and not git(p,"status","--porcelain")

def train(seed):
    args = [sys.executable,"-m","nanochat.train","--device","cpu","--max-steps","6",
            "--batch-size","2","--sequence-len","32","--n-layer","1","--n-head","2",
            "--n-kv-head","2","--n-embd","16","--seed",seed,"--warmup-steps","0",
            "--artifacts-dir",out/"training","--run-id",f"native-{seed}","--checkpoint-interval","2",
            "--save-initial-weights","--attention-type","tropical","--tokenizer","task","--data-dir",data]
    result = run(args,p)
    (out/f"train-{seed}.log").write_text(result.stdout+result.stderr)
    print("trained",seed,flush=True)

def observe(seed,analysis,step,group):
    checkpoint=out/f"training/baseline/nanochat/native-{seed}/checkpoints"
    target=out/"cohorts"/group/f"native-{seed}-{analysis}-{step}"
    cli(p,"routes","--checkpoint",checkpoint,"--step",step,"--task","hier","--sample","8",
        "--seed",analysis,"--device","cpu","--no-region-count","--out",target)
    record=load(target/"summary.json")
    assert record["meta"]["training_seed"]==seed and record["meta"]["weights_sha256"]==sha(checkpoint/f"model_{step:06d}.pt")
    assert record["meta"]["initial_weights_sha256"]==sha(checkpoint/"initial/model_000000.pt")
    assert sorted(x.name for x in checkpoint.glob("model_*.pt"))==["model_000001.pt","model_000003.pt","model_000005.pt"]
    assert [x["step"] for x in record["results"]["reuse"]["checkpoint_curve"]]==([-1,1] if step==1 else [-1,1,3])
    assert not record["provenance"]["tainted"] and not record["train_provenance"]["tainted"]
    print("measured",seed,analysis,step,group,flush=True)
    return target

train(41)
prior=observe(41,42,1,"pre")
registry=p/"hypotheses/registry.yaml"
with registry.open("ab") as f:
    f.write(b"\n"+(root/"fixture.yaml").read_bytes())
git(p,"add","hypotheses/registry.yaml")
git(p,"commit","-qm","Register separate diagnostic reuse control with published threshold and minimum")
anchor=git(p,"rev-parse","HEAD")
git(p,"commit","--allow-empty","-qm","Freeze native post-registration producer")
producer=git(p,"rev-parse","HEAD")
assert not git(p,"status","--porcelain") and not git(p,"diff",published,"HEAD","--",*code)
registry_sha=sha(registry)
observe(41,43,1,"reevaluated-pre")
for seed in seeds:
    train(seed)
    observe(seed,42,1,"post")
early=observe(11,43,1,"post")
later=observe(11,44,3,"post")
assert load(early/"summary.json")["train_provenance"]["git_sha"]==producer
for case in ("mixed","single","unknown"):
    target=out/"cohorts"/case
    target.mkdir()
    if case=="mixed":
        for dirname in ("pre","reevaluated-pre","post"):
            for path in (target.parent/dirname).glob("*/summary.json"):
                save(target/(dirname+"-"+path.parent.name)/"summary.json",load(path))
    elif case=="single":
        for path in sorted((target.parent/"post").glob("native-11-*/summary.json")):
            save(target/path.parent.name/"summary.json",load(path))
    else:
        record=load(early/"summary.json")
        record["train_provenance"]=None
        save(target/"unidentified"/"summary.json",record)
all_rows={}
for case in ("pre","reevaluated-pre","post","mixed","single","unknown"):
    row=rule(p,fixture_hyp,out/"cohorts"/case,out/"reports"/case)
    facts=overview(row)
    assert facts["anchor"]==anchor
    if case in ("post","mixed"):
        assert facts["verdict"] in ("refuted","supported","inconclusive") and facts["units"]=={"tropical":5}
        assert facts["excluded"]==({"pre_registration":2} if case=="mixed" else {})
    elif case=="single":
        assert facts["reason"]=="insufficient_seeds"
    elif case=="unknown":
        assert facts["excluded"]=={"missing_training_lineage":1}
    else:
        assert facts["excluded"]=={"pre_registration":1}
    all_rows[case]=facts
future=load(early/"traces.json")
future["checkpoint_series"].append(load(later/"traces.json")["checkpoint_series"][-1])
save(out/"future.json",future)
bad=cli(consumer,"routes","--from-store",out/"future.json","--out",out/"refused-future",require=False)
assert bad.returncode!=0 and "checkpoint" in (bad.stdout+bad.stderr).lower()
(out/"future-weight-refusal.log").write_text(bad.stdout+bad.stderr)
assert sha(registry)==registry_sha
save(out/"result.json",dict(registered=anchor,producer=producer,old=published,
     rows=all_rows,threshold=0.10,minimum=5,old_training_seed=41,post_training_seeds=seeds,
     saved_steps=[1,3,5],future_weight_refusal=bad.returncode))
print(json.dumps(load(out/"result.json"),sort_keys=True),flush=True)
