# Surreal initialization and weight-normalization audit

Use this as a bounded model experiment. The June comparison motivates
the treatment selection and supplies no observations for the new estimate.
The hypothesis is that the log-gain coordinate in the current repository
projection lowers in-range validation NLL by at least 0.10 nats over an
ordinary learnable linear gain at matched effective initialization. A smaller
improvement falls below the declared worthwhile margin. Differences outside
this setup remain open.

Use the repository fully shuffled hierarchical placebo generator. Treat each
ASCII space-separated token as one unit of the 120-token public generator
alphabet. Remove the two task header tokens. Keep the first 49 body tokens
of documents long enough and check exact prefix disjointness across splits.
Score all 48 next-token predictions, including those from deeper-tree
documents as a separate stress metric. The primary split is validation at
the training depth. This neutral language-modeling setup does not use the
old tokenizer, model width, training optimizer or held-out depth as its
primary endpoint. It tests gain coordinates and initialization, not an
asymptotic claim or the separate valuation-distance architecture.

The standard-only sizing run uses corpus 90210 and model seeds 91, 92 and
93 at 64, 192 and 384 steps. Pick the earliest rung where all three standard
models beat the add-one-smoothed training unigram prediction by 0.02 nats on
the validation split. Stop without a comparison if none qualifies. Require
the same floor on every standard seed in the actual comparison before
assigning an effect-size disposition. This historical-placement-independent
rule is the only rung and stop rule.

Use eight fresh paired model seeds 300 through 307 and corpus 64019.
Run five arms at the selected step with width 64, two layers, two heads,
FP32 CPU, batch eight and fixed AdamW (0.004, betas 0.8/0.95, zero weight
decay). Share batch order, nonprojection weights and the causal SDPA
implementation. Compare:

- Stock dense initialization including a zero attention output projection.
- Stock dense attention with only the output initialized as in the proxy.
- Dense projections initialized to the proxy's effective matrices.
- Those same matrices represented as linear row gain times normalized
  direction, using the same raw direction tensors as the proxy.
- Those same matrices represented by the repository's exponential gain.

Compare initialized projection outputs on fixed probes and require rejection
of a planted 25% gain mismatch. Check the uniform predictor against the log
vocabulary loss. The historical reference used independent model
initializations. Here the shared initialization isolates the projection
choices. Apply the repository layer in otherwise identical standard
attention to avoid diagnostic overhead confounding the training-time
contrast. Record parameter counts, measured CPU and elapsed training time,
and token budgets, which are the same within the comparison. This is a
fixed-recipe contrast. No claim about optimally tuned methods or compute
scaling follows.

Use a two-sided 95% paired Student interval for the primary mean difference
(log gain minus linear gain). Exclude a worthwhile reduction when the
lower endpoint exceeds -0.10. Establish it only when the upper endpoint
is below -0.10. Otherwise the result is inconclusive. At eight pairs, the
planning SD of 0.07 gives an expected half-width of about 0.059; the test is
sized to distinguish a true null or a -0.20-nat effect from that threshold
under the planning assumption. Report measured variability. All additional
contrasts are descriptive. No seed extension or re-tuning.

This is a quarantined sizing result. The previous registered prediction
and its current eligibility do not change. All hypotheses left outside
the comparison retain their prior epistemic status.
