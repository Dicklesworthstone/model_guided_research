"""Apply the independent catalogue check and recount all acquisition costs."""

import json
import sys
from collections import Counter
from pathlib import Path

from check_replay import follow, independently_named, load, verify_exhaustion, without_timings


def audit(cohort, library, prior, prior_floor, results):
    cases = [load(Path(cohort) / f"{i:02}.json") for i in range(24)]
    old = load(prior)
    old_names = load(prior_floor)
    runs = [load(path) for path in results]
    first = runs[0]
    if without_timings(first) != without_timings(runs[1]):
        raise ValueError("Arm order or hash seed changed the result")
    for panel in ("matching", "controls"):
        arms = first[panel]["arms"]
        if arms["scalar"] != arms["indexed"]:
            raise ValueError("Exact comparison changed under batching")
    selected = first["matching"]["arms"]["indexed"]
    if selected["stats"] != old["enumeration"] or not first["ambiguous_refused"]:
        raise ValueError("Catalogue counts changed or the ambiguity control escaped")
    rows = []
    for i, case in enumerate(cases):
        observed = selected["actions"][str(i)]
        catalogue = dict(witnesses=selected["witnesses"][str(i)], distinct_named_actions=len(observed),
                         action=observed[0] if len(observed) == 1 else None)
        previous = old["results"][i]["catalogue"]
        if any(catalogue[k] != previous[k] for k in catalogue):
            raise ValueError("Historical catalogue data changed")
        rows.append(dict(index=i, order=case["label_count"], catalogue=catalogue))
    checked_pairs = verify_exhaustion(load(library)[2], cases, rows)
    totals = {name: Counter() for name in ("scalar", "indexed", "square")}
    answer_count = 0
    for i, (case, row, history) in enumerate(zip(cases, first["cases"], old_names, strict=True)):
        root, edges = independently_named(case)
        expected = [root, edges]
        if (row["index"], row["order"]) != (i, len(edges)):
            raise ValueError("Wrong case denominator")
        for arm, counts in totals.items():
            observed = row[arm]
            historical = history["square" if arm == "square" else "catalogue"]
            if observed["action"] != expected or observed["paid"] != historical["paid"]:
                raise ValueError(f"A recovered action or its tape changed in {arm}")
            for word, label in observed["paid"]:
                if label != follow(expected, word):
                    raise ValueError("Wrong oracle reply")
                counts.update(calls=1, symbols=len(word))
            counts["edges"] += 2 * len(edges)
            if arm != "square":
                for split, answers in observed["answers"].items():
                    targets = [follow(expected, word) for word, _, _ in case[split]]
                    if answers != targets or observed["structures"] != 1:
                        raise ValueError("Incorrect held-out answers or unresolved structure")
                    answer_count += len(answers)
    timing = []
    ratios = []
    for sample in runs:
        matching = sample["matching"]["cpu_ns"]
        naming = {arm: sum(row[arm]["cpu_ns"] for row in sample["cases"]) for arm in totals}
        ratio = matching["scalar"] / matching["indexed"]
        ratios.append(ratio)
        timing.append(dict(common_cpu_ns=sample["common_cpu_ns"], matching_cpu_ns=matching, naming_cpu_ns=naming,
                           control_cpu_ns=sample["controls"]["cpu_ns"], ratio=ratio))
    control_pairs = first["controls"]["arms"]["indexed"]["witnesses"]
    if control_pairs["-1"] or control_pairs["-2"] or len(first["control_pairs"]) != 6:
        raise ValueError("Missing controls or an invalid control was retained")
    print(json.dumps(dict(
        timing=timing, threshold=8, gate=all(value >= 8 for value in ratios), totals=totals,
        compatible_pairs=checked_pairs, paired_cases=len(cases), heldout_answers=answer_count, controls=len(control_pairs),
    ), sort_keys=True))


if __name__ == "__main__":
    audit(*sys.argv[1:5], results=sys.argv[5:])
