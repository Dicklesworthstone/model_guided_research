"""Compare exact all-distinct catalogue construction in three live arms."""

import argparse
import json
import resource
import subprocess
from collections import deque
from pathlib import Path
from time import monotonic_ns, process_time_ns

from anchor_study import filtered_index
from catalogue_study import canonical

ORDERS = (32, 64, 128)


def read_json(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        raise ValueError(f"Invalid JSON input {path}") from error


def frattini_cosets(table):
    n = len(table)
    squares = sorted({table[x][x] for x in range(n)})
    square_group = {0}
    queue = deque([0])
    while queue:
        row = table[queue.popleft()]
        for square in squares:
            target = row[square]
            if target not in square_group:
                square_group.add(target)
                queue.append(target)
    if 4 * len(square_group) != n:
        raise ValueError("Square subgroup does not have index four")
    cosets = [-1] * n
    index = 0
    for i in range(n):
        if cosets[i] == -1:
            for j in square_group:
                cosets[table[i][j]] = index
            index += 1
    if index != 4:
        raise ValueError("Square cosets do not partition the group")
    return cosets


def early(n, groups):
    shapes, calls = filtered_index(n, [(False, table) for table in groups.values()], "0123")
    return shapes, calls, {}


def frattini(n, groups):
    shapes = set()
    calls = 0
    for table in groups.values():
        cosets = frattini_cosets(table)
        square = [table[x][x] for x in range(n)]
        possible = [x for x in range(n) if cosets[x]]
        for a in possible:
            for b in possible:
                if cosets[a] == cosets[b] or square[a] == square[b]:
                    continue
                calls += 1
                shape = canonical(table, a, b)
                if len(shape) != n:
                    raise ValueError("Frattini test accepted a nongenerating pair")
                shapes.add(shape)
    return sorted(shapes), calls, {}


def child_cpu_ns():
    usage = resource.getrusage(resource.RUSAGE_CHILDREN)
    return round(1e9 * (usage.ru_utime + usage.ru_stime))


def orbit(n, groups, gap, packages):
    gap_wall = monotonic_ns()
    gap_cpu = child_cpu_ns()
    result = subprocess.run(
        [str(gap), "-q", "-b", "-A", "-r", "--quitonbreak", "--packagedirs", str(packages),
         "-c", f"MgrOrbitOrder := {n};;", "orbit-export.g"],
        cwd=Path(__file__).resolve().parent, capture_output=True, check=True, text=True, timeout=60,
    )
    gap_cpu_ns = child_cpu_ns() - gap_cpu
    gap_wall_ns = monotonic_ns() - gap_wall
    try:
        raw = json.loads(result.stdout)
    except ValueError as error:
        raise ValueError("GAP orbit export is not JSON") from error
    if raw[:4] != ["4.16.1", "1.7.0", "1.13.0", n] or [row[0] for row in raw[4]] != list(groups):
        raise ValueError("Orbit provider used the wrong group inventory or versions")
    shapes = []
    for identifier, _, _, _, pairs in raw[4]:
        table = groups[identifier]
        for a, b, _ in pairs:
            shape = canonical(table, a, b)
            if len(shape) != n:
                raise ValueError("Orbit representative does not generate its group")
            shapes.append(shape)
    return sorted(shapes), len(shapes), {
        "provider": raw,
        "gap_cpu_ns": gap_cpu_ns,
        "gap_wall_ns": gap_wall_ns,
    }


def measure(builder, *args):
    start = monotonic_ns()
    local, child = process_time_ns(), child_cpu_ns()
    shapes, calls, extra = builder(*args)
    cpu = process_time_ns() - local + child_cpu_ns() - child
    wall = monotonic_ns() - start
    return {
        "calls": calls, "cpu_ns": cpu, "wall_ns": wall, **extra,
        "shapes": [bytes(dest for step in shape for dest in step).hex() for shape in shapes],
    }


def run_order(n, groups, gap, packages, *, reverse):
    builders = (
        ("early", early, (n, groups)),
        ("frattini", frattini, (n, groups)),
        ("orbit", orbit, (n, groups, gap, packages)),
    )
    results = {
        name: measure(builder, *args)
        for name, builder, args in (reversed(builders) if reverse else builders)
    }
    return {"order": n, "groups": len(groups), "arms": results}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("tables", type=Path)
    parser.add_argument("gap", type=Path)
    parser.add_argument("packages", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--reverse", action="store_true")
    args = parser.parse_args()
    raw = read_json(args.tables)
    if raw[:2] != ["4.16.1", "1.7.0"]:
        raise ValueError("Unexpected input group library")
    rows = []
    for n in ORDERS:
        groups = {i: table for size, i, rank, abelian, table in raw[3] if size == n and rank == 2 and not abelian}
        rows.append(run_order(n, groups, args.gap, args.packages, reverse=args.reverse))
        print(n, *(rows[-1]["arms"][arm]["calls"] for arm in ("early", "frattini", "orbit")), flush=True)
    with args.output.open("x", encoding="utf-8") as handle:
        json.dump({"orders": rows}, handle, sort_keys=True)
        handle.write("\n")


if __name__ == "__main__":
    main()
