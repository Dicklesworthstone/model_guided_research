import json
import random
import sys
from collections import defaultdict
from functools import cache
from pathlib import Path

import posterior as post
import probes
from address_fixtures import DIM, POOLS, encode, sha_json

SEEDS = (27111, 27112, 27113)
ARMS = ("noiseless", "repeat_check", "balance", "answer")
BUDGET = 5
CASES = 12
FLIPS = tuple(range(6))  # Zero means every reply is truthful.


def fresh():
    for seed in SEEDS:
        for salt, family in enumerate(probes.FAMILIES):
            rng = random.Random(seed + 78119 + 4999 * salt)
            for index in range(CASES):
                leaves = post.generate_leaves(rng, family)
                nodes = sorted({path[:i] for path in leaves for i in range(len(path) + 1)})
                assert len(leaves) == 64 and len(nodes) == 127
                ns = tuple(rng.sample(range(DIM), DIM)), rng.randrange(1 << DIM)
                keys = dict(zip(nodes, rng.sample(POOLS[1], len(nodes)), strict=True))
                ptr = {path: encode(key, *ns) for path, key in keys.items()}
                records = {keys[path]: () if path in leaves else (ptr[path + (0,)], ptr[path + (1,)])
                           for path in rng.sample(nodes, len(nodes))}
                query = rng.choice(sorted(leaves))
                yield seed, family, index, records, ptr[()], query, keys[query], ns


def physical_probes(keys, versions, x0, p0):
    distinct = probes.partitions(keys, versions, x0, p0)
    existing = {(key, bit) for key, bit, _ in distinct}
    all_maps = (1 << len(versions)) - 1
    constants = []
    for key in sorted(keys):
        for bit in range(DIM):
            if (key, bit) not in existing:
                coded = {(((key ^ x0) >> order[bit]) & 1) ^ ((p0 >> bit) & 1) for order, _ in versions}
                if len(coded) == 1:
                    constants.append((key, bit, all_maps if coded.pop() else 0))
                    return sorted(distinct + constants)
    return distinct


def assess(labels, tests, true_index):
    complete = (1 << len(labels)) - 1
    actual = 1 << true_index
    by_label = defaultdict(int)
    for i, label in enumerate(labels):
        by_label[label] |= 1 << i
    group = [by_label[label] for label in labels]

    def certified(state):
        possible = state[0] | state[1]
        if possible:
            only = (possible & -possible).bit_length() - 1
            if not possible & ~group[only]:
                return labels[only]
        return None

    def weight(state, remaining):
        a, b = state
        return (1 + remaining) * a.bit_count() + b.bit_count()

    def step(state, matches):
        clean, spent = state
        return clean & matches, (spent & matches) | (clean & ~matches)

    def cert_weight(state, remaining):
        return 0 if certified(state) is None else weight(state, remaining)

    @cache
    def choices(state):
        result = []
        seen = set()
        for key, bit, mask in tests:
            yes = step(state, mask)
            no = step(state, mask ^ complete)
            pair = tuple(sorted((yes, no)))
            if pair not in seen and yes != no:
                seen.add(pair)
                result.append((key, bit, mask, yes, no))
        return result

    @cache
    def best_one(state):
        base = cert_weight(state, 1)
        if base:
            return base
        return max((cert_weight(yes, 0) + cert_weight(no, 0)
                    for _, _, _, yes, no in choices(state)), default=0)

    def strongest(state, depth):
        return max((weight((state[0] & masks, state[1] & masks), depth) for masks in by_label.values()), default=0)

    @cache
    def pick(method, state, budget):
        if certified(state) is not None or not (state[0] | state[1]):
            return None

        def utility(option):
            _, _, _, yes, no = option
            w_yes, w_no = weight(yes, budget - 1), weight(no, budget - 1)
            assert w_yes + w_no == weight(state, budget)
            immediate = cert_weight(yes, budget - 1) + cert_weight(no, budget - 1)
            balance = min(w_yes, w_no)
            if method == "balance":
                return (balance,)
            if budget == 1:
                return immediate, balance
            if budget == 2:
                return best_one(yes) + best_one(no), immediate, balance
            assert method == "answer"
            return immediate, strongest(yes, budget - 1) + strongest(no, budget - 1), balance

        return max(choices(state), key=utility, default=None)

    def execute(method, flip):
        trace = []

        def ask(option):
            key, bit, mask = option[:3]
            reply = bool(actual & mask)
            reply ^= (len(trace) + 1 == flip)
            trace.append([key, bit, int(reply)])
            return reply

        if method in ("noiseless", "repeat_check"):
            state = 0, complete
            spent = False
            for k in (2, 1):
                option = pick("answer", state, k)
                if option is None:
                    break
                first = ask(option)
                if method == "repeat_check" and not spent:
                    second = ask(option)
                    if first != second:
                        first = ask(option)
                        spent = True
                mask = option[2]
                state = step(state, mask if first else mask ^ complete)
        else:
            state = complete, 0
            for left in range(BUDGET, 0, -1):
                option = pick(method, state, left)
                if option is None:
                    break
                key, bit, mask, yes, no = option
                state = yes if ask(option) else no
                assert (state[0] | state[1]) & actual and not (state[0] & state[1])
        assert len(trace) <= BUDGET
        return dict(answer=certified(state), trace=trace)

    outcomes = {arm: [execute(arm, flip) for flip in FLIPS] for arm in ARMS}
    gold = labels[true_index]
    assert all(x["answer"] in (gold, None) for arm in ARMS[1:] for x in outcomes[arm])
    assert all(x["answer"] == outcomes["noiseless"][0]["answer"] for x in outcomes["repeat_check"])
    return outcomes


def planted():
    return assess([17, 93], [(7, 0, 1)], 0)


def run(output):
    rows = []
    for seed, family, index, records, root, query, target, ns in fresh():
        x0, p0, book = probes.versions(records, root, query)
        truth, = (i for i, (order, _) in enumerate(book) if order == ns[0])
        assert encode(x0, *ns) == p0 and book[truth][1] == target
        labels = [leaf for _, leaf in book]
        tests = physical_probes(records, book, x0, p0)
        decisions = assess(labels, tests, truth)
        old = probes.assess(labels, probes.partitions(records, book, x0, p0), truth, seed + index)
        assert decisions["noiseless"][0]["answer"] == old["2"]["answer_lookahead"]["answer"]
        rows.append(dict(seed=seed, family=family, index=index, target=target,
                         fixture=sha_json([records, root, query]), versions=book, base=[x0, p0], decisions=decisions))
        if index == CASES - 1:
            print(seed, family, CASES, flush=True)
    assert len(rows) == 72
    with output.open("x", encoding="utf-8") as out:
        json.dump(dict(rows=rows, toy=planted()), out, separators=(",", ":"))


if __name__ == "__main__":
    run(Path(sys.argv[1]))
