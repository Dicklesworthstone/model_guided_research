if LoadPackage("smallgrp") <> true then Error("SmallGrp unavailable"); fi;
SizeScreen([4096, 100]);;
IndexedGroup := function(order, index)
  local group, sorted, zero, orderOfElements, indices, i, table;
  group := SmallGroup(order, index);
  sorted := AsSSortedList(group);
  zero := PositionSorted(sorted, One(group));
  orderOfElements := Concatenation([zero], Filtered([1 .. order], i -> i <> zero));
  indices := ListWithIdenticalEntries(order, 0);
  for i in [1 .. order] do
    indices[orderOfElements[i]] := i - 1;
  od;
  table := List(orderOfElements, a -> List(orderOfElements,
                b -> indices[PositionSorted(sorted, sorted[a] * sorted[b])]));
  return [order, index, RankPGroup(group), IsAbelian(group), table];
end;;
OrderInventory := function(order)
  return [order, NumberSmallGroups(order), IdsOfAllSmallGroups(order, RankPGroup, 1),
          IdsOfAllSmallGroups(order, RankPGroup, 2)];
end;;
inventory := List([32, 64, 128], OrderInventory);;
Print("[\"", GAPInfo.Version, "\",\"", PackageInfo("smallgrp")[1].Version, "\",\n", inventory, ",\n[\n");
first := true;;
for row in inventory do
  for id in Concatenation(row[3], row[4]) do
    if not first then Print(",\n"); fi;
    first := false;
    Print(IndexedGroup(id[1], id[2]));
  od;
od;
Print("\n]]\n");
QUIT;
