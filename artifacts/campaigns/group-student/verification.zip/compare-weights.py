"""A complete student must match the original eager arm before using capture."""
import hashlib
import json
import sys
from pathlib import Path

import torch

eager, captured = map(Path, sys.argv[1:])
for i in ("00", "12"):
    for arm in ("active", "random", "short_only"):
        a, b = [json.loads((root / i / f"{arm}.json").read_bytes()) for root in (eager, captured)]
        keys = ("data_sha", "init_sha", "steps", "batch", "dense_positions", "n_params", "losses")
        assert all(a[k] == b[k] for k in keys), (i, arm, "metadata")
        first, other = [root / i / x["weights"] for root, x in ((eager, a), (captured, b))]
        one, two = [torch.load(path, map_location="cpu", weights_only=True) for path in (first, other)]
        assert list(one) == list(two)
        fingerprint = hashlib.sha256()
        for name, value in one.items():
            raw_a = value.contiguous().view(torch.uint8)
            raw_b = two[name].contiguous().view(torch.uint8)
            assert torch.equal(raw_a, raw_b), (i, arm, name, "parameter mismatch")
            fingerprint.update(name.encode())
            fingerprint.update(raw_a.numpy().tobytes())
        print(i, arm, "all 10 logged losses and all parameter bytes equal",
              fingerprint.hexdigest(), "eager/captured ms", a["cuda_ms"], b["cuda_ms"], flush=True)
