"""Lower-bound acquisition by disclosing the hidden shape after a few queries."""

import argparse
import json
from collections import defaultdict
from functools import cache
from pathlib import Path
from zipfile import ZipFile

from bench_optimal import ANCHORS, CAMPAIGN, READ_PRICE, counts, inventory, price, summary

MAX_WORK = 300_000


class Exhausted(Exception):
    pass


def walk(graph, word):
    state = 0
    for mark in word:
        state = graph[mark][state]
    return state


def anchor_state(graph):
    names = []
    signature = []
    for word in ANCHORS:
        endpoint = walk(graph, word)
        if endpoint not in names:
            names.append(endpoint)
        signature.append(names.index(endpoint))
    return tuple(signature), tuple(names)


def name_prices(graph):
    layer = {walk(graph, word) for word in ANCHORS}
    prices = dict.fromkeys(layer, READ_PRICE + 2)
    length = 2
    while layer:
        layer = {graph[mark][state] for mark in "01" for state in layer} - prices.keys()
        length += 1
        prices.update(dict.fromkeys(layer, READ_PRICE + length))
    if len(prices) != len(graph["0"]):
        raise ValueError("Reference action is not transitive")
    return prices


def partition(state, endpoints):
    replies = defaultdict(list)
    for (slot, names), endpoint in zip(state, endpoints, strict=True):
        if endpoint in names:
            replies[names.index(endpoint)].append((slot, names))
        else:
            replies[len(names)].append((slot, (*names, endpoint)))
    return tuple(tuple(rows) for rows in replies.values())


def relaxation(graphs, state, depth, upper):
    work = 0
    prices = [name_prices(graph) for graph in graphs]
    order = len(graphs[0]["0"])

    def spend():
        nonlocal work
        if work == MAX_WORK:
            raise Exhausted
        work += 1

    @cache
    def naming(rows):
        floor = after_free_reply = 0
        for slot, names in rows:
            missing = sorted(cost for endpoint, cost in prices[slot].items() if endpoint not in names)
            floor += sum(missing[:-1])
            after_free_reply += sum(missing[:-2])
        return floor, after_free_reply

    def candidates(slots):
        queue = []
        seen = set()

        def add(length, vector):
            if vector not in seen:
                spend()
                seen.add(vector)
                queue.append((length, vector))

        for word in ANCHORS:
            add(len(word), tuple(walk(graphs[slot], word) for slot in slots))
        for length, vector in queue:
            yield length, vector
            for mark in "01":
                add(length + 1, tuple(graphs[slot][mark][node] for slot, node in zip(slots, vector, strict=True)))

    @cache
    def optimum(rows, steps, ceiling):
        lower, after_free_reply = naming(rows)
        if steps == 0 or len(rows) == 1 or lower > ceiling:
            return lower
        spend()
        best = ceiling + 1
        slots = tuple(slot for slot, _ in rows)
        for length, vector in candidates(slots):
            spend()
            total = len(rows) * (READ_PRICE + length)
            if total + after_free_reply >= best:
                break
            children = partition(rows, vector)
            if len(children) == 1 and (children[0] == rows or len(children[0][0][1]) == order):
                continue
            pending = sum(naming(child)[0] for child in children)
            for child in children:
                if total + pending >= best:
                    break
                pending -= naming(child)[0]
                total += optimum(child, steps - 1, best - total - pending - 1)
            else:
                best = min(best, total)
                if best == lower:
                    break
        return best

    try:
        minimum = optimum(state, depth, upper)
    except Exhausted:
        return None, work
    if not naming(state)[0] <= minimum <= upper:
        raise ValueError("Relaxed optimum violates its lower or upper limit")
    return minimum, work


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("work", type=Path)
    parser.add_argument("--depth", type=int, choices=range(1, 7), default=2)
    args = parser.parse_args()
    with ZipFile(args.work / CAMPAIGN / "upper-budget-results.zip") as archive:
        forward = json.loads(archive.read("scored.json"))
        replay = json.loads(archive.read("replay.json"))
    verified = summary(args.work, forward, replay)
    with ZipFile(args.work / CAMPAIGN / "optimal-naming-bound.zip") as archive:
        prior = json.loads(archive.read("naming-bound.json"))
    output = {}
    for n, graphs in inventory(args.work).items():
        per_case = forward["orders"][str(n)]["cases"]
        classes = defaultdict(list)
        for slot, graph in enumerate(graphs):
            signature, names = anchor_state(graph)
            classes[signature].append((slot, names))
        branches = []
        for signature, entries in sorted(classes.items()):
            anchored = len(entries) * len(ANCHORS) * (READ_PRICE + 2)
            gbs = sum(price(counts([word for word, _ in per_case[slot]["gbs"]["tape"]])) for slot, _ in entries)
            exact = (
                sum(price(counts([word for word, _ in per_case[slot]["optimal"]["tape"]])) for slot, _ in entries)
                if "optimal" in per_case[0]
                else None
            )
            floor0, _ = relaxation(graphs, tuple(entries), 0, gbs - anchored)
            floors = [floor0]
            work = []
            for depth in range(1, args.depth + 1):
                floor, expanded = relaxation(graphs, tuple(entries), depth, gbs - anchored)
                floors.append(floor)
                work.append(expanded)
            strongest = max(floor for floor in floors if floor is not None)
            monotone = [floor for floor in floors if floor is not None]
            if monotone != sorted(monotone) or (exact is not None and not anchored + strongest <= exact <= gbs):
                raise ValueError("Inconsistent post-anchor lower bound")
            branches.append(
                {
                    "signature": signature,
                    "shapes": len(entries),
                    "gbs": gbs,
                    "exact": exact,
                    "floors": [anchored + floor if floor is not None else None for floor in floors],
                    "strongest_floor": anchored + strongest,
                    "work": work,
                }
            )
        floor = sum(branch["strongest_floor"] for branch in branches)
        old = sum(branch["floors"][0] for branch in branches)
        gbs = sum(branch["gbs"] for branch in branches)
        if old != prior[str(n)]["known_shape_minimum"] or gbs != verified["orders"][str(n)]["arms"]["gbs"]["cost"]:
            raise ValueError("Published controls differ")
        output[n] = {
            "classes": branches,
            "known_shape_floor": old,
            "strongest_floor": floor,
            "gbs": gbs,
            "savings_ceiling": gbs - floor,
        }
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
