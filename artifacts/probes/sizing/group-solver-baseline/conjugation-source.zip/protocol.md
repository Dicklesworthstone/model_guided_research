# Unseen-label conjugation on held-out actions

Bead `jqc4.2`. The earlier preflight is reserved for debugging.
It found a fitting table for the 12-state problem but exhausted the
resource limit while searching for a second one. Conjugating by a
permutation of unseen names constructed that second table directly.

## Intervention and controls

Use the frozen solver code from `a719c25` for the native baseline.
The candidate obtains its first fitting model with the same pinned solver.
When two names remain unobserved, it finds the shortest lexicographically
first word leading to an unseen name in that model. It swaps that name with
the lowest other unseen name, conjugates all transitions and the root,
and checks the two witness models before paying for the distinguishing
word. Observed endpoints are fixed by the transposition. The actual answer
can be either prediction or another name and is always charged and added
as an ordinary constraint. Use the original alternative-table check when
fewer than two names remain unobserved. A new round still obtains a valid
base model before making any prediction. Square continuation handles a
base UNKNOWN, alternative UNKNOWN, or the 65-round limit, and pays
for its fallback reads.

Compare with the current square learner and the previously frozen
visible-state explorer. All four arms know the full opaque name set
and receive the same four words of length two and their endpoints.
Charge those four. Each word counts as one reset and endpoint read.
The turns and advances table expands both symbols into their primitive
motion strings. Quaternion and torus cases are simulated unit motions.
Hardware latencies and prices are outside this panel.

## Fixed cases and budgets

| Case | States | Ordered marks | Motion units |
| --- | ---: | --- | --- |
| Square mirrors | 8 | On-spot turn, advance then turn | T, FT |
| Pentagon mirrors | 10 | On-spot turn, advance then turn | T, FT |
| Hexagon turn first | 12 | On-spot turn, advance | T, F |
| Octagon turn first | 16 | On-spot turn, advance | T, F |
| Quaternion units | 8 | Right multiply by i, right multiply by j | T, T |
| Two-axis torus | 9 | Advance in first, advance in second coordinate | F, F |
| Exhaustion control | 8 | Square mirrors relabeled | T, FT |

The ring states are position and facing. Turn reverses facing and advance
adds that facing modulo the size. The torus is the product of two
3-cycles. The ordered generators of the reused ring sizes differ from
their forward-first marks in the prior preflight. A second relabeling of
the first action is included only as the one-unit exhaustion control.
The opaque name seeds are 251181 through 251187 in this order. Rotate
execution order by starting with a different arm on each case.

Use Z3 4.15.4, one thread, seed zero, a deterministic 2,000,000 resource
limit per check, and the same 65-round limit. There is no per-check
wall timeout. DSR's deadline aborts an entire run. Log resource counts,
UNKNOWN reasons, output decisions, candidate witnesses and actual paid
tapes. Compute CPU including subprocess and witness costs. Replay with
the second Python hash seed and compare every untimed field. Require
the 1-unit control to take the exact square fallback tape. Reject an
attempt to swap an exposed name.

## Decision

The independent checker must reconstruct the full marked tables of all
seven cases and verify every paid oracle response and each SAT witness.
For every constructive query, it brute-checks shortest access to any
unseen name and the shortest disagreement between the two models.
Final UNSAT remains solver-reported.

Exclude only the resource control from the outcome totals. Report all
six ordinary cases. The candidate improves completion only if its set
of solver-completed cases strictly contains the native solver's set.
Require at least half as few alternative-table checks without losing
any completion as the separate work-count gate. The oracle-count gate
requires at least 10% fewer total charged reads than square closure and
no increase in total primitive motions. Publish each disposition and
all fallbacks, even if they disagree. The panel is fixed, small, and
synthetic. A physical end-to-end claim requires measured oracle costs.
