"""Check the exchange rule and hand-solvable order-two oracle."""

import pytest
from ordered_policy import canonical, compile_ordered, inverted, partition

from nanochat.group_acquisition import PlanningBudgetExceeded, _prepare


def test_exchange_preserves_both_reply_classes():
    before = ((0, (0,)), (1, (0,)))
    first = (1, 1)
    second = (1, 2)
    (left,) = partition(before, first).values()
    (right,) = partition(before, second).values()

    left_outcomes = partition(left, second)
    right_outcomes = partition(right, first)
    assert inverted("000", "001", left_outcomes, 2)
    assert not inverted("001", "000", right_outcomes, 2)
    assert not inverted("000", "001", partition(left, (0, 2)), 2)
    assert {canonical(child, "") for child in left_outcomes.values()} == {
        canonical(child, "") for child in right_outcomes.values()
    }


@pytest.mark.parametrize(("read_price", "minimum"), [(16, 254), (0, 30)])
def test_order_two_minimum_and_budget(read_price, minimum):
    index = _prepare([((1, 1), (0, 0)), ((1, 0), (0, 1)), ((0, 1), (1, 0))])
    plan = compile_ordered(index, read_price=read_price, max_work=300_000)
    assert plan.total_cost == minimum
    assert 0 < plan.seed_work <= plan.work
    assert compile_ordered(index, read_price=read_price, max_work=plan.work).total_cost == minimum
    with pytest.raises(PlanningBudgetExceeded):
        compile_ordered(index, read_price=read_price, max_work=plan.work - 1)
