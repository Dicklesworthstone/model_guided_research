"""Cross model reuse with temporary unseen-name rank symmetry."""

import argparse
import json
import random
import resource
import subprocess
from itertools import pairwise, permutations
from pathlib import Path
from time import monotonic_ns, process_time_ns

from active import ANCHORS, RESOURCES, BoundedModels, shortest_disagreement
from study import conjugation_learning, naming_alternative, table_for
from transport import fit_reply
from verify import witness_endpoint

from scripts.group_rewrite_probe import teach_panel_case

CASES = (
    ("pentagon-turn-first", "ring", (5,), ("T", "F"), False),
    ("hexagon-mirrors", "ring", (6,), ("T", "FT"), False),
    ("octagon-mirrors", "ring", (8,), ("T", "FT"), False),
    ("nonagon-turn-first", "ring", (9,), ("T", "F"), False),
    ("two-by-four-torus", "torus", (2, 4), ("F", "F"), False),
    ("three-by-four-torus", "torus", (3, 4), ("F", "F"), False),
    ("tetrahedron", "tetrahedron", (), ("T", "T"), False),
    ("two-by-four-exhausted", "torus", (2, 4), ("F", "F"), True),
)
ARMS = ("square", "conjugation", "reuse", "rank", "combined")


def oracle_table(kind, dimensions, primitives):
    if kind == "ring":
        return table_for("ring", dimensions[0], primitives)
    if kind == "torus":
        height, width = dimensions
        return (
            tuple((i + width) % (height * width) for i in range(height * width)),
            tuple(i - i % width + (i + 1) % width for i in range(height * width)),
        )
    if kind != "tetrahedron":
        raise ValueError(f"Unknown oracle action {kind}")
    elements = [
        p for p in permutations(range(4))
        if sum(p[i] > p[j] for i in range(4) for j in range(i + 1, 4)) % 2 == 0
    ]
    lookup = {p: i for i, p in enumerate(elements)}
    return tuple(tuple(lookup[tuple(p[i] for i in g)] for p in elements) for g in ((1, 2, 0, 3), (1, 0, 3, 2)))


class ScopeTrace(BoundedModels):
    def __init__(self, initial, names, ask, *, exhausted):
        super().__init__("z3", initial, names, ask, audit=True, low_resource=exhausted)
        self.search_trace = []

    def exchange(self, *commands):
        self.search_trace.extend(
            command for command in commands
            if command in {"(push)", "(pop)", "(check-sat)"} or command.startswith("(assert ")
        )
        return super().exchange(*commands)


def find_base(solver, rank, observations):
    unseen = sorted(set(solver.names) - set(observations.values()))
    indices = [solver.indices[name] for name in unseen] if rank and len(unseen) >= 2 else []
    if indices:
        clauses = [
            f"(assert (bvult (rank {solver.value(a)}) (rank {solver.value(b)})))"
            for a, b in pairwise(indices)
        ]
        solver.exchange("(push)", *clauses)
    try:
        status = solver.check()
        first = solver.witness() if status["status"] == "sat" else None
    finally:
        if indices:
            solver.exchange("(pop)")
    return status, first, indices


def fitting_learning(initial, names, ask, *, exhausted, reuse, rank):
    solver = ScopeTrace(initial, sorted(names), ask, exhausted=exhausted)
    observations = dict(initial)
    events = []
    cached = None
    method = None
    terminal = "query-cap"
    try:
        for _ in range(65):
            event = {}
            events.append(event)
            if cached is None:
                base, first, indices = find_base(solver, rank, observations)
                event.update(base=base, rank_order=indices)
                if base["status"] == "unknown":
                    terminal = "unknown-base"
                    break
                if first is None:
                    raise ValueError("The public oracle transcript is inconsistent")
            else:
                event["reuse"] = method
                first = cached
            event["first"] = first
            witness_endpoint(first, solver.names, observations, "00")
            # An observed response must enter the incremental solver before
            # the next real SAT or uniqueness check. Reused rounds can defer
            # sending the queued assertion, but witness checks see it now.
            named = naming_alternative(first, solver.names, observations)
            if named is not None:
                word, second, swapped = named
                event["swap"] = swapped
            else:
                alternative, second = solver.alternative_right_table(first)
                event["alternative"] = alternative
                if alternative["status"] == "unsat":
                    right = {
                        key: {label: solver.names[i] for label, i in zip(solver.names, first["R" + key], strict=True)}
                        for key in "01"
                    }
                    return right, events, "unique-right-table", solver.search_trace
                if alternative["status"] == "unknown":
                    terminal = "unknown-alternative"
                    break
                if second is None:
                    raise ValueError("Alternative SAT supplied no witness")
                word = shortest_disagreement(first, second)
            if word in observations:
                raise ValueError("Proposed an observed word")
            answer = ask(word)
            event.update(second=second, word=word, answer=answer)
            if reuse:
                cached, method = fit_reply(event, solver.names, observations)
            observations[word] = answer
            if cached is not None:
                witness_endpoint(cached, solver.names, observations, word)
            solver.commands.append(solver.assert_endpoint(word, answer))
    finally:
        solver.close()
    closure, _ = teach_panel_case(observations, set(names), ask, squares=True)
    return {mark: closure.maps["R" + mark] for mark in "01"}, events, terminal, solver.search_trace


def run_case(spec, index):
    name, kind, dimensions, primitives, exhausted = spec
    table = oracle_table(kind, dimensions, primitives)
    labels = [f"opaque{i:02d}" for i in range(len(table[0]))]
    random.Random(251431 + index).shuffle(labels)

    def endpoint(word):
        state = 0
        for letter in word:
            state = table[int(letter)][state]
        return labels[state]

    initial = {word: endpoint(word) for word in ANCHORS}
    names = set(labels)
    arms = {}
    offset = index % len(ARMS)
    for arm in ARMS[offset:] + ARMS[:offset]:
        tape = []

        def ask(word, tape=tape):
            label = endpoint(word)
            tape.append([word, label])
            return label

        start_cpu, start_wall = process_time_ns(), monotonic_ns()
        before = resource.getrusage(resource.RUSAGE_CHILDREN)
        trace = None
        if arm == "square":
            actions, _ = teach_panel_case(initial, names, ask, squares=True)
            right = {symbol: actions.maps["R" + symbol] for symbol in "01"}
            events, terminal = [], "closure"
        elif arm == "conjugation":
            right, events, terminal = conjugation_learning(initial, names, ask, exhausted=exhausted)
        else:
            right, events, terminal, trace = fitting_learning(
                initial, names, ask, exhausted=exhausted, reuse=arm in {"reuse", "combined"}, rank=arm in {"rank", "combined"}
            )
        after = resource.getrusage(resource.RUSAGE_CHILDREN)
        cpu = process_time_ns() - start_cpu + round(
            1e9 * (after.ru_utime + after.ru_stime - before.ru_utime - before.ru_stime)
        )
        arms[arm] = {
            "right": right, "paid": tape, "events": events, "terminal": terminal, "trace": trace,
            "cpu_ns": cpu, "wall_ns": monotonic_ns() - start_wall,
        }
    return {
        "case": name, "kind": kind, "dimensions": dimensions, "primitives": primitives,
        "exhausted": exhausted, "labels": labels, "initial": initial, "arms": arms,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    version = subprocess.check_output(["z3", "--version"], text=True, timeout=5).strip()
    if not version.startswith("Z3 version 4.15.4 "):
        raise ValueError(f"Unexpected Z3 version: {version}")
    cases = []
    for index, spec in enumerate(CASES):
        row = run_case(spec, index)
        print(row["case"], *(row["arms"][arm]["terminal"] for arm in ARMS[1:]), flush=True)
        cases.append(row)
    with args.output.open("x", encoding="utf-8") as handle:
        json.dump({"cases": cases, "z3": version, "rlimit": RESOURCES}, handle, sort_keys=True)
        handle.write("\n")


if __name__ == "__main__":
    main()
