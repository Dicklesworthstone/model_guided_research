"""Construct and test positive-word certificates for marked S5 actions."""
import argparse
import itertools
import json
import random
import time
from pathlib import Path

from audit_compact import check_closure, check_transport

from nanochat.diagnostics_data import _group_elements
from scripts.group_rewrite_probe import rooted_graph
from scripts.group_student_probe import (
    acquire_with_memo,
    cancelled_key,
    digest,
    distinct_words,
    graph_digest,
    graph_equations,
    identify_known_family,
    pair_key,
    save,
    walk_action,
)

PREVIOUS = Path("artifacts/probes/sizing/group-congruence")
SEED = 2026112318


def orbit_words(gens):
    identity = tuple(range(len(gens[0])))
    orbit = [identity]
    names = {identity: ""}
    for state in orbit:
        for i, generator in enumerate(gens):
            nxt = tuple(generator[k] for k in state)
            if nxt not in names:
                orbit.append(nxt)
                names[nxt] = names[state] + str(i)
    return names


def transposition(i, j):
    permutation = list(range(5))
    permutation[i], permutation[j] = j, i
    return tuple(permutation)


def relations(rank):
    alphabet = [str(i) for i in range(rank)]
    result = [(x + x, "") for x in alphabet]
    for i, left in enumerate(alphabet):
        for j, right in enumerate(alphabet[:i]):
            if i - j == 1:
                result.append((left + right + left, right + left + right))
            else:
                result.append((left + right, right + left))
    return result


def closure_proof():
    proof = []
    for rank in range(1, 5):
        top = rank - 1
        tails = ["".join(str(i) for i in range(top, low - 1, -1)) for low in range(rank + 1)]
        normal = {lead + tail for lead in [""] + [str(i) for i in range(top)] for tail in tails}
        rules = relations(rank)
        rules += [(right, left) for left, right in rules if right]
        for tail, generator in itertools.product(tails, map(str, range(rank))):
            initial = tail + generator
            frontier = [(initial, [])]
            seen = {initial}
            for word, path in frontier:
                if word in normal:
                    proof.append(dict(rank=rank, tail=tail, generator=generator, steps=path, target=word))
                    break
                for left, right in rules:
                    for pos in range(len(word) - len(left) + 1):
                        if word.startswith(left, pos):
                            dest = word[:pos] + right + word[pos + len(left):]
                            if dest not in seen:
                                seen.add(dest)
                                frontier.append((dest, path + [[pos, left, right]]))
            else:
                raise ValueError(f"Cannot close {tail} * {generator} at rank {rank}")
    return proof


def expand(word, transport):
    return "".join(transport[int(letter)] for letter in word)


def transport_candidate(generators):
    names = orbit_words(generators)
    if len(names) != 120:
        raise ValueError("Expected a generating pair of S5")
    candidate = rooted_graph("s5", generators)
    simple_names = orbit_words([transposition(i, i + 1) for i in range(4)])
    options = []
    for order in itertools.permutations(range(5)):
        if order[0] > order[-1]:
            continue
        forward = [names[transposition(i, j)] for i, j in zip(order, order[1:])]
        backward = [simple_names[tuple(order.index(g[i]) for i in order)] for g in generators]
        proposed = [(expand(a, forward), expand(b, forward)) for a, b in relations(4)]
        proposed += [(str(i), expand(word, forward)) for i, word in enumerate(backward)]
        equations = sorted({pair_key(a, b) for a, b in proposed if a != b})
        cost = sum(len(a) + len(b) for a, b in equations)
        options.append(((cost, len(equations), equations, order), forward, backward))
    (_, _, equations, order), forward, backward = min(options)
    if any(walk_action(a, candidate) != walk_action(b, candidate) for a, b in equations):
        raise ValueError("Transport failed on the candidate")
    return dict(generators=generators, point_order=order, forward=forward, backward=backward, equations=equations)


def families():
    s5 = _group_elements("s5")
    return (
        ("s5", s5, 6),
        ("c120", [(i,) for i in range(120)], 4),
        ("a5xc2", [(*p, bit) for p in _group_elements("a5") for bit in range(2)], 4),
        ("s4xc5", [(*p, i) for p in itertools.permutations(range(4)) for i in range(5)], 4),
    )


def marked_graph(family, pair):
    if family == "s5":
        return rooted_graph(family, pair)
    if family == "c120":
        return rooted_graph(family, tuple(tuple((x + g[0]) % 120 for x in range(120)) for g in pair))
    permutation_size, cyclic_size = {"a5xc2": (5, 2), "s4xc5": (4, 5)}[family]
    action = tuple(
        (*g[:-1], *(permutation_size + (i + g[-1]) % cyclic_size for i in range(cyclic_size)))
        for g in pair
    )
    return rooted_graph(family, action)


def cover(output):
    congruence, proposal = (PREVIOUS / name for name in ("coverage.json", "proposal-coverage.json"))
    c, p = (json.loads(path.read_bytes()) for path in (congruence, proposal))
    excluded = set(c["spent"]) | {x["graph_sha"] for x in c["presentations"] + p["cases"]}
    rng = random.Random(SEED)
    panel = []
    for family, elements, quota in families():
        found = 0
        for _ in range(10000):
            pair = rng.choice(elements), rng.choice(elements)
            graph = marked_graph(family, pair)
            fingerprint = graph_digest(graph)
            if len(graph) == 120 and fingerprint not in excluded:
                panel.append(dict(family=family, pair=pair, graph_sha=fingerprint))
                excluded.add(fingerprint)
                found += 1
                if found == quota:
                    break
        else:
            raise ValueError(f"Found {found} of {quota} fresh cases for {family}")
    save(output, dict(seed=SEED, producer=digest(Path(__file__)), prior=[digest(congruence), digest(proposal)], cases=panel))


def catalog_and_proofs():
    started = time.perf_counter()
    graphs = {}
    markings = {}
    elements = _group_elements("s5")
    for pair in itertools.product(elements, repeat=2):
        graph = rooted_graph("s5", pair)
        if len(graph) == len(elements):
            fingerprint = graph_digest(graph)
            if fingerprint not in graphs:
                graphs[fingerprint] = graph
                markings[fingerprint] = pair
    index_seconds = time.perf_counter() - started
    started = time.perf_counter()
    witnesses = {h: transport_candidate(pair) for h, pair in sorted(markings.items())}
    proof = closure_proof()
    proof_seconds = time.perf_counter() - started
    return dict(sorted(graphs.items())), witnesses, proof, index_seconds, proof_seconds


def certify(equations, known, equal):
    trace = []
    for left, right in equations:
        reused = (left, right) in known
        answer = known[left, right] if reused else equal(left, right)
        trace.append(dict(pair=[left, right], reused=reused, answer=answer))
        if not answer:
            return False, trace
    return True, trace


def run(coverage, output):
    manifest = json.loads(coverage.read_bytes())
    if digest(Path(__file__)) != manifest["producer"] or manifest["prior"] != [
        digest(PREVIOUS / "coverage.json"), digest(PREVIOUS / "proposal-coverage.json")
    ]:
        raise ValueError("Experiment source or earlier coverage does not match the freeze")
    catalog, witnesses, proof, index_seconds, proof_seconds = catalog_and_proofs()
    started = time.perf_counter()
    check_closure(proof)
    if len(catalog) != 57 or set(witnesses) != set(catalog):
        raise ValueError("Incomplete catalog proof coverage")
    for fingerprint, witness in witnesses.items():
        check_transport(witness, fingerprint)
    verification_seconds = time.perf_counter() - started
    cases = []
    for i, case in enumerate(manifest["cases"]):
        truth = marked_graph(case["family"], case["pair"])
        if graph_digest(truth) != case["graph_sha"]:
            raise ValueError("Manifest failed to reconstruct")
        arms = {}
        for kind in ("edge", "compact"):
            paid = []
            oracle_seconds = 0.0

            def equal(left, right):
                nonlocal oracle_seconds
                start = time.perf_counter()
                answer = walk_action(left, truth) == walk_action(right, truth)
                oracle_seconds += time.perf_counter() - start
                paid.append([left, right, answer])
                return answer

            before = time.perf_counter()
            proposal = identify_known_family(catalog, equal)
            candidate = proposal["marked_class"]
            selection = len(paid)
            known = {tuple(event["pair"]): event["answer"] for event in proposal["queries"]}
            equations = graph_equations(catalog[candidate]) if kind == "edge" else witnesses[candidate]["equations"]
            accepted, certificate = certify(equations, known, equal)
            checked = len(paid) - selection
            fallback = None if accepted else acquire_with_memo(120, equal, cancelled_key)
            table = catalog[candidate] if accepted else tuple(tuple(x) for x in fallback["edges"])
            if table != truth:
                raise ValueError("Wrong action from certificate or fallback")
            arms[kind] = dict(
                accepted=accepted, proposal=proposal, certificate=certificate, fallback=fallback,
                paid=paid, selection=selection, checked=checked, seconds=time.perf_counter() - before,
                oracle_seconds=oracle_seconds,
            )
        rng = random.Random(98270 + i)
        used = set()
        samples = [(w, walk_action(w, truth)) for n in (16, 32, 64, 128) for w in distinct_words(rng, used, 48, n)]
        cases.append(dict(index=i, **case, arms=arms, samples=samples))
    save(output, dict(
        coverage_sha256=digest(coverage), closure=proof, transports=witnesses,
        index_seconds=index_seconds, proof_seconds=proof_seconds, verification_seconds=verification_seconds, cases=cases,
    ))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("pilot", "cover", "run"))
    parser.add_argument("--coverage", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.phase == "pilot":
        pair = (transposition(0, 1), (1, 2, 3, 4, 0))
        save(args.output, dict(closure=closure_proof(), transport=transport_candidate(pair)))
    elif args.phase == "cover":
        cover(args.output)
    elif args.coverage is not None:
        run(args.coverage, args.output)
    else:
        parser.error("run requires a frozen coverage manifest")
