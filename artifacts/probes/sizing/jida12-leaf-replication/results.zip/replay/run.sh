#!/bin/bash
set -euo pipefail
export PATH="/home/ubuntu/.local/bin:$PATH"
export MGR_LEAF_TRAIN_SEED="$1"
export MGR_LEAF_SHA=fb0fe89a34cddd43285903d497e0c9b0a4e4cdb1
export MGR_LEAF_BASE=/data/ssd/tmp/mgr-leaf-replication.1ZSTXLXL
export MGR_LEAF_ROOT="$MGR_LEAF_BASE/artifacts/probes/sizing/jida12-leaf-replication/seed-$1"
export MGR_LEAF_CORPUS=/data/ssd/tmp/mgr-hier-paired.Ji7EOJkO/artifacts/probes/sizing/jida12-paired-hier
export MGR_LEAF_ANSWER=/data/ssd/tmp/mgr-paired-answer.0v90pl7G/artifacts/probes/sizing/jida12-paired-answer
export MGR_LEAF_PILOT=/data/ssd/tmp/mgr-hier-leaf.F0aTylAY/artifacts/probes/sizing/jida12-leaf-position
export DSR_REPOS_FILE="$MGR_LEAF_BASE/campaign.yaml"
export DSR_QUALITY_LOG_DIR="$MGR_LEAF_BASE/seed-$1/receipts"
export UV_PROJECT_ENVIRONMENT=/data/ssd/tmp/mgr-eval-ci.bevt3nLW/qualified-venv
export OMP_NUM_THREADS=4 MKL_NUM_THREADS=4
gate="$MGR_LEAF_BASE/seed-$1/gate"
mkdir -p "$gate"
dsr quality --tool hierarchy-leaf-replication-preflight --work-dir "$gate" --check-timeout 240
dsr quality --tool hierarchy-leaf-replication-train --work-dir "$gate" --check-timeout 1200
for name in detached joint; do
  export MGR_LEAF_RUN="$name"
  dsr quality --tool hierarchy-leaf-replication-eval --work-dir "$gate" --check-timeout 240
done
