# eval-tasks — answer-swap

- checkpoint: `/data/ssd/tmp/mgr-paired-answer.0v90pl7G/artifacts/probes/sizing/jida12-paired-answer/runs/answer-swap/checkpoints` @ step 2047
- attention_type: standard
- n_params: 819,200
- seeds: [10, 11, 12] · examples/seed: 24 · decode: ['greedy']

| task | EM in-range | EM held-out | ppl in/held | slope held-out [CI95] | curve |
|---|---|---|---|---|---|
| hier_paired | 0.014 | 0.000 | 5169.2/5334.4 | - | [curve](curve_hier_paired.png) |

- hier_paired in_range: both answers correct on 0/36 pairs (0 incomplete)
- hier_paired held_out: both answers correct on 0/36 pairs (0 incomplete)

See `summary.json` (schema mgr.evaltasks.v5) for the full output and `generations.jsonl` for per-example receipts.
