"""Plot paid checks spent on state discovery and on transitions to known states."""
import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

base = Path(sys.argv[1])
old = json.loads((base / "pilot-summary.json").read_bytes())
fresh = json.loads((base / "relator-summary.json").read_bytes())
plt.rcParams.update({"font.family": "DejaVu Sans", "axes.spines.top": False, "axes.spines.right": False,
                     "axes.spines.left": False, "axes.labelcolor": "#263344", "font.size": 10,
                     "text.color": "#162638", "xtick.color": "#263344", "ytick.color": "#263344"})
fig, axes = plt.subplots(1, 2, figsize=(11.8, 4.7), gridspec_kw={"width_ratios": [1, 1.1]})
discovery = "#067569"
revisit = "#a9becd"

def draw(axis, labels, new, old, step, ceiling):
    positions = range(len(labels))
    axis.barh(positions, new, color=discovery, height=.52, label="New states")
    axis.barh(positions, old, left=new, color=revisit, height=.52, label="Known states")
    totals = [a+b for a,b in zip(new,old,strict=True)]
    for i,n in enumerate(totals):
        axis.text(n+ceiling*.012, i, f"{n:,}", va="center", fontsize=9)
    axis.set_yticks(positions, labels)
    axis.invert_yaxis()
    axis.set_xlim(0, ceiling)
    axis.set_xticks(range(0, ceiling, step))
    axis.xaxis.set_major_formatter(FuncFormatter(lambda x, _: f"{x/1000:g}k" if x else "0"))
    axis.spines["bottom"].set_color("#8ca1af")
    axis.tick_params(axis="y", length=0, pad=7)
    axis.grid(axis="x", color="#dde6ec", linewidth=.65)
    axis.set_axisbelow(True)
    axis.set_xlabel("Paid equality checks", labelpad=10)

arms = ["breadth_first", "symbol_counts", "one_view", "seven_views"]
draw(axes[0], ["Breadth-first", "Symbol counts", "One neural view", "Seven neural views"],
     [old["breakdown"][a]["new"] for a in arms], [old["breakdown"][a]["revisit"] for a in arms],
     10000, 56000)
axes[0].set_title("Ranking changes the cost of revisits", loc="left", fontsize=12, fontweight="bold", pad=10)
arms = ["raw", "cancelled", "relator"]
draw(axes[1], ["Raw pair", "Cancellation", "Cyclic relator"], [fresh["primary"][a]["paid_new"] for a in arms],
     [fresh["primary"][a]["paid"]-fresh["primary"][a]["paid_new"] for a in arms], 50000, 225000)
axes[1].set_title("Reusing answers changes discovery", loc="left", fontsize=12, fontweight="bold", pad=10)
handles, labels = axes[0].get_legend_handles_labels()
fig.subplots_adjust(left=.15, right=.97, bottom=.24, top=.77, wspace=.43)
fig.suptitle("Where equality checks go when recovering group actions", x=.15, y=.96, ha="left", fontsize=16, fontweight="bold")
fig.text(.15,.86,"24 pretrained S5/A5 cases on the left and 12 fresh S5/A6 cases on the right.", fontsize=10, color="#456075")
fig.legend(handles, labels, loc="lower left", bbox_to_anchor=(.14,.025), frameon=False, ncol=2, handlelength=1.3)
fig.savefig(sys.argv[2], dpi=180, facecolor="white")
