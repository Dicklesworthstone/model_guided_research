from common import *
from collections import Counter

inp=root/"inputs"
out=root/"runs"/"retained"
out.mkdir(parents=True,exist_ok=True)
history=root/"retained-history"
obs=inp/"observations"
observed={}
for directory in sorted(obs.iterdir()):
    train,analysis,step=map(int,directory.name.split("-")[1:])
    c=inp/f"training/baseline/nanochat/cpu-{train}/checkpoints"
    stored=load(directory/"traces.json")
    original=load(directory/"summary.json")
    assert original["meta"]["weights_sha256"]==sha(c/f"model_{step:06d}.pt")
    assert original["meta"]["initial_weights_sha256"]==sha(c/"initial/model_000000.pt")
    assert sorted(x.name for x in c.glob("model_*.pt"))==["model_000001.pt","model_000003.pt","model_000005.pt"]
    assert stored["checkpoint_series"][-1]["traces"]==stored["traces"]
    scored=sum(t["scored_draws"] for t in stored["traces"])
    survived=sum(t["surviving_draws"] for t in stored["traces"])
    st=original["results"]["stability"]
    assert (scored,survived)==(st["perturbation_draws_scored"],st["perturbation_draws_survived"])
    for suffix in ("json","parquet"):
        target=out/"replay"/directory.name/suffix
        cli(consumer,"routes","--from-store",directory/f"traces.{suffix}","--out",target)
        assert all(sha(target/name)==sha(directory/name) for name in ("report.md","summary.json"))
    measured=out/"direct"/directory.name
    cli(consumer,"routes","--checkpoint",c,"--step",step,"--task","hier","--sample","8",
        "--seed",analysis,"--device","cpu","--no-region-count","--out",measured)
    fresh=load(measured/"traces.json")
    assert fresh["traces"]==stored["traces"] and fresh["checkpoint_series"]==stored["checkpoint_series"],directory.name
    assert load(measured/"summary.json")["results"]==original["results"]
    observed[directory.name]=dict(survived=survived,scored=scored,source_sha256=sha(directory/"summary.json"),
            weights=original["meta"]["weights_sha256"],curve=[v["step"] for v in stored["checkpoint_series"]])
    print("retained raw replay/direct",directory.name,survived,scored,flush=True)
assert len(observed)==7
published_row=overview(rule(consumer,route_hyp,obs,out/"reports"/"published-only"))
restored_row=overview(rule(history,route_hyp,obs,out/"reports"/"supplemental-history"))
assert published_row["excluded"]=={"unknown_revision":7} and restored_row["units"]=={"tropical":5}
controls={}
for case in ("constant","shuffled","signal","swapped","future-series"):
    target=out/"controls"/case
    proc=cli(consumer,"routes","--from-store",inp/"trace-controls"/f"{case}.json","--out",target, require=False)
    if case=="future-series":
        assert proc.returncode and "checkpoint" in (proc.stdout+proc.stderr).lower()
        (out/"future.log").write_text(proc.stdout+proc.stderr)
        controls[case]=proc.returncode
    else:
        assert proc.returncode==0,(proc.stdout,proc.stderr)
        results=load(target/"summary.json")["results"]
        ari=results["clustering"]["ari_trace"]
        rho=results["stability"]["spearman_margin_vs_stability"]
        assert (ari==0 if case=="constant" else ari<=0 if case=="shuffled" else ari==1)
        assert abs(rho-(-1 if case=="swapped" else 1))<1e-12
        controls[case]=dict(ARI=ari,rho=rho)
regions={}
for case,reason in (("generated",None),("native-mixed","checkpoint_curve_requires_separate_cohort"),
                    ("missing-arm-proof","region_bound_or_oracle_failure"),("missing-curve-row","region_bound_or_oracle_failure")):
    row=overview(rule(history,"hyp-tropical-structured-support-beats-dense",inp/"region-cohorts"/case,out/"regions"/case))
    if reason:
        assert row["excluded"]=={reason:5},(case,row)
    else:
        assert row["verdict"] in ("supported","refuted","inconclusive") and row["units"]=={"tropical":5}
    regions[case]=row
chrono={}
for case in sorted((inp/"chrono-cohorts").iterdir()):
    row=overview(rule(root/"chronology","hyp-verifier-dyck",case,out/"chronology"/case.name))
    if case.name in ("qualified","same-frozen-source"):
        assert row["verdict"]=="supported" and row["units"]=={"tropical":3}
    else:
        assert row["verdict"]=="blocked" and (len(row["excluded"]) or row["reason"]=="insufficient_seeds")
    chrono[case.name]=row
result=dict(observations=observed,frozen_checkout_alone=published_row,
            with_producer_history=restored_row,route_controls=controls,regions=regions,planted_chronology=chrono)
save(out/"result.json",result)
print(json.dumps(result,sort_keys=True),flush=True)
