"""Recount word-level copy operations and probe a fixed sample of the training corpus."""
from collections import Counter, defaultdict
from hashlib import sha256
import json
from pathlib import Path
import random
import sys

import pyarrow.parquet as pq
import torch
from cli import _eval_score_doc, _load_eval_checkpoint
from nanochat.diagnostics_data import TASKS
from nanochat.tokenizer import checkpoint_tokenizer


def describe(rows):
    positions = defaultdict(Counter)
    prefixes = Counter()
    lengths = Counter()
    operations = defaultdict(Counter)
    for row in rows:
        target = row["expected"].split()
        got = row["got"].split()
        prefix = 0
        for i, word in enumerate(target):
            correct = i < len(got) and got[i] == word
            positions[i + 1]["correct"] += int(correct)
            positions[i + 1]["words"] += 1
            if prefix == i and correct:
                prefix += 1
        exact = prefix == len(target)
        assert exact == row["correct"]
        prefixes[prefix] += 1
        lengths["short" if len(got) < len(target) else "long" if len(got) > len(target) else "equal"] += 1
        operations[row["operation"]]["exact"] += int(exact)
        operations[row["operation"]]["cases"] += 1
    return dict(cases=len(rows), positions=dict(positions), correct_prefix_histogram=dict(prefixes),
                output_word_count=dict(lengths), operations=dict(operations),
                word_matches=sum(v["correct"] for v in positions.values()),
                target_words=sum(v["words"] for v in positions.values()))


def operation(doc):
    op = doc.split()[3]
    assert op in ("COPY", "REV") or op.startswith("ROT")
    return "ROT" if op.startswith("ROT") else op


root, out = map(Path, sys.argv[1:3])
out.mkdir(parents=True, exist_ok=True)
spec = TASKS["copyops"]
evaluation = {}
for seed in (0, 1, 2):
    splits = spec.generate(480, seed, spec.resolve_dials(None))
    for portion, region in (("train", "in_range"), ("test", "held_out")):
        for i, doc in enumerate(splits[portion][:48]):
            evaluation[(region, seed, i)] = doc
evaluation_docs = set(evaluation.values())
shards = sorted((root / "data/copyops").glob("train_*.parquet"))
assert shards
all_training = set()
for shard in shards:
    all_training.update(pq.read_table(shard, columns=["text"]).column("text").to_pylist())
samples = random.Random(20261123).sample(sorted(all_training - evaluation_docs), 144)
overlap = Counter(region for (region, _, _), doc in evaluation.items() if doc in all_training)
rows = []
device = torch.device("cpu")
for seed in range(3):
    folder = root / f"evals/tasks/eval-b0-copyops-standard-s{seed}"
    meta = json.loads((folder / "summary.json").read_bytes())["meta"]
    groups = defaultdict(list)
    in_range_novel = []
    for line in (folder / "generations.jsonl").read_bytes().splitlines():
        r = json.loads(line)
        if r["mode"] != "greedy":
            continue
        doc = evaluation[r["region"], r["eval_seed"], r["doc_index"]]
        assert spec.split_prompt(doc)[1] == r["expected"]
        observation = {**r, "operation": operation(doc)}
        groups[r["region"]].append(observation)
        if r["region"] == "in_range" and doc not in all_training:
            in_range_novel.append(observation)
    checkpoint = root / f"runs/budget_0/copyops/standard/seed_{seed}/checkpoints"
    model, ckpt, step = _load_eval_checkpoint(checkpoint, meta["checkpoint"]["step"], device)
    tok = checkpoint_tokenizer(checkpoint, ckpt)
    with torch.inference_mode():
        for i, doc in enumerate(samples):
            scored = _eval_score_doc(model, tok, spec, doc, device=device, temperature=0.0, seed=0)
            assert scored is not None
            correct, expected, got = scored
            groups["training_corpus"].append(dict(doc_index=i, expected=expected, got=got, correct=correct,
                                                  operation=operation(doc)))
    assert all(len(items) == 144 for items in groups.values()) and len(groups) == 3
    (out / f"training-seed-{seed}.json").write_text(json.dumps(groups["training_corpus"], indent=2) + "\n")
    rows.append(dict(training_seed=seed, step=step, splits={region: describe(items) for region, items in groups.items()},
                     in_range_absent_from_training=describe(in_range_novel)))
(out / "word-results.json").write_text(json.dumps(dict(scorecard=root.name, training_documents_unique=len(all_training),
    training_sample_sha256=sha256("\n".join(samples).encode()).hexdigest(),
    evaluation_examples_present_in_training={key:overlap[key] for key in ("in_range","held_out")}, rows=rows), indent=2) + "\n")
