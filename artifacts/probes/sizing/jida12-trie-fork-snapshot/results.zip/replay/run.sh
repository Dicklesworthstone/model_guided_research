#!/bin/bash
set -euo pipefail
export PATH="/home/ubuntu/.local/bin:$PATH"
export MGR_FORK=/data/ssd/tmp/mgr-trie-fork.H9Kib9vr MGR_FORK_SHA="$1"
export DSR_REPOS_FILE="$MGR_FORK/campaign.yaml" DSR_QUALITY_LOG_DIR="$MGR_FORK/receipts"
export UV_PROJECT_ENVIRONMENT=/data/ssd/tmp/mgr-eval-ci.bevt3nLW/qualified-venv
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
mkdir -p "$MGR_FORK/gate"
dsr quality --tool hierarchy-trie-fork-snapshot --work-dir "$MGR_FORK/gate" --check-timeout 360
