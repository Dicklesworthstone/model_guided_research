# mgr certify

- run_id: `20261123_014551` · seed: 42 · device: cuda · dtype: fp32
- git: `bc470ab`
- result: **67 passed / 0 failed / 5 errored** in 74.7s

| Mechanism | Check | Family | Status | Measured | Tolerance | ms |
|---|---|---|---|---:|---:|---:|
| standard | causality_no_future_grad | causality | pass | 0.000e+00 | <= 1.000e-12 | 6846.0 |
| tropical | causality_no_future_grad | causality | pass | 0.000e+00 | <= 1.000e-12 | 2839.1 |
| ultrametric | causality_no_future_grad | causality | pass | 0.000e+00 | <= 1.000e-12 | 1156.6 |
| simplicial | causality_no_future_grad | causality | pass | 0.000e+00 | <= 1.000e-12 | 368.1 |
| quaternion | causality_no_future_grad | causality | pass | 0.000e+00 | <= 1.000e-12 | 733.4 |
| braid | causality_no_future_grad | causality | pass | 0.000e+00 | <= 1.000e-12 | 296.2 |
| fractal | causality_no_future_grad | causality | pass | 0.000e+00 | <= 1.000e-12 | 76.3 |
| octonion | causality_no_future_grad | causality | pass | 0.000e+00 | <= 1.000e-12 | 366.9 |
| surreal | causality_no_future_grad | causality | pass | 0.000e+00 | <= 1.000e-12 | 468.4 |
| reversible | causality_no_future_grad | causality | pass | 0.000e+00 | <= 1.000e-12 | 17724.7 |
| gauge | causality_no_future_grad | causality | pass | 0.000e+00 | <= 1.000e-12 | 77.3 |
| clifford | causality_no_future_grad | causality | error | nan | <= 1.000e-12 | 48.5 |
| hyperbolic | causality_no_future_grad | causality | pass | 0.000e+00 | <= 1.000e-12 | 11780.6 |
| standard | rope_pairwise_norm_preservation | classical | pass | 2.384e-07 | <= 1.000e-05 | 13.3 |
| standard | causal_mask_structure | classical | pass | 0.000e+00 | <= 0.000e+00 | 3.6 |
| standard | rmsnorm_unit_rms | classical | pass | 1.788e-07 | <= 1.000e-03 | 3.2 |
| standard | softmax_row_stochastic | classical | pass | 1.192e-07 | <= 1.000e-06 | 2.7 |
| tropical | lipschitz_1_sup_norm_q | classical | pass | 9.903e-01 | <= 1.000e+00 | 51.8 |
| tropical | lipschitz_1_sup_norm_v | classical | pass | 9.719e-01 | <= 1.000e+00 | 26.9 |
| tropical | score_center_pure_gauge_shift | classical | pass | 9.537e-07 | <= 1.000e-05 | 4.7 |
| tropical | margin_matches_bruteforce | classical | pass | 0.000e+00 | <= 1.000e-06 | 173.2 |
| tropical | maslov_endpoint_within_sandwich | reduction | pass | 1.666e-01 | <= 1.000e+00 | 95.1 |
| tropical | ffn_lipschitz_1_sup_norm | classical | pass | 9.528e-01 | <= 1.000e+00 | 9.1 |
| tropical | ffn_collapse_single_layer | classical | pass | 2.220e-16 | <= 1.000e-09 | 18.4 |
| quaternion | qmul_associativity | classical | pass | 3.553e-15 | <= 1.000e-10 | 13.9 |
| quaternion | qmul_norm_multiplicative | classical | pass | 1.776e-15 | <= 1.000e-10 | 7.5 |
| quaternion | qconj_antihomomorphism | classical | pass | 8.882e-16 | <= 1.000e-10 | 3.5 |
| quaternion | rotor_norm_preservation | classical | pass | 8.882e-16 | <= 1.000e-10 | 3.1 |
| clifford | cgp_associativity | classical | error | nan | <= 1.000e-10 | 5.4 |
| clifford | reversion_antihomomorphism | classical | error | nan | <= 1.000e-10 | 3.1 |
| clifford | rotor_norm_preservation | classical | error | nan | <= 1.000e-09 | 5.5 |
| clifford | quaternion_subalgebra_reduction | reduction | error | nan | <= 1.000e-10 | 4.3 |
| hyperbolic | lorentz_constraint_residual | classical | pass | 4.172e-06 | <= 2.000e-05 | 4.0 |
| hyperbolic | exp_log_origin_roundtrip | classical | pass | 2.980e-08 | <= 2.000e-05 | 53.7 |
| hyperbolic | energy_gromov_reduces_to_standard | reduction | pass | 1.788e-05 | <= 2.000e-05 | 41.9 |
| octonion | omul_norm_multiplicative | classical | pass | 5.329e-15 | <= 1.000e-09 | 7.8 |
| octonion | omul_alternativity | classical | pass | 1.421e-14 | <= 1.000e-09 | 248.1 |
| octonion | omul_nonassociativity_witness | classical | pass | 5.920e+01 | >= 1.000e-02 | 19.4 |
| octonion | o_times_conj_is_norm_squared | classical | pass | 7.105e-15 | <= 1.000e-09 | 8.2 |
| octonion | reduces_to_quaternion_on_subalgebra | reduction | pass | 0.000e+00 | <= 1.000e-09 | 5.7 |
| reversible | forward_inverse_roundtrip | classical | pass | 1.192e-07 | <= 1.000e-05 | 14.7 |
| reversible | custom_autograd_grad_parity | classical | pass | 4.064e-07 | <= 1.000e-04 | 50.4 |
| reversible | symplectic_jacobian | classical | pass | 6.661e-16 | <= 1.000e-09 | 4322.8 |
| reversible | energy_drift_separation | classical | pass | 1.054e-07 | <= 2.000e-01 | 5703.4 |
| gauge | rotation_inverse_roundtrip | classical | pass | 2.384e-07 | <= 1.000e-05 | 24.7 |
| gauge | rotation_pairwise_norm_preservation | classical | pass | 2.384e-07 | <= 1.000e-05 | 14.5 |
| gauge | rotation_additivity_cumsum_law | classical | pass | 3.576e-07 | <= 1.000e-05 | 16.2 |
| gauge | zero_transport_reduces_to_standard_attention | reduction | pass | 0.000e+00 | <= 2.000e-05 | 29.5 |
| gauge | kv_decode_matches_full_forward | classical | pass | 3.576e-07 | <= 1.000e-04 | 484.5 |
| ultrametric | strong_triangle_inequality_lcp | classical | pass | 0.000e+00 | <= 0.000e+00 | 116.2 |
| ultrametric | trie_decode_matches_hard_kernel | reduction | pass | 2.682e-07 | <= 1.000e-03 | 299.1 |
| braid | ybe_law_holds | classical | pass | 8.882e-16 | <= 1.000e-10 | 10.8 |
| braid | restricted_law_violates_ybe | classical | pass | 4.432e+00 | >= 1.000e-03 | 4.4 |
| braid | payload_multiset_invariance | classical | pass | 0.000e+00 | <= 0.000e+00 | 7.2 |
| braid | rmatrix_braid_relation_holds | classical | pass | 1.421e-14 | <= 1.000e-10 | 7.3 |
| braid | rmatrix_inversion_relation_holds | classical | pass | 1.377e-14 | <= 1.000e-10 | 0.7 |
| braid | rmatrix_transfer_matrices_commute | classical | pass | 4.997e-17 | <= 1.000e-10 | 9.7 |
| braid | rmatrix_perturbed_transfer_separates | classical | pass | 3.356e-05 | >= 1.000e-06 | 3.8 |
| braid | rmatrix_mass_partition_charge_conserved | classical | pass | 1.776e-15 | <= 1.000e-05 | 32.2 |
| braid | heuristic_mass_partition_violated | classical | pass | 2.173e+00 | >= 1.000e-03 | 37.7 |
| simplicial | mass_conservation_two_hop | classical | pass | 5.960e-08 | <= 1.000e-05 | 14.2 |
| simplicial | zero_triangle_reduces_to_standard_attention | reduction | pass | 5.364e-07 | <= 2.000e-05 | 155.2 |
| simplicial | triplet_mass_conservation | classical | pass | 1.192e-07 | <= 1.000e-05 | 68.7 |
| simplicial | triplet_wedge_antisymmetry | classical | pass | 0.000e+00 | <= 1.000e-05 | 16.1 |
| fractal | router_branch_simplex | classical | pass | 1.192e-07 | <= 1.000e-06 | 7.9 |
| fractal | zero_ifs_reduces_to_prototype_attention | reduction | pass | 0.000e+00 | <= 1.000e-05 | 397.5 |
| fractal | ifs_moran_contractivity | classical | pass | 4.768e-07 | <= 1.000e-05 | 36.1 |
| surreal | row_norm_equals_exp_scale | classical | pass | 1.192e-07 | <= 1.000e-05 | 6.8 |
| surreal | layer_linearity | classical | pass | 1.550e-06 | <= 1.000e-04 | 7.9 |
| surreal | scale_shift_equivariance | classical | pass | 1.431e-06 | <= 1.000e-04 | 3.5 |
| surreal | zero_omega_reduces_to_standard_attention | reduction | pass | 7.153e-07 | <= 2.000e-05 | 22.5 |
| surreal | valuation_dominance_monotone | classical | pass | 0.000e+00 | <= 1.000e-05 | 43.8 |
