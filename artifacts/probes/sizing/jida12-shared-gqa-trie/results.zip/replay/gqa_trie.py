import hashlib
import importlib.util
import json
import os
import platform
import random
import statistics
import sys
import time
from pathlib import Path

import torch

from nanochat.engine import KVCache
from nanochat.gpt import GPT, GPTConfig
from nanochat.model_utils import repeat_kv_heads
from nanochat.ultrametric_attention_torch import UltrametricCausalSelfAttention as Incumbent


HEADS, LAYERS, WIDTH, K = 4, 2, 64, 8
GRID = ((1, 128), (1, 512), (2, 128), (2, 512), (4, 512))
SAMPLES = 7
PAYLOAD = ("_child", "_sum_v", "_count")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_candidate(path):
    spec = importlib.util.spec_from_file_location("trie_gqa_candidate", path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module.UltrametricCausalSelfAttention


def exact(a, b):
    assert a.shape == b.shape and a.dtype == b.dtype == torch.float32
    assert bool(torch.isfinite(a).all()) and bool(torch.isfinite(b).all())
    torch.testing.assert_close(a.view(torch.int32), b.view(torch.int32), rtol=0, atol=0)


def models(candidate, kv_heads, mode="trie", schedule="ultrametric", hard=True, digits=None):
    config = GPTConfig(sequence_len=640, vocab_size=128, n_layer=LAYERS, n_head=HEADS, n_kv_head=kv_heads,
                       n_embd=WIDTH, attention_type=schedule, ultrametric_mode=mode, ultrametric_hard_digits=hard,
                       ultrametric_K=K, ultrametric_digits_k=digits)
    torch.manual_seed(7740 + kv_heads)
    baseline = GPT(config).eval()
    baseline.init_weights()
    # The training initializer zeroes these weights. Set deterministic nonzero
    # projections so the logit comparison exercises every attention layer.
    baseline.lm_head.weight.normal_(std=.04)
    for block in baseline._blocks():
        block.attn.c_proj.weight.normal_(std=.055)
        block.mlp.c_proj.weight.normal_(std=.055)
    narrow = GPT(config).eval()
    for index, block in enumerate(narrow._blocks()):
        if isinstance(block.attn, Incumbent):
            block.attn = candidate(config, index).eval()
    narrow.load_state_dict(baseline.state_dict())
    return dict(incumbent=baseline, shared=narrow)


def cache(kv_heads, batch, capacity):
    return KVCache(batch_size=batch, num_heads=kv_heads, seq_len=capacity,
                   head_dim=WIDTH // HEADS, num_layers=LAYERS)


def storage(model, kv):
    dense = kv.kv_cache.untyped_storage().nbytes()
    tries = []
    for block in model._blocks():
        states = getattr(block.attn, "_trie_cache", None)
        if states is not None and kv in states:
            tries.extend(trie for row in states[kv].tries for trie in row)
    trie_bytes = sum(getattr(trie, field).untyped_storage().nbytes() for trie in tries for field in PAYLOAD)
    return dict(dense=dense, trie=trie_bytes, total=dense + trie_bytes, tries=len(tries))


def validate_states(old, new, old_cache, new_cache, kv_heads, batch):
    old_state, new_state = (model._blocks()[0].attn._trie_cache[kv] for model, kv in
                            ((old, old_cache), (new, new_cache)))
    assert old_state.seen_Tk == new_state.seen_Tk == old_cache.pos == new_cache.pos
    assert len(old_state.tries) == len(new_state.tries) == batch
    for before, after in zip(old_state.tries, new_state.tries, strict=True):
        assert len(before) == HEADS and len(after) == kv_heads
        for head, trie in enumerate(before):
            neighbor = after[head // (HEADS // kv_heads)]
            assert trie._size == neighbor._size and trie._cap == neighbor._cap
            assert all(torch.equal(getattr(trie, field), getattr(neighbor, field)) for field in PAYLOAD)


def cycle(model, kv_heads, prompt, next_tokens, *, full=False):
    n = prompt.shape[1]
    prefix = cache(kv_heads, 1, n)
    start = time.perf_counter_ns()
    prefill = [model(chunk, kv_cache=prefix) for chunk in prompt.split(64, dim=1)]
    prefill_ns = time.perf_counter_ns() - start
    prime = storage(model, prefix) if full else None
    decode = cache(kv_heads, 2, n + next_tokens.shape[1])
    start = time.perf_counter_ns()
    decode.prefill(prefix)
    fork_ns = time.perf_counter_ns() - start
    del prefix
    start = time.perf_counter_ns()
    first = model(next_tokens[:, :1], kv_cache=decode)
    first_ns = time.perf_counter_ns() - start
    start = time.perf_counter_ns()
    steady = [model(token, kv_cache=decode) for token in next_tokens[:, 1:].split(1, dim=1)]
    steady_ns = time.perf_counter_ns() - start
    times = dict(prefill=prefill_ns, fork=fork_ns, first=first_ns, steady=steady_ns)
    result = dict(prefill_storage=prime, decode_storage=storage(model, decode)) if full else None
    return times, (prefill, first, steady), result, decode


def median_ratios(samples):
    return {name: statistics.median(row["incumbent"][name] / row["shared"][name] for row in samples)
            for name in ("prefill", "fork", "first", "steady")}


def measured(candidate, kv_heads, n):
    arms = models(candidate, kv_heads)
    generator = torch.Generator().manual_seed(40500 + kv_heads + n)
    prompt = torch.randint(128, (1, n), generator=generator)
    next_tokens = torch.randint(128, (2, 9), generator=generator)
    warm = {arm: cycle(model, kv_heads, prompt, next_tokens, full=True) for arm, model in arms.items()}
    _, (old_prefill, old_first, old_steady), old_bytes, old_cache = warm["incumbent"]
    _, (new_prefill, new_first, new_steady), new_bytes, new_cache = warm["shared"]
    exact(old_first, new_first)
    for a, b in zip(old_prefill + old_steady, new_prefill + new_steady, strict=True):
        exact(a, b)
    validate_states(*arms.values(), old_cache, new_cache, kv_heads, 2)
    for key in ("prefill_storage", "decode_storage"):
        assert old_bytes[key]["dense"] == new_bytes[key]["dense"]
        assert old_bytes[key]["tries"] * kv_heads == new_bytes[key]["tries"] * HEADS
        assert old_bytes[key]["trie"] * kv_heads == new_bytes[key]["trie"] * HEADS
    output_elements = sum(t.numel() for t in old_prefill + [old_first] + old_steady)
    rng = random.Random(17110 + n + kv_heads)
    paired = []
    for _ in range(SAMPLES):
        order = rng.sample(tuple(arms), 2)
        row = {arm: cycle(arms[arm], kv_heads, prompt, next_tokens)[0] for arm in order}
        paired.append(dict(order=order, **row))
    base = old_bytes["decode_storage"]["total"]
    used = new_bytes["decode_storage"]["total"]
    return dict(kv_heads=kv_heads, context=n, incumbent=old_bytes, shared=new_bytes, paired=paired,
                speedup=median_ratios(paired), fraction_saved=1 - used / base, bitwise_logit_elements=output_elements)


def lifecycle(candidate):
    scenarios = (
        ("trie", "ultrametric", True, None),
        ("trie", "ultrametric,standard", True, 3),
        ("trie", "ultrametric", False, 3),
        ("kernel", "ultrametric", True, None),
        ("balltree", "ultrametric", True, 3),
    )
    tally = {}
    generator = torch.Generator().manual_seed(5119)
    tokens = torch.randint(128, (2, 15), generator=generator)
    for mode, schedule, hard, digits in scenarios:
        arms = models(candidate, 2, mode, schedule, hard, digits)
        measured_arms = []
        for model in arms.values():
            kv = cache(2, 2, 4)
            first = model(tokens[:, :6], kv_cache=kv)
            assert kv.kv_cache.shape[4] > 4 and kv.pos == 6
            step = model(tokens[:, 6:7], kv_cache=kv)
            chunk = model(tokens[:, 7:10], kv_cache=kv)
            last = model(tokens[:, 10:11], kv_cache=kv)
            kv.reset()
            same_len = (tokens[:, :6] + 17) % 128
            first_reset = model(same_len, kv_cache=kv)
            reset_step = model(tokens[:, 6:7], kv_cache=kv)
            assert not torch.equal(first, first_reset)
            clean = cache(2, 2, kv.kv_cache.shape[4])
            clean_prefill = model(same_len, kv_cache=clean)
            clean_step = model(tokens[:, 6:7], kv_cache=clean)
            exact(first_reset, clean_prefill)
            exact(reset_step, clean_step)
            projected = model._blocks()[0].attn.project_qkv(torch.randn(2, 3, WIDTH, generator=torch.Generator().manual_seed(3)))
            assert all(t.size(1) == HEADS for t in projected)
            measured_arms.append([first, step, chunk, last, first_reset, reset_step, *projected])
        for a, b in zip(*measured_arms, strict=True):
            exact(a, b)
        tally[str((mode, schedule, hard, digits))] = sum(t.numel() for t in measured_arms[0])
    return tally


def digit_boundaries(candidate):
    pairs = 0
    for kv_heads in (1, 2, 4):
        module = models(candidate, kv_heads)["shared"]._blocks()[0].attn
        for dtype in (torch.float32, torch.bfloat16):
            module.to(dtype=dtype)
            module.to_digits_k.weight[0].fill_(1)
            for steps in (1, 7, 63, 65, 127):
                g = torch.Generator().manual_seed(kv_heads * 300 + steps)
                k = torch.randn(2, kv_heads, steps, WIDTH // HEADS, generator=g).to(dtype)
                k[..., 1::2] = -k[..., ::2]
                expanded, _ = repeat_kv_heads(k, k, n_head=HEADS)
                full = module._digits_hard_int(module.to_digits_k(expanded))
                native = module._digits_hard_int(module.to_digits_k(k))
                expected, _ = repeat_kv_heads(native, native, n_head=HEADS)
                assert torch.equal(full, expected)
                pairs += full.numel()
    return pairs


def main(candidate_path, output):
    cpu = max(os.sched_getaffinity(0))
    os.sched_setaffinity(0, {cpu})
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    candidate = load_candidate(candidate_path)
    with torch.inference_mode():
        controls = lifecycle(candidate)
        digits = digit_boundaries(candidate)
        rows = []
        for kv_heads, n in GRID:
            row = measured(candidate, kv_heads, n)
            print(kv_heads, n, row["fraction_saved"], row["speedup"], flush=True)
            rows.append(row)
    criteria = dict(physical_gqa_saving=all(row["fraction_saved"] >= .15 for row in rows if row["kv_heads"] < HEADS),
                    mha_no_growth=rows[-1]["fraction_saved"] == 0,
                    long_fork_decode_gain=all(row["speedup"]["first"] >= 1.15 for row in rows
                                              if row["kv_heads"] < HEADS and row["context"] == 512),
                    no_large_latency_regression=all(row["speedup"][metric] >= .90 for row in rows
                                                    for metric in ("prefill", "steady")))
    report = dict(host=platform.node(), cpu=cpu, torch_version=torch.__version__, heads=HEADS, layers=LAYERS, width=WIDTH,
                  K=K, samples=SAMPLES, candidate_sha256=digest(candidate_path),
                  incumbent_sha256=digest(Path(sys.modules[Incumbent.__module__].__file__)), lifecycle=controls,
                  exact_digit_comparisons=digits, workloads=rows, criteria=criteria, advance=all(criteria.values()))
    with output.open("x") as handle:
        json.dump(report, handle, indent=2)


if __name__ == "__main__":
    main(*map(Path, sys.argv[1:]))
