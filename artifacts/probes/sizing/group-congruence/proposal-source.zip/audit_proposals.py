"""Independent permutation-level audit of proposals and fallback."""
import hashlib
import itertools
import json
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path


def pointwise(group, gens):
    identity = (0,) if group == "z60" else tuple(range(len(gens[0])))

    def advance(state, letter):
        if group == "z60":
            return ((state[0] + gens[letter][0]) % 60,)
        return tuple(gens[letter][i] for i in state)

    def evaluate(word):
        state = identity
        for letter in word:
            state = advance(state, int(letter))
        return state

    states = [identity]
    ids = {identity: 0}
    names = [""]
    edges = []
    for index, state in enumerate(states):
        row = []
        for ch in (0, 1):
            dst = advance(state, ch)
            if dst not in ids:
                ids[dst] = len(states)
                states.append(dst)
                names.append(names[index] + str(ch))
            row.append(ids[dst])
        edges.append(row)
    return edges, names, evaluate, ids


def digest(graph):
    return hashlib.sha256(json.dumps(graph).encode()).hexdigest()


def cancelled(left, right):
    left_start = 0
    for a, b in zip(left, right):
        if a != b:
            break
        left_start += 1
    left, right = left[left_start:], right[left_start:]
    right_start = 0
    for a, b in zip(reversed(left), reversed(right)):
        if a != b:
            break
        right_start += 1
    if right_start:
        left, right = left[:-right_start], right[:-right_start]
    return min((left, right), (right, left))


def replay(arm, table, graph, reps, action):
    known = 1
    used = [set(), set()]
    memo = {("", ""): True}
    count = Counter()
    rules = {}
    matcher = None
    normalized = {}

    def reduce_word(word):
        if word in normalized:
            return normalized[word]
        original = word
        steps = []
        if matcher is not None:
            while match := matcher.search(word):
                lhs = match[0]
                rhs = rules[lhs]
                steps.append([match.start(), lhs, rhs])
                newer = word[:match.start()] + rhs + word[match.end():]
                assert (len(newer), newer) < (len(word), word)
                word = newer
        assert action(word) == action(original)
        normalized[original] = (word, steps)
        return normalized[original]

    def key(a, b):
        pair = cancelled(a,b)
        if arm == "cancelled":
            return pair
        while True:
            a, b = (reduce_word(word)[0] for word in pair)
            nxt = cancelled(a,b)
            if nxt == pair:
                return pair
            pair = nxt

    input_tape = iter(table["trace"])
    for source, row in enumerate(graph):
        for digit, destination in enumerate(row):
            event = next(input_tape)
            word = reps[source] + str(digit)
            assert event["word"] == word and event["target"] == destination
            choices = set(range(known)) - used[digit]
            refs = {text: i for i, text in enumerate(reps[:known])}
            normal, proof = reduce_word(word) if arm == "congruence" else (word, [])
            trials = event["trials"]
            paid = 0
            if arm == "congruence" and normal in refs:
                assert event["normal_form"] == normal and event["substitutions"] == proof
                assert destination == refs[normal] and destination in choices and not trials
                count["rewritten"] += 1
                count["rewrite_steps"] += len(proof)
            elif known == len(graph) and len(choices) == 1:
                assert not trials and destination == next(iter(choices)) and "normal_form" not in event
                count["forced"] += 1
            else:
                assert "normal_form" not in event
                def priority(i):
                    a, b = (abs(word.count(c) - reps[i].count(c)) for c in "01")
                    return (144 * ((a % 2) + (b % 2)) + a + b, i)
                ordered = sorted(choices, key=priority)
                accept = False
                for index, (target, source_kind, answer) in enumerate(trials):
                    assert target == ordered[index] and type(answer) is bool
                    ref = reps[target]
                    pair = key(word, ref)
                    cached = memo.get(pair)
                    if arm == "congruence":
                        a,b = pair
                        if a == b:
                            cached = True
                        elif a in refs and b in refs:
                            cached = False
                    assert source_kind == ("cache" if cached is not None else "oracle")
                    assert answer is (action(word) == action(ref))
                    if cached is not None:
                        assert answer is cached
                    else:
                        memo[pair] = answer
                        paid += 1
                    count[f"{source_kind}_{'equal' if answer else 'different'}"] += 1
                    if answer:
                        assert index == len(trials)-1 and target == destination
                        accept = True
                if not accept:
                    assert len(trials) == len(ordered) and destination == known and reps[known] == word
                    known += 1
                    count["new"] += 1
                    count["paid_new"] += paid
            assert destination not in used[digit] and action(word) == action(reps[destination])
            used[digit].add(destination)
            if arm == "congruence" and word != reps[destination]:
                target = reps[destination]
                assert (len(word),word) > (len(target), target)
                rules[word] = target
                matcher = re.compile("|".join(sorted(rules, key=lambda w: (-len(w),w))))
                normalized.clear()
    assert next(input_tape, None) is None and known == len(graph)
    assert table["edges"] == graph and table["representatives"] == reps
    derived = {"paid_new", "rewrite_steps"}
    assert {k:v for k,v in count.items() if k not in derived and v} == table["counts"]
    assert table["memo_entries"] == len(memo)
    assert table["memo_symbols"] == sum(len(a)+len(b) for a,b in memo)
    if arm == "congruence":
        assert table["rule_count"] == len(rules)
        assert table["rule_symbols"] == sum(len(a)+len(b) for a,b in rules.items())
    assert 0 <= table["oracle_seconds"] <= table["seconds"]
    count["paid"] = count["oracle_equal"] + count["oracle_different"]
    return count


def build_catalog():
    perms = list(itertools.permutations(range(5)))
    graphs = {}
    for pair in itertools.product(perms, repeat=2):
        graph, reps, _, _ = pointwise("s5", pair)
        if len(graph) != 120:
            continue
        equations = sorted({
            tuple(sorted((reps[i]+str(g),reps[d])))
            for i,row in enumerate(graph) for g,d in enumerate(row) if reps[i]+str(g) != reps[d]
        })
        graphs[digest(graph)] = (graph, equations)
    return dict(sorted(graphs.items()))


def replay_family(family, catalog, action, target):
    remaining = list(catalog)

    def eval_graph(graph, word):
        i = 0
        for c in word:
            i = graph[i][int(c)]
        return i

    for question in family["queries"]:
        balances = []
        count = len(remaining)
        for a,b in catalog[remaining[0]][1]:
            pos = {
                h for h in remaining
                if eval_graph(catalog[h][0], a) == eval_graph(catalog[h][0], b)
            }
            if 0 < len(pos) < count:
                balances.append((abs(2 * len(pos)-count), (a,b), pos))
        _, best, yes = min(balances, key=lambda row: row[:2])
        assert best == tuple(question["pair"]) and len(yes) == question["predicted_yes"]
        assert question["candidates"] == count
        a,b = best
        answer = action(a) == action(b)
        assert question["answer"] is answer
        remaining = [h for h in remaining if (h in yes) is answer]
    assert remaining == [target] == [family["marked_class"]]
    assert 0 <= family["oracle_seconds"] <= family["seconds"]



def embedded(family, pair):
    if family == "s5":
        return pair
    if family == "a5xc2":
        return [g[:5] + ([6, 5] if g[5] else [5, 6]) for g in pair]
    modulus = 120 if family == "c120" else 60
    return [[(offset + (-x if reflected else x)) % modulus for x in range(modulus)]
            for offset, reflected in pair]


def verifier(certificate, equations, tried, evaluate):
    observed = [tuple(row["pair"]) for row in certificate]
    assert len(equations) == 121 and 0 < len(observed) <= len(equations)
    assert observed == equations[:len(observed)]
    assert len(observed) == len(set(observed))
    paid = 0
    for i, (row, (a, b)) in enumerate(zip(certificate, observed, strict=True)):
        reused = (a, b) in tried
        correct = evaluate(a) == evaluate(b)
        assert row["reused"] is reused and row["answer"] is correct
        if reused:
            assert tried[a, b] is correct
        paid += not reused
        assert correct or i == len(observed) - 1
    accepted = certificate[-1]["answer"]
    assert not accepted or observed == equations
    return paid, accepted


coverage, experiment, prior, source = (Path(x) for x in sys.argv[1:])
manifest = json.loads(coverage.read_bytes())
run = json.loads(experiment.read_bytes())
old = json.loads(prior.read_bytes())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert manifest["prior"] == sha(prior) and manifest["producer"] == sha(source)
assert run["coverage_sha256"] == sha(coverage)
assert manifest["seed"] == 2026112314
seen = set(old["spent"]) | {p["graph_sha"] for p in old["presentations"]}
catalog = build_catalog()
assert run["catalog"] == len(catalog) == 57
ordered_families = ["s5"] * 6 + ["c120"] * 6 + ["d60"] * 3 + ["a5xc2"] * 3
assert len(manifest["cases"]) == len(run["results"]) == len(ordered_families)
totals = defaultdict(Counter)
per_case = []
tamper = set()
for index, (case, row) in enumerate(zip(manifest["cases"], run["results"], strict=True)):
    family = case["family"]
    assert ordered_families[index] == row["family"] == family
    graph, names, evaluate, ids = pointwise("permutation", embedded(family, case["pair"]))
    h = digest(graph)
    assert len(graph) == 120 and index == row["index"]
    assert h == case["graph_sha"] == row["graph_sha"] and h not in seen
    seen.add(h)
    baseline = row["baseline"]
    assert baseline["representatives"] == names
    counts = replay("cancelled", baseline, graph, names, evaluate)
    acc = row["accelerated"]
    pick = acc["proposal"]
    proposed = pick["marked_class"]
    queries = pick["queries"]
    replay_family({**pick, "oracle_seconds": 0, "seconds": 0}, catalog, evaluate, proposed)
    tried = {tuple(q["pair"]): q["answer"] for q in queries}
    assert len(tried) == len(queries)
    table, equations = catalog[proposed]
    checks, accepted = verifier(acc["certificate"], equations, tried, evaluate)
    assert acc["accepted"] is accepted
    assert checks == acc["new_queries"]
    assert accepted is (family == "s5")
    if accepted:
        assert table == graph and row["fallback"] is None
        fallback = 0
    else:
        assert h not in catalog
        actual = row["fallback"]
        assert {k: v for k, v in actual.items() if not k.endswith("seconds")} == {
            k: v for k, v in baseline.items() if not k.endswith("seconds")
        }
        fallback = counts["paid"]
    if accepted not in tamper:
        corrupted = [dict(event) for event in acc["certificate"]]
        corrupted[-1]["answer"] = not accepted
        try:
            verifier(corrupted, equations, tried, evaluate)
        except AssertionError:
            tamper.add(accepted)
        else:
            raise AssertionError("Verifier accepted a corrupted certificate")
    words = row["samples"]
    assert Counter(len(w) for w, _ in words) == {16: 48, 32: 48, 64: 48, 128: 48}
    assert len({w for w, _ in words}) == 192
    assert all(ids[evaluate(w)] == answer for w, answer in words)
    costs = dict(cases=1, accepted=int(accepted), baseline=counts["paid"], selection=len(queries),
                 certificate=checks, fallback=fallback, paid=len(queries)+checks+fallback,
                 edges=len(graph)*2, words=len(words))
    totals[family].update(costs)
    per_case.append(dict(family=family, index=index, **costs))
assert tamper == {False, True}
s5 = totals["s5"]
savings = 1 - s5["paid"] / s5["baseline"]
out_of_family = [group for group in totals if group != "s5"]
assert sum(totals[g]["accepted"] for g in out_of_family) == 0
assert sum(totals[g]["cases"] for g in out_of_family) == 12
other = sum((totals[g] for g in out_of_family), Counter())
summary = dict(
    gate_passed=(s5["accepted"] == 6 and savings >= 0.90),
    s5_query_savings=savings, outside_overhead=other["paid"]-other["baseline"],
    outside_overhead_fraction=other["paid"]/other["baseline"]-1,
    pooled_query_savings=1-sum(row["paid"] for row in totals.values())/sum(row["baseline"] for row in totals.values()),
    covered_edges=sum(row["edges"] for row in totals.values()),
    held_out_words=sum(row["words"] for row in totals.values()),
    totals=totals, cases=per_case, catalog=run["catalog"], corrupted_certificate_probes=len(tamper),
)
print(json.dumps(summary, sort_keys=True))
