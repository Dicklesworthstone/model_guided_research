import hashlib
import importlib.util
import json
import os
import platform
import random
import statistics
import sys
import time
from pathlib import Path

import torch

from nanochat.ultrametric_attention_torch import _PackedPrefixTrie as ShippedTrie


HEADS, K, DIM = 4, 16, 16
SAMPLES, COPIES = 17, 64
GRID = tuple((radix, length) for radix in (2, 16) for length in (256, 1024, 4096))
DEVICE = torch.device("cpu")
TENSORS = ("_child", "_sum_v", "_count")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load_candidate(path):
    spec = importlib.util.spec_from_file_location("trie_index_candidate", path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module._PackedPrefixTrie


def bytes_for(tensors):
    return sum(tensor.untyped_storage().nbytes() for tensor in tensors)


def logical_bytes(tensors):
    return sum(tensor.numel() * tensor.element_size() for tensor in tensors)


def exact_states(base, new):
    assert base._size == new._size and base._cap == new._cap and base._child.dtype == torch.int32
    expected = torch.int16 if new._cap <= 32768 else torch.int32
    assert new._child.dtype == expected
    assert torch.equal(base._child, new._child.to(torch.int32))
    assert torch.equal(base._count, new._count)
    assert torch.equal(base._sum_v.view(torch.int32), new._sum_v.view(torch.int32))


def build(cls, radix, keys, values):
    trie = cls(p=radix, K=K, head_dim=DIM, device=DEVICE)
    for code, value in zip(keys, values, strict=True):
        trie.insert(code, value)
    return trie


def exact_attention(keys, values, queries, alpha):
    depth = (queries[:, None, :] == keys[None, :, :]).cumprod(-1).sum(-1)
    mass = alpha ** depth.to(torch.float64)
    result = (mass @ values.to(torch.float64)) / mass.sum(-1, keepdim=True)
    return result.to(torch.float32)


def warm_copy(source, dest):
    for loc, data in zip(dest, source, strict=True):
        loc.copy_(data)


def sample_copy(source, dest):
    start = time.perf_counter_ns()
    for _ in range(COPIES):
        warm_copy(source, dest)
    return time.perf_counter_ns() - start


def sample_query(tries, queries):
    start = time.perf_counter_ns()
    for trie, batch in zip(tries, queries, strict=True):
        for key in batch:
            trie.query(key, alpha=2.0)
    return time.perf_counter_ns() - start


def interleave(operations, rng):
    rows = []
    for _ in range(SAMPLES):
        order = rng.sample(("shipped", "narrow"), 2)
        sample = {arm: operations[arm]() for arm in order}
        rows.append(dict(order=order, **sample))
    return rows


def ratio(samples):
    return statistics.median(row["shipped"] / row["narrow"] for row in samples)


def workload(candidate, radix, length):
    g = torch.Generator(device=DEVICE).manual_seed(20261200 + length + radix)
    rng = random.Random(8009 + length + radix)
    tries = {"shipped": [], "narrow": []}
    queries = []
    build_ms = {arm: [] for arm in tries}
    for head in range(HEADS):
        keys = torch.randint(radix, (length, K), generator=g)
        keys[-2:] = keys[0]
        values = torch.randn(length, DIM, generator=g)
        misses = []
        while len(misses) < 8:
            key = torch.randint(radix, (K,), generator=g)
            if not bool((keys == key).all(1).any()):
                misses.append(key)
        query = torch.cat([keys[:8], torch.stack(misses)])
        queries.append(query)
        classes = {"shipped": ShippedTrie, "narrow": candidate}
        for arm in rng.sample(tuple(classes), 2):
            start = time.perf_counter_ns()
            tries[arm].append(build(classes[arm], radix, keys, values))
            build_ms[arm].append((time.perf_counter_ns() - start) / 1e6)
        exact_states(tries["shipped"][head], tries["narrow"][head])
        old = torch.stack([tries["shipped"][head].query(key, alpha=2.0) for key in query])
        new = torch.stack([tries["narrow"][head].query(key, alpha=2.0) for key in query])
        assert torch.equal(old.view(torch.int32), new.view(torch.int32))
        torch.testing.assert_close(old, exact_attention(keys, values, query, 2.0), rtol=1e-4, atol=2e-5)
    allocated = {arm: tuple(getattr(trie, name) for trie in seq for name in TENSORS) for arm, seq in tries.items()}
    active = {arm: tuple(getattr(trie, name)[:trie._size] for trie in seq for name in TENSORS)
              for arm, seq in tries.items()}
    copied = {arm: tuple(torch.empty_like(t) for t in src) for arm, src in active.items()}
    for arm in tries:
        warm_copy(active[arm], copied[arm])
        sample_query(tries[arm], queries)
    transfers = interleave({arm: lambda a=arm: sample_copy(active[a], copied[a]) for arm in tries}, rng)
    lookup = interleave({arm: lambda a=arm: sample_query(tries[a], queries) for arm in tries}, rng)
    assert all(torch.equal(src, dst) for arm in tries for src, dst in zip(active[arm], copied[arm], strict=True))
    caps = [trie._cap for trie in tries["shipped"]]
    occupied = [trie._size for trie in tries["shipped"]]
    dtypes = [str(trie._child.dtype) for trie in tries["narrow"]]
    if (radix, length) == (16, 4096):
        assert all(cap >= 65536 for cap in caps)
        assert all(int(trie._child.max()) > 32767 for trie in tries["narrow"])
    for head, (base, narrow) in enumerate(zip(tries["shipped"], tries["narrow"], strict=True)):
        for trie in (base, narrow):
            trie.reset()
            trie.insert(queries[head][-1], torch.arange(DIM, dtype=torch.float32))
        exact_states(base, narrow)
        assert torch.equal(base.query(queries[head][0], alpha=2.0), narrow.query(queries[head][0], alpha=2.0))
    storage = {arm: bytes_for(seq) for arm, seq in allocated.items()}
    return dict(radix=radix, length=length, capacities=caps, occupied=occupied, narrower_child_dtypes=dtypes,
                bytes_allocated=storage, live_copy_bytes={arm: logical_bytes(seq) for arm, seq in active.items()},
                storage_fraction_saved=1 - storage["narrow"] / storage["shipped"], build_ms=build_ms,
                bitwise_queries=HEADS * 16, duplicate_keys=2, reset_checks=HEADS,
                copy_ns=transfers, query_ns=lookup, copy_speedup=ratio(transfers), query_speedup=ratio(lookup))


def structural_panel(candidate, path):
    blocks = json.loads(path.read_bytes())["blocks"]
    counts = {}
    for cell in ("native", "reordered", "mixed2", "depth3", "reordered3"):
        correct = 0
        for block in blocks:
            case = block[cell]
            codes = [tuple(int(key[-1]) for key in route) for route in case["leaves"]]
            assert len(set(codes)) == len(codes) == 9

            def padded(path):
                return torch.tensor([*path, 3, *([0] * (K - len(path) - 1))])

            keys = torch.stack([padded(code) for code in codes])
            values = torch.eye(DIM)[:len(codes)]
            base = build(ShippedTrie, 16, keys, values)
            narrow = build(candidate, 16, keys, values)
            exact_states(base, narrow)
            for row in case["rows"]:
                query = padded(tuple(int(key[-1]) for key in row["route"]))
                first, second = (trie.query(query, alpha=2.0) for trie in (base, narrow))
                assert torch.equal(first.view(torch.int32), second.view(torch.int32))
                correct += int(second.argmax()) == row["expected"]
        assert correct == 144
        counts[cell] = correct
    return counts


def main(candidate_file, panel_file, out):
    cpu = max(os.sched_getaffinity(0))
    os.sched_setaffinity(0, {cpu})
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    candidate = load_candidate(candidate_file)
    with torch.inference_mode():
        panel = structural_panel(candidate, panel_file)
        rows = []
        for radix, length in GRID:
            row = workload(candidate, radix, length)
            print(radix, length, row["storage_fraction_saved"], row["copy_speedup"], row["query_speedup"], flush=True)
            rows.append(row)
    control = next(row for row in rows if (row["radix"], row["length"]) == (2, 4096))
    primary = next(row for row in rows if (row["radix"], row["length"]) == (16, 1024))
    criteria = dict(primary_bytes=primary["storage_fraction_saved"] >= .20,
                    primary_copy=primary["copy_speedup"] >= 1.10,
                    binary_bytes=control["storage_fraction_saved"] >= .05,
                    binary_copy=control["copy_speedup"] >= .95,
                    query_no_large_regression=all(row["query_speedup"] >= .90 for row in rows))
    data = dict(host=platform.node(), cpu=cpu, torch_version=torch.__version__, heads=HEADS, head_dim=DIM,
                K=K, copies_per_sample=COPIES, paired_samples=SAMPLES, panel_correct=panel,
                panel_sha256=sha(panel_file.read_bytes()), candidate_sha256=sha(candidate_file.read_bytes()),
                shipped_sha256=sha(Path(sys.modules[ShippedTrie.__module__].__file__).read_bytes()),
                workloads=rows, criteria=criteria, advance=all(criteria.values()))
    with out.open("x") as stream:
        json.dump(data, stream, indent=2)


if __name__ == "__main__":
    main(*map(Path, sys.argv[1:]))
