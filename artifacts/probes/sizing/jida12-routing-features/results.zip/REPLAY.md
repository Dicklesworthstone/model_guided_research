# Matched branch-local readouts

Bead model_guided_research-qlse fixed the protocol at
`3ea38f0e68814f679000a8ecf64d39b250d6213e`. The scoring run used
`0878e1d0286ffa1e0686e6d64c206cbfb43da794` with a corrected checkpoint
window assertion. Both pre-score failures are included in receipts.

Recount the archived scores with Python 3.13 using the sibling-order archive
at `artifacts/probes/sizing/jida12-sibling-order/results.zip` for checkpoint
and fit schedule provenance. From a fresh unpacked directory, use
`uv run --offline --no-project --python 3.13 python recount.py verify
/path/to/this/results.zip /path/to/sibling-order/results.zip` as a single
command. The recount checks both source manifests, the panel hash, the
terminal DSR log hashes, and every per-query routing decision.

The original panel was generated with `MGR_LEAF_TRAIN_SEED=32` and
`campaign.yaml` before any readout scoring. To reproduce the scored run,
point `MGR_FEATURES` at a fresh unpacked directory, place a clean detached
checkout of the scoring revision at `source`, set `MGR_FEATURES_SHA` to
that SHA, set `MGR_LEAF_TRAIN_SEED=32`, and point `DSR_REPOS_FILE` at
`transfer-v2.yaml`. Use a Python 3.13 project environment with the locked
dependencies and run DSR tool `routing-feature-transfer-v2`. The DSR config
names the original training-input location. Restore the three archived
checkpoint/schedule inputs there or adapt the path for a different host. The
script checks all input content hashes. Checkpoint weights and fitted probe
schedules are runtime dependencies of this rerun. The score recount needs
only the two archives.
