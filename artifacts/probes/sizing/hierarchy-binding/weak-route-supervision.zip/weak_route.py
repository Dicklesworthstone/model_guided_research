import copy
import hashlib
import json
import math
import random
import sys
from pathlib import Path
from zipfile import ZipFile

import pyarrow.parquet as pq
import torch

from addressed import (
    BATCH, CELLS, EPOCHS, FIT_ROWS, Binding, checked_corpus, evaluate, identity,
    tensors, token_vectors, write,
)
from binding_score import PANEL_HASH, WEIGHTS, load_model, sha
from cli import _eval_split_examples
from nanochat.diagnostics_data import TASKS

ARCHIVE = "94a8d7a97010089a771b5d6d6554ab7e08e297fc8748b9a5fe8647b740ccc75a"
READOUT = "6b0c32483177b950544254b699bd6bd2fc908ad2319af153b3fce6ad49b6b85e"
PANEL_SEEDS = (7401, 7402, 7403)
ARMS = ("exact", "marginal", "hard")


def make_panel(prior, compared, parent, output):
    root, manifest = checked_corpus(prior)
    assert sha(prior / "baseline-panel.json") == PANEL_HASH
    assert sha(compared / "readout-panel.json") == READOUT
    assert sha(parent) == ARCHIVE
    with ZipFile(parent) as archive:
        addressed = json.loads(archive.read("panel.json"))
    used = set()

    def add(docs):
        assert all(identity(left) == identity(right) for left, right in zip(docs[::2], docs[1::2], strict=True))
        ids = {identity(doc) for doc in docs}
        assert 2 * len(ids) == len(docs) and not ids.intersection(used)
        used.update(ids)

    for name in manifest["sha256"]:
        add(pq.read_table(root / name, columns=["text"]).column("text").to_pylist())
    for source in (json.loads((prior / "baseline-panel.json").read_bytes()),
                   json.loads((compared / "readout-panel.json").read_bytes()), addressed):
        for regions in source.values():
            for docs in regions.values():
                add(docs)
    assert len(used) == 2300
    panel = {}
    spec = TASKS["hier_bind"]
    for seed in PANEL_SEEDS:
        in_range, held_out, _ = _eval_split_examples(spec, n=24, seed=seed)
        _, deep, _ = _eval_split_examples(spec, n=24, seed=seed, dials={"depth": 3})
        panel[seed] = dict(zip(CELLS, (in_range, held_out, deep), strict=True))
        for docs in panel[seed].values():
            add(docs)
    assert len(used) == 2408
    write(output, panel)


def leaf_logps(logps, queries):
    sample = torch.arange(len(queries))[:, None]
    current = logps.new_zeros((len(queries), 1))
    for hop, alias in enumerate(queries.unbind(dim=1)):
        width = 1 << hop
        nodes = torch.arange(width - 1, 2 * width - 1)[None, :]
        branches = logps[sample, nodes, alias[:, None]]
        current = (current[..., None] + branches).flatten(1)
    return current


def masks(docs, sides):
    targets = 2 * sides[:, 0] + sides[:, 1]
    rng = random.Random(80761)
    partitions = []
    for left, right in zip(docs[::2], docs[1::2], strict=True):
        assert identity(left) == identity(right)
        first_color = rng.sample(range(4), 2)
        partitions.append([int(leaf in first_color) for leaf in range(4)])
    colors = torch.tensor(partitions).repeat_interleave(2, dim=0)
    wanted_color = colors.gather(1, targets[:, None])
    weak = colors == wanted_color
    exact = torch.arange(4)[None, :] == targets[:, None]
    assert bool((weak.sum(dim=1) == 2).all() and (exact & weak).equal(exact))
    assert bool((targets[::2] != targets[1::2]).all())
    return exact, weak, colors


def fit(head, aliases, keys, queries, rows, observed, order, hard):
    opt = torch.optim.AdamW(head.parameters(), lr=.003, weight_decay=0)
    losses = []
    for batch in order:
        routes = leaf_logps(head(aliases, keys, rows[batch]), queries[batch])
        compatible = routes.masked_fill(~observed[batch], -torch.inf)
        score = compatible.max(dim=1).values if hard else compatible.logsumexp(dim=1)
        loss = -score.mean()
        opt.zero_grad(set_to_none=True)
        loss.backward()
        opt.step()
        losses.append(float(loss.detach()))
    steps = FIT_ROWS // BATCH
    assert len(losses) == steps * EPOCHS and all(map(math.isfinite, losses))
    return [sum(losses[:steps]) / steps, sum(losses[-steps:]) / steps]


def run(prior, panel_path, output, seed):
    root, _ = checked_corpus(prior)
    docs = pq.read_table(root / "train_000.parquet", columns=["text"]).column("text").to_pylist()[:FIT_ROWS]
    assert len(docs) == FIT_ROWS
    queries, rows, sides = tensors(docs)
    exact, weak, colors = masks(docs, sides)
    raw = json.loads(panel_path.read_bytes())
    panel = {region: tensors([doc for eval_seed in PANEL_SEEDS for doc in raw[str(eval_seed)][region]])
             for region in CELLS}
    model, tok = load_model(prior, seed)
    aliases = token_vectors(model, tok, ("a0", "a1"))
    keys = token_vectors(model, tok, ("k0", "k1"))
    shuffle = torch.Generator().manual_seed(seed + 41200)
    order = [batch for _ in range(EPOCHS) for batch in torch.randperm(FIT_ROWS, generator=shuffle).split(BATCH)]
    torch.manual_seed(seed + 500)
    initial = Binding()
    with torch.no_grad():
        logps = initial(aliases, keys, rows[:16])
        routes = leaf_logps(logps, queries[:16])
        assert torch.allclose(routes.logsumexp(dim=1), torch.zeros(16), atol=1e-6, rtol=0)
        for i, (first, second) in enumerate(sides[:16].tolist()):
            q0, q1 = queries[i].tolist()
            direct = logps[i, 0, q0, first] + logps[i, 1 + first, q1, second]
            assert routes[i, 2 * first + second] == direct
    outcomes = {"initial": evaluate(initial, aliases, keys, panel)}
    for name in ARMS:
        head = copy.deepcopy(initial)
        losses = fit(head, aliases, keys, queries, rows, exact if name == "exact" else weak, order, name == "hard")
        outcomes[name] = dict(epoch_loss=losses, **evaluate(head, aliases, keys, panel))
        print(f"{seed} {name} first/last loss {losses}", flush=True)
    write(output, dict(checkpoint=WEIGHTS[seed], panel_sha256=sha(panel_path), train_rows=FIT_ROWS,
                       updates=len(order), paired_same_color=int((weak[::2] == weak[1::2]).all(dim=1).sum()),
                       colorings_sha256=hashlib.sha256(bytes(colors.flatten().tolist())).hexdigest(),
                       outcomes=outcomes))


if __name__ == "__main__":
    torch.set_num_threads(1)
    mode, *args = sys.argv[1:]
    if mode == "panel":
        make_panel(*map(Path, args))
    else:
        *paths, seed = args
        run(*map(Path, paths), int(seed))
