import hashlib
import json
import sys
from collections import Counter
from pathlib import Path

import pyarrow.parquet as pq

from nanochat.diagnostics_data import TASKS, content_sha256, hier_bind_answer
from nanochat.tokenizer import TASK_TOKENIZER_DEFAULT_VOCAB, train_task_tokenizer


def audit(root):
    spec = TASKS["hier_bind"]
    manifest = json.loads((root / "manifest.json").read_text())
    tokenizer = train_task_tokenizer([root / "train_000.parquet"], TASK_TOKENIZER_DEFAULT_VOCAB)
    bos = tokenizer.get_bos_token_id()
    result = {}
    for split, filename in (("train", "train_000.parquet"), ("val", "val_000.parquet"),
                            ("test", "heldout/test_000.parquet")):
        file = root / filename
        assert hashlib.sha256(file.read_bytes()).hexdigest() == manifest["sha256"][filename]
        docs = pq.read_table(file, columns=["text"]).column("text").to_pylist()
        assert content_sha256(docs) == manifest["content_sha256"][filename]
        assert len(docs) == manifest["split_sizes"][split]
        correct, blind_correct, corpus_lengths, paired_bag = 0, 0, Counter(), 0
        for left, right in zip(docs[::2], docs[1::2], strict=True):
            p, a = spec.split_prompt(left)
            q, b = spec.split_prompt(right)
            assert a != b and p.split(" BIND ")[0] == q.split(" BIND ")[0]
            assert p.split(" PATH ")[1] == q.split(" PATH ")[1]
            assert Counter(p.split()) == Counter(q.split())
            correct += hier_bind_answer(p) == a
            correct += hier_bind_answer(q) == b
            if Counter(tokenizer.encode(p, prepend=bos)) == Counter(tokenizer.encode(q, prepend=bos)):
                paired_bag += 1
            first_leaf = next(word for word in p.split(" BIND ")[0].split() if word.startswith("v"))
            blind_correct += int(first_leaf == a) + int(first_leaf == b)
            for doc in (left, right):
                corpus_lengths[len(tokenizer.encode(doc, prepend=bos))] += 1
        assert correct == len(docs) and blind_correct <= len(docs) // 2
        assert paired_bag == len(docs) // 2
        result[split] = dict(documents=len(docs), pairs=len(docs) // 2, symbolic_correct=correct,
                             identical_prompt_token_bags=paired_bag, first_leaf_correct=blind_correct,
                             first_leaf_both_correct=0, min_tokens=min(corpus_lengths),
                             max_tokens=max(corpus_lengths), over_320=sum(n for k, n in corpus_lengths.items()
                                                                         if k > 320),
                             token_histogram=sorted(corpus_lengths.items()))
    return dict(depth=manifest["dials"]["depth"], vocab_size=tokenizer.get_vocab_size(), splits=result)


root = Path(sys.argv[1])
with (root / "audit.json").open("x", encoding="utf-8") as file:
    outcomes = {name: audit(root / name / "hier_bind") for name in ("default", "deep")}
    json.dump(outcomes, file, indent=2)
    print(json.dumps(outcomes))
