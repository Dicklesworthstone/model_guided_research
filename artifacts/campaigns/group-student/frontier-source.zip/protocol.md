# Exhaustive shortest informative frontier

Bead `model_guided_research-0yfo`. This compares the shipped shortlist with
an exact search over admissible words, which have at least two symbols.
The catalogue and scoring criterion remain fixed. Both selectors compile
their structural decisions, with the same late naming and square cap.

## Why the frontier is complete

Let `N` be the number of fitting shapes and `u` the unused roster size,
with the existing convention `f = max(1, u)`. Divide reply bucket sizes by
the common factorial as in the released selector. A known-label bucket
has size `f × k` for `k` matching shapes. An unassigned-label bucket has
size `m` for `m` shapes with an unassigned endpoint at the query word.
A word is informative when the largest bucket is below `N × f`. Thus
a word fails that condition exactly when all shapes force one known reply
or when all shapes force the sole unused reply. With zero unused labels
the unassigned case is impossible.

In either case, the forced reply defines one endpoint in every live
shape. Any suffix applied to a different word with the same forced reply
therefore reaches the same endpoint vector and has the same score. Keeping
its first shortlex representative preserves the smallest length and first
lexicographic spelling for any extension. Breadth-first search starts with
the four admissible anchors. It expands every distinct forced reply once
and scores the entire first informative layer. An already paid word has
a forced reply. The output is exactly the
minimum `(length, worst bucket, word)` over all informative admissible
words. At most the roster size of forced prefixes can be expanded.

The ordinary compiler remains the default and the shipped bundle is
unchanged. The candidate uses `compile_policy(index, exhaustive_frontier=True)`.
The small-order diagnostics independently enumerate every binary word up to
the selected length and recompute the admissible reply buckets from the
facts on live shapes. These controls use orders 4, 6 and 8.

## Comparison frozen before scoring

- Use all 151, 503 and 1,799 distinct marked actions of orders 32, 64 and
  128. Rotate the three live arms by case. Reverse the arrangement and
  roster on the second execution, using the two previous relabelings and
  hash seeds 0 and 991. The released source at `5c39b8c` drives square
  closure and the shipped shortlist in the same invocation.
- Every returned table must equal the prior exact table and the
  independently decoded rooted truth. Require both released controls to
  reproduce their exact archived words, replies and terminal statuses.
  Preserve the new arm's paid tapes and require identical canonical
  word sequences and terminal statuses across relabeling. The teacher
  computes its replies directly from the independently audited shapes.
- Primary gate is **no increase in aggregate paid reads and a strict
  reduction in total input symbols at every order in both executions**
  relative to the shipped shortlist. Summarize all six cells. Report
  counts of both marks, per-case gains and regressions, and costs relative
  to square closure. Host process CPU and wall time include the actual
  online invocation. Catalogue loading, compilation and shipped-policy
  load are timed separately.
- Stop after two full exact runs. DSR validates execution independently
  of the performance prediction. Preserve a valid loss under the fixed
  threshold. This tests a finite exhaustive symbolic workload. A
  learned prior floor, seed-power calculation, new neural mechanism and
  hardware pricing are outside its scope.
