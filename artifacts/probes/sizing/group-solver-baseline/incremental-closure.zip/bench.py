"""Paid-tape equivalence and paired CPU timings for the endpoint learner."""

import hashlib
import json
from itertools import product
from pathlib import Path
from statistics import median
from time import process_time_ns

import incumbent
from fixture.verify import explicit_action, walk

from scripts import group_rewrite_probe as candidate


def panel_four():
    record = json.loads(Path("fixture/scored.json").read_text())
    cases = []
    for case in record["cases"]:
        labels = case["labels_bfs"]
        start, edges, _ = explicit_action(case["family"], case["generators"], labels)

        def ask(word, root=start, lookup=edges):
            return walk(root, lookup, word)

        cases.append((case["initial"], set(labels), ask, case["arms"]["square"]["right"], None))
    return cases


def panel_eight():
    path = Path(candidate.__file__).resolve().parents[1] / (
        "artifacts/probes/sizing/group-query-completion/panel.json"
    )
    cases = []
    for case in json.loads(path.read_text())["cases"]:
        labels = case["names"]
        gen = tuple(tuple(g) for g in case["generators"])
        graph = incumbent.rooted_graph(case["group"], gen)
        if hashlib.sha256(json.dumps(graph).encode()).hexdigest() != case["graph_digest"]:
            raise ValueError("Historical action differs from the archived fixture")

        def ask(word, rows=graph, names=labels):
            state = 0
            for mark in word:
                state = rows[state][int(mark)]
            return names[state]

        initial = {
            word: ask(word)
            for n in range(2, 9)
            for letters in product("01", repeat=n)
            if (word := "".join(letters))
        }
        cases.append((initial, set(labels), ask, case["arms"]["commuting"]["right"], case["arms"]["ablation"]["right"]))
    return cases


def measured(learner, cases, squares):
    start = process_time_ns()
    output = [
        learner(initial, names, oracle, squares=squares)
        for initial, names, oracle, _, _ in cases
    ]
    return process_time_ns() - start, [(action.maps, paid) for action, paid in output]


def compare(cases, squares, *, ratio_min):
    raw = []
    (before, expected), (after, got) = (
        measured(m.teach_panel_case, cases, squares) for m in (incumbent, candidate)
    )
    if expected != got:
        raise ValueError("Warm-up changed a paid query or a generator table")
    for (maps, _), (_, _, _, expected_square, expected_ablation) in zip(got, cases, strict=True):
        expected_right = expected_square if squares or expected_ablation is None else expected_ablation
        if {g: maps["R" + g] for g in "01"} != expected_right:
            raise ValueError("Reconstructed table differs from the archived truth")
    for number in range(13):
        batch = (("incumbent", incumbent), ("candidate", candidate))
        if number % 2:
            batch = batch[::-1]
        pair = {}
        for name, module in batch:
            pair[name], rows = measured(module.teach_panel_case, cases, squares)
            if rows != expected:
                raise ValueError(f"Paired observation {number + 1} changed an exact result")
        raw.append(pair)
    speedup = median(p["incumbent"] / p["candidate"] for p in raw)
    return {
        "cases": len(cases),
        "squares": squares,
        "equal_action_bindings": sum(sum(map(len, maps.values())) for maps, _ in got),
        "equal_paid_queries": sum(len(tape) for _, tape in got),
        "cpu_ns": {arm: median(p[arm] for p in raw) for arm in ("incumbent", "candidate")},
        "median_paired_speedup": speedup,
        "minimum_ratio": ratio_min,
        "passes": speedup >= ratio_min,
        "pairs": raw,
    }


def main():
    four, eight = panel_four(), panel_eight()
    results = {
        "depth4": compare(four, True, ratio_min=1.5),
        "depth8": compare(eight, True, ratio_min=1.5),
        "depth8_ablation": compare(eight, False, ratio_min=1 / 1.10),
    }
    print(json.dumps(results, indent=2))
    if not all(row["passes"] for row in results.values()):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
