# Condition the catalogue on anchors before building it

## Question and fixed data

Can the exact small-group learner avoid materializing marked actions that
its four public replies already rule out? The comparison fixes orders
32, 64 and 128. GAP 4.16.1 and SmallGrp 1.7.0 report 51, 267 and 2328
groups at these orders. Use the complete indexed inventory of groups
with generator rank at most two at each order (20, 54 and 163 groups).
The minimum generator rank of a finite p-group is the dimension of its
Frattini quotient. By the Burnside basis theorem, no group omitted by
the rank filter can have a generating pair. Both builders take the same
frozen export and start with its rows already in memory.
[SmallGrp indexing documentation](https://docs.gap-system.org/pkg/smallgrp/doc/chap1_mj.html)
[Burnside basis theorem, Craven's lecture notes](https://web.mat.bham.ac.uk/D.A.Craven/docs/lectures/finitegroups2012.pdf)

Use the stored `canonical` traversal and `catalogue_learning` from
`fe33cc9` as the incumbent. The full builder runs the original traversal
on every ordered pair of each eligible group, deduplicates canonical
rooted graphs and buckets them by the four anchor answers. The proposed
builder conditions directly on the anchor pattern before traversing.
Only the public order and the equality pattern of `00, 01, 10, 11`
enter construction. Later learning sees the actual opaque labels through
the unchanged query policy. The catalogue assumes a regular group action
as in the previous comparison.

## Exact reduction

For generators a and b the four anchor states are a², ab, ba and b².
Equality of their opaque labels is equality of those elements. If a² or
b² equals either ab or ba, cancellation gives a=b and all four entries
are equal. With different generators the only remaining equalities are
between a² and b² and between ab and ba. Thus at most five partitions are
possible. Use the restricted-growth strings `0000`, `0110`, `0112`,
`0120` and `0123`. The ten remaining partitions must produce no shape
and require no traversals. If ab=ba, all words in the two generators
commute and they generate an abelian group. If ab≠ba, the generated group
is nonabelian. For two-generator groups of the requested order, filter
the group class and the pair equalities before traversal. This changes
no possible rooted marked action.

On the commuting branch, generate shapes directly. A marked finite
abelian group is a quotient of Z², with its two marks the images of
the coordinate vectors. If the order is n, the kernel has unique column
Hermite basis (w,0),(s,h) with wh=n and 0≤s<w. To see existence and
uniqueness, take w as the positive generator of the intersection of
the kernel with the first coordinate axis. Take h as the positive
generator of its projection on the second axis and reduce the first
coordinate of the corresponding vector modulo w to get s. Subtracting
these two vectors reduces every lattice point to the unique rectangle
0≤x<w, 0≤y<h. Its area is the index. Apply the two coordinate shifts in
this rectangle, adjust x by −s on wraparound in y, and retain exactly
the compatible anchor partitions. The number of complete abelian
marked shapes before the anchor filter is the sum of divisors of n.

## Gates and stopping rule

At each of the three orders, compare the actual sorted graphs across all
15 partitions. The direct abelian construction must match all three
commuting buckets from the complete traversal. The checker must also
reject a dropped shape and a graph assigned to a wrong anchor class.
It verifies explicit edge domains, bijectivity, canonical traversal,
anchor patterns and the exact abelian count.

Exercise the unchanged acquisition path on two frozen 32-state actions.
Use a 16-site dihedral ring with marks T and FT, and a 4×8 torus with the
two positive axes. Shuffle opaque labels with seeds 251531 and 251532,
respectively. Charge the four anchors and each additional paid word.
Require the routed and full catalogues to return identical query tapes,
statuses and exact tables. The verifier must reconstruct both actions
independently. Orders 64 and 128 are builder benchmarks.

Measure process CPU and wall time for one full build at each order and
for each feasible filtered build and applicable direct lattice build.
Report exact canonical-traversal counts in both pair builders. Test a
cold single-case route against the incumbent complete build from the
same in-memory export, within a single invocation. Use the lattice
branch when the anchors show commutation and the filtered group branch
otherwise. The timing criterion is a median cold CPU ratio of at least
2× across the ten feasible order-by-profile cells at 64 and 128, on
both executions. Report all cells, including slow or neutral cases, and
keep the cost of the reusable full index visible for warm operation.

Score once with Python 3.13 and hash seed 0. Replay once with hash seed
991 and reverse the builder order. All non-timing fields must agree.
Run no extra seeds or orders in the decision panel. The numbers at
256 and 512 in the preliminary inventory are sizing only. This reports
finite construction and integration evidence, without a population,
hardware timing, or trained-model comparison.
