# Exact acquisition by shortest informative tier

The released census traded local computation for fewer endpoint reads and fewer
executed generator symbols. This comparison fixes the policy and changes its
implementation. The primary threshold is at least a factor of two less online
process CPU against live released length-first in each complete execution. A
live square-closure arm measures the remaining CPU cost or gain against the
domain baseline.

## Exact decisions

The exhaustive shortlist consists of words of length two through four, shortest
anchor-seeded access words for the first surviving shape, and one disagreement
between the first two canonically completed candidates. Previously queried words
are excluded. The ordering is `(length, worst remaining mass, word)`, and a word
is informative only if its worst remaining mass is strictly below the current
mass. For the fixed part of the shortlist, any length after the first informative
tier therefore loses. Sort tiers by word and batch the same endpoint counts
within each one. If a fixed winner exists, a breadth-first disagreement search
only needs to visit pairs at depths up to that length. It keeps the same ordering
and completion rule as the released search. If there is no fixed winner, the
disagreement search runs to completion. Compare its candidate by the same key.
The optimized trace records the selected score and the actual number of probe
scores computed. The released full-shortlist minimax statistic remains in the
legacy evidence and plays no part in length-first selection.

After the exact fit is unique, use its cached shortest access ordering to visit
each unnamed state except the last. Validate each answer against the unused
roster and infer the last name. The cap continues to trigger square closure.

## Frozen comparison

- Use the committed GAP 4.16.1 and SmallGrp 1.7.0 tables for all groups of
  orders 60 and 120. Run on all 376 and 1,498 marked generating actions,
  respectively, with their prior order preserved.
- In each run share the four charged initial endpoint observations. Rotate
  arm order by shape slot, then reverse that order for the second execution.
  Use the two released affine naming permutations and Python hash seeds 0 and
  991. Record wall and process CPU for each invocation. Report the common
  cold catalogue and endpoint index costs and the added tier preparation cost
  separately, alongside full online totals. The square arm does not consume
  the catalogue or its index.
- Reconstruct the inventory independently and validate every named transition
  and paid call. Require equality against the historical raw tape, action and
  decision trace for the live legacy and square arms on the original names.
  Require exact equality of current optimized and legacy paid tapes and
  decision traces in both runs, including after mapping the names back to
  canonical indices. Recompute the optimized selected scores and version
  spaces independently on the original names. Verify the uniqueness boundary
  and the shortest naming suffix. Retain separate counts of `0`, `1`, total
  symbols and endpoint reads.
- Outside primary timing, force the optimized learner to fall back at four
  facts in an ambiguous case and compare its paid tape and table with square
  closure. Also reject an oracle that reuses an already assigned name at the
  first singleton naming query. Execute both controls on both relabelings.
- Both executions must pass exactness and each aggregate online CPU ratio
  must be at least two. Preserve both raw runs and report the result at the
  fixed threshold. This measures software acquisition on regular actions. The
  physical device qualification remains a separate open check.
