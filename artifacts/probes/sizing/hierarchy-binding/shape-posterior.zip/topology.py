import itertools
import json
import random
import sys
from collections import Counter
from functools import cache
from pathlib import Path

from address_fixtures import DIM, POOLS, make_pair, sha_json

SEEDS = (13011, 13012, 13013)
CELLS = ((2, 16), (3, 16), (4, 16), (6, 8))
WORDS = range(1 << DIM)


@cache
def inverse_lut(order):
    table = b"\0"
    for bit in order:
        table += bytes(key | (1 << bit) for key in table)
    return table


def hole(words):
    parity = next(iter(words)).bit_count() % 2
    if len(words) == len(POOLS[parity]) - 1 and words <= set(POOLS[parity]):
        missing, = set(POOLS[parity]) - words
        return missing
    return None


def landmarks(keys, pointers, anchors):
    if anchors:
        yield anchors[0]
        return
    signatures = {}
    for key in keys:
        label = tuple(sorted((key ^ x).bit_count() for x in keys))
        signatures.setdefault(label, []).append(key)
    pointer = min(pointers, key=lambda q: (len(signatures.get(
        tuple(sorted((q ^ p).bit_count() for p in pointers)), ())), q))
    signature = tuple(sorted((pointer ^ p).bit_count() for p in pointers))
    for key in sorted(signatures.get(signature, ())):
        yield key, pointer


def permutations(keys, pointers, key_base, ptr_base, anchors):
    def counts(words, base):
        words = tuple(word ^ base for word in words)
        masks = tuple(sum(((word >> bit) & 1) << i for i, word in enumerate(words)) for bit in range(DIM))
        return tuple(tuple((a & b).bit_count() for b in masks) for a in masks)

    left, right = counts(keys, key_base), counts(pointers, ptr_base)
    allowed = [tuple(k for k in range(DIM) if left[k][k] == right[p][p] and
                     all(((key ^ key_base) >> k & 1) == ((ptr ^ ptr_base) >> p & 1) for key, ptr in anchors))
               for p in range(DIM)]
    priorities = sorted(range(DIM), key=lambda p: len(allowed[p]))
    assignment = [-1] * DIM

    def extend(at, taken):
        if at == DIM:
            yield tuple(assignment)
            return
        bit = priorities[at]
        for candidate in allowed[bit]:
            flag = 1 << candidate
            if taken & flag or any(left[candidate][assignment[earlier]] != right[bit][earlier]
                                   for earlier in priorities[:at]):
                continue
            assignment[bit] = candidate
            yield from extend(at + 1, taken | flag)

    yield from extend(0, 0)


def isometries(keys, pointers, anchors):
    missing = hole(keys), hole(pointers)
    if not anchors and None not in missing:
        # Moving the unique omitted word to zero makes the two punctured banks identical.
        key_base, ptr_base = missing
        for order in itertools.permutations(range(DIM)):
            yield inverse_lut(order), key_base, ptr_base
        return
    for key_base, ptr_base in landmarks(keys, pointers, anchors):
        relative = {key ^ key_base for key in keys}
        normalized = tuple(pointer ^ ptr_base for pointer in pointers)
        for order in permutations(keys, pointers, key_base, ptr_base, anchors):
            table = inverse_lut(order)
            if all(table[p] in relative for p in normalized):
                yield table, key_base, ptr_base


def observe(doc):
    return {key: tuple(row) if row[0] != row[1] else ()
            for key, row in zip(doc["keys"], doc["link"], strict=True)}


def verify_tree(records, root_ptr, depth, decoder):
    table, key_base, ptr_base = decoder
    pending = [table[root_ptr ^ ptr_base] ^ key_base]
    seen = set()
    for _ in range(depth):
        children = []
        for key in pending:
            edges = records[key]
            if not edges or key in seen:
                return False
            seen.add(key)
            children.extend(table[ptr ^ ptr_base] ^ key_base for ptr in edges)
        pending = children
    return (len(set(pending)) == len(pending) and not seen.intersection(pending)
            and all(not records[key] for key in pending) and len(seen) + len(pending) == len(records))


def walk(records, root_ptr, query, decoder):
    table, key_base, ptr_base = decoder
    route = [table[root_ptr ^ ptr_base] ^ key_base]
    for alias in query:
        ptr = records[route[-1]][alias]
        route.append(table[ptr ^ ptr_base] ^ key_base)
    return tuple(route)


def solve(observations, anchors=()):
    records, root, query = observations[0]
    count = (1 << (len(query) + 1)) - 1
    keys = set(records)
    symbols = [root, *(ptr for edges in records.values() for ptr in edges)]
    pointers = set(symbols)
    assert len(keys) == len(pointers) == len(symbols) == count
    assert all(len(edges) in (0, 2) for table, _, _ in observations for edges in table.values())
    for table, root_ptr, probes in observations:
        assert set(table) == keys and len(probes) == len(query)
        other_symbols = [root_ptr, *(ptr for edges in table.values() for ptr in edges)]
        assert len(other_symbols) == count and set(other_symbols) == pointers
    gcount = 0
    routes = [Counter() for _ in observations]
    for decoder in isometries(keys, pointers, anchors):
        gcount += 1
        for (table, root_ptr, probes), log in zip(observations, routes, strict=True):
            if verify_tree(table, root_ptr, len(probes), decoder):
                log[walk(table, root_ptr, probes, decoder)] += 1
    return dict(bank_maps=gcount, orientations=[dict(
        maps=sum(log.values()), routes=[dict(path=route, maps=number) for route, number in sorted(log.items())])
        for log in routes])


def fresh():
    namespaces = set()
    for seed in SEEDS:
        for depth, size in CELLS:
            rng = random.Random(seed + 80724 + 320 * depth)
            for ix in range(size):
                while True:
                    namespace = tuple(rng.sample(range(DIM), DIM)), rng.randrange(1 << DIM)
                    if namespace not in namespaces:
                        namespaces.add(namespace)
                        break
                yield seed, depth, ix, namespace, make_pair(rng, depth, ix, POOLS[1], namespace)


def controls():
    signatures = (0, 0, 1, 2, 3, 4, 5, 6)
    words = [0, *(sum(((tag >> bit) & 1) << i for i, tag in enumerate(signatures)) for bit in range(3))]
    anchors = tuple((word, word) for word in words)
    witnesses = {
        "distinct_answers": {4: (1, 2), 1: (8, 16), 2: (32, 64), 8: (), 16: (), 32: (), 64: ()},
        "same_answer": {4: (64, 32), 64: (8, 16), 32: (1, 2), 8: (), 16: (), 1: (), 2: ()},
    }
    return {name: ([(records, 4, (0, 0))], anchors) for name, records in witnesses.items()}


def run(output):
    rows = []
    for seed, depth, ix, namespace, pair in fresh():
        inputs = [(observe(doc), doc["root"], tuple(doc["query"])) for doc in pair]
        result = solve(inputs)
        for doc, measured in zip(pair, result["orientations"], strict=True):
            gold = tuple(doc["keys"][i] for i in doc["chain"])
            assert gold in [route["path"] for route in measured["routes"]]
        rows.append(dict(seed=seed, depth=depth, pair=ix, namespace=namespace, fixture=sha_json(pair), **result))
    planted = {name: solve(inputs, anchors) for name, (inputs, anchors) in controls().items()}
    assert len(rows) == 168
    with output.open("x", encoding="utf-8") as stream:
        json.dump(dict(rows=rows, controls=planted), stream)
    print("Enumerated 168 pairs and two ambiguity controls.", flush=True)


if __name__ == "__main__":
    run(Path(sys.argv[1]))
