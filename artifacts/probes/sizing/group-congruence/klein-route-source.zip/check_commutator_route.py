"""Build an independent group panel and audit the cyclic-commutator route."""

import argparse
import hashlib
import json
import random
from collections import Counter
from itertools import permutations, product
from pathlib import Path

from check_alternating_route import PANEL, PRIOR, digests
from check_short_certificate import action, answers, checksum, plain, read, validate_tape, walk

SEED = 251759
TARGETS = ("s3xc20", "c3-by-c40")
OUTSIDE = "s4xc5"
CONTROLS = ("c120", "s5", "a5xc2")
ARMS = ("fallback", "edge", "short", "routed", "extended", "commutator")


def group(family):
    if family in {"s3xc20", "s3xc2", "s4xc5", "a4"}:
        degree, modulus = {"s3xc20": (3, 20), "s3xc2": (3, 2), "s4xc5": (4, 5), "a4": (4, 1)}[family]
        pool = [p + (a,) for p, a in product(permutations(range(degree)), range(modulus)) if family != "a4" or not (
            sum(p[i] > p[j] for i in range(degree) for j in range(i + 1, degree)) % 2
        )]

        def multiply(left, right):
            return tuple(right[index] for index in left[:degree]) + ((left[-1] + right[-1]) % modulus,)

        return pool, tuple(range(degree)) + (0,), multiply
    if family == "heisenberg3":
        def multiply(left, right):
            x, y, z = left
            a, b, c = right
            return (x + a) % 3, (y + b) % 3, (z + c + x * b) % 3

        return list(product(range(3), repeat=3)), (0, 0, 0), multiply
    normal, quotient, multiplier = {"c3-by-c40": (3, 40, 2), "c3-by-c4": (3, 4, 2), "c9-by-c3": (9, 3, 4)}[family]

    def multiply(left, right):
        return (left[0] + pow(multiplier, left[1], normal) * right[0]) % normal, (left[1] + right[1]) % quotient

    return list(product(range(normal), range(quotient))), (0, 0), multiply


def graph_for(marks, identity, multiply):
    states = [identity]
    indices = {identity: 0}
    graph = []
    for state in states:
        row = []
        for mark in marks:
            target = multiply(state, mark)
            if target not in indices:
                indices[target] = len(states)
                states.append(target)
            row.append(indices[target])
        graph.append(row)
    return graph


def make_panel(root):
    latest = read(root / PANEL / "alternating-route-coverage.json")
    spent = {identifier for path in PRIOR for identifier in digests(read(root / path))} | set(digests(latest))
    rng = random.Random(SEED)
    cases = []
    for family in (*TARGETS, OUTSIDE):
        pool, identity, multiply = group(family)
        count = 0
        for _ in range(10_000):
            marks = rng.choice(pool), rng.choice(pool)
            graph = graph_for(marks, identity, multiply)
            identifier = checksum(graph)
            if len(graph) != 120 or identifier in spent:
                continue
            cases.append(dict(family=family, marks=list(map(list, marks)), graph=graph, graph_sha=identifier))
            spent.add(identifier)
            count += 1
            if count == 6:
                break
        if count != 6:
            raise ValueError(f"Too few fresh markings for {family}")
    for family in CONTROLS:
        cases.extend([case for case in latest["cases"] if case["family"] == family][:2])
    return dict(seed=SEED, cases=cases)


def normalized(report):
    result = plain(report)
    del result["alternating_cpu_ns"]
    return result


def verify_witness(graph, witness):
    c = witness["word"]
    a_order, b_order = witness["orders"]
    if c != "01" + "0" * (a_order - 1) + "1" * (b_order - 1) or any(
        min(power for power in range(1, len(graph) + 1) if walk(graph, mark * power) == 0) != order
        for mark, order in zip("01", (a_order, b_order), strict=True)
    ):
        raise ValueError("Wrong commutator word or generator order")
    if not answers(graph, ("01", c + "10")) or walk(graph, c) == 0:
        raise ValueError("The proposed word is not the nontrivial commutator")
    if rejected := witness.get("rejected"):
        if rejected == "commutator_order" and walk(graph, c * 3) != 0:
            return
        if rejected in {"normalization_0", "normalization_1"} and walk(graph, c * 3) == 0:
            mark = rejected[-1]
            if not any(answers(graph, (mark + c, c * power + mark)) for power in (1, 2)):
                return
        raise ValueError("Incorrect rejection reason")

    w, s, h = witness["lattice"]
    alpha, beta = witness["signs"]
    r, t = witness["powers"]
    if 3 * w * h != len(graph) or not (w > 0 and h > 0 and 0 <= s < w and r in range(3) and t in range(3)):
        raise ValueError("Invalid lattice or lift powers")
    if alpha not in {1, -1} or beta not in {1, -1} or not all(answers(graph, pair) for pair in (
        (c * 3, ""), ("0" + c, c * (alpha % 3) + "0"), ("1" + c, c * (beta % 3) + "1"),
        ("0" * w, c * r), ("0" * s + "1" * h, c * t),
    )):
        raise ValueError("A proposed lift relation fails")
    endpoints = {walk(graph, c * k + "0" * x + "1" * y) for k, x, y in product(range(3), range(w), range(h))}
    if endpoints != set(range(len(graph))):
        raise ValueError("The normal forms are not bijective")


def census():
    from scripts.group_student_probe import _try_order_three_commutator

    result = {}
    families = ("s3xc2", "c3-by-c4", "heisenberg3", "c9-by-c3", "a4")
    for family in families:
        pool, identity, multiply = group(family)
        paid_maximum = 0
        count = 0
        classes = set()
        for marks in product(pool, repeat=2):
            graph = graph_for(marks, identity, multiply)
            if len(graph) != len(pool):
                continue
            calls = 0

            def equal(left, right, actual=graph):
                nonlocal calls
                calls += 1
                return answers(actual, (left, right))

            if equal("01", "10"):
                raise ValueError("Unexpected commuting generating pair")
            recovered, witness = _try_order_three_commutator(len(pool), equal)
            verify_witness(graph, witness)
            if family == "a4":
                if recovered is not None:
                    raise ValueError("Order-four derived subgroup accepted")
            elif recovered is None or list(map(list, recovered)) != graph:
                raise ValueError("Uncatalogued order did not recover exactly")
            classes.add(checksum(graph))
            count += 1
            paid_maximum = max(paid_maximum, calls)
        if not count:
            raise ValueError("Empty transfer census")
        result[family] = dict(order=len(pool), generating_pairs=count, markings=len(classes), maximum_calls=paid_maximum)
    return result


def audit(root, coverage, primary, replay, baseline, previous):
    manifest, scored, replay, baseline, previous = map(read, (coverage, primary, replay, baseline, previous))
    if manifest != make_panel(root) or scored["coverage_sha256"] != hashlib.sha256(coverage.read_bytes()).hexdigest():
        raise ValueError("Scored the wrong panel")
    current = normalized(scored)
    if current != normalized(replay):
        raise ValueError("Different hash seed changed the tape")
    prior_controls = {row["graph_sha"]: row["arms"]["extended"] for row in normalized(previous)["results"]}
    counts = {family: {arm: Counter() for arm in ARMS} for family in (*TARGETS, OUTSIDE, *CONTROLS)}
    attempt_counts = []
    forged_checked = False
    for case, row, clean in zip(manifest["cases"], scored["results"], current["results"], strict=True):
        family = case["family"]
        if family in CONTROLS:
            graph = action(family, case["marks"])[0]
        else:
            _, identity, multiply = group(family)
            graph = graph_for(case["marks"], identity, multiply)
        identifier = checksum(graph)
        if graph != case["graph"] or identifier != case["graph_sha"] or (identifier, family) != (row["graph_sha"], row["family"]):
            raise ValueError("Independent group and manifest disagree")
        if set(row["arms"]) != set(ARMS):
            raise ValueError("Missing comparison arm")
        for name, arm in row["arms"].items():
            validate_tape(graph, arm["paid"])
            if graph != arm["right"]:
                raise ValueError("Recovered graph differs")
            counts[family][name].update(calls=len(arm["paid"]), symbols=sum(len(a) + len(b) for a, b, _ in arm["paid"]), cpu_ns=arm["cpu_ns"])
        candidate = clean["arms"].pop("commutator")
        extended = clean["arms"]["extended"]
        if family in CONTROLS:
            if candidate != extended or extended != prior_controls[identifier]:
                raise ValueError("An already solved class changed")
            continue
        witness = candidate["commutator"]
        verify_witness(graph, witness)
        tail = clean["arms"]["fallback"]["paid"]
        before = extended["paid"][:-len(tail)]
        if extended["paid"] != before + tail or candidate["paid"][:len(before)] != before:
            raise ValueError("Prior attempts did not replay before the direct route")
        if family == OUTSIDE:
            extra = len(candidate["paid"]) - len(extended["paid"])
            if "rejected" not in witness or candidate["paid"][-len(tail):] != tail or not 0 < extra <= 15:
                raise ValueError("Failed recognition changed the fallback tape or exceeded its cap")
            attempt_counts.append(dict(family=family, branch_calls=extra, rejection=witness["rejected"]))
        else:
            if "rejected" in witness:
                raise ValueError("A target failed direct recovery")
            attempt_counts.append(dict(family=family, branch_calls=len(candidate["paid"]) - len(before), lattice=witness["lattice"]))
            if not forged_checked:
                wrong = dict(witness, powers=[(witness["powers"][0] + 1) % 3, witness["powers"][1]])
                try:
                    verify_witness(graph, wrong)
                except ValueError:
                    forged_checked = True
                else:
                    raise ValueError("The verifier accepted a forged lift")
    if current != normalized(baseline):
        raise ValueError("Original CLI after the addition changed the existing evidence")
    extended_calls, direct_calls = (sum(counts[family][arm]["calls"] for family in TARGETS) for arm in ("extended", "commutator"))
    print(json.dumps(dict(
        exact=True, default_unchanged=True, forged_lift_rejected=forged_checked,
        checked_transitions=24 * 120 * 2 * len(ARMS), gate=5 * direct_calls <= extended_calls,
        extended_calls=extended_calls, commutator_calls=direct_calls, totals=counts, branches=attempt_counts, census=census(),
    ), indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    modes = parser.add_subparsers(dest="mode", required=True)
    for name in ("cover", "audit"):
        mode = modes.add_parser(name)
        mode.add_argument("root", type=Path)
        mode.add_argument("coverage", type=Path)
    for name in ("primary", "replay", "baseline", "previous"):
        mode.add_argument(name, type=Path)
    args = parser.parse_args()
    if args.mode == "cover":
        with args.coverage.open("x", encoding="utf-8") as file:
            json.dump(make_panel(args.root), file, sort_keys=True)
            file.write("\n")
    else:
        audit(args.root, args.coverage, args.primary, args.replay, args.baseline, args.previous)
