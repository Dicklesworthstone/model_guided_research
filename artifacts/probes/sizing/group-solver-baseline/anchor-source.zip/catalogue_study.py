"""Compare exhaustive rooted group shapes with solver and local closure."""

import argparse
import json
import random
import resource
import subprocess
from collections import Counter, deque
from itertools import permutations, product
from pathlib import Path
from time import monotonic_ns, process_time_ns

from active import ANCHORS
from base_study import fitting_learning, oracle_table

from scripts.group_rewrite_probe import teach_panel_case

SPECS = (
    ("two-by-seven-torus", "torus", (2, 7), ("F", "F")),
    ("decagon-mirrors", "ring", (10,), ("T", "FT")),
    ("dodecagon-turn-first", "ring", (12,), ("T", "F")),
    ("two-by-three-torus", "torus", (2, 3), ("F", "F")),
    ("two-by-five-torus", "torus", (2, 5), ("F", "F")),
    ("two-by-six-torus", "torus", (2, 6), ("F", "F")),
    ("four-by-four-torus", "torus", (4, 4), ("F", "F")),
    ("symmetric-four", "s4", (), ("T", "T")),
)
ARMS = ("square", "reuse", "catalogue")
GROUP_COUNTS = {6: 2, 10: 2, 12: 5, 14: 2, 16: 14, 20: 5, 24: 15}
MARKS = ((1, 2, 3, 0), (1, 0, 2, 3))

type Shape = tuple[tuple[int, int], ...]


def canonical(table, a, b):
    frontier = deque([0])
    index = {0: 0}
    result = []
    while frontier:
        state = frontier.popleft()
        targets = (table[state][a], table[state][b])
        for target in targets:
            if target not in index:
                index[target] = len(index)
                frontier.append(target)
        result.append((index[targets[0]], index[targets[1]]))
    return tuple(result)


def catalogue(raw):
    gap, smallgrp, records = raw
    expected = [(n, i) for n, count in GROUP_COUNTS.items() for i in range(1, count + 1)]
    if (gap, smallgrp) != ("4.16.1", "1.7.0") or [tuple(row[:2]) for row in records] != expected:
        raise ValueError("Unexpected library versions or incomplete group ID inventory")
    shapes: dict[int, set[Shape]] = {n: set() for n in GROUP_COUNTS}
    for n, _, table in records:
        for a, b in product(range(n), repeat=2):
            action = canonical(table, a, b)
            if len(action) == n:
                shapes[n].add(action)
    return {n: sorted(forms) for n, forms in shapes.items()}


def endpoint(shape, word):
    state = 0
    for symbol in word:
        state = shape[state][int(symbol)]
    return state


def fitting_names(shape, facts):
    by_state = {}
    by_name = {}
    for word, label in facts.items():
        state = endpoint(shape, word)
        if by_state.setdefault(state, label) != label or by_name.setdefault(label, state) != state:
            return None
    return by_state


def access_words(shape):
    queue = deque((word, endpoint(shape, word)) for word in ANCHORS)
    seen = set()
    while queue:
        word, state = queue.popleft()
        if state not in seen:
            seen.add(state)
            yield word
            queue.extend((word + str(mark), dest) for mark, dest in enumerate(shape[state]))


def complete_names(mapping, names):
    free = iter(sorted(names.difference(mapping.values())))
    return [mapping[i] if i in mapping else next(free) for i in range(len(names))]


def distinguishing_pair(first, second, names):
    a, known_a = first
    b, known_b = second
    labels_a, labels_b = complete_names(known_a, names), complete_names(known_b, names)
    queue = deque((w, endpoint(a, w), endpoint(b, w)) for w in ANCHORS)
    visited = set()
    while queue:
        word, x, y = queue.popleft()
        if labels_a[x] != labels_b[y]:
            return word
        if (x, y) not in visited:
            visited.add((x, y))
            queue.extend((word + str(mark), a[x][mark], b[y][mark]) for mark in range(2))
    raise ValueError("Different canonical actions have identical labeled endpoints")


def choose_query(candidates, words, facts, names):
    free = len(names) - len(set(facts.values()))
    if len(candidates) > 1:
        words.add(distinguishing_pair(candidates[0], candidates[1], names))
    best = None
    for word in words - facts.keys():
        buckets = Counter(mapping.get(endpoint(shape, word)) for shape, mapping in candidates)
        unnamed = buckets.pop(None, 0)
        # Divide the concrete survivor count by a common factorial.
        worst = max(unnamed, max(buckets.values(), default=0) * max(1, free))
        score = (worst, len(word), word)
        if best is None or score < best:
            best = score
    if best is None or best[0] >= len(candidates) * max(1, free):
        raise ValueError("No informative query for a non-singleton version space")
    return best[2], best[0]


def catalogue_learning(initial, names, ask, shapes):
    facts = dict(initial)
    events = []
    possible = shapes
    for _ in range(65):
        viable = [(shape, mapping) for shape in possible if (mapping := fitting_names(shape, facts)) is not None]
        if not viable:
            raise ValueError("Catalogue lacks any action consistent with the transcript")
        if len(viable) == 1 and len(set(facts.values())) >= len(names) - 1:
            shape, mapping = viable[0]
            labels = complete_names(mapping, names)
            right = {
                str(mark): {labels[i]: labels[dest[mark]] for i, dest in enumerate(shape)} for mark in range(2)
            }
            return right, events, "unique-catalogue"
        shortlist = {word for shape, _ in viable for word in access_words(shape)}
        word, worst = choose_query(viable, shortlist, facts, names)
        answer = ask(word)
        facts[word] = answer
        events.append({"word": word, "answer": answer, "shapes": len(viable), "worst": worst})
        possible = [shape for shape, _ in viable]
    closure, _ = teach_panel_case(facts, names, ask, squares=True)
    return {mark: closure.maps["R" + mark] for mark in "01"}, events, "query-cap"


def oracle(spec):
    _, kind, dimensions, commands = spec
    if kind != "s4":
        return oracle_table(kind, dimensions, commands)
    elements = list(permutations(range(4)))
    lookup = {p: i for i, p in enumerate(elements)}
    return tuple(tuple(lookup[tuple(p[j] for j in mark)] for p in elements) for mark in MARKS)


def run_case(spec, index, shapes):
    columns = oracle(spec)
    labels = [f"opaque{i:02d}" for i in range(len(columns[0]))]
    random.Random(251501 + index).shuffle(labels)
    names = set(labels)
    action = tuple(zip(*columns, strict=True))

    def observe(word):
        return labels[endpoint(action, word)]

    initial = {word: observe(word) for word in ANCHORS}
    arms = {}
    offset = index % len(ARMS)
    for arm in ARMS[offset:] + ARMS[:offset]:
        paid = []

        def ask(word, tape=paid):
            answer = observe(word)
            tape.append([word, answer])
            return answer

        start_wall, start_cpu = monotonic_ns(), process_time_ns()
        before = resource.getrusage(resource.RUSAGE_CHILDREN)
        trace = None
        if arm == "square":
            closure, _ = teach_panel_case(initial, names, ask, squares=True)
            right = {mark: closure.maps["R" + mark] for mark in "01"}
            events, terminal = [], "closure"
        elif arm == "reuse":
            right, events, terminal, trace = fitting_learning(
                initial, names, ask, exhausted=False, reuse=True, rank=False
            )
        else:
            right, events, terminal = catalogue_learning(initial, names, ask, shapes[len(names)])
        after = resource.getrusage(resource.RUSAGE_CHILDREN)
        cpu = process_time_ns() - start_cpu + round(
            1e9 * (after.ru_utime + after.ru_stime - before.ru_utime - before.ru_stime)
        )
        arms[arm] = {
            "right": right, "paid": paid, "events": events, "terminal": terminal, "trace": trace,
            "cpu_ns": cpu, "wall_ns": monotonic_ns() - start_wall,
        }
    return {"spec": spec, "labels": labels, "initial": initial, "arms": arms}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("catalogue", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    z3 = subprocess.check_output(["z3", "--version"], text=True, timeout=5).strip()
    if not z3.startswith("Z3 version 4.15.4 "):
        raise ValueError(f"Unexpected Z3 version: {z3}")
    start = process_time_ns()
    try:
        raw = json.loads(args.catalogue.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        parser.error(str(error))
    shapes = catalogue(raw)
    offline_cpu_ns = process_time_ns() - start
    rows = []
    for i, spec in enumerate(SPECS):
        row = run_case(spec, i, shapes)
        print(spec[0], *(row["arms"][arm]["terminal"] for arm in ARMS), flush=True)
        rows.append(row)
    with args.output.open("x", encoding="utf-8") as handle:
        json.dump({
            "cases": rows, "sizes": {n: len(forms) for n, forms in shapes.items()}, "z3": z3,
            "offline_cpu_ns": offline_cpu_ns,
        }, handle, sort_keys=True)
        handle.write("\n")


if __name__ == "__main__":
    main()
