"""Construct a frozen panel and independently replay commutator-seeded Klein lifts."""

import argparse
import hashlib
import json
import random
from collections import Counter
from itertools import permutations, product
from pathlib import Path

from check_alternating_route import PANEL, PRIOR, digests
from check_commutator_route import CONTROLS, graph_for, normalized
from check_fifth_power_route import ARMS as PREVIOUS_ARMS
from check_fifth_power_route import REPLAYS as OLDER_REPLAYS
from check_fifth_power_route import TARGETS as FIFTH_TARGETS
from check_fifth_power_route import model as earlier_model
from check_klein_route import order, verify_lift, verify_rejection
from check_short_certificate import action, answers, checksum, read, validate_tape, walk

SEED = 251771
TARGET, OUTSIDE = "a4xc10", "d8xc15"
REPLAYS = (*OLDER_REPLAYS, *FIFTH_TARGETS)
ARMS = (*PREVIOUS_ARMS, "involution")


def model(family):
    if family in {"d8", OUTSIDE}:
        modulus = 1 if family == "d8" else 15

        def multiply(left, right):
            a, b, c = left
            d, e, f = right
            return (a + (-d if b else d)) % 4, (b + e) % 2, (c + f) % modulus

        return list(product(range(4), range(2), range(modulus))), (0, 0, 0), multiply
    if family == "a4xc2":
        even = [p for p in permutations(range(4)) if sum(p[i] > p[j] for i in range(4) for j in range(i + 1, 4)) % 2 == 0]

        def multiply(left, right):
            return tuple(right[i] for i in left[:4]) + ((left[-1] + right[-1]) % 2,)

        return [p + (k,) for p, k in product(even, range(2))], (0, 1, 2, 3, 0), multiply
    return earlier_model(family)


def make_panel(root):
    latest = read(root / PANEL / "fifth-power-route-coverage.json")
    history = (*PRIOR, *(PANEL / f"{name}-route-coverage.json" for name in ("alternating", "commutator", "klein")))
    used = {identifier for path in history for identifier in digests(read(root / path))} | set(digests(latest))
    rng = random.Random(SEED)
    cases = []
    for family, requested in ((TARGET, 8), (OUTSIDE, 6)):
        pool, identity, multiply = model(family)
        count = 0
        for _ in range(10_000):
            marks = rng.choice(pool), rng.choice(pool)
            graph = graph_for(marks, identity, multiply)
            identifier = checksum(graph)
            if len(graph) == 120 and identifier not in used:
                cases.append(dict(family=family, marks=list(map(list, marks)), graph=graph, graph_sha=identifier))
                used.add(identifier)
                count += 1
                if count == requested:
                    break
        if count != requested:
            raise ValueError(f"Insufficient new cases for {family}")
    for family in REPLAYS:
        cases.extend([row for row in latest["cases"] if row["family"] == family][:2])
    return dict(seed=SEED, cases=cases)


def verify_witness(graph, witness, commutator, orders):
    verify_lift(graph, witness)
    d, e = witness["basis"]
    if d != commutator or not answers(graph, ("01", d + "10")) or orders != tuple(order(graph, mark) for mark in "01"):
        raise ValueError("Incorrect paid commutator or generator orders")
    kernel = "", d, e, d + e
    odd = len(witness["quotient"]) % 2 == 1
    if witness["quotient_oracle"] != ("square" if odd else "cosets") or not witness["quotient_queries"]:
        raise ValueError("Invalid quotient oracle choice or missing trace")
    for left, right, reply in witness["quotient_queries"]:
        expected = any(answers(graph, (left, offset + right)) for offset in kernel)
        if reply is not expected:
            raise ValueError("Quotient equality disagrees with explicit cosets")
        if odd:
            inverse = "".join(mark * (orders[int(mark)] - 1) for mark in reversed(right))
            if (walk(graph, (left + inverse) * 2) == 0) != expected:
                raise ValueError("Odd quotient square comparison is wrong")


def census():
    from scripts.group_student_probe import _try_klein_four_quotient

    results = {}
    for family in ("a4", "a4xc2", "d8"):
        pool, identity, multiply = model(family)
        count = maximum = false_square = 0
        modes = Counter()
        for marks in product(pool, repeat=2):
            graph = graph_for(marks, identity, multiply)
            if len(graph) != len(pool):
                continue
            paid = 0

            def equal(left, right, table=graph):
                nonlocal paid
                paid += 1
                return answers(table, (left, right))

            if equal("01", "10"):
                raise ValueError("Unexpected abelian transfer case")
            order_a, order_b = (next(k for k in range(1, len(pool) + 1) if equal(mark * k, "")) for mark in "01")
            orders = (order_a, order_b)
            c = "01" + "0" * (order_a - 1) + "1" * (order_b - 1)
            paid = 0
            recovered, witness = _try_klein_four_quotient(len(pool), equal, orders, commutator=c)
            if family == "d8":
                if recovered is not None or witness.get("rejected") != "central_involution":
                    raise ValueError("The central-involution control did not refuse")
                verify_rejection(graph, witness)
            else:
                if recovered is None or [list(row) for row in recovered] != graph:
                    raise ValueError("Transfer action did not recover")
                verify_witness(graph, witness, c, orders)
                modes[witness["quotient_oracle"]] += 1
                if family == "a4xc2":
                    d, e = witness["basis"]
                    mark_index = next(index for index, mark in enumerate(marks) if mark[-1])
                    involution = str(mark_index) * (orders[mark_index] // 2)
                    if walk(graph, involution * 2) != 0 or any(answers(graph, (involution, word)) for word in ("", d, e, d + e)):
                        raise ValueError("The even quotient should contain a false square match")
                    false_square += 1
            count += 1
            maximum = max(maximum, paid)
        if count == 0:
            raise ValueError("Empty transfer coverage")
        results[family] = dict(order=len(pool), generating_pairs=count, maximum_branch_calls=maximum,
                               quotient_modes=modes, invalid_square_matches=false_square)
    return results


def audit(root, coverage, primary, repeat, baseline, previous):
    manifest, scored, replay, baseline, previous = map(read, (coverage, primary, repeat, baseline, previous))
    if manifest != make_panel(root) or scored["coverage_sha256"] != hashlib.sha256(coverage.read_bytes()).hexdigest():
        raise ValueError("Wrong frozen panel")
    current = normalized(scored)
    if current != normalized(replay):
        raise ValueError("Hash seed changed the non-timing record")
    prior = {row["graph_sha"]: row["arms"]["fifth_power"] for row in normalized(previous)["results"]}
    counts = {family: {arm: Counter() for arm in ARMS} for family in (TARGET, OUTSIDE, *REPLAYS)}
    branches = []
    forged_checked = False
    for case, row, clean in zip(manifest["cases"], scored["results"], current["results"], strict=True):
        family = case["family"]
        if family in CONTROLS:
            graph = action(family, case["marks"])[0]
        else:
            _, identity, multiply = model(family)
            graph = graph_for(case["marks"], identity, multiply)
        identifier = checksum(graph)
        if graph != case["graph"] or identifier != case["graph_sha"] or (identifier, family) != (row["graph_sha"], row["family"]):
            raise ValueError("Independent reconstruction differs")
        if set(row["arms"]) != set(ARMS):
            raise ValueError("Missing benchmark arm")
        for name, arm in row["arms"].items():
            validate_tape(graph, arm["paid"])
            if arm["right"] != graph:
                raise ValueError("Incorrect action")
            counts[family][name].update(calls=len(arm["paid"]), symbols=sum(len(a) + len(b) for a, b, _ in arm["paid"]), cpu_ns=arm["cpu_ns"])
        candidate = clean["arms"].pop("involution")
        incumbent = clean["arms"]["fifth_power"]
        if family in REPLAYS:
            if candidate != incumbent or incumbent != prior[identifier]:
                raise ValueError("Already solved controls changed")
            continue
        witness = candidate["involution"]
        tail = clean["arms"]["fallback"]["paid"]
        prefix = incumbent["paid"][:-len(tail)]
        if incumbent["paid"] != prefix + tail or candidate["paid"][:len(prefix)] != prefix:
            raise ValueError("Common prefix or original fallback differs")
        if family == OUTSIDE:
            added = len(candidate["paid"]) - len(incumbent["paid"])
            if witness.get("rejected") != "central_involution" or not 0 < added <= 3 or candidate["paid"][-len(tail):] != tail:
                raise ValueError("Outside rejection or its cost failed")
            verify_rejection(graph, witness)
            branches.append(dict(family=family, branch_calls=added, reason=witness["rejected"]))
        else:
            c, orders = candidate["commutator"]["word"], tuple(candidate["commutator"]["orders"])
            verify_witness(graph, witness, c, orders)
            branches.append(dict(family=family, branch_calls=len(candidate["paid"]) - len(prefix), quotient_mode=witness["quotient_oracle"]))
            if not forged_checked:
                corrections = [list(row) for row in witness["corrections"]]
                corrections[0][0] ^= 1
                try:
                    verify_witness(graph, dict(witness, corrections=corrections), c, orders)
                except ValueError:
                    forged_checked = True
                else:
                    raise ValueError("Forged lift accepted")
    if current != normalized(baseline):
        raise ValueError("The incumbent CLI changed")
    target = counts[TARGET]
    before, after = target["fifth_power"]["calls"], target["involution"]["calls"]
    print(json.dumps(dict(
        exact=True, default_unchanged=True, forged_correction_rejected=forged_checked,
        checked_transitions=30 * 120 * 2 * len(ARMS), gate=10 * after <= 3 * before,
        incumbent_calls=before, involution_calls=after, totals=counts, branches=branches, census=census(),
    ), indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    modes = parser.add_subparsers(dest="mode", required=True)
    for name in ("cover", "audit"):
        mode = modes.add_parser(name)
        mode.add_argument("root", type=Path)
        mode.add_argument("coverage", type=Path)
    for name in ("primary", "repeat", "baseline", "previous"):
        mode.add_argument(name, type=Path)
    args = parser.parse_args()
    if args.mode == "cover":
        with args.coverage.open("x", encoding="utf-8") as file:
            json.dump(make_panel(args.root), file, sort_keys=True)
            file.write("\n")
    else:
        audit(args.root, args.coverage, args.primary, args.repeat, args.baseline, args.previous)
