"""Measure token exposure in corpus equivalents for the copy operation baselines."""
from hashlib import sha256
import json
from pathlib import Path
import sys

import pyarrow.parquet as pq
from nanochat.tokenizer import checkpoint_tokenizer

jsonfile = lambda f: json.loads(f.read_bytes())
project, research, output = map(Path, sys.argv[1:])
rows = []
for budget, root, token_root in (
    ("1T", project/"scorecards/vdc4-copyops-tasktok-shuf-b1-rung", research/"copyops-lrprobe/nanochat/lr4x-s0/checkpoints"),
    ("2T", research/"scorecards/vdc4-copyops-tasktok-shuf-b2-rung", None),
    ("4T", research/"scorecards/vdc4-copyops-tasktok-shuf-b4-rung", None),
    ("10T", research/"scorecards/vdc4-copyops-tasktok-shuf-b10-s64-rung", None),
):
    runs = root/"runs/budget_0/copyops/standard"
    ckpt = token_root or runs/"seed_0/checkpoints"
    vocab = ckpt/"tokenizer/tokenizer.json"
    digest = sha256(vocab.read_bytes()).hexdigest()
    meta = jsonfile(next(ckpt.glob("meta_*.json")))
    tok = checkpoint_tokenizer(ckpt, meta)
    datadir = root/"data/copyops"
    manifest = jsonfile(datadir/"manifest.json")
    total = docs = 0
    for shard in sorted(datadir.glob("train_*.parquet")):
        assert sha256(shard.read_bytes()).hexdigest() == manifest["sha256"][shard.name]
        for batch in pq.ParquetFile(shard).iter_batches(batch_size=1024, columns=["text"]):
            strings = batch.column(0).to_pylist()
            total += sum(map(len, tok.encode(strings, prepend=tok.get_bos_token_id())))
            docs += len(strings)
    assert docs == manifest["split_sizes"]["train"]
    for seed in range(3):
        train = jsonfile(runs/f"seed_{seed}/summary.json")
        eval_meta = jsonfile(root/f"evals/tasks/eval-b0-copyops-standard-s{seed}/summary.json")["meta"]
        assert train["hparams"]["data_shuffle"] == "epoch" and eval_meta["evaluator"]["bos_prefixed"]
        consumed = train["results"]["measured_tokens"]
        assert consumed == train["budget"]["max_steps"] * train["budget"]["tokens_per_step_global"]
        if token_root is None:
            assert sha256((runs/f"seed_{seed}/checkpoints/tokenizer/tokenizer.json").read_bytes()).hexdigest() == digest
        rows.append(dict(budget=budget, seed=seed, documents=docs, train_tokens_including_bos=total, training_tokens=consumed,
                         corpus_equivalents=consumed/total, tokenizer_sha256=digest,
                         tokenizer_source=("retrained on the hash-verified original 1T corpus" if token_root else "original checkpoint")))
output.write_text(json.dumps(dict(rows=rows), indent=2)+"\n")
