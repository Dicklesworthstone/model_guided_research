# Cost-sensitive generalized binary search on the same oracle

Use all 368 distinct rooted and marked actions at the seven audited orders.
Orders 10 and 12 form the primary panel. Order 6 connects to the published
exact optimum. The remaining four orders probe transfer. Rebuild the full
census from the pinned Cayley tables and weight each shape equally per
order. A complete public roster is given before each run. Each learner pays
for the same four anchors and receives only the opaque endpoint of each
queried reset word. A reset and read costs 16 and both commands cost one.
Stop after the fixed census. This is a finite symbolic comparison.

Run live square closure, shortlist, exhaustive shortest frontier, and
cost-sensitive generalized binary search (GBS). The latter applies the
expected version-space mass reduction per query cost from Guillory and
Bilmes (2009) and Golovin, Krause, and Ray (2010, section 2). Use the bounded
menu of all words of lengths two through six and every indexed word.
If none can distinguish any viable labeled hypotheses, use the shortest
frontier. Use the same structure-phase cap and optimal residual naming
rule as the other catalogue arms. Compare to the published order-6 optimum
after replay. [Average-Case Active Learning with Costs](https://arxiv.org/abs/0905.2997) ·
[GBS gain and notation](https://www.cs.cmu.edu/~dgolovin/papers/nips10.pdf)

At a history with `s` compatible shapes and `f` unseen labels, each shape
has `f!` equally weighted named completions. A query divides the shapes
into known-reply counts `b_j` and an unseen bucket `u`. Each shape in the
unseen bucket can yield any remaining name. In units of `(f-1)!`, the
individual reply-bin masses are `f b_j` for seen replies and `u` for each
of the `f` unseen replies. The expected removed mass has the same ordering
as `(s f)^2 - f^2 sum(b_j^2) - f u^2`. Divide by the paid query cost and
break ties by shortlex. With zero unseen names, each shape has a single
completion and the gain numerator becomes `s^2 - sum(b_j^2)`. Explicit
enumeration of tiny named hypotheses checks the score. The adaptation
compares a finite candidate menu on this oracle. It does not claim the
published approximation guarantee for this budgeted implementation.

The preregistered utility prediction requires every GBS case to recover
an exact table without the structural cap fallback and a pooled weighted
cost at orders 10 and 12 at least 2% lower than the better of the two
original catalogue controls. Report all per-order totals and paid counts,
number and magnitude of regressions, cap fallbacks, and host index,
compile and online CPU. Keep the prices, menu and denominators fixed.

Make two independent processes with different names, roster order, hash
seeds and reversed arm and case execution order. Replay the table and
every paid endpoint against the reference tables. Recount the three
charges and require identical normalized tapes. On the three previously
scored orders, require the released controls to reproduce their archived
word sequences. Scope the resulting claims to the oracle and inventory.
No physical measurement, novelty for GBS itself, or model-guided gain is
inferred from these runs.
