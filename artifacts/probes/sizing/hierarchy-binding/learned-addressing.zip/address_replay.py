import hashlib
import json
import math
import sys
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

from address_fixtures import ARMS, CELLS, DIM, POOLS, SEEDS, code, evaluation, feature, sha_json, training

SOURCE = "aa66627f557e8d4ab0423f126d1cdb6748aa2dff"
LOCK = "fb5619167973f23bad0d6501f939511cfcd689337df6675617781b73e45492db"
FILES = ("address_fixtures.py", "address_fit.py", "address_fit.yaml", "frozen.sha256", "protocol.txt",
         "address_replay.py", "method.md", "replay.yaml", *(f"fit-{seed}.json" for seed in SEEDS))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def receipt_id(read, files):
    path, = (name for name in files if name.endswith("/receipt.json"))
    receipt = json.loads(read(path))
    assert receipt["tool"] == "hierarchy-learned-addressing" and receipt["status"] == "passed"
    assert receipt["executed"] == receipt["passed"] == receipt["total"] == 1
    assert not receipt["dry_run"] and not receipt["skipped"]
    check, = receipt["checks"]
    assert check["passed"] and check["executed"] and check["exit_code"] == 0
    log = Path(path).with_name(Path(check["log_path"]).name).as_posix()
    assert sha(read(log)) == check["log_sha256"]
    config = Path(path).with_name(Path(receipt["config_snapshot_path"]).name).as_posix()
    assert read(config) == read("address_fit.yaml")
    assert sha(read(config)) == receipt["config_sha256"] == receipt["config_sha256_after"]
    return Path(path).parent.name


def inverse(pointer, namespace):
    perm, sign = namespace
    pointer ^= sign
    return sum((1 << src) for coord, src in enumerate(perm) if pointer & (1 << coord))


def validate(doc, depth, parity, namespace):
    keys, links = doc["keys"], doc["link"]
    size = (1 << (depth + 1)) - 1
    assert len(keys) == len(set(keys)) == len(links) == size
    assert all(key.bit_count() % 2 == parity for key in keys)
    positions = {key: slot for slot, key in enumerate(keys)}
    known = [[positions[inverse(pointer, namespace)] for pointer in pair] for pair in links]
    assert known == doc["edge"]
    chain = [positions[inverse(doc["root"], namespace)]]
    assert len(doc["query"]) == depth
    for alias in doc["query"]:
        chain.append(known[chain[-1]][alias])
    assert chain == doc["chain"] and len(set(chain)) == len(chain)
    leaves = {slot for slot, row in enumerate(known) if row == [slot, slot]}
    assert len(leaves) == 1 << depth
    compatible = doc["candidates"]
    assert len(compatible) == len(set(compatible)) == 1 << (depth - 1)
    assert set(compatible) <= leaves and chain[-1] in compatible


def validate_pairs(docs, depth, parity, namespace):
    for left, right in zip(docs[::2], docs[1::2], strict=True):
        for doc in (left, right):
            validate(doc, depth, parity, namespace)
        assert all(left[name] == right[name] for name in ("keys", "root", "query"))
        edit, = (i for i, (a, b) in enumerate(zip(left["link"], right["link"], strict=True)) if a != b)
        assert left["link"][edit] == right["link"][edit][::-1]
        position = left["chain"].index(edit)
        assert right["chain"][:position + 1] == left["chain"][:position + 1]
        assert right["chain"][-1] != left["chain"][-1]
        assert list(map(sorted, left["link"])) == list(map(sorted, right["link"]))
        a, b = set(left["candidates"]), set(right["candidates"])
        assert a == b or a.isdisjoint(b)


def score_table(matrix, namespace):
    assert len(matrix) == DIM and all(len(row) == DIM and all(map(math.isfinite, row)) for row in matrix)
    columns = list(zip(*matrix, strict=True))
    candidates = {key: feature(key) for key in POOLS[1]}
    table = {}
    for pointer in range(1 << DIM):
        if inverse(pointer, namespace) not in candidates:
            continue
        coords = feature(pointer)
        projected = [math.fsum(x * w for x, w in zip(coords, column, strict=True)) for column in columns]
        table[pointer] = {key: math.fsum(x * w for x, w in zip(vector, projected, strict=True))
                          for key, vector in candidates.items()}
    assert len(table) == 128
    return table


def greedy(doc, scores, reverse=False, erased=False):
    indices = range(len(doc["keys"]))
    if reverse:
        indices = indices[::-1]
    ties = 0

    def lookup(pointer):
        nonlocal ties
        choices = scores[pointer]
        ranked = [choices[doc["keys"][index]] for index in indices]
        best = max(ranked)
        ties += ranked.count(best) > 1
        return indices[ranked.index(best)]

    links = list(map(sorted, doc["link"])) if erased else doc["link"]
    trace = [lookup(doc["root"])]
    for alias in doc["query"]:
        trace.append(lookup(links[trace[-1]][alias]))
    return trace, ties


def summarize(panel, traces, table, depth):
    full, terminal, erased, reordered = [], [], [], []
    hop_correct = [0] * (depth + 1)
    ties = 0
    for doc, observed in zip(panel, traces, strict=True):
        reference, tied = greedy(doc, table)
        assert observed == reference
        reversed_trace, _ = greedy(doc, table, reverse=True)
        erased_trace, _ = greedy(doc, table, erased=True)
        gold = doc["chain"]
        full.append(reference == gold)
        terminal.append(reference[-1] == gold[-1])
        erased.append(erased_trace == gold)
        reordered.append(reference == reversed_trace)
        ties += tied
        for hop, (predicted, want) in enumerate(zip(reference, gold, strict=True)):
            hop_correct[hop] += predicted == want

    def paired(exact):
        return sum(a and b for a, b in zip(exact[::2], exact[1::2], strict=True))

    return dict(full_pairs=paired(full), terminal_pairs=paired(terminal), erased_pairs=paired(erased),
                reversal_agreement=sum(reordered), full_docs=sum(full), docs=len(full), tied_lookups=ties,
                correct_at_hop=hop_correct)


def check_namespace(table, namespace):
    margins = []
    for pointer, scores in table.items():
        key = inverse(pointer, namespace)
        margins.append(scores[key] - max(score for candidate, score in scores.items() if key != candidate))
    return dict(strict_matches=sum(margin > 0 for margin in margins), keys=len(margins), min_margin=min(margins))


def replay(read, files):
    lock = read("frozen.sha256")
    assert sha(lock) == LOCK
    for line in lock.decode().splitlines():
        digest, path = line.split()
        assert sha(read(path)) == digest
    results = {}
    primary = []
    exact_oracle_pairs = 0
    for seed in SEEDS:
        namespace = code(seed)
        train, panel = training(seed), evaluation(seed)
        assert len(train) == 1536
        validate_pairs(train, 2, 0, namespace)
        for depth, pairs in CELLS:
            docs = panel[str(depth)]
            assert len(docs) == 2 * pairs
            validate_pairs(docs, depth, 1, namespace)
            exact_oracle_pairs += len(docs) // 2
        raw = json.loads(read(f"fit-{seed}.json"))
        assert raw["seed"] == seed and raw["steps"] == 288
        assert raw["namespace"] == [*namespace] and raw["train"] == sha_json(train) and raw["panel"] == sha_json(panel)
        assert tuple(raw["matrices"]) == tuple(raw["trace"]) == ARMS and set(raw["losses"]) == {"direct", "weak"}
        assert all(len(series) == 288 and all(math.isfinite(x) and x >= 0 for x in series)
                   for series in raw["losses"].values())
        assert raw["matrices"]["raw"] == [[int(i == j) for j in range(DIM)] for i in range(DIM)]
        arms = {}
        for name, matrix in raw["matrices"].items():
            table = score_table(matrix, namespace)
            arms[name] = {str(depth): summarize(panel[str(depth)], raw["trace"][name][str(depth)], table, depth)
                          for depth, _ in CELLS}
            arms[name]["namespace"] = check_namespace(table, namespace)
            if name in raw["losses"]:
                losses = raw["losses"][name]
                arms[name]["mean_train_loss_first_last_96"] = [sum(losses[:96]) / 96, sum(losses[-96:]) / 96]
        for depth in ("2", "3", "4"):
            weak, direct, raw_dot = (arms[name][depth] for name in ("weak", "direct", "raw"))
            primary.append(weak["full_pairs"] >= 34 and direct["full_pairs"] >= 34
                           and weak["erased_pairs"] == 0
                           and weak["reversal_agreement"] == weak["docs"]
                           and (depth == "2" or weak["full_pairs"] >= raw_dot["full_pairs"] + 18))
        results[str(seed)] = arms
    assert len(primary) == 9 and exact_oracle_pairs == 360
    return dict(source=SOURCE, fit_receipt=receipt_id(read, files), primary_pass=sum(primary),
                primary_total=len(primary), gate=all(primary), exact_oracle_pairs=exact_oracle_pairs, results=results)


def verify(path):
    with ZipFile(path) as archive:
        names = archive.namelist()
        assert archive.testzip() is None and len(names) == len(set(names))
        decision = replay(archive.read, names)
        assert decision == json.loads(archive.read("decision.json"))
    print(json.dumps(decision))


def build(root, bundle):
    files = {name: root / name for name in FILES}
    receipt, = (root / "receipts").glob("*/*/receipt.json")
    for name in ("receipt.json", "check-1.log", "checks-config.yaml"):
        path = receipt.with_name(name)
        files[path.relative_to(root).as_posix()] = path
    decision = replay(lambda name: files[name].read_bytes(), files.keys())
    with ZipFile(bundle, "x", compression=ZIP_DEFLATED) as archive:
        for name, path in files.items():
            archive.write(path, name)
        archive.writestr("decision.json", json.dumps(decision, indent=2) + "\n")
    print(json.dumps(decision))


if __name__ == "__main__":
    mode, *args = sys.argv[1:]
    {"build": build, "verify": verify}[mode](*map(Path, args))
