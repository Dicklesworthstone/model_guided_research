import json
import sys
from pathlib import Path

import torch

sys.path.insert(0, str(Path.cwd()))
from cli import _eval_score_doc, _eval_split_examples, _load_eval_checkpoint
from nanochat.diagnostics_data import TASKS
from nanochat.tokenizer import checkpoint_tokenizer

root = Path(sys.argv[1])
spec = TASKS["hier"]
device = torch.device("cpu")
panels = {seed: _eval_split_examples(spec, n=24, seed=seed)[0] for seed in (0, 1, 2)}
for run_id in sys.argv[2:]:
    directory = root / "runs" / "standard" / run_id
    interaction = json.loads((directory / "answer-interaction.json").read_bytes())
    candidate = directory / "checkpoints"
    model, meta, step = _load_eval_checkpoint(candidate, None, device, fingerprint_weights=True)
    assert interaction["checkpoint_sha256"] == meta["weights_sha256"]
    assert interaction["checkpoint_step"] == step
    tok = checkpoint_tokenizer(candidate, meta)
    rows = []
    for row in interaction["rows"]:
        if "other_query" not in row:
            continue
        document = panels[row["seed"]][row["index"]]
        tree = document.split(" PATH ", maxsplit=1)[0]
        changed = f"{tree} PATH {' '.join(row['other_query'])} OUT {row['other_answer']}"
        assert row["answer"] != row["other_answer"]
        correct = []
        for text in (document, changed):
            assert spec.checker(text) is True
            scored = _eval_score_doc(model, tok, spec, text, device=device, temperature=0.0, seed=row["seed"])
            assert scored is not None
            correct.append(scored[0])
        rows.append(dict(seed=row["seed"], index=row["index"], correct=correct))
    report = {
        "run_id": run_id, "weights_sha256": meta["weights_sha256"], "pairs": len(rows),
        "original_correct": sum(row["correct"][0] for row in rows),
        "changed_correct": sum(row["correct"][1] for row in rows),
        "both_correct": sum(all(row["correct"]) for row in rows),
        "query_blind_both_correct_ceiling": 0,
        "rows": rows,
    }
    with (directory / "paired-accuracy.json").open("x", encoding="utf-8") as output:
        output.write(json.dumps(report, indent=2) + "\n")
    print(json.dumps({key: value for key, value in report.items() if key != "rows"}))
