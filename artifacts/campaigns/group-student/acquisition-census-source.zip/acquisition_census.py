"""Run the released acquisition policies on the complete marked-action inventory."""

import json
import sys
from pathlib import Path
from time import monotonic_ns, process_time_ns

from catalogue_replay import read
from catalogue_study import ANCHORS, endpoint
from cold_catalogue import reduced_shapes
from four_anchor import digest, measure, prepare
from incumbent.four_anchor import measure as measure_square


def labelled_roster(n, slot, reverse):
    slope, offset = (19, 7 * slot + 11) if reverse else (17, 13 * slot + 7)
    return [str((slope * i + offset) % n) for i in range(n)]


def run(library, output, reverse):
    started_cpu, started_wall = process_time_ns(), monotonic_ns()
    raw = read(library)
    shapes, counts, _ = reduced_shapes(raw, lattices=True)
    builder = dict(cpu_ns=process_time_ns() - started_cpu, wall_ns=monotonic_ns() - started_wall)
    started_cpu, started_wall = process_time_ns(), monotonic_ns()
    indices = {n: prepare(forms) for n, forms in shapes.items()}
    preparation = dict(cpu_ns=process_time_ns() - started_cpu, wall_ns=monotonic_ns() - started_wall)

    rows = []
    for n, forms in shapes.items():
        index = indices[n]
        for slot, action in enumerate(forms):
            names = labelled_roster(n, slot, reverse)

            def evaluate(word, graph=action, labels=names):
                return labels[endpoint(graph, word)]

            start_cpu, start_wall = process_time_ns(), monotonic_ns()
            anchors = {word: evaluate(word) for word in ANCHORS}
            initial = dict(cpu_ns=process_time_ns() - start_cpu, wall_ns=monotonic_ns() - start_wall)
            order = ("square", "length") if (slot % 2 == 0) != reverse else ("length", "square")
            arms = {}
            for arm in order:
                if arm == "square":
                    arms[arm] = measure_square(n, evaluate, index, anchors, "square")
                else:
                    arms[arm] = measure(n, evaluate, index, anchors, distances=None)
            rows.append(dict(order=n, slot=slot, anchors=anchors, initial=initial, arms=arms))
        print(f"Finished order {n}, {len(forms)} exact marked actions scored.", flush=True)
    with output.open("x", encoding="utf-8") as file:
        json.dump(dict(
            rows=rows, renamed=reverse, shape_digest=digest(shapes), builder=builder, preparation=preparation,
            shape_counts={n: len(forms) for n, forms in shapes.items()},
            traversals=sum(row["traversals"] for row in counts),
        ), separators=(",", ":"), sort_keys=True, fp=file)
        file.write("\n")


if __name__ == "__main__":
    run(Path(sys.argv[1]), Path(sys.argv[2]), reverse=sys.argv[3] == "reverse")
