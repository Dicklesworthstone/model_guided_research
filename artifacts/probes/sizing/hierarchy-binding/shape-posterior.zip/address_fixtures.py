import hashlib
import json
import random

DIM = 8
SEEDS = (9011, 9012, 9013)
CELLS = ((2, 36), (3, 36), (4, 36), (6, 12))
TRAIN_PAIRS = 768
ARMS = ("raw", "initial", "direct", "weak")
POOLS = tuple(tuple(x for x in range(1 << DIM) if x.bit_count() % 2 == parity) for parity in (0, 1))


def code(seed):
    rng = random.Random(seed + 10080)
    perm = rng.sample(range(DIM), DIM)
    sign_mask = rng.randrange(1 << DIM)
    return perm, sign_mask


def encode(value, perm, sign_mask):
    return sum(((value >> src) & 1) << dst for dst, src in enumerate(perm)) ^ sign_mask


def feature(key):
    return tuple(2 * ((key >> bit) & 1) - 1 for bit in range(DIM))


def make_pair(rng, depth, slot, pool, namespace):
    leaf_start = (1 << depth) - 1
    size = 2 * leaf_start + 1
    canonical = rng.sample(pool, size)
    order = rng.sample(range(size), size)
    slot_by_node = {node: pos for pos, node in enumerate(order)}
    outputs = [encode(key, *namespace) for key in canonical]
    query = [rng.randrange(2) for _ in range(depth)]
    switches = [rng.randrange(2) for _ in range(leaf_start)]
    colors = set(rng.sample(range(leaf_start, size), 1 << (depth - 1)))

    def orient():
        edges = [(2 * node + 1 + swap, 2 * node + 2 - swap) for node, swap in enumerate(switches)]
        edges.extend([(node, node) for node in range(leaf_start, size)])
        chain = [0]
        for alias in query:
            chain.append(edges[chain[-1]][alias])
        palette = [node for node in range(leaf_start, size) if (node in colors) == (chain[-1] in colors)]
        return dict(
            keys=[canonical[node] for node in order],
            link=[[outputs[left], outputs[right]] for node in order for left, right in [edges[node]]],
            root=outputs[0], query=query, chain=[slot_by_node[node] for node in chain],
            edge=[[slot_by_node[child] for child in edges[node]] for node in order],
            candidates=sorted(slot_by_node[node] for node in palette),
        )

    first = orient()
    switch = order[first["chain"][slot % depth]]
    switches[switch] ^= 1
    second = orient()
    assert first["chain"][-1] != second["chain"][-1]
    return first, second


def training(seed):
    rng = random.Random(seed + 21200)
    namespace = code(seed)
    return [doc for pair in range(TRAIN_PAIRS) for doc in make_pair(rng, 2, pair, POOLS[0], namespace)]


def evaluation(seed):
    namespace = code(seed)
    return {str(depth): [doc for pair in range(pairs) for doc in make_pair(
        rng, depth, pair, POOLS[1], namespace)]
            for depth, pairs in CELLS for rng in (random.Random(seed + 43100 + 200 * depth),)}


def sha_json(data):
    return hashlib.sha256(json.dumps(data, separators=(",", ":"), allow_nan=False).encode()).hexdigest()
