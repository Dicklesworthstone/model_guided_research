import hashlib
import json
import math
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path.cwd()))
from nanochat.tokenizer import HuggingFaceTokenizer

root, run = Path(sys.argv[1]), sys.argv[2]
directory = root / "evals" / "tasks" / run
summary = json.loads((directory / "summary.json").read_bytes())
panel = json.loads((root / "panel.json").read_bytes())
task = summary["tasks"]["hier_paired"]
training = root / "runs" / "standard" / run / "checkpoints"
tokenizer = HuggingFaceTokenizer.from_directory(str(training / "tokenizer"))
weights = training / f"model_{summary['meta']['checkpoint']['step']:06d}.pt"
with weights.open("rb") as handle:
    assert summary["meta"]["checkpoint"]["weights_sha256"] == hashlib.file_digest(handle, "sha256").hexdigest()
assert summary["meta"]["sizing_input"]
assert not summary["provenance"]["tainted"] and not summary["train_provenance"]["tainted"]
assert summary["provenance"]["git_sha"] == summary["train_provenance"]["git_sha"]
receipts = {}
for line in (directory / "generations.jsonl").read_text().splitlines():
    row = json.loads(line)
    key = row["region"], row["eval_seed"], row["doc_index"]
    assert row["task"] == "hier_paired" and row["mode"] == "greedy" and key not in receipts
    receipts[key] = row

regions = {}
for region, pairs in panel["evaluation"].items():
    by_seed = []
    for seed, counts in enumerate(task["paired_exact_match"]["counts"][region]):
        assert counts["eval_seed"] == seed
        both = one = neither = skipped = correct = 0
        answers = Counter()
        for pair in pairs:
            if pair["eval_seed"] != seed:
                continue
            outcomes = []
            for offset, document in enumerate(pair["documents"]):
                number = 2 * pair["pair_index"] + offset
                expected = pair["answers"][offset]
                length = len(tokenizer.encode(document, prepend=tokenizer.get_bos_token_id()))
                assert length == pair["full_doc_tokens"][offset] <= 321
                row = receipts.get((region, seed, number))
                if row is None:
                    outcomes.append(None)
                else:
                    assert row["expected"] == expected
                    pred = row["got"].split()[:len(expected.split())]
                    actual = pred == expected.split()
                    assert row["correct"] == actual
                    outcomes.append(actual)
                    answers[expected] += 1
                    correct += actual
            if None in outcomes:
                skipped += 1
            elif all(outcomes):
                both += 1
            elif any(outcomes):
                one += 1
            else:
                neither += 1
        assert counts == dict(eval_seed=seed, pairs=12, both_correct=both, one_correct=one,
                              neither_correct=neither, incomplete=skipped)
        assert both + one + neither + skipped == 12
        assert math.isclose(task["paired_exact_match"]["greedy"][region]["per_seed"][seed], both / 12)
        by_seed.append(dict(pairs=12, queries=sum(answers.values()), both=both, incomplete=skipped,
                            exact=correct, prior=max(answers.values(), default=0)))
    regions[region] = {key: sum(row[key] for row in by_seed) for key in by_seed[0]}
held_out = regions["held_out"]
report = {
    "run_id": run, "weights_sha256": summary["meta"]["checkpoint"]["weights_sha256"],
    "source_revision": summary["provenance"]["git_sha"], "regions": regions,
    "passes": held_out["queries"] == 72 and held_out["both"] >= 4 and held_out["exact"] > held_out["prior"],
}
with (directory / "recount.json").open("x", encoding="utf-8") as handle:
    handle.write(json.dumps(report, indent=2) + "\n")
print(json.dumps(report))
