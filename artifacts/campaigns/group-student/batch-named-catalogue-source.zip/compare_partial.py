"""Compare scalar and batched construction of full labelled action tables."""

import json
import sys
import time
from pathlib import Path

import numpy as np
from benchmark_indexed import control_observations, solve_panel
from catalogue_replay import WORDS, read
from incumbent.benchmark_indexed import solve_panel as solve_incumbent
from incumbent.partial_match import partial_matches as match_incumbent
from partial_match import distinct_named_tables, partial_matches

MATCHERS = {"scalar_tables": match_incumbent, "batch_tables": partial_matches}


def match(tables, observations, order):
    arms = {}
    for arm in order:
        start = time.process_time_ns()
        witnesses, actions, diagnostics = MATCHERS[arm](tables, observations)
        cpu = time.process_time_ns() - start
        arms[arm] = dict(
            cpu_ns=cpu,
            diagnostics=diagnostics,
            witnesses=witnesses,
            actions={i: sorted(actions[i]) for i in actions},
        )
    a, b = (arms[label] for label in order)
    if any(a[key] != b[key] for key in ("witnesses", "actions", "diagnostics")):
        raise ValueError("Batched label transport changed the exact version space")
    return arms


def root_control():
    """The root still distinguishes two labelings with identical right edges."""
    matrix = np.asarray([[0, 1, 2], [1, 2, 0], [2, 0, 1]])
    tables = distinct_named_tables(matrix, np.array([1, 1]), np.array([2, 2]), np.array([[0, 1], [2, 0]]), ("0", "2"))
    edges = (("1", "2"), ("2", "0"), ("0", "1"))
    if tables != {("0", edges), ("2", edges)}:
        raise ValueError("Root-sensitive deduplication or the single-label fill is incorrect")
    return sorted(tables)


def run(cohort, catalogue, prior, output, reverse):
    start = time.process_time_ns()
    _, _, tables = read(catalogue)
    parsing_cpu_ns = time.process_time_ns() - start
    cases = [read(cohort / f"{i:02}.json") for i in range(24)]
    observations = {i: (c["label_count"], dict(c["arms"]["short_only"]["rows"])) for i, c in enumerate(cases)}
    controls, control_pairs = control_observations(tables, read(prior), observations[0])
    controls[6] = (120, {word: str(sum(int(mark) + 1 for mark in word)) for word in WORDS})

    control = root_control()
    order = tuple(reversed(MATCHERS)) if reverse else tuple(MATCHERS)
    matching = match(tables, observations, order)
    naming = {}
    for arm in order:
        inputs = {"arms": {"indexed": matching[arm]}}
        if arm == "batch_tables":
            naming[arm] = solve_panel(tables, cases, observations, inputs, ("indexed",), reuse_named=True)
        else:
            naming[arm] = solve_incumbent(tables, cases, observations, inputs, ("indexed",))
    outside = match(tables, controls, order)
    checked = outside["batch_tables"]["witnesses"]
    cyclic_periods = outside["batch_tables"]["diagnostics"]["periods"][6]
    if (checked[-1] or checked[-2] or not checked[6]
            or any(pair not in checked[i] for i, pair in control_pairs.items())
            or cyclic_periods is None or any(exact is not None for _, exact in cyclic_periods)):
        raise ValueError("The outside census failed a valid or invalid control")
    with output.open("x", encoding="utf-8") as file:
        json.dump(dict(parsing_cpu_ns=parsing_cpu_ns, matching=matching, naming=naming,
                       controls=outside, control_pairs=control_pairs, root_control=control), file, sort_keys=True)
        file.write("\n")


if __name__ == "__main__":
    run(*map(Path, sys.argv[1:5]), reverse=sys.argv[5] == "reverse")
