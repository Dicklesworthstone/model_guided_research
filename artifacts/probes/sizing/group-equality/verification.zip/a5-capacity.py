"""Count marked A5 actions up to identity-preserving ordered generator isomorphism."""
import json
from itertools import product
from pathlib import Path
from nanochat.diagnostics_data import _group_elements, _GROUP_GENERATORS
from scripts.group_rewrite_probe import rooted_graph
from scripts.group_student_probe import graph_digest

elements = _group_elements("a5")
classes = set()
for pair in product(elements, repeat=2):
    graph = rooted_graph("a5", pair)
    if len(graph) == len(elements):
        classes.add(graph_digest(graph))
learner = Path(__import__("sys").argv[1])
used = {json.loads(p.read_bytes())["graph_sha"] for p in learner.glob("*.json")}
used.update(c["graph_digest"] for c in json.loads(Path("artifacts/probes/sizing/group-query-completion/panel.json").read_bytes())["cases"])
used.add(graph_digest(rooted_graph("a5", tuple(_GROUP_GENERATORS["a5"]))))
print(json.dumps(dict(all=len(classes), spent=len(classes & used), unused=len(classes-used))))
