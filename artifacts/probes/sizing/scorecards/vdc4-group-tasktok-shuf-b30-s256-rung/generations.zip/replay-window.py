"""Read a sizing scorecard and its generations.zip using the frozen task generator."""

from hashlib import sha256
import json
from pathlib import Path
import sys
from zipfile import ZipFile

from nanochat.diagnostics_data import TASKS
from nanochat.tokenizer import checkpoint_tokenizer

scorecard = Path(sys.argv[1])
manifest = json.loads((scorecard / "manifest.json").read_bytes())
results = []
with ZipFile(scorecard / "generations.zip") as archive:
    for cell in manifest["cells"]:
        task = cell["task"]
        if task == "placebo":
            continue
        folder = Path("evals/tasks") / ("eval-" + cell["id"])
        evaluation = json.loads((scorecard / folder / "summary.json").read_bytes())
        meta = evaluation["meta"]
        directory = scorecard / "runs/budget_0" / task / "standard" / f"seed_{cell['seed']}" / "checkpoints"
        tok = checkpoint_tokenizer(directory, {"tokenizer": meta["tokenizer"]})
        vocab = (directory / "tokenizer/tokenizer.json").read_bytes()
        window = meta["checkpoint"]["model_config"]["sequence_len"]
        assert window == 256 and meta["examples_per_seed"] == 48 and meta["seeds"] == [0, 1, 2]
        assert meta["tokenizer"]["kind"] == "task" and meta["evaluator"]["bos_prefixed"]
        records = [json.loads(line) for line in archive.read(str(folder / "generations.jsonl")).splitlines()]
        cases = {(r["eval_seed"], r["region"], r["doc_index"]): r for r in records if r["mode"] == "greedy"}
        assert len(cases) == 288
        spec = TASKS[task]
        lengths = {"in_range": [], "held_out": []}
        for seed in meta["seeds"]:
            splits = spec.generate(480, seed, spec.resolve_dials(meta["dials"]))
            for split, region in (("train", "in_range"), ("test", "held_out")):
                for index, doc in enumerate(splits[split][:48]):
                    prompt, expected = spec.split_prompt(doc)
                    assert cases[seed, region, index]["expected"] == expected
                    context = tok.encode(prompt, prepend=tok.get_bos_token_id())
                    answer = tok.encode(" " + expected)
                    lengths[region].append(len(context) + len(answer))
        report = {}
        for region, values in lengths.items():
            assert len(values) == 144
            report[region] = dict(scored=len(values), fit=sum(n <= window for n in values), min=min(values), max=max(values))
        results.append(dict(task=task, training_seed=cell["seed"], training_window=window,
                            tokenizer_sha256=sha256(vocab).hexdigest(), regions=report))
print(json.dumps({"scorecard": scorecard.name, "length_definition": "BOS + prompt + expected completion",
                  "rows": results}, indent=2))
