import hashlib
import itertools
import json
import math
import sys
from collections import Counter
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


ARMS = ("canonical", "augmented")
REGISTRATION = "7deeef18c007d01e798bc63348011b022a60343b"
LOCK = "61a19d863515f435ecbe7d8a8cc4c02af87b2a9db02254b9f7c4d59c961dbceb"
PANEL = "a945284b92ac3492adbd665f8164ccfe3c4471a674fd07e11693bd7b6dc067e1"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def recount(read, names, baseline):
    manifest = read("replay/frozen.sha256")
    assert sha(manifest) == LOCK
    for line in manifest.decode().splitlines():
        expected, name = line.split()
        assert sha(read(name if name == "panel.json" else f"replay/{name}")) == expected
    panel_hash = sha(read("panel.json"))
    assert panel_hash == PANEL
    panel = json.loads(read("panel.json"))
    assert panel["generator_seed"] == 81 and panel["checked_prior_contexts"] == 32648
    addresses = [[f"k0x{r}", f"k1x{c}"] for r, c in itertools.product(range(3), repeat=2)]
    assert addresses == panel["addresses"]
    assert panel["tokenizer_sha256"] == sha(baseline.read("tokenizer.json"))
    layouts = panel["permutations"]
    assert len(layouts) == 1296
    permutations = itertools.product(itertools.permutations(range(3)), repeat=4)
    for layout, order in zip(layouts, permutations, strict=True):
        assert layout["order"] == [list(part) for part in order]
        roots, *children = order
        assert layout["labels"] == [3 * roots.index(r) + children[r].index(c)
                                    for r, c in itertools.product(range(3), repeat=2)]
    decisions = {}
    for arm in ARMS:
        predicted = json.loads(read(f"evals/{arm}.json"))
        assert (predicted["arm"], predicted["seed"], predicted["panel_sha256"]) == (arm, 32, panel_hash)
        trained = json.loads(baseline.read(f"seed-32/runs/{arm}/summary.json"))
        assert trained["weights_sha256"] == predicted["weights_sha256"]
        assert trained["location_head_sha256"] == predicted["head_sha256"]
        all_nine, total_correct, first_error = 0, 0, None
        by_layout = Counter()
        worst_margin = math.inf
        for index, (layout, rows) in enumerate(zip(layouts, predicted["rows"], strict=True)):
            assert len(rows) == 9
            correct = 0
            for address, target, logits in zip(addresses, layout["labels"], rows, strict=True):
                assert len(logits) == 9 and all(map(math.isfinite, logits))
                found = max(range(9), key=logits.__getitem__)
                right = target == found
                correct += right
                margin = logits[target] - max(logit for i, logit in enumerate(logits) if i != target)
                if margin < worst_margin:
                    worst_margin = margin
                if not right and first_error is None:
                    first_error = dict(layout_index=index, order=layout["order"], address=address,
                                       expected_ordinal=target, predicted_ordinal=found)
            total_correct += correct
            all_nine += correct == 9
            by_layout[correct] += 1
        decisions[arm] = dict(all_nine=all_nine, correct_queries=total_correct, first_error=first_error,
                              exact_on_fixture=all_nine == 1296,
                              by_layout={str(count): total for count, total in sorted(by_layout.items())},
                              worst_gold_margin=worst_margin)
    receipts = sorted(name for name in names if name.endswith("/receipt.json"))
    assert len(receipts) == 3
    assert {name.split("/")[1] for name in receipts} == {"hierarchy-sibling-orbit-prepare", "hierarchy-sibling-orbit-eval"}
    for path in receipts:
        receipt = json.loads(read(path))
        assert receipt["status"] == "passed" and len(receipt["checks"]) == 1
        check = receipt["checks"][0]
        assert sha(read(path.removesuffix("receipt.json") + Path(check["log_path"]).name)) == check["log_sha256"]
    return dict(registration=REGISTRATION, layouts=1296, queries=11664, one_fixture=True, results=decisions,
                manifest_sha256=sha(manifest), panel_sha256=panel_hash,
                receipt_ids=[path.split("/")[-2] for path in receipts])


def bundle(root, lineage, destination):
    frozen = root / "frozen.sha256"
    files = {"replay/frozen.sha256": frozen, "replay/orbit_archive.py": root / "orbit_archive.py"}
    for line in frozen.read_text().splitlines():
        _, name = line.split()
        files[name if name == "panel.json" else f"replay/{name}"] = root / name
    for arm in ARMS:
        name = f"evals/{arm}.json"
        files[name] = root / name
    for receipt in (root / "receipts").glob("*/*/receipt.json"):
        for filename in ("receipt.json", "check-1.log", "checks-config.yaml"):
            path = receipt.with_name(filename)
            files[str(path.relative_to(root))] = path
    with ZipFile(lineage) as baseline:
        decision = recount(lambda name: files[name].read_bytes(), files, baseline)
    with ZipFile(destination, "x", compression=ZIP_DEFLATED) as archive:
        for name, path in files.items():
            archive.write(path, name)
        archive.writestr("decision.json", json.dumps(decision, indent=2) + "\n")


def verify(destination, lineage):
    with ZipFile(destination) as archive, ZipFile(lineage) as baseline:
        assert archive.testzip() is None
        names = archive.namelist()
        assert len(names) == len(set(names))
        assert not any(name.endswith((".pt", ".parquet", ".safetensors")) for name in names)
        observed = recount(archive.read, names, baseline)
        assert observed == json.loads(archive.read("decision.json"))
    print(json.dumps(observed))


if __name__ == "__main__":
    command, *paths = sys.argv[1:]
    {"bundle": bundle, "verify": verify}[command](*map(Path, paths))
