"""Matched acquisitions using the installed selector and its compiled counterpart."""

import argparse
import json
from functools import partial
from pathlib import Path
from time import monotonic_ns, process_time_ns
from zipfile import ZipFile

import released_acquisition as released

from nanochat import group_acquisition as current

ORDERS = {32: 151, 64: 503, 128: 1799}
MODES = ("square", "tiered", "compiled")


def timed(function, *args, **kwargs):
    cpu, wall = process_time_ns(), monotonic_ns()
    result = function(*args, **kwargs)
    return result, {"cpu_ns": process_time_ns() - cpu, "wall_ns": monotonic_ns() - wall}


def read_zip(archive, member):
    with ZipFile(archive) as source:
        return json.loads(source.read(member))


def decode_catalogue(archive):
    result = {}
    for row in read_zip(archive, "scored.json")["orders"]:
        shapes = []
        for profile in row["profiles"].values():
            for packed in profile["full"]:
                value = bytes.fromhex(packed)
                shapes.append(tuple(zip(value[::2], value[1::2], strict=True)))
        if len(set(shapes)) != ORDERS[row["order"]] or len(shapes) != ORDERS[row["order"]]:
            raise ValueError("Unexpected marked inventory")
        result[row["order"]] = sorted(shapes)
    if set(result) != set(ORDERS):
        raise ValueError("Incomplete marked inventory")
    return result


def labels_for(n, slot, reverse):
    multiplier, offset = (19, 7 * slot + 11) if reverse else (17, 13 * slot + 7)
    return [str((multiplier * state + offset) % n) for state in range(n)]


def measure_one(learner, roster, graph, labels, expected, anchors, mode):
    tape = []

    def oracle(word):
        state = 0
        for mark in word:
            state = graph[state][int(mark)]
        reply = labels[state]
        tape.append((word, reply))
        return reply

    result, cost = timed(learner, roster, oracle)
    root, edges = expected["action"]
    truth = {str(i): tuple(edge) for i, edge in enumerate(edges)}
    terminal = "square" if mode == "square" else expected["terminal"]
    if (result.root, result.transitions, result.terminal) != (root, truth, terminal):
        raise ValueError(f"{mode} changed an archived named action or terminal state")
    if tape != [*anchors.items(), *map(tuple, expected["tape"])]:
        raise ValueError(f"{mode} changed an archived paid tape")
    return dict(**cost, calls=len(tape), symbols=sum(len(word) for word, _ in tape), terminal=result.terminal)


def run(work, output, reverse):
    if not Path(current.__file__).resolve().is_relative_to(work):
        raise ValueError("The candidate comes from a different checkout")
    archive = work / "artifacts/probes/sizing/group-solver-baseline/anchor-results.zip"
    history = work / "artifacts/campaigns/group-student/transfer-results.zip"
    actual = decode_catalogue(archive)
    published = read_zip(history, "replay.json" if reverse else "scored.json")["rows"]
    rows = {(row["order"], row["slot"]): row for row in published}
    if len(rows) != sum(ORDERS.values()) or len(rows) != len(published):
        raise ValueError("Missing or duplicate archived tape")
    measured = {}
    for n, shapes in actual.items():
        if reverse:
            candidate, candidate_load = timed(current.load_catalogue, archive, n)
            baseline, baseline_load = timed(released.load_catalogue, archive, n)
        else:
            baseline, baseline_load = timed(released.load_catalogue, archive, n)
            candidate, candidate_load = timed(current.load_catalogue, archive, n)
        policy, compilation = timed(current.compile_policy, candidate)
        setup = {"tiered": baseline_load, "candidate_load": candidate_load, "compile": compilation}
        learners = {
            "square": released.acquire,
            "tiered": partial(released.acquire, catalogue=baseline),
            "compiled": partial(current.acquire, catalogue=policy),
        }
        roster = list(map(str, range(n)))
        if reverse:
            roster.reverse()
        scores = []
        for slot, graph in enumerate(shapes):
            rotation = slot % len(MODES)
            order = MODES[rotation:] + MODES[:rotation]
            if reverse:
                order = tuple(reversed(order))
            labels = labels_for(n, slot, reverse)
            archived = rows[n, slot]
            expected_edges = {label: [labels[a], labels[b]] for label, (a, b) in zip(labels, graph, strict=True)}
            expected_table = [labels[0], [expected_edges[str(i)] for i in range(n)]]
            if any(result["action"] != expected_table for result in archived["arms"].values()):
                raise ValueError(f"Wrong marked truth for order {n}, slot {slot}")
            sampled = {}
            for mode in order:
                expected = archived["arms"]["tiered" if mode == "compiled" else mode]
                sampled[mode] = measure_one(learners[mode], roster, graph, labels, expected, archived["anchors"], mode)
            scores.append(sampled)
        measured[n] = {"setup": setup, "cases": scores}
        print(f"Order {n}: {len(scores)} exact cases scored", flush=True)
    with output.open("x", encoding="utf-8") as handle:
        json.dump({"reverse": reverse, "orders": measured}, handle, separators=(",", ":"), sort_keys=True)
        handle.write("\n")


def summarize(first_path, second_path):
    samples = [json.loads(path.read_text(encoding="utf-8")) for path in (first_path, second_path)]
    if [sample["reverse"] for sample in samples] != [False, True]:
        raise ValueError("Expected both preregistered replay directions")
    totals = []
    checked = 0
    for sample in samples:
        per_order = {}
        for n, cells in sample["orders"].items():
            if len(cells["cases"]) != ORDERS[int(n)]:
                raise ValueError("Incomplete acquisition census")
            checked += sum(len(row) for row in cells["cases"])
            arms = {
                mode: {measure: sum(row[mode][measure] for row in cells["cases"])
                       for measure in ("cpu_ns", "wall_ns", "calls", "symbols")}
                for mode in MODES
            }
            warm = arms["compiled"]["cpu_ns"]
            setup = cells["setup"]
            cold = warm + setup["candidate_load"]["cpu_ns"] + setup["compile"]["cpu_ns"]
            per_order[n] = dict(
                arms=arms, setup=setup, cold_compiled_cpu_ns=cold,
                twice_as_fast_as_tiered=2 * warm <= arms["tiered"]["cpu_ns"],
                faster_than_square=warm < arms["square"]["cpu_ns"],
            )
        if set(map(int, per_order)) != set(ORDERS):
            raise ValueError("An order was omitted")
        totals.append(per_order)
    passed = all(row[key] for run in totals for row in run.values()
                 for key in ("twice_as_fast_as_tiered", "faster_than_square"))
    print(json.dumps({"orders": totals, "warm_prediction_passed": passed, "checked_acquisitions": checked},
                     sort_keys=True))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(required=True, dest="operation")
    score = commands.add_parser("score")
    score.add_argument("work", type=Path)
    score.add_argument("output", type=Path)
    score.add_argument("--reverse", action="store_true")
    summary = commands.add_parser("summary")
    summary.add_argument("first", type=Path)
    summary.add_argument("second", type=Path)
    args = parser.parse_args()
    if args.operation == "score":
        run(args.work, args.output, args.reverse)
    else:
        summarize(args.first, args.second)
