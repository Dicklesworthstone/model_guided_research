# Route Observatory Report (`mgr.bench.routes.v2`)

- **Mechanism**: `tropical`
- **Task**: `hier`
- **Checkpoint**: `/private/tmp/mgr-route-verifier.hMb9aRVM/training/baseline/nanochat/cpu-11/checkpoints` (step `3`)
- **Samples**: `8` (seed `44`)
- **Brute-force cross-check verified**: `True`

## 1. Route Reuse & Consolidation

- **Route entropy (bits)**: `3.4528` (first `3.4528` -> last `3.4528`, delta `0.0000`)
- **Program reuse ratio**: `0.2500` (first `0.2500` -> last `0.2500`, delta `0.0000`)
- **Top-5 program share**: `0.5625`

## 2. Perturbation & Paraphrase Stability (`vdc.1` Probe Spec)

- **Probe spec**: `vdc.1-linf-embedding-v1` (`default_eps=0.05`)
- **Margin aggregation**: `min` (tightest decision along route)
- **Spearman rho(gamma_min, stability)**: `unavailable`
- **Unchanged perturbation draws**: 2 / 64
- **Mean perturbation stability**: `0.0312`
- **Mean paraphrase stability**: `0.8828` (8 measured)

## 3. Unsupervised Trace Clustering vs Attention-Entropy Baseline

- **Latent task classes (`K=1`)**: `['3']`
- **Trace clustering ARI**: `unavailable`
- **Attention-entropy baseline ARI**: `unavailable`
- **Prompt-only control ARI**: `unavailable`
- **ARI gain (trace - baseline)**: `unavailable`
