# Identifiability from two compatible leaves

For a fixed tree and query with true leaf y, draw a balanced coloring uniformly from all partitions of four leaves into two colors. The color of y gives a compatible set containing y and one wrong leaf J. Each wrong leaf occurs as J with probability one third. For any predicted leaf distribution p produced independently of the coloring, Jensen's inequality gives

`E[-log(p[y] + p[J])] >= -log(p[y] + (1 - p[y]) / 3).`

If p[y] is below one, this lower bound is strictly positive. Concentrating on y gives zero loss for every coloring, so the point mass at y is the unique population optimum for this fixed input. The proof concerns the scoring rule under independent label ambiguity. One draw is fixed per observed tree in this experiment, so the proof does not establish identifiability for a single training example or convergence of the fitted head.

The readout normalizes child probabilities at every parsed row and composes them over an explicit tree. With a singleton compatible leaf its probability is the product along that leaf's path. With two compatible leaves their probabilities are added before taking the logarithm. The hard latent control keeps just the higher-probability compatible route. Fresh evaluation uses no color information. The association-erased evaluation keeps queries and row orders while erasing the assignment from each alias to a child. Each edited pair then has identical inputs and distinct desired routes, so its two orientations cannot both be correct.

This is a scoped study of weak supervision with the parsed tree, alias roles, and shared local readout provided. The symbolic solver remains exact and is used to verify the expected paths. Related work includes Cour, Sapp, and Taskar's [Learning from Partial Labels](https://jmlr.org/papers/v12/cour11a.html) and Guu et al.'s [From Language to Programs](https://aclanthology.org/P17-1097/).
