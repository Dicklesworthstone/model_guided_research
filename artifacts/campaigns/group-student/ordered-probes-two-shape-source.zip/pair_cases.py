"""Compare both exact algorithms on every two-shape anchor class."""

import argparse
import json
from collections import defaultdict
from pathlib import Path
from time import process_time_ns

from bench_optimal import ANCHORS, MAX_WORK, READ_PRICE, acquire_case, counts, inventory, opaque_names, price


def case_groups(work):
    groups = {}
    for order, graphs in inventory(work).items():
        patterns = defaultdict(list)
        for slot, graph in enumerate(graphs):
            replies = [graph[second][graph[first][0]] for first, second in ANCHORS]
            pattern = "".join(str(replies.index(endpoint)) for endpoint in replies)
            patterns[pattern].append((slot, graph))
        groups[order] = {pattern: shapes for pattern, shapes in patterns.items() if len(shapes) == 2}
    return groups


def score(work, reverse):
    from nanochat import group_acquisition as acq

    if not Path(acq.__file__).resolve().is_relative_to(work.resolve()):
        raise ValueError("Compiler loaded outside the designated checkout")
    output = {}
    for order, groups in case_groups(work).items():
        for pattern, cases in groups.items():
            key = f"{order}-{pattern}"
            shapes = [tuple(zip(graph["0"].values(), graph["1"].values(), strict=True)) for _, graph in cases]
            started = process_time_ns()
            try:
                solution = acq.compile_optimal_policy(acq._prepare(shapes), read_price=READ_PRICE, max_work=MAX_WORK)
            except acq.PlanningBudgetExceeded:
                output[key] = {"exhausted": True, "compile_ns": process_time_ns() - started}
                continue
            work_ns = process_time_ns() - started
            acquired = {}
            for slot, graph in reversed(cases) if reverse else cases:
                names = opaque_names(order, slot, reverse)
                roster = names[1:] + names[:1] if reverse else names[::-1]
                acquired[slot] = acquire_case(acq.acquire, graph, names, roster, solution.policy)
            output[key] = {
                "work": solution.work,
                "compile_ns": work_ns,
                "objective": solution.total_cost,
                "tapes": acquired,
            }
    return output


def check(work, before, after):
    result = {}
    total_before = total_after = recovered = 0
    for order, groups in case_groups(work).items():
        for pattern, cases in groups.items():
            key = f"{order}-{pattern}"
            row = {}
            for label, data, reverse in (("original", before, False), ("specialized", after, True)):
                run = data[key]
                if "exhausted" in run:
                    row[label] = {"exhausted": True, "compile_ns": run["compile_ns"]}
                    continue
                weighted_cost = 0
                for slot, graph in cases:
                    names = opaque_names(order, slot, reverse)
                    tape = run["tapes"][str(slot)]
                    expected = {names[i]: [names[graph["0"][i]], names[graph["1"][i]]] for i in range(order)}
                    if tape["root"] != names[0] or tape["table"] != expected or tape["terminal"] != "unique":
                        raise ValueError("Incorrect two-shape acquisition")
                    words = [word for word, _ in tape["tape"]]
                    if words[:4] != list(ANCHORS) or len(set(words)) != len(words):
                        raise ValueError("Invalid pair tape")
                    for word, label_seen in tape["tape"]:
                        state = 0
                        for mark in word:
                            state = graph[mark][state]
                        if label_seen != names[state]:
                            raise ValueError("Invalid paid reply")
                    weighted_cost += price(counts(words))
                    recovered += 1
                if weighted_cost != run["objective"] or not 0 < run["work"] <= MAX_WORK:
                    raise ValueError("Incorrect paired objective or meter")
                row[label] = {"cost": weighted_cost, "work": run["work"], "compile_ns": run["compile_ns"]}
            if "exhausted" in row["specialized"]:
                raise ValueError("The two-shape shortcut exhausted")
            if "cost" in row["original"]:
                if row["original"]["cost"] != row["specialized"]["cost"]:
                    raise ValueError("The two exact algorithms disagree")
                total_before += row["original"]["work"]
                total_after += row["specialized"]["work"]
            result[key] = row
    if set(before) != set(result) or set(after) != set(result):
        raise ValueError("Missing two-shape case")
    return {
        "checked_acquisitions": recovered,
        "shared_work": [total_before, total_after],
        "cases": result,
    }


def main():
    parser = argparse.ArgumentParser()
    commands = parser.add_subparsers(dest="command", required=True)
    run = commands.add_parser("score")
    run.add_argument("work", type=Path)
    run.add_argument("output", type=Path)
    run.add_argument("--reverse", action="store_true")
    verify = commands.add_parser("check")
    verify.add_argument("work", type=Path)
    verify.add_argument("original", type=Path)
    verify.add_argument("specialized", type=Path)
    args = parser.parse_args()
    if args.command == "score":
        with args.output.open("x", encoding="utf-8") as out:
            json.dump(score(args.work, args.reverse), out, sort_keys=True, separators=(",", ":"))
    else:
        original = json.loads(args.original.read_text(encoding="utf-8"))
        specialized = json.loads(args.specialized.read_text(encoding="utf-8"))
        print(json.dumps(check(args.work, original, specialized), indent=2))


if __name__ == "__main__":
    main()
