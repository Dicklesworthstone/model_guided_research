"""Independent pointwise oracle audit and credit replay for the live scheduler."""
import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path
from zipfile import ZipFile

from audit_compact import digest, pointwise
from audit_order_free import ARCHIVE, MANIFESTS, audit_arm, checked_prior_library
from order_free_probe import digest as file_digest

HISTORY = Path("artifacts/probes/sizing/group-order-free")
ORDERS = {"s5": 120, "a6": 360, "s4": 24, "c1": 1, "c2": 2, "a4": 12, "c3": 3}


def counterfactual(frontier, speculative, proved):
    programs = dict(frontier=iter(frontier), proposal=iter(speculative))
    awaiting = {name: next(stream, None) for name, stream in programs.items()}
    knowledge = {}
    tapes = []
    credit = 0
    while True:
        for name in ("frontier", "proposal"):
            while awaiting[name] is not None:
                a, b, answer = awaiting[name]
                key = frozenset((a, b))
                if key not in knowledge:
                    break
                assert answer is knowledge[key]
                awaiting[name] = next(programs[name], None)
            if awaiting[name] is None and (name == "frontier" or proved):
                return name, tapes
        owner = "proposal" if credit >= 4 and awaiting["proposal"] is not None else "frontier"
        a, b, answer = awaiting[owner]
        key = frozenset((a, b))
        assert key not in knowledge
        knowledge[key] = answer
        credit += 1 if owner == "frontier" else -4
        assert credit >= 0
        tapes.append([owner, a, b, answer])


def live_cost(record, winner, expected):
    assert record["winner"] == winner and record["paid"] == expected
    charges = Counter(owner for owner, *_ in expected)
    assert record["counts"] == [charges["frontier"], charges["proposal"]]
    assert 0 <= record["oracle_seconds"] <= record["seconds"]
    return charges


def verify_run(coverage, experiment, producer):
    manifest = json.loads(coverage.read_bytes())
    results = json.loads(experiment.read_bytes())
    reused = HISTORY / "coverage.json"
    archive_path = HISTORY / "verification.zip"
    assert manifest["producer"] == file_digest(producer)
    assert manifest["reused"] == file_digest(reused) and manifest["archived"] == file_digest(archive_path)
    assert manifest["library"] == file_digest(ARCHIVE) and manifest["prior"] == [file_digest(p) for p in MANIFESTS]
    assert results["coverage_sha256"] == file_digest(coverage)
    with ZipFile(archive_path) as archive:
        old = json.loads(archive.read("run.json"))["results"]
    schedule_replay = json.loads((HISTORY / "summary.json").read_bytes())["schedule_replay"]["cases"]
    earlier, *rest = [json.loads(path.read_bytes()) for path in (*MANIFESTS, reused)]
    consumed = set(earlier["spent"]) | {row["graph_sha"] for row in earlier["presentations"]}
    consumed.update(row["graph_sha"] for previous in rest for row in previous["cases"])
    catalog, proof = checked_prior_library()
    assert len(old) == len(schedule_replay) == 18
    expected = [(p, i, case) for p, cases in (
        ("reused", rest[-1]["cases"]), ("conformance", manifest["cases"])
    ) for i, case in enumerate(cases)]
    totals = defaultdict(lambda: defaultdict(Counter))
    coverage_ids = set()
    discovered_tail = set()
    detail = []
    edge_count = 0
    rejected_tamper = False
    assert len(expected) == len(results["cases"]) == 28
    for (panel, index, case), row in zip(expected, results["cases"], strict=True):
        family = case["family"]
        assert panel == row["panel"] and index == row["index"]
        assert all(row[k] == v for k, v in case.items())
        truth, _, evaluate, _ = pointwise("permutation", case["generators"])
        fingerprint = digest(truth)
        assert fingerprint == case["graph_sha"] and len(truth) == ORDERS[family]
        assert (fingerprint in catalog) == (family == "s5")
        if panel == "conformance":
            assert fingerprint not in consumed and fingerprint not in coverage_ids and case["fresh"]
            coverage_ids.add(fingerprint)
            if family == "s5":
                discovered_tail.add(fingerprint)
        baseline = row["baseline"]
        isolated = row["isolated"]
        base, _ = audit_arm(baseline, False, truth, evaluate, catalog, proof)
        spec, _ = audit_arm(isolated, True, truth, evaluate, catalog, proof)
        plan_count = spec["selection_checks"] + spec["certificate_checks"]
        proved = isolated["accepted"]
        assert proved is (family == "s5")
        winner, tape = counterfactual(baseline["paid"], isolated["paid"][:plan_count], proved)
        live = row["live"]
        by_owner = live_cost(live, winner, tape)
        result = live["result"]
        assert result["edges"] == truth
        if winner == "frontier":
            assert {k: v for k,v in result.items() if k != "seconds"} == {
                k: v for k,v in baseline["acquisition"].items() if k != "seconds"
            }
        else:
            assert proved and result["proposal"] == isolated["proposal"] and result["checks"] == isolated["checks"]
        assert (winner == "proposal") == (family == "s5")
        if panel == "reused":
            assert fingerprint == old[index]["graph_sha"] == row["graph_sha"]
            assert baseline["paid"] == old[index]["baseline"]["paid"]
            assert isolated["paid"] == old[index]["treatment"]["paid"]
            previous = schedule_replay[index]
            assert len(tape) == previous["replay"]
            assert by_owner["frontier"] == previous["baseline_share"]
            assert by_owner["proposal"] == previous["speculative_share"]
            assert (winner == "proposal") == bool(previous["certified"])
        assert len(tape) <= base["checks"] + base["checks"] // 4
        if proved:
            assert len(tape) <= 5 * plan_count
        if not rejected_tamper and by_owner["proposal"]:
            broken = {**live, "paid": [["proposal", *tape[0][1:]], *tape[1:]]}
            try:
                live_cost(broken, winner, tape)
            except AssertionError:
                rejected_tamper = True
            else:
                raise AssertionError("Wrong payer accepted")
        edge_count += 2*len(truth)
        costs = dict(
            baseline=base["checks"], proposal_first=spec["checks"], live=len(tape), certified=int(winner == "proposal"),
            baseline_symbols=base["symbols"], live_symbols=sum(len(a)+len(b) for _,a,b,_ in tape),
            frontier_charges=by_owner["frontier"], proposal_charges=by_owner["proposal"], cases=1,
        )
        totals[panel][family].update(costs)
        detail.append(dict(panel=panel, index=index, family=family, order=len(truth), **costs))
    assert discovered_tail == set(catalog).difference(consumed)
    assert {f:t["cases"] for f,t in totals["conformance"].items()} == {"s5": 2, "a4": 4, "c3": 4}
    assert rejected_tamper and len(coverage_ids) == 10
    print(json.dumps(dict(
        passed=True, audited_cases=28, audited_live_edges=edge_count, cross_tape_mutation_rejected=rejected_tamper,
        totals=totals, per_case=detail,
    ), sort_keys=True))


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("coverage", type=Path)
    cli.add_argument("experiment", type=Path)
    cli.add_argument("producer", type=Path)
    argv = cli.parse_args()
    verify_run(argv.coverage, argv.experiment, argv.producer)
