#!/bin/bash
set -euo pipefail
export PATH="/home/ubuntu/.local/bin:$PATH"
export MGR_LEAF_SHA=4c6ff60b62261231e0c84f22f25f189ba98089b4
export DSR_REPOS_FILE=/data/ssd/tmp/mgr-hier-leaf.F0aTylAY/campaign.yaml DSR_QUALITY_LOG_DIR=/data/ssd/tmp/mgr-hier-leaf.F0aTylAY/receipts
export UV_PROJECT_ENVIRONMENT=/data/ssd/tmp/mgr-eval-ci.bevt3nLW/qualified-venv
export OMP_NUM_THREADS=4 MKL_NUM_THREADS=4
dsr quality --tool hierarchy-leaf-preflight --work-dir /data/ssd/tmp/mgr-hier-leaf.F0aTylAY/gate --check-timeout 240
dsr quality --tool hierarchy-leaf-train --work-dir /data/ssd/tmp/mgr-hier-leaf.F0aTylAY/gate --check-timeout 1200
for name in detached joint; do
  export MGR_LEAF_RUN="$name"
  dsr quality --tool hierarchy-leaf-eval --work-dir /data/ssd/tmp/mgr-hier-leaf.F0aTylAY/gate --check-timeout 240
done
