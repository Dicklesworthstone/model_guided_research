# Route Observatory Report (`mgr.bench.routes.v2`)

- **Mechanism**: `tropical`
- **Task**: `hier`
- **Checkpoint**: `/private/tmp/mgr-route-verifier.hMb9aRVM/training/baseline/nanochat/cpu-11/checkpoints` (step `1`)
- **Samples**: `4` (seed `42`)
- **Brute-force cross-check verified**: `True`

## 1. Route Reuse & Consolidation

- **Route entropy (bits)**: `3.0000` (first `3.0000` -> last `3.0000`, delta `0.0000`)
- **Program reuse ratio**: `0.0000` (first `0.0000` -> last `0.0000`, delta `0.0000`)
- **Top-5 program share**: `0.6250`

## 2. Perturbation & Paraphrase Stability (`vdc.1` Probe Spec)

- **Probe spec**: `vdc.1-linf-embedding-v1` (`default_eps=0.05`)
- **Margin aggregation**: `min` (tightest decision along route)
- **Spearman rho(gamma_min, stability)**: `unavailable`
- **Unchanged perturbation draws**: 1 / 32
- **Mean perturbation stability**: `0.0312`
- **Mean paraphrase stability**: `0.8984` (4 measured)

## 3. Unsupervised Trace Clustering vs Attention-Entropy Baseline

- **Latent task classes (`K=2`)**: `['2', '3']`
- **Trace clustering ARI**: `0.0000`
- **Attention-entropy baseline ARI**: `-0.3333`
- **Prompt-only control ARI**: `1.0000`
- **ARI gain (trace - baseline)**: `0.3333`

## 4. Newton-Polytope Realized Region Counting (`8gk.3` / `oeno`)

- **Bound violations (Props 0, 1, 2)**: `0`
- **Tropical regions vs T slope**: `6.4731`
- **Per-param region slope gap (tropical - ReLU MLP)**: `+0.016857`
