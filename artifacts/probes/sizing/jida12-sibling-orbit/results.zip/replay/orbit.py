import itertools
import sys
from pathlib import Path

from sibling_order import (
    LocationHead, SPEC, HuggingFaceTokenizer, _load_eval_checkpoint, corpus, digest, leaf_entries,
    read, serialize, states, tokenizer_path, torch, tree_from_text, tree_of, write,
)


ARMS = ("canonical", "augmented")


def ordered(tree, order):
    roots, *children = order
    keys = tuple(sorted(tree))
    return {keys[r]: {key: tree[keys[r]][key] for key in
                      (sorted(tree[keys[r]])[i] for i in children[r])} for r in roots}


def documents(tree, addresses, tokenizer):
    serialized = serialize(tree)
    leaves = leaf_entries(serialized)
    mapping = {path: (index, value) for index, (path, value, _) in enumerate(leaves)}
    assert set(mapping) == set(addresses)
    bos = tokenizer.get_bos_token_id()
    prefixes = [tokenizer.encode(serialized[:end], prepend=bos) for _, _, end in leaves]
    prompts, labels = [], []
    for path in addresses:
        label, answer = mapping[path]
        doc = f"{serialized} PATH {' '.join(path)} OUT {answer}"
        assert SPEC.checker(doc) is True
        prompt, found = SPEC.split_prompt(doc)
        ids = tokenizer.encode(prompt, prepend=bos)
        full = tokenizer.encode(doc, prepend=bos)
        assert len(ids) == 104 and full[:104] == ids and 104 < len(full) <= 128 and found == answer
        assert all(ids[:len(prefix)] == prefix for prefix in prefixes)
        prompts.append(ids)
        labels.append(label)
    assert sorted(labels) == list(range(9))
    return prompts, [len(prefix) - 1 for prefix in prefixes], labels


def prepare(output, reference, prior, *other):
    known, _ = corpus(reference)
    for path in other[:4]:
        data = read(path)
        known.update(tree_of(row["documents"][0]) for rows in data.get("evaluation", data).values() for row in rows)
    for path, cells in zip(other[4:],
                           (("a", "b"), ("normal", "length_only", "nested"), ("normal", "permuted", "expanded", "nested")),
                           strict=True):
        known.update(block[cell]["tree"] for block in read(path)["blocks"] for cell in cells)
    assert len(known) == 32648
    tokenizer_dir = tokenizer_path(reference)
    tokenizer = HuggingFaceTokenizer.from_directory(str(tokenizer_dir))
    tokenizer_hash = digest(tokenizer_dir / "tokenizer.json")
    assert tokenizer_hash == read(prior / "seed-32" / "preflight.json")["tokenizer_sha256"]
    orders = list(itertools.product(itertools.permutations(range(3)), repeat=4))
    for doc in SPEC.generate(4800, 81, SPEC.resolve_dials(None))["train"][::2]:
        text = tree_of(doc)
        leaves = leaf_entries(text)
        if text in known or len(leaves) != 9 or len({value for _, value, _ in leaves}) != 9:
            continue
        tree = tree_from_text(text)
        addresses = sorted(path for path, _, _ in leaves)
        layouts = [ordered(tree, order) for order in orders]
        contexts = {serialize(layout) for layout in layouts}
        assert len(contexts) == 1296
        if not known.intersection(contexts):
            break
    else:
        raise ValueError("no fresh full nine-leaf tree")
    permutations = []
    for order, layout in zip(orders, layouts, strict=True):
        _, _, labels = documents(layout, addresses, tokenizer)
        permutations.append(dict(order=order, labels=labels))
    write(output, dict(generator_seed=81, canonical_text=text, addresses=addresses, permutations=permutations,
                       tokenizer_sha256=tokenizer_hash, checked_prior_contexts=len(known)))
    print("1296 distinct serializations, 9 queries per serialization, 104-token prompts", flush=True)


@torch.inference_mode()
def evaluate(panel_path, prior, output, arm):
    panel = read(panel_path)
    root = prior / "seed-32" / "runs" / arm
    checkpoint = root / "checkpoints"
    model, meta, step = _load_eval_checkpoint(checkpoint, None, torch.device("cpu"), fingerprint_weights=True)
    summary = read(root / "summary.json")
    assert not summary["provenance"]["tainted"] and step == 2047
    assert summary["provenance"]["git_sha"] == "594fd4358a6820998ab16156d165041715b652ca"
    assert meta["weights_sha256"] == summary["weights_sha256"]
    assert digest(checkpoint / "location_head.pt") == summary["location_head_sha256"]
    assert digest(checkpoint / "tokenizer" / "tokenizer.json") == panel["tokenizer_sha256"]
    tokenizer = HuggingFaceTokenizer.from_directory(str(checkpoint / "tokenizer"))
    head = LocationHead().eval()
    head.load_state_dict(torch.load(checkpoint / "location_head.pt", weights_only=True))
    tree = tree_from_text(panel["canonical_text"])
    addresses = list(map(tuple, panel["addresses"]))
    rows = []
    for group in itertools.batched(panel["permutations"], 16):
        prompts, candidates = [], []
        for layout in group:
            ids, positions, labels = documents(ordered(tree, layout["order"]), addresses, tokenizer)
            assert labels == layout["labels"]
            prompts.extend(ids)
            candidates.extend([positions] * 9)
        _, hidden = states(model, torch.tensor(prompts))
        logits = head(hidden, torch.full((len(prompts),), 103), torch.tensor(candidates))
        assert bool(torch.isfinite(logits).all())
        rows.extend(logits.view(len(group), 9, 9).tolist())
    write(output / f"{arm}.json", dict(arm=arm, seed=32, panel_sha256=digest(panel_path),
                                      weights_sha256=summary["weights_sha256"],
                                      head_sha256=summary["location_head_sha256"], rows=rows))


if __name__ == "__main__":
    command, *args = sys.argv[1:]
    if command == "prepare":
        prepare(*map(Path, args))
    elif command == "evaluate":
        assert args[-1] in ARMS
        evaluate(*map(Path, args[:-1]), args[-1])
    else:
        raise ValueError(command)
