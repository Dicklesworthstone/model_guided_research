from common import *
import copy

src=root/"runs/joined"
history=root/"joined-history"
out=root/"runs/portable"
out.mkdir(exist_ok=True,parents=True)
anchor=load(src/"result.json")["registered"]
registry=history/"hypotheses/registry.yaml"
original_registry=sha(registry)
inputs=[(case, d) for case in ("post","pre","reevaluated-pre") for d in sorted((src/"cohorts"/case).iterdir())]
ckpt=src/"training/baseline/nanochat/native-11/checkpoints"
for a in (45,46):
    d=out/"extra"/f"native-11-{a}-1"
    cli(history,"routes","--checkpoint",ckpt,"--step",1,"--task","hier","--sample","8","--seed",a,
        "--device","cpu","--no-region-count","--out",d)
    inputs.append(("post",d))

counts={}
for case,d in inputs:
    stored=load(d/"traces.json")
    orig=load(d/"summary.json")
    st=orig["results"]["stability"]
    rr=orig["results"]["reuse"]
    rows=stored["traces"]
    scored=sum(t["scored_draws"] for t in rows)
    survived=sum(t["surviving_draws"] for t in rows)
    programs=[tuple(h["program"]) for t in rows for h in t["head_programs"]]
    assert scored==st["perturbation_draws_scored"] and survived==st["perturbation_draws_survived"]
    assert len(programs)==rr["total_observations"] and len(set(programs))==rr["unique_programs"]
    key=case+"-"+d.name
    counts[key]=dict(prompts=len(rows),draws=scored,survivors=survived,programs=len(programs),unique=len(set(programs)))
    for suffix in ("json","parquet"):
        target=out/"mixed"/suffix/key
        cli(consumer,"routes","--from-store",d/f"traces.{suffix}","--out",target)
        assert sha(target/"summary.json")==sha(d/"summary.json") and sha(target/"report.md")==sha(d/"report.md")
        if suffix=="parquet" and case=="post" and orig["meta"]["training_seed"]==11:
            save(out/"one-model"/key/"summary.json",load(target/"summary.json"))
assert len(counts)==11
votes={}
for suffix in ("json","parquet"):
    result=overview(rule(history,fixture_hyp,out/"mixed"/suffix,out/"adjudicate"/suffix))
    assert result["units"]=={"tropical":5} and result["excluded"]=={"pre_registration":2}
    assert result["anchor"]==anchor and result["selected"]==5
    votes[suffix]=result
assert votes["parquet"]==votes["json"]
assert len(list((out/"one-model").glob("*/summary.json")))==5
unit=overview(rule(history,fixture_hyp,out/"one-model",out/"adjudicate"/"one-model"))
assert unit["reason"]=="insufficient_seeds"
first=src/"cohorts/post/native-11-42-1"
template=load(first/"traces.json")
last=load(src/"cohorts/post/native-11-44-3/traces.json")["checkpoint_series"][-1]
assert last["step"]==3
actual=load(first/"summary.json")
save(out/"unknown"/"summary.json",dict(actual,train_provenance=None))
missing=overview(rule(history,fixture_hyp,out/"unknown",out/"adjudicate"/"missing"))
assert missing["excluded"]=={"missing_training_lineage":1}
controls={}
for case in ("constant","shuffled","signal","future"):
    store=copy.deepcopy(template)
    if case=="future":
        store["checkpoint_series"].append(last)
    else:
        traces=[]
        for i in range(32):
            row=copy.deepcopy(template["traces"][0])
            label=i%2
            row.update(latent_label=(i//2)%2 if case=="shuffled" else label,
                       decisions=[0,0] if case=="constant" else [4*label]*2, prompt_control_features=[label+1])
            traces.append(row)
        store["traces"]=traces
        store["checkpoint_series"][-1]["traces"]=copy.deepcopy(traces)
    path=out/"controls"/(case+".json")
    save(path,store)
    proc=cli(consumer,"routes","--from-store",path,"--out",out/"control-results"/case,require=False)
    if case=="future":
        assert proc.returncode==2 and "must end at the selected step" in (proc.stdout+proc.stderr)
        controls["future_exit"]=proc.returncode
    else:
        assert proc.returncode==0,(case,proc.stdout,proc.stderr)
        ari=load(out/"control-results"/case/"summary.json")["results"]["clustering"]["ari_trace"]
        assert ari==0 if case=="constant" else ari<=0 if case=="shuffled" else ari==1
        controls[case]=ari
assert sha(registry)==original_registry
result=dict(source=published,anchor=anchor,input_stores=len(inputs),draws_scored=sum(x["draws"] for x in counts.values()),
            draws_survived=sum(x["survivors"] for x in counts.values()),raw_per_observation=counts,joined=votes,
            single_model_five_analysis_seeds=unit,missing=missing,controls=controls)
save(out/"result.json",result)
print(json.dumps(result,sort_keys=True),flush=True)
