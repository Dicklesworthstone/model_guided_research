from common import *
from collections import Counter

cwd=root/"historical"
out=root/"runs"/"historical"
source=load(consumer/"artifacts/adjudications/jida36-eligibility-replay/eligibility-audit.json")
assert git(cwd,"rev-parse","HEAD")==source["corpus_commit"]==corpus
assert git(cwd,"rev-parse","HEAD:artifacts")==source["artifact_tree"]
assert git(cwd,"rev-parse","HEAD:hypotheses/registry.yaml")==source["registry_blob"]
registry=cwd/"hypotheses/registry.yaml"
orig=sha(registry)
raw={}
for tag,executable in (("ci-v6",cwd/"cli.py"),("ci-v7",consumer/"cli.py")):
    run([sys.executable,executable,"adjudicate","--all","--dry-run","--artifacts","artifacts",
         "--artifacts-dir",out,"--run-id",tag],cwd)
    rows=load(out/"adjudications"/tag/"verdicts.json")["verdicts"]
    raw[tag]={row["id"]:row for row in rows}
    assert len(rows)==75 and set(raw[tag])==set(source["hypotheses"])
matrix=Counter()
rejected=Counter()
paths=set()
holds=[]
for name,ref in source["hypotheses"].items():
    old=raw["ci-v6"][name]
    new=raw["ci-v7"][name]
    for tag,record in (("ci-v6",old),("ci-v7",new)):
        assert record["verdict"]==ref[tag],(name,tag,record["verdict"],ref[tag])
        assert record.get("reason_code")==ref.get(tag+"_reason"),(name,tag)
    assert new.get("registration_commit")==ref.get("registration_commit"),name
    selected=set(new.get("artifacts",[]))
    assert selected==set(ref.get("ci-v7_selected",[])), name
    assert set(old.get("artifacts",[]))-selected==set(ref.get("ci-v6_only",[])),name
    assert selected-set(old.get("artifacts",[]))==set(ref.get("ci-v7_only",[])),name
    expected={(k,p) for k,group in ref.get("ci-v7_excluded_by_reason",{}).items() for p in group}
    actual={(r["reason_code"],r["path"]) for r in new.get("excluded_evidence",[])}
    assert expected==actual,name
    for reason,path in actual:
        rejected[reason]+=1
        paths.add(path)
    matrix[old["verdict"]+"->"+new["verdict"]]+=1
    if new.get("reason_code")=="manual_hold":
        holds.append(name)
assert sorted(holds)==sorted(source["manual_holds"]) and sha(registry)==orig
count=len(git(cwd,"ls-files","artifacts/**/summary.json").splitlines())
for tag in raw:
    report=(out/"adjudications"/tag/"report.md").read_text()
    assert "artifacts indexed: 526 from ['artifacts']" in report
result=dict(corpus=corpus,source=published,entries=75,tracked_summary_files=count,
            indexed_artifact_summaries=526,matrix=dict(matrix),
            raw_exclusions=dict(rejected),distinct_excluded_paths=len(paths),holds=sorted(holds),
            registry_sha256=orig)
save(out/"result.json",result)
print(json.dumps(result,sort_keys=True),flush=True)
