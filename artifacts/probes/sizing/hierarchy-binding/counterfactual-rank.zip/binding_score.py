import hashlib
import json
import math
import sys
from collections import Counter
from pathlib import Path

import torch

from cli import _load_eval_checkpoint
from nanochat.diagnostics_data import TASKS, _hier_paths, _parse_hier_tree, hier_bind_answer
from nanochat.tokenizer import HuggingFaceTokenizer

PANEL_HASH = "50d42225c52ea0cfbc5f9e823f76d06708cb90cc6c2b49071187a039d4b6041b"
TRAIN_SHA = "aac00af89abfe2dcf1dfea5f75ceac2f0c1c1ac8"
TOKENIZER_HASH = "65ee2e257fe068be35b6973d67f65bde25cfdccf309e8954425fc320affc7fee"
WEIGHTS = {
    8831: "3ef4f613c2f2bfb372013d53490e918140fba01208afdf07070cc4c9a602d27f",
    8832: "4a44f1fe1baa6adf1aba38f1cb8a7edc9e534e85df75c20d51fb0cc93b32c1e7",
    8833: "ebd4a8d25e102c08f03dbddd7ef271b08693fb55ec76f372c439d0eaf867f19a",
}
EVAL_SEEDS = (3301, 3302, 3303)
REGIONS = ("in_range", "held_out")
KINDS = ("left", "right", "neutral", "left_null", "right_null", "neutral_again")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def split_prompt(doc):
    prefix, answer = TASKS["hier_bind"].split_prompt(doc)
    tree, suffix = prefix.split(" BIND ")
    records, query = suffix.split(" PATH ")
    rows = [row.split() for row in records.split(" ; ")]
    assert all(len(row) == 5 for row in rows)
    assert query.endswith(" OUT") and hier_bind_answer(prefix) == answer
    return prefix, answer, tree, rows, query


def render(tree, rows, query):
    return f"{tree} BIND {' ; '.join(' '.join(row) for row in rows)} PATH {query}"


def visited_scopes(rows, query):
    table = {scope: {a: k, b: j} for scope, a, k, b, j in rows}
    scope = "r"
    visited = set()
    for alias in query.split()[:-1]:
        visited.add(scope)
        scope += table[scope][alias][-1]
    return visited


def swapped(rows, index):
    changed = [row.copy() for row in rows]
    changed[index][2], changed[index][4] = changed[index][4], changed[index][2]
    return changed


def unused_scope_resample(tree, rows, query, changed_index):
    visited = visited_scopes(rows, query)
    depth = len(rows[changed_index][0])
    choices = [i for i, row in enumerate(rows) if row[0] not in visited]
    chosen = min(choices, key=lambda i: (abs(depth - len(rows[i][0])), abs(i - changed_index), i))
    return render(tree, swapped(rows, chosen), query), rows[chosen][0]


def neutralized(rows):
    return [[scope, a, {"a0": "k0", "a1": "k1"}[a], b, {"a0": "k0", "a1": "k1"}[b]]
            for scope, a, _, b, _ in rows]


def pair_inputs(left_doc, right_doc):
    left, a, tree, rows, query = split_prompt(left_doc)
    right, b, other_tree, other_rows, other_query = split_prompt(right_doc)
    assert (tree, query) == (other_tree, other_query) and a != b
    assert Counter(left.split()) == Counter(right.split())
    changed, = [i for i, (l, r) in enumerate(zip(rows, other_rows, strict=True)) if l != r]
    assert swapped(rows, changed) == other_rows
    target_scope = rows[changed][0]
    assert target_scope in visited_scopes(rows, query) & visited_scopes(other_rows, query)
    left_null, left_unused = unused_scope_resample(tree, rows, query, changed)
    right_null, right_unused = unused_scope_resample(tree, other_rows, query, changed)
    assert (hier_bind_answer(left_null), hier_bind_answer(right_null)) == (a, b)
    neutral = render(tree, neutralized(rows), query)
    assert neutral == render(other_tree, neutralized(other_rows), other_query)
    assert all(Counter(prompt.split()) == Counter(left.split()) for prompt in (left_null, right_null, neutral))
    parsed = _parse_hier_tree(tree.split()[3:])
    assert parsed is not None
    candidates = sorted({value for _, value in _hier_paths(parsed)}, key=lambda label: int(label[1:]))
    assert a in candidates and b in candidates and len(candidates) in (4, 8)
    return dict(answers=[a, b], candidates=candidates, changed_scope=target_scope,
                unused_scopes=[left_unused, right_unused],
                prompts=dict(zip(KINDS, (left, right, neutral, left_null, right_null, neutral), strict=True)))


def load_model(prior, seed):
    root = prior / "baseline/artifacts/probes/sizing/baseline/nanochat" / f"hier-bind-{seed}"
    ckpt = root / "checkpoints"
    train = json.loads((root / "summary.json").read_bytes())
    model, meta, step = _load_eval_checkpoint(ckpt, None, torch.device("cpu"), fingerprint_weights=True)
    assert step == 511 and meta["seed"] == seed and meta["weights_sha256"] == WEIGHTS[seed]
    assert train["provenance"]["git_sha"] == TRAIN_SHA and not train["provenance"]["tainted"]
    assert model.config.sequence_len == 192 and model.config.attention_type == "standard"
    tokenizer_dir = ckpt / "tokenizer"
    assert sha(tokenizer_dir / "tokenizer.json") == TOKENIZER_HASH
    tok = HuggingFaceTokenizer.from_directory(str(tokenizer_dir))
    return model.eval(), tok


@torch.inference_mode()
def score_pair(model, tok, pair):
    bos = tok.get_bos_token_id()
    lengths = set()
    rows = []
    target_lengths = set()
    for prompt in pair["prompts"].values():
        ids = tok.encode(prompt, prepend=bos)
        lengths.add(len(ids))
        for answer in pair["candidates"]:
            full = tok.encode(f"{prompt} {answer}", prepend=bos)
            assert full[:len(ids)] == ids and len(ids) < len(full) <= model.config.sequence_len
            target_lengths.add(len(full) - len(ids))
            rows.append(full)
    boundary, = lengths
    suffix_length, = target_lengths
    ids = torch.tensor(rows)
    logits = model(ids[:, :-1])[:, boundary - 1:]
    targets = ids[:, boundary:].unsqueeze(-1)
    sums = logits.double().log_softmax(-1).gather(-1, targets).squeeze(-1).sum(-1)
    groups = sums.reshape(len(KINDS), len(pair["candidates"])).tolist()
    grouped = dict(zip(KINDS, groups, strict=True))
    assert grouped.pop("neutral_again") == grouped["neutral"]
    assert all(math.isfinite(value) for group in grouped.values() for value in group)
    return dict(prompt_tokens=boundary, answer_tokens=suffix_length, scores=grouped)


def run(panel_path, prior, output):
    assert sha(panel_path) == PANEL_HASH
    panel = json.loads(panel_path.read_bytes())
    assert set(panel) == set(map(str, EVAL_SEEDS))
    pairs = []
    for seed in EVAL_SEEDS:
        for region in REGIONS:
            docs = panel[str(seed)][region]
            assert len(docs) == 24
            for i, (left, right) in enumerate(zip(docs[::2], docs[1::2], strict=True)):
                pair = pair_inputs(left, right)
                assert len(pair["candidates"]) == (4 if region == "in_range" else 8)
                pairs.append(dict(eval_seed=seed, region=region, index=i, **pair))
    assert len(pairs) == 72

    outcomes = {}
    for seed in WEIGHTS:
        model, tok = load_model(prior, seed)
        outcomes[seed] = [
            {**{key: value for key, value in pair.items() if key != "prompts"}, **score_pair(model, tok, pair)}
            for pair in pairs
        ]
        print(f"Checkpoint {seed}: scored 72 pairs, with equal-length full answers and neutral duplicates", flush=True)
    with output.open("x", encoding="utf-8") as stream:
        json.dump(dict(panel_sha256=PANEL_HASH, checkpoint_sha256=WEIGHTS, tokenizer_sha256=TOKENIZER_HASH,
                       results=outcomes), stream, allow_nan=False, indent=2)
        stream.write("\n")


if __name__ == "__main__":
    torch.set_num_threads(2)
    run(*map(Path, sys.argv[1:]))
