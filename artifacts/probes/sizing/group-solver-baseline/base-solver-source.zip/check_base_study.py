"""Independently replay the group actions, model policy, and search scopes."""

import argparse
import copy
import json
from itertools import pairwise, product
from pathlib import Path

from check_study import (
    ANCHORS,
    action_truth,
    model_endpoint,
    rooted,
    shortest_word,
    untimed,
    validate_check,
    verify_selection,
    walk,
)
from verify import witness_endpoint

SPECS = (
    ("pentagon-turn-first", "ring", (5,), ("T", "F"), False),
    ("hexagon-mirrors", "ring", (6,), ("T", "FT"), False),
    ("octagon-mirrors", "ring", (8,), ("T", "FT"), False),
    ("nonagon-turn-first", "ring", (9,), ("T", "F"), False),
    ("two-by-four-torus", "torus", (2, 4), ("F", "F"), False),
    ("three-by-four-torus", "torus", (3, 4), ("F", "F"), False),
    ("tetrahedron", "tetrahedron", (), ("T", "T"), False),
    ("two-by-four-exhausted", "torus", (2, 4), ("F", "F"), True),
)
ARMS = ("square", "conjugation", "reuse", "rank", "combined")


def expected_action(spec, labels):
    case, kind, dimensions, primitives, exhausted = spec
    if kind == "ring":
        return action_truth((case, kind, dimensions[0], primitives, exhausted), labels)
    if kind == "torus":
        height, width = dimensions
        grid = dict(zip(product(range(height), range(width)), labels, strict=True))
        return {
            "0": {name: grid[(row + 1) % height, col] for (row, col), name in grid.items()},
            "1": {name: grid[row, (col + 1) % width] for (row, col), name in grid.items()},
        }
    klein = ((0, 1, 2, 3), (1, 0, 3, 2), (2, 3, 0, 1), (3, 2, 1, 0))
    elements = sorted(p for a, b, c, d in klein for p in ((a, b, c, d), (b, c, a, d), (c, a, b, d)))
    names = dict(zip(elements, labels, strict=True))
    return {
        "0": {name: names[b, c, a, d] for (a, b, c, d), name in names.items()},
        "1": {name: names[b, a, d, c] for (a, b, c, d), name in names.items()},
    }


def conjugate(model, a, b):
    swap = {a: b, b: a}
    result = {"root": swap.get(model["root"], model["root"])}
    for key in ("R0", "R1", "L0", "L1"):
        mapping = {swap.get(i, i): swap.get(dest, dest) for i, dest in enumerate(model[key])}
        result[key] = [mapping[i] for i in range(len(mapping))]
    return result


def expected_reuse(event, names, exposed):
    word, received = event["word"], names.index(event["answer"])
    models = (event["first"], event["second"])
    predictions = [model_endpoint(model, word) for model in models]
    for model, predicted, method in zip(models, predictions, ("first-model", "second-model"), strict=True):
        if predicted == received:
            return model, method
    if received not in exposed:
        for model, predicted in zip(models, predictions, strict=True):
            if predicted not in exposed:
                return conjugate(model, predicted, received), "new-name-transposition"
    return None, None


def verify_new_arm(row, names, initial, arm):
    facts = dict(initial)
    expected_trace, paid = [], []
    terminal = initial_status = None
    bases = reused = ranked = alternatives = swaps = 0
    next_model, method = None, None
    width = (len(names) - 1).bit_length()

    def value(index):
        return f"(_ bv{index} {width})"

    for event in row["events"]:
        if terminal is not None:
            raise ValueError("Search continued after a terminal decision")
        exposed = {names.index(label) for label in facts.values()}
        unseen = set(range(len(names))) - exposed
        if next_model is None:
            order = sorted(unseen) if arm in {"rank", "combined"} and len(unseen) > 1 else []
            if event.get("rank_order") != order or "reuse" in event:
                raise ValueError("Base check violated its assigned rank/reuse policy")
            if order:
                ranked += 1
                expected_trace.append("(push)")
                expected_trace.extend(
                    f"(assert (bvult (rank {value(a)}) (rank {value(b)})))" for a, b in pairwise(order)
                )
            expected_trace.append("(check-sat)")
            if order:
                expected_trace.append("(pop)")
            bases += 1
            status = validate_check(event["base"])
            initial_status = initial_status or status
            if status == "unknown":
                terminal = "unknown-base"
                continue
            if status != "sat":
                raise ValueError("Base check found inconsistent observations")
        else:
            if ("base" in event or "rank_order" in event or event.get("reuse") != method
                    or event.get("first") != next_model):
                raise ValueError("Recorded reuse does not match the prior paid answer")
            reused += 1

        first = event["first"]
        witness_endpoint(first, names, facts, "00")
        if len(unseen) >= 2:
            word = event["word"]
            a = model_endpoint(first, word)
            b = min(unseen - {a})
            first_access = shortest_word(lambda w, model=first, states=unseen: model_endpoint(model, w) in states, len(word))
            if (a not in unseen or event.get("swap") != [a, b] or "alternative" in event
                    or event["second"] != conjugate(first, a, b)
                    or word != first_access):
                raise ValueError("Wrong transposition or first access word")
            swaps += 1
        else:
            if "swap" in event:
                raise ValueError("Swapped a known name")
            differences = " ".join(
                f"(distinct vR{mark}x{i} {value(dest)})"
                for mark in "01" for i, dest in enumerate(first["R" + mark])
            )
            expected_trace.extend(("(push)", f"(assert (or {differences}))", "(check-sat)", "(pop)"))
            alternatives += 1
            status = validate_check(event["alternative"])
            if status == "unknown":
                terminal = "unknown-alternative"
                continue
            if status == "unsat":
                terminal = "unique-right-table"
                for mark in "01":
                    expected = dict(zip(names, (names[i] for i in first["R" + mark]), strict=True))
                    if row["right"][mark] != expected:
                        raise ValueError("Final table disagrees with the witness")
                continue

        word = event["word"]
        if word in facts or not 3 <= len(word) <= len(names) + 2:
            raise ValueError("Unexpected oracle query")
        second = event["second"]
        if witness_endpoint(second, names, facts, word) == names[model_endpoint(first, word)]:
            raise ValueError("Both candidate models predict the same answer")
        earliest = shortest_word(lambda w, a=first, b=second: model_endpoint(a, w) != model_endpoint(b, w), len(word))
        if word != earliest:
            raise ValueError("A shorter or lexicographically earlier disagreement exists")
        paid.append([word, event["answer"]])
        if arm in {"reuse", "combined"}:
            next_model, method = expected_reuse(event, names, exposed)
        facts[word] = event["answer"]

    if (row["trace"] != expected_trace or row["terminal"] != (terminal or "query-cap")
            or row["paid"][:len(paid)] != paid):
        raise ValueError("Search scopes, stopping rule, or native paid tape differs")
    if terminal == "unique-right-table" and row["paid"] != paid:
        raise ValueError("Extra labels after a uniqueness result")
    return {
        "base_checks": bases, "reused": reused, "ranked": ranked, "alt_checks": alternatives, "swaps": swaps,
        "native_reads": len(paid), "fallback_reads": len(row["paid"]) - len(paid), "first_base": initial_status,
    }


def verify(record):
    manifest = tuple(
        (c["case"], c["kind"], tuple(c["dimensions"]), tuple(c["primitives"]), c["exhausted"])
        for c in record["cases"]
    )
    if manifest != SPECS or record["rlimit"] != 2_000_000 or not record["z3"].startswith("Z3 version 4.15.4 "):
        raise ValueError("Changed case manifest or solver budget")
    rows, seen = [], set()
    for case, spec in zip(record["cases"], SPECS, strict=True):
        labels = case["labels"]
        names = sorted(labels)
        if names != [f"opaque{i:02d}" for i in range(len(labels))]:
            raise ValueError("Malformed opaque label roster")
        truth = expected_action(spec, labels)
        root = labels[0]
        graph = rooted(truth, root)
        if len(graph) != len(labels) or (graph in seen) != spec[4]:
            raise ValueError("Unexpected duplicate or disconnected marked action")
        seen.add(graph)
        initial = {word: walk(root, truth, word) for word in ANCHORS}
        if case["initial"] != initial or set(case["arms"]) != set(ARMS):
            raise ValueError("Changed bootstrap or arm set")
        results = {}
        for arm, row in case["arms"].items():
            if row["right"] != truth:
                raise ValueError("Recovered action differs from ground truth")
            words = set(initial)
            for word, answer in row["paid"]:
                if word in words or len(word) < 2 or walk(root, truth, word) != answer:
                    raise ValueError("Incorrect or duplicate oracle call")
                words.add(word)
            movement = "".join(spec[3][int(mark)] for word in sorted(words) for mark in word)
            counts = {
                "reads": len(words), "turns": movement.count("T"), "advances": movement.count("F"),
                "symbols": sum(map(len, words)), "cpu_ns": row["cpu_ns"], "terminal": row["terminal"],
            }
            if arm == "square":
                if row["events"] or row["trace"] is not None or row["terminal"] != "closure":
                    raise ValueError("Square arm reports solver work")
            elif arm == "conjugation":
                counts.update(verify_selection(row, names, initial, can_swap=True))
                counts["first_base"] = validate_check(row["events"][0]["base"])
            else:
                counts.update(verify_new_arm(row, names, initial, arm))
            if spec[4] and arm != "square" and (
                row["terminal"] != "unknown-base" or row["paid"] != case["arms"]["square"]["paid"]
            ):
                raise ValueError("Forced exhaustion did not preserve square fallback")
            results[arm] = counts
        rows.append({"case": spec[0], "edges": 2 * len(names), "arms": results})
    return rows


def reject_forgery(record, target):
    forged = copy.deepcopy(record)
    for case in forged["cases"]:
        row = case["arms"]["rank" if target == "scope" else "reuse"]
        if target == "scope" and "(pop)" in row["trace"]:
            row["trace"].remove("(pop)")
            break
        if target == "reuse":
            event = next((e for e in row["events"] if "reuse" in e), None)
            if event:
                event["reuse"] = "forged"
                break
    else:
        return False
    try:
        verify(forged)
    except ValueError:
        return True
    raise ValueError(f"Checker accepted forged {target} evidence")


def decision(rows):
    ordinary = rows[:-1]
    completed = {
        arm: {row["case"] for row in ordinary if row["arms"][arm]["terminal"] == "unique-right-table"}
        for arm in ARMS[1:]
    }
    rescued = {
        arm: [row["case"] for row in ordinary if row["arms"][arm]["first_base"] == "sat"
              and row["arms"]["conjugation"]["first_base"] == "unknown"]
        for arm in ARMS[2:]
    }
    counters = ("reads", "symbols", "turns", "advances", "cpu_ns", "base_checks", "reused", "ranked",
                "alt_checks", "swaps", "native_reads", "fallback_reads")
    totals = {
        arm: {key: sum(row["arms"][arm].get(key, 0) for row in ordinary) for key in counters}
        for arm in ARMS
    }
    baseline = completed["conjugation"]
    return {
        "edges_per_arm": sum(row["edges"] for row in rows),
        "completed": {arm: sorted(cases) for arm, cases in completed.items()},
        "improved_completion": {arm: baseline < completed[arm] for arm in ARMS[2:]},
        "halved_base_checks_without_coverage_loss": {
            arm: 2 * totals[arm]["base_checks"] <= totals["conjugation"]["base_checks"] and baseline <= completed[arm]
            for arm in ("reuse", "combined")
        },
        "rescued_initial_unknowns": rescued,
        "totals": totals,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("scored", type=Path)
    parser.add_argument("replay", type=Path)
    args = parser.parse_args()
    try:
        scored, replay = (json.loads(path.read_text(encoding="utf-8")) for path in (args.scored, args.replay))
    except (OSError, ValueError) as error:
        parser.error(str(error))
    rows = verify(scored)
    verify(replay)
    if untimed(scored) != untimed(replay):
        raise ValueError("Non-timing fields changed on replay")
    controls = {target: reject_forgery(scored, target) for target in ("scope", "reuse")}
    print(json.dumps({"exact_replay": True, "forgeries_rejected": controls, "decision": decision(rows), "rows": rows}, indent=2))


if __name__ == "__main__":
    main()
