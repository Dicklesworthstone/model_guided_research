"""Prospectively fixed exact endpoint-acquisition comparison."""

import argparse
import json
import random
import re
import resource
import subprocess
import time
from heapq import heappop, heappush
from itertools import permutations, product
from pathlib import Path

from scripts.group_rewrite_probe import teach_panel_case

SIDES = ("R0", "R1", "L0", "L1")
PANEL = (("d14", 3), ("q16", 3), ("f21", 5), ("s4", 5))


def group(family):
    if family in {"s3", "s4"}:
        degree = int(family[1:])
        elements = tuple(permutations(range(degree)))

        def multiply(x, y):
            return tuple(x[i] for i in y)

        return elements, multiply
    modulus, orders, conjugation, carry = {
        "c5": (5, 1, 1, 0),
        "d14": (7, 2, -1, 0),
        "q16": (8, 2, -1, 4),
        "f21": (7, 3, 2, 0),
    }[family]

    def multiply(x, y):
        a, b = x
        c, d = y
        return (a + conjugation**b * c + carry * (b + d >= orders)) % modulus, (b + d) % orders

    return tuple(product(range(modulus), range(orders))), multiply


def rooted(elements, multiply, generators):
    orbit = [elements[0]]
    indices = {orbit[0]: 0}
    rows = []
    for x in orbit:
        destinations = []
        for g in generators:
            endpoint = multiply(x, g)
            if endpoint not in indices:
                indices[endpoint] = len(orbit)
                orbit.append(endpoint)
            destinations.append(indices[endpoint])
        rows.append(tuple(destinations))
    return tuple(rows)


def fixtures(development):
    families = (("c5", 1), ("s3", 1)) if development else PANEL
    for number, (family, repeats) in enumerate(families):
        rng = random.Random((2026112401 if development else 2026112501) + number)
        elements, multiply = group(family)
        seen = set()
        for _ in range(10_000):
            generators = tuple(rng.choices(elements, k=2))
            rows = rooted(elements, multiply, generators)
            if len(rows) != len(elements) or rows in seen:
                continue
            seen.add(rows)
            labels = [f"u{i:02d}" for i in range(len(rows))]
            rng.shuffle(labels)
            yield family, generators, rows, labels
            if len(seen) == repeats:
                break
        if len(seen) != repeats:
            raise ValueError(f"Insufficient distinct rooted actions: {family}")


class SolverTeacher:
    """Only public observations enter the solver. The callback is the oracle."""

    def __init__(self, solver, initial, names, ask, *, audit, low_resource):
        self.ask = ask
        self.names = names
        self.audit = audit
        self.solver = solver
        self.indices = {name: index for index, name in enumerate(names)}
        self.width = (len(names) - 1).bit_length()
        self.events = []
        self.proc = None
        self.initial = initial
        self.low_resource = low_resource

    def initialize(self):
        names = self.names
        sort = f"(_ BitVec {self.width})"
        self.commands = [
            "(set-logic QF_UFBV)",
            "(set-option :timeout 5000)",
            f"(set-option :rlimit {1 if self.low_resource else 10000000})",
            "(set-option :smt.random_seed 0)",
            f"(declare-const root {sort})",
        ]
        if len(names) < 1 << self.width:
            self.commands.append(f"(assert (bvult root {self.value(len(names))}))")
        self.model_keys = ["root"]
        for side in SIDES:
            self.commands.append(f"(declare-fun {side} ({sort}) {sort})")
            keys = [f"v{side}x{i}" for i in range(len(names))]
            self.model_keys.extend(keys)
            for i, key in enumerate(keys):
                self.commands.append(f"(define-fun {key} () {sort} ({side} {self.value(i)}))")
                if len(names) < 1 << self.width:
                    self.commands.append(f"(assert (bvult {key} {self.value(len(names))}))")
            self.commands.append(f"(assert (distinct {' '.join(keys)}))")
        for x, y in product("01", repeat=2):
            for i in range(len(names)):
                v = self.value(i)
                self.commands.append(f"(assert (= (L{x} (R{y} {v})) (R{y} (L{x} {v}))))")
        for symbol in "01":
            self.commands.append(f"(assert (= (L{symbol} root) (R{symbol} root)))")
        # A strictly decreasing predecessor rank witnesses reachability.
        self.commands.extend((
            f"(declare-fun rank ({sort}) {sort})",
            f"(declare-fun predecessor ({sort}) {sort})",
            f"(assert (= (rank root) {self.value(0)}))",
        ))
        for i in range(len(names)):
            v = self.value(i)
            parent = f"(predecessor {v})"
            in_range = f"(bvult {parent} {self.value(len(names))})" if len(names) < 1 << self.width else "true"
            self.commands.append(
                f"(assert (or (= root {v}) (and {in_range} "
                f"(bvult (rank {parent}) (rank {v})) "
                f"(or (= (R0 {parent}) {v}) (= (R1 {parent}) {v})))))"
            )
        for word, label in self.initial.items():
            self.commands.append(self.assert_endpoint(word, label))

    def value(self, item):
        return f"(_ bv{item} {self.width})"

    def word_term(self, word):
        term = "root"
        for letter in word:
            term = f"(R{letter} {term})"
        return term

    def assert_endpoint(self, word, label):
        return f"(assert (= {self.word_term(word)} {self.value(self.indices[label])}))"

    def exchange(self, *commands):
        if self.proc is None:
            self.initialize()
            self.proc = subprocess.Popen(
                [self.solver, "-in", "-smt2"], stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True
            )
        assert self.proc.stdin is not None and self.proc.stdout is not None
        self.proc.stdin.write("\n".join((*self.commands, *commands, '(echo "END-MGR")', "")))
        self.commands.clear()
        self.proc.stdin.flush()
        lines = []
        while True:
            line = self.proc.stdout.readline()
            if not line or line.startswith("(error"):
                raise ValueError(f"Z3 protocol failed: {line!r}")
            if line.strip() == "END-MGR":
                return "".join(lines).strip()
            lines.append(line)

    def witness(self):
        raw = self.exchange(f"(get-value ({' '.join(self.model_keys)}))")
        values = {
            key: int(value[2:], 2 if value[1] == "b" else 16)
            for key, value in re.findall(r"\((\w+) (#(?:b[01]+|x[\da-f]+))\)", raw)
        }
        if set(values) != set(self.model_keys):
            raise ValueError(f"Invalid get-value response: {raw!r}")
        return {
            "root": values["root"],
            **{side: [values[f"v{side}x{i}"] for i in range(len(self.names))] for side in SIDES},
        }

    def endpoint(self, word):
        raw = self.exchange(f"(get-value ({self.word_term(word)}))")
        value = re.search(r" (#(?:b[01]+|x[\da-f]+))\)\)$", raw)
        if value is None:
            raise ValueError(f"Invalid endpoint response: {raw!r}")
        digits = value[1]
        return int(digits[2:], 2 if digits[1] == "b" else 16)

    def __call__(self, word):
        start = self.exchange("(check-sat)")
        if start not in {"sat", "unknown"}:
            raise ValueError(f"Public group observations are inconsistent: {start}")
        event = {"word": word, "base": start, "alternative": None, "candidates": [], "models": []}
        candidate = None
        if start == "sat":
            index = self.endpoint(word)
            candidate = self.names[index]
            event["candidates"].append(candidate)
            if self.audit:
                event["models"].append(self.witness())
            alternative = self.exchange(
                "(push)", f"(assert (distinct {self.word_term(word)} {self.value(index)}))", "(check-sat)"
            )
            if alternative == "sat":
                event["candidates"].append(self.names[self.endpoint(word)])
                if self.audit:
                    event["models"].append(self.witness())
            elif alternative not in {"unsat", "unknown"}:
                raise ValueError(f"Unexpected Z3 alternative result: {alternative}")
            self.exchange("(pop)")
            event["alternative"] = alternative
        if event["alternative"] == "unsat":
            assert candidate is not None
            label = candidate
        else:
            label = self.ask(word)
            self.commands.append(self.assert_endpoint(word, label))
        self.events.append(event | {"label": label})
        return label

    def close(self):
        if self.proc is None:
            return
        assert self.proc.stdin is not None and self.proc.stdout is not None
        self.proc.stdin.close()
        status = self.proc.wait(timeout=10)
        self.proc.stdout.close()
        if status != 0:
            raise ValueError(f"Z3 exited {status}")


def visible_exploration(initial, names, ask):
    """Reset-word adaptation of visible-state exploration on permutations."""
    right = {symbol: {} for symbol in "01"}
    for word, target in initial.items():
        if word[:-1] in initial:
            right[word[-1]][initial[word[:-1]]] = target
    best = {}
    for word, target in initial.items():
        best.setdefault(target, word)
    frontier = [(len(word), word, state) for state, word in best.items()]
    frontier.sort()
    proposals = []
    while frontier:
        _, word, state = heappop(frontier)
        if best[state] != word:
            continue
        for symbol, column in right.items():
            extension = word + symbol
            if state not in column:
                unused = names.difference(column.values())
                if len(unused) == 1:
                    (column[state],) = unused
                else:
                    column[state] = ask(extension)
                    proposals.append((extension, column[state]))
            target = column[state]
            if target not in best or (len(extension), extension) < (len(best[target]), best[target]):
                best[target] = extension
                heappush(frontier, (len(extension), extension, target))
    if any(set(column) != names for column in right.values()):
        raise ValueError("Visible explorer failed to visit the complete action")
    return right, proposals


def run_case(rows, labels, solver, initial_depth, order, *, audit, low_resource):
    def endpoint(word):
        position = 0
        for letter in word:
            position = rows[position][int(letter)]
        return labels[position]

    initial = {
        word: endpoint(word)
        for length in range(2, initial_depth + 1)
        for letters in product("01", repeat=length)
        if (word := "".join(letters))
    }
    result = {}
    for arm in order:
        paid = []

        def ask(word):
            label = endpoint(word)
            paid.append([word, label])
            return label

        children_before = resource.getrusage(resource.RUSAGE_CHILDREN)
        cpu_start = time.process_time_ns()
        wall_start = time.monotonic_ns()
        if arm == "z3":
            teacher = SolverTeacher(solver, initial, sorted(labels), ask, audit=audit, low_resource=low_resource)
            try:
                actions, proposals = teach_panel_case(initial, set(labels), teacher, squares=True)
            finally:
                teacher.close()
            events = teacher.events
            solver_started = teacher.proc is not None
            right = {a: actions.maps["R" + a] for a in "01"}
        elif arm == "square":
            actions, proposals = teach_panel_case(initial, set(labels), ask, squares=True)
            right = {a: actions.maps["R" + a] for a in "01"}
            events = []
            solver_started = False
        else:
            right, proposals = visible_exploration(initial, set(labels), ask)
            events = []
            solver_started = False
        wall_ns = time.monotonic_ns() - wall_start
        cpu_ns = time.process_time_ns() - cpu_start
        children_after = resource.getrusage(resource.RUSAGE_CHILDREN)
        child_cpu_ns = round(
            1e9 * (
                children_after.ru_utime + children_after.ru_stime
                - children_before.ru_utime - children_before.ru_stime
            )
        )
        result[arm] = {
            "right": right,
            "paid": paid,
            "proposals": proposals,
            "solver_events": events,
            "solver_started": solver_started,
            "cpu_ns": cpu_ns + child_cpu_ns,
            "solver_cpu_ns": child_cpu_ns,
            "wall_ns": wall_ns,
        }
    return {"initial": initial, "order": order, "arms": result}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("--z3", default="z3")
    parser.add_argument("--development", action="store_true")
    parser.add_argument("--audit", action="store_true")
    parser.add_argument("--control", choices=("full", "unknown"))
    args = parser.parse_args()
    if args.control and not args.development:
        parser.error("--control requires --development")
    version = subprocess.check_output([args.z3, "--version"], text=True).strip()
    if not version.startswith("Z3 version 4.15.4 "):
        raise ValueError(f"Expected Z3 4.15.4: {version}")
    cases = []
    for i, (family, generators, rows, labels) in enumerate(fixtures(args.development)):
        arms = ("square", "z3", "visible")
        offset = i % len(arms)
        order = arms[offset:] + arms[:offset]
        depth = 8 if args.control == "full" else 2 if args.development else 4
        result = run_case(
            rows, labels, args.z3, depth, order, audit=args.audit, low_resource=args.control == "unknown"
        )
        case = {"family": family, "generators": generators, "labels_bfs": labels, **result}
        cases.append(case)
        print(f"{i + 1:2d} {family}: completed all three learners", flush=True)
    with args.output.open("x") as handle:
        json.dump(
            {"z3_version": version, "development": args.development, "audit": args.audit, "control": args.control,
             "cases": cases},
            handle,
            sort_keys=True,
        )
        handle.write("\n")


if __name__ == "__main__":
    main()
