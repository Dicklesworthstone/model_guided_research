import json
import sys
from collections import Counter
from itertools import permutations
from pathlib import Path
from zipfile import ZipFile

import pyarrow.parquet as pq

root, inputs = map(Path, sys.argv[1:])
training = pq.read_table(inputs / 'data/group/train_000.parquet').column('text').to_pylist()
labels = {}
for doc in training:
    t = doc.split()
    labels[t[3], ''.join(v[1:] for v in t[5:-2])] = t[-1]
generators = {'s5': ((1,0,2,3,4),(1,2,3,4,0)), 'a5': ((1,2,0,3,4),(1,2,3,4,0)), 's3': ((1,0,2),(1,2,0))}
catalog = {}
for g,(a,b) in generators.items():
    ps = list(permutations(range(len(a))))
    if g == 'a5':
        ps = [p for p in ps if sum(x>y for i,x in enumerate(p) for y in p[i+1:])%2 == 0]
    catalog[g] = {p:i for i,p in enumerate(ps)}
def endpoint(g,w):
    if g == 'z60':
        return 'e'+str(sum(1 if v=='0' else 7 for v in w)%60)
    a,b = generators[g]
    dest = []
    for x in range(len(a)):
        for v in w:
            x=(a,b)[int(v)][x]
        dest.append(x)
    return 'e'+str(catalog[g][tuple(dest)])
assert all(endpoint(g,w)==e for (g,w),e in labels.items())
for seed in range(3):
    pseudo=json.loads((root/f'self-labels-{seed}.json').read_text())
    short_ok=sum(pseudo[g].get(w)==y for (g,w),y in labels.items() if g in ('s5','a5'))
    print('seed',seed,'short S5/A5 correct',short_ok,'of',1016)
    for arm in ('primary','transfer-supervised','transfer-blind'):
        data=json.loads((root/f'{arm}-{seed}.json').read_text())
        assert len(data)==144 and len({(r['seed'],r['index']) for r in data})==144
        used=Counter()
        for r in data:
            g=r['group']; w=r['word']
            assert endpoint(g,w)==r['expected']
            for i,old,new in r['steps']:
                assert w[i:i+len(old)]==old and len(old)>len(new)
                if arm.endswith('blind'):
                    assert pseudo[g][old]==pseudo[g][new]
                else:
                    assert labels[g,old]==labels[g,new]
                if g in ('s5','a5'):
                    used['valid' if labels[g,old]==labels[g,new] else 'invalid']+=1
                w=w[:i]+new+w[i+len(old):]
            assert w==r['compact'] and sorted(w)==sorted(r['sham'])
            assert endpoint(g,w)==r['compact_endpoint'] and endpoint(g,r['sham'])==r['sham_endpoint']
        print(arm,seed,'S5/A5 substitutions',dict(used))
print('Verified all training labels, 1296 row traces, original and compact and sham endpoints.')
