import hashlib
import itertools
import json
import sys
from collections import Counter
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import calibration as c
from address_fixtures import DIM, SEEDS, evaluation, sha_json

SOURCE = "ad6e65a3fba227743c7ca1ad5ce486141ccaf413"
LOCK = "1ed2c9474b355f5c50cd20b9bda66aec14e3f7f9a5b2ddbac4879902ad2d243e"
PRIOR = "12c4c7f53a128476594c1aca0e51da0f609084801cf375f788b9b7b2ff8782c8"
FILES = ("address_fixtures.py", "calibration.py", "calibrate.yaml", "protocol.txt", "frozen.sha256",
         "benchmark.json", "calibration_replay.py", "argument.md", "replay.yaml")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def transform(key, permutation, signs):
    digits = f"{key:08b}"[::-1]
    mapped = "".join(digits[source] for source in reversed(permutation))
    return int(mapped, 2) ^ signs


def trial_maps(anchors):
    x0, y0 = anchors[0]
    for order in itertools.permutations(range(DIM)):
        signs = transform(x0, order, 0) ^ y0
        if all(transform(x, order, signs) == y for x, y in anchors[1:]):
            yield order, signs


def exhaustive_anchor_orbit():
    words = range(1 << DIM)
    namespace = ((3, 7, 0, 6, 1, 4, 2, 5), 181)
    anchors = tuple((x, transform(x, *namespace)) for x in c.DESIGNED)
    observed = []
    for count, expected in [(3, 16), (4, 1)]:
        maps = list(trial_maps(anchors[:count]))
        assert len(maps) == expected
        possible = {q: set() for q in words}
        for namespace in maps:
            for key in words:
                possible[transform(key, *namespace)].add(key)
        computed, total, _, _ = c.resolve(words, words, anchors[:count], False)
        assert total == len(maps)
        assert {q: set(options) for q, options in computed.items()} == possible
        observed.append(dict(anchors=count, maps=total, pointer_orbits=len(possible)))
    return observed


def check_witness(raw):
    records = {int(k): v for k, v in raw["records"].items()}
    anchors = raw["external_anchors"] + [[key, x] for key, (x, y) in records.items() if x == y]
    answers = Counter()
    for params in trial_maps(anchors):
        address = {transform(key, *params): key for key in records}
        if address.keys() != records.keys():
            continue
        root = address[raw["root"]]
        frontier = [root]
        seen = {root}
        for hop in range(len(raw["query"])):
            children = [address[q] for key in frontier for q in records[key]]
            assert len(set(children)) == len(children) and not seen.intersection(children)
            seen.update(children)
            frontier = children
        assert seen == records.keys()
        assert all([address[q] for q in records[key]] == [key, key] for key in frontier)
        node = root
        for alias in raw["query"]:
            node = address[records[node][alias]]
        answers[node] += 1
    assert sorted(answers) == raw["two_valid_targets"] == [8, 32]
    assert raw == json.loads(json.dumps(c.witness()))
    return dict(targets=sorted(answers), consistent_maps=sum(answers.values()))


def check_routes(pair, namespace):
    for doc in pair:
        address = {transform(key, *namespace): pos for pos, key in enumerate(doc["keys"])}
        assert len(address) == len(doc["keys"])
        edges = [[address[ptr] for ptr in row] for row in doc["link"]]
        assert edges == doc["edge"]
        route = [address[doc["root"]]]
        for alias in doc["query"]:
            route.append(edges[route[-1]][alias])
        assert route == doc["chain"]


def replay_prior(prior_archive):
    assert digest(prior_archive.read_bytes()) == PRIOR
    totals = []
    with ZipFile(prior_archive) as archive:
        assert digest(archive.read("address_fixtures.py")) == digest(Path(c.__file__).with_name("address_fixtures.py").read_bytes())
        for seed in SEEDS:
            panel = evaluation(seed)
            report = json.loads(archive.read(f"fit-{seed}.json"))
            assert report["panel"] == sha_json(panel)
            namespace = report["namespace"]
            for depth, docs in panel.items():
                solved = 0
                for pair in zip(docs[::2], docs[1::2], strict=True):
                    check_routes(pair, namespace)
                    first = pair[0]
                    records = c.observe(first)
                    leaf = [(key, q) for key, (q, r) in records.items() if q == r]
                    inverse = {transform(key, *namespace): key for key in records}
                    possible, _, _, _ = c.resolve(records, inverse, leaf, False)
                    edges = []
                    for doc in pair:
                        actual = c.traverse(c.observe(doc), doc["root"], doc["query"], possible)
                        gold = [doc["keys"][i] for i in doc["chain"]]
                        assert actual == gold[:len(actual)]
                        edges.append(actual == gold)
                    solved += all(edges)
                totals.append(dict(seed=seed, depth=int(depth), solved=solved, pairs=len(docs) // 2))
    return totals


def verify_receipt(read, names):
    receipt_path, = (n for n in names if n.endswith("/receipt.json"))
    receipt = json.loads(read(receipt_path))
    assert receipt["tool"] == "hierarchy-dynamic-namespace" and receipt["status"] == "passed"
    assert receipt["passed"] == receipt["executed"] == receipt["total"] == 1
    assert not receipt["dry_run"] and not receipt["skipped"]
    check, = receipt["checks"]
    assert check["passed"] and check["executed"] and check["exit_code"] == 0
    log = Path(receipt_path).with_name(Path(check["log_path"]).name).as_posix()
    assert digest(read(log)) == check["log_sha256"]
    cfg = Path(receipt_path).with_name("checks-config.yaml").as_posix()
    assert read(cfg) == read("calibrate.yaml")
    assert digest(read(cfg)) == receipt["config_sha256"] == receipt["config_sha256_after"]
    return Path(receipt_path).parent.name


def replay(read, names, prior_archive):
    manifest = read("frozen.sha256")
    assert digest(manifest) == LOCK
    for line in manifest.decode().splitlines():
        sha, path = line.split()
        assert digest(read(path)) == sha
    raw = json.loads(read("benchmark.json"))
    assert len(raw["rows"]) == 252
    totals = {str(depth): {mode: dict(pairs=0, complete=0, full_map=0, unique=0, pointers=0)
                           for mode in c.MODES} for depth, _ in c.CELLS}
    three_anchor_spaces = []
    for raw_case, fixture in zip(raw["rows"], c.fresh(), strict=True):
        seed, depth, pair_id, pair, namespace, external = fixture
        assert (seed, depth, pair_id) == tuple(raw_case[k] for k in ("seed", "depth", "pair_id"))
        assert raw_case["namespace"] == [list(namespace[0]), namespace[1]]
        assert sha_json(pair) == raw_case["fixture"]
        assert set(external + list(c.DESIGNED)).isdisjoint(pair[0]["keys"])
        check_routes(pair, namespace)
        outcomes = c.score(pair, namespace, external)
        assert outcomes == raw_case["outcomes"]
        three_anchor_spaces.append(outcomes["designed3"]["maps_from_matches"])
        for name, result in outcomes.items():
            cell = totals[str(depth)][name]
            cell["pairs"] += 1
            cell["complete"] += result["complete"]
            cell["full_map"] += result["maps_from_matches"] == 1
            cell["unique"] += result["unique"]
            cell["pointers"] += len(pair[0]["keys"])
        if depth == 6:
            absent, = set(c.POOLS[1]) - set(pair[0]["keys"])
            antipode = absent ^ ((1 << DIM) - 1)
            assert antipode in pair[0]["keys"]
            assert outcomes["bank"]["unique"] <= 1
    assert {depth: cell["bank"]["pairs"] for depth, cell in totals.items()} == {"2": 72, "3": 72, "4": 72, "6": 36}
    prior = replay_prior(prior_archive)
    assert raw["prior_leaf_anchor"] == prior and sum(row["pairs"] for row in prior) == 360
    gates = dict(
        designed=all(arms["designed4"]["complete"] == arms["designed4"]["full_map"] == arms["designed4"]["pairs"]
                     for arms in totals.values()),
        three_anchor_space=set(three_anchor_spaces) == {16},
        near_full_blind=totals["6"]["bank"]["complete"] == 0,
        leaf_depth4=totals["4"]["leaf"]["complete"] >= 58,
        leaf_depth6=totals["6"]["leaf"]["complete"] >= 29,
    )
    return dict(source=SOURCE, receipt=verify_receipt(read, names), cases=totals, gates=gates, pass_all=all(gates.values()),
                exhaustive=exhaustive_anchor_orbit(), ambiguity=check_witness(raw["witness"]),
                prior_leaf_pairs=sum(row["solved"] for row in prior), prior_total_pairs=360)


def verify(path, prior_archive):
    with ZipFile(path) as archive:
        names = archive.namelist()
        assert archive.testzip() is None and len(names) == len(set(names))
        decision = replay(archive.read, names, prior_archive)
        assert decision == json.loads(archive.read("decision.json"))
    print(json.dumps(decision))


def build(root, bundle, prior_archive):
    files = {name: root / name for name in FILES}
    receipt, = (root / "receipts").glob("*/*/receipt.json")
    for name in ("receipt.json", "check-1.log", "checks-config.yaml"):
        path = receipt.with_name(name)
        files[path.relative_to(root).as_posix()] = path
    decision = replay(lambda name: files[name].read_bytes(), files.keys(), prior_archive)
    with ZipFile(bundle, "x", compression=ZIP_DEFLATED) as archive:
        for name, path in files.items():
            archive.write(path, name)
        archive.writestr("decision.json", json.dumps(decision, indent=2) + "\n")
    print(json.dumps(decision))


if __name__ == "__main__":
    action, *paths = sys.argv[1:]
    {"build": build, "verify": verify}[action](*map(Path, paths))
