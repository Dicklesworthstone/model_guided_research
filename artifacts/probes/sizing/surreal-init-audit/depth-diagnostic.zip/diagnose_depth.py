"""Reproduce the placebo sizing trajectories and split held-out loss by support."""

import argparse
import json
from pathlib import Path

import torch
import torch.nn.functional as F
from audit_surreal import (
    BATCH,
    LENGTH,
    PROBE_CORPUS,
    PROBE_SEEDS,
    RUNGS,
    VOCAB,
    build,
    dataset,
    digest,
    evaluate,
)


@torch.inference_mode()
def held_out_groups(model, rows, seen):
    model.eval()
    total = torch.zeros(2, dtype=torch.float64)
    count = torch.zeros(2, dtype=torch.int64)
    for batch in rows.split(16):
        targets = batch[:, 1:].reshape(-1)
        logits = model(batch[:, :-1]).reshape(-1, len(VOCAB))
        loss = F.cross_entropy(logits, targets, reduction="none").double()
        trained = seen[targets]
        for idx, mask in enumerate((trained, ~trained)):
            total[idx] += loss[mask].sum()
            count[idx] += mask.sum()
    model.train()
    return {
        name: {"tokens": int(number), "nll": float(loss / number)}
        for name, loss, number in zip(("seen", "absent"), total, count, strict=True)
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("sizing", type=Path)
    args = parser.parse_args()
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    original = json.loads(args.sizing.read_text())
    packed, card = dataset(PROBE_CORPUS)
    if card["hash"] != original["corpus"]["hash"]:
        raise ValueError("Changed placebo corpus")
    seen = torch.bincount(packed["train"][:, 1:].reshape(-1), minlength=len(VOCAB)) > 0
    output = {"absent_token_types": [VOCAB[i] for i in (~seen).nonzero().flatten().tolist()], "runs": {}}
    for seed in PROBE_SEEDS:
        reference = original["runs"][str(seed)]
        model = build(seed)[0]
        optimizer = torch.optim.AdamW(model.parameters(), lr=0.004, betas=(0.8, 0.95), weight_decay=0.0)
        generator = torch.Generator().manual_seed(seed + 40_000)
        take = torch.randint(len(packed["train"]), (RUNGS[-1], BATCH), generator=generator)
        if digest(take.tolist()) != reference["batch_hash"]:
            raise ValueError("Changed training trajectory input")
        scores = {}
        for step, indices in enumerate(take, 1):
            batch = packed["train"][indices]
            loss = model(batch[:, :-1], batch[:, 1:].contiguous())
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            optimizer.step()
            if step in RUNGS:
                expected = reference["rungs"][str(step)]
                if abs(evaluate(model, packed["val"]) - expected["val"]) > 1e-6:
                    raise ValueError("Validation trajectory differs from the sizing run")
                groups = held_out_groups(model, packed["test"], seen)
                total = sum(row["tokens"] * row["nll"] for row in groups.values())
                count = sum(row["tokens"] for row in groups.values())
                if count != len(packed["test"]) * LENGTH or abs(total / count - expected["test"]) > 1e-6:
                    raise ValueError("Held-out numerator or denominator changed")
                scores[str(step)] = groups
        output["runs"][str(seed)] = scores
    print(json.dumps(output, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
