"""Verify the automorphisms and the exact partition of viable pairs."""

import argparse
import copy
import json
from itertools import product
from pathlib import Path

from check_study import rooted

ORDERS = (32, 64, 128)


def read_json(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        raise ValueError(f"Invalid JSON file {path}") from error


def verify_group(table, record):
    _, aut_order, automorphisms, cosets, representatives = record
    n = len(table)
    domain = list(range(n))
    if (len(cosets) != n or cosets[0] != 0 or set(cosets) != set(range(4))
            or any(cosets[table[a][b]] != (cosets[a] ^ cosets[b]) for a, b in product(domain, repeat=2))):
        raise ValueError("The claimed Frattini map is not a quotient onto the Klein group")
    for perm in automorphisms:
        if (sorted(perm) != domain or perm[0] != 0
                or any(perm[table[a][b]] != table[perm[a]][perm[b]] for a, b in product(domain, repeat=2))):
            raise ValueError("A supplied permutation is not an automorphism")

    viable = {
        (a, b) for a, b in product(domain, repeat=2)
        if cosets[a] and cosets[b] and cosets[a] != cosets[b]
        and len({table[a][a], table[a][b], table[b][a], table[b][b]}) == 4
    }
    count = len(viable)
    shapes = []
    for a, b, size in representatives:
        if (a, b) not in viable:
            raise ValueError("Representative is ineligible or repeats an orbit")
        orbit = {(a, b)}
        frontier = {(a, b)}
        while frontier:
            frontier = {(perm[x], perm[y]) for x, y in frontier for perm in automorphisms} - orbit
            orbit.update(frontier)
        if len(orbit) != size or size != aut_order or not orbit <= viable:
            raise ValueError("Incorrect orbit size or overlap")
        viable.difference_update(orbit)
        graph = rooted({mark: {x: table[x][pair] for x in domain} for mark, pair in zip("01", (a, b), strict=True)}, 0)
        if len(graph) != n:
            raise ValueError("Orbit representative failed transitivity")
        shapes.append(bytes(dest for step in graph for dest in step).hex())
    if viable:
        raise ValueError("Orbit representatives omitted eligible generating pairs")
    return shapes, count


def verify_order(row, groups, historical):
    n, arms = row["order"], row["arms"]
    orbit = arms["orbit"]
    provider = orbit["provider"]
    if (set(arms) != {"early", "frattini", "orbit"} or row["groups"] != len(groups)
            or provider[:4] != ["4.16.1", "1.7.0", "1.13.0", n]
            or [record[0] for record in provider[4]] != list(groups)):
        raise ValueError("Wrong live arm, provider version, or inventory")
    reconstructed, pair_count, aut_count = [], 0, 0
    for record in provider[4]:
        shapes, pairs = verify_group(groups[record[0]], record)
        reconstructed.extend(shapes)
        pair_count += pairs
        aut_count += len(record[2])
    if (sorted(reconstructed) != historical["full"] or sorted(set(reconstructed)) != sorted(reconstructed)
            or any(arm["shapes"] != historical["full"] for arm in arms.values())):
        raise ValueError("Canonical output disagrees with the frozen or live baseline")
    if (arms["early"]["calls"] != historical["filter_work"]["calls"]
            or arms["frattini"]["calls"] != pair_count or orbit["calls"] != len(reconstructed)):
        raise ValueError("Traversal accounting disagrees with verified eligible pairs")
    for arm in arms.values():
        if arm["cpu_ns"] <= 0 or arm["wall_ns"] <= 0:
            raise ValueError("Malformed timings")
    if not (0 < orbit["gap_cpu_ns"] <= orbit["cpu_ns"] and 0 < orbit["gap_wall_ns"] <= orbit["wall_ns"]):
        raise ValueError("Orbit timing omitted the GAP provider")
    return {
        "order": n, "groups": len(groups), "shapes": len(reconstructed), "verified_automorphism_generators": aut_count,
        "covered_generating_pairs": pair_count, "arms": {
            key: {field: value for field, value in arm.items() if field not in {"shapes", "provider"}}
            for key, arm in arms.items()
        },
    }


def reject_forgery(row, groups, historical, *, mutate_permutation):
    forged = copy.deepcopy(row)
    records = forged["arms"]["orbit"]["provider"][4]
    if mutate_permutation:
        perm = records[0][2][0]
        perm[1], perm[2] = perm[2], perm[1]
    else:
        next(record[4] for record in records if record[4]).pop()
    try:
        verify_order(forged, groups, historical)
    except ValueError:
        return True
    raise ValueError("The verifier accepted corrupt automorphism or orbit evidence")


def without_timing(record):
    compact = copy.deepcopy(record)
    for row in compact["orders"]:
        for arm in row["arms"].values():
            for key in ("cpu_ns", "wall_ns", "gap_cpu_ns", "gap_wall_ns"):
                arm.pop(key, None)
    return compact


def decision(record):
    row = record["orders"][-1]["arms"]
    early, frattini, orbit = (row[arm]["cpu_ns"] for arm in ("early", "frattini", "orbit"))
    return {
        "lower_cpu_than_early_by_at_least_twofold": 2 * orbit <= early,
        "lower_cpu_than_frattini_by_at_least_twenty_percent": 5 * orbit <= 4 * frattini,
    }


def main():
    parser = argparse.ArgumentParser()
    for kind in ("tables", "historical", "scored", "replay"):
        parser.add_argument(kind, type=Path)
    args = parser.parse_args()
    raw, previous, scored, replay = (read_json(p) for p in (args.tables, args.historical, args.scored, args.replay))
    if (raw[:2] != ["4.16.1", "1.7.0"] or [row["order"] for row in scored["orders"]] != list(ORDERS)
            or without_timing(scored) != without_timing(replay)):
        raise ValueError("Wrong order ladder, source library or nontiming replay")
    inventory = {
        n: {i: table for size, i, rank, abelian, table in raw[3] if size == n and rank == 2 and not abelian}
        for n in ORDERS
    }
    history = {row["order"]: row["profiles"]["0123"] for row in previous["orders"]}
    checks = [verify_order(row, inventory[row["order"]], history[row["order"]]) for row in scored["orders"]]
    first = scored["orders"][0]
    print(json.dumps({
        "exact_replay": True,
        "forgeries_rejected": {
            "invalid_automorphism": reject_forgery(first, inventory[32], history[32], mutate_permutation=True),
            "missing_orbit": reject_forgery(first, inventory[32], history[32], mutate_permutation=False),
        },
        "scored_gate": decision(scored),
        "replay_gate": decision(replay),
        "scored": checks,
        "replay": [
            {"order": row["order"], "arms": {
                kind: {item: value for item, value in arm.items() if item not in {"provider", "shapes"}}
                for kind, arm in row["arms"].items()
            }}
            for row in replay["orders"]
        ],
    }, indent=2))


if __name__ == "__main__":
    main()
