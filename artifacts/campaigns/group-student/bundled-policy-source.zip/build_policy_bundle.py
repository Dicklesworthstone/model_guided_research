"""Build immutable policy data from the independently audited shape archive."""

import json
import sys
from pathlib import Path
from zipfile import ZIP_STORED, ZipFile, ZipInfo

from nanochat import group_acquisition as solver


def encode(node):
    if node is None:
        return None
    if isinstance(node, solver._Probe):
        return [node.word, [[rank, encode(child)] for rank, child in sorted(node.branches.items())]]
    if isinstance(node, solver._Determined):
        return [node.row, node.observed_states]
    raise TypeError(type(node))


def build(catalogue_path, output):
    with output.open("xb") as destination, ZipFile(destination, "w", compression=ZIP_STORED) as archive:
        for order in solver.CATALOGUE_ORDERS:
            compiled = solver.compile_policy(solver.load_catalogue(catalogue_path, order))
            payload = {
                "format": "mgr.group-policy.v1",
                "catalogue": solver.CATALOGUE_SHA256,
                "shapes": [bytes(value for edge in shape for value in edge).hex() for shape in compiled.shapes],
                "tree": encode(compiled._root),
            }
            member = ZipInfo(f"{order}.json", (1980, 1, 1, 0, 0, 0))
            member.create_system = 3
            member.external_attr = 0o100644 << 16
            archive.writestr(member, json.dumps(payload, sort_keys=True, separators=(",", ":")) + "\n")
            print(f"Bundled order {order}, {len(compiled.shapes)} marked actions", flush=True)


if __name__ == "__main__":
    build(*map(Path, sys.argv[1:]))
