import json
import math
from pathlib import Path
import sys
from zipfile import ZipFile

root = Path(sys.argv[1])
results = []
with ZipFile(root / "generations.zip") as archive:
    for seed in range(3):
        folder = Path(f"evals/tasks/eval-b0-copyops-standard-s{seed}")
        scores = json.loads((root / folder / "summary.json").read_bytes())["tasks"]["copyops"]
        outcomes = [json.loads(line) for line in archive.read(str(folder / "generations.jsonl")).splitlines()]
        held = [r for r in outcomes if r["region"] == "held_out" and r["mode"] == "greedy"]
        assert len(held) == 144 and scores["skipped_too_long"] == 0
        correct = short = rescuable = 0
        for r in held:
            expected = r["expected"].split()
            got = r["got"].split()
            exact = got[:len(expected)] == expected
            assert r["correct"] == exact
            correct += exact
            short += len(got) < len(expected)
            rescuable += len(got) < len(expected) and got == expected[:len(got)]
        floor = scores["answer_prior"]["held_out"]["mean"]
        needed = math.ceil((floor + 0.10) * len(held))
        results.append(dict(training_seed=seed, cases=len(held), correct=correct, short=short,
                            strict_prefix_of_answer=rescuable, upper_bound_correct=correct+rescuable,
                            needed_to_clear=needed, can_clear_by_appending=correct+rescuable>=needed))
print(json.dumps(dict(scorecard=root.name, scope="Only appending words after the observed output is allowed.", rows=results), indent=2))
