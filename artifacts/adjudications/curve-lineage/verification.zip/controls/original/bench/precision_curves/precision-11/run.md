# precision-curve — precision-11

- task arith · seed pairing 11
- AUC digit 1.0000 vs float 1.0000 -> ratio 1.000

| arm | fraction | quality |
|---|---|---|
| digit | 0.250 | 1.0000 |
| digit | 1.000 | 1.0000 |
| float | 0.125 | 0.9999 |
| float | 1.000 | 1.0000 |
