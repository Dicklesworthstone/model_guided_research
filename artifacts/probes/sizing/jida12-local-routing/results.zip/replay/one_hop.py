import itertools
import math
import random
import re
import sys
from pathlib import Path

from depth_cross import topology
from sibling_order import (
    F, LocationHead, SPEC, HuggingFaceTokenizer, _load_eval_checkpoint, corpus, digest, leaf_entries,
    read, serialize, shuffle_tree, states, tokenizer_path, torch, tree_from_text, tree_of, write,
)


HEAD_SEEDS = (101, 102, 103)
FIT_ROWS = 1536
BATCH = 8


def pack(text, routes, tokenizer):
    bos = tokenizer.get_bos_token_id()
    leaves = leaf_entries(text)
    mapping = {route: (i, value) for i, (route, value, _) in enumerate(leaves)}
    by_route = {}
    parents = {}
    scope = []
    words = iter(re.finditer(r"\S+", text[len("TASK hier TREE "):]))
    for word in words:
        if word.group() == "(":
            key = next(words)
            scope.append(key.group())
            route = tuple(scope)
            parent = route[:-1]
            assert route not in by_route
            parents.setdefault(parent, []).append(len(by_route))
            prefix = text[:len("TASK hier TREE ") + key.end()]
            by_route[route] = tokenizer.encode(prefix, prepend=bos)
        elif word.group() == ")":
            scope.pop()
    assert not scope and 1 <= len(leaves) <= 9
    leaf_prefixes = [tokenizer.encode(text[:end], prepend=bos) for _, _, end in leaves]
    edges = list(by_route)
    rows = []
    for route in routes:
        expected, value = mapping[route]
        doc = f"{text} PATH {' '.join(route)} OUT {value}"
        assert SPEC.checker(doc) is True
        prompt, target = SPEC.split_prompt(doc)
        ids = tokenizer.encode(prompt, prepend=bos)
        full = tokenizer.encode(doc, prepend=bos)
        assert target == value and full[:len(ids)] == ids and len(ids) < len(full) <= 128
        assert all(ids[:len(prefix)] == prefix for prefix in itertools.chain(by_route.values(), leaf_prefixes))
        query_prefixes = [tokenizer.encode(f"{text} PATH {' '.join(route[:i + 1])}", prepend=bos)
                          for i in range(len(route))]
        assert all(ids[:len(prefix)] == prefix for prefix in query_prefixes)
        qp = [len(prefix) - 1 for prefix in query_prefixes]
        ep = [len(prefix) - 1 for prefix in by_route.values()]
        for i, index in enumerate(qp):
            siblings = parents[route[:i]]
            hits = [edge for edge in siblings if ids[ep[edge]] == ids[index]]
            assert hits == [edges.index(route[:i + 1])]
        rows.append(dict(ids=ids, route=route, expected=expected, query_keys=qp, document=doc))
    return dict(text=text, leaves=[route for route, _, _ in leaves], leaf_positions=[len(p)-1 for p in leaf_prefixes],
                edge_paths=edges, edge_positions=[len(p)-1 for p in by_route.values()], rows=rows)


def panel(output, reference, old_case_files):
    known, _ = corpus(reference)
    for path in old_case_files[:4]:
        data = read(path)
        known.update(tree_of(row["documents"][0]) for rows in data.get("evaluation", data).values() for row in rows)
    for path, cells in zip(old_case_files[4:],
                           (("a", "b"), ("normal", "length_only", "nested"), ("normal", "permuted", "expanded", "nested")),
                           strict=True):
        known.update(block[cell]["tree"] for block in read(path)["blocks"] for cell in cells)
    assert len(known) == 32648
    orbit = read(Path("/data/ssd/tmp/mgr-sibling-orbit.PlnAYAg1/panel.json"))
    orbit_tree = tree_from_text(orbit["canonical_text"])
    for entry in orbit["permutations"]:
        roots, *children = entry["order"]
        keys = sorted(orbit_tree)
        tree = {}
        for j in roots:
            root = keys[j]
            branch = orbit_tree[root]
            names = sorted(branch)
            tree[root] = {names[k]: branch[names[k]] for k in children[j]}
        assert serialize(tree) not in known
        known.add(serialize(tree))
    assert len(known) == 33944
    tok = HuggingFaceTokenizer.from_directory(str(tokenizer_path(reference)))
    rng = random.Random(91047)
    blocks = []
    for seed in (91, 92, 93):
        selected = 0
        for document in SPEC.generate(4800, seed, SPEC.resolve_dials(None))["train"][::2]:
            text = tree_of(document)
            leaves = leaf_entries(text)
            if len(leaves) != 9 or len({value for _, value, _ in leaves}) != 9:
                continue
            layout = (selected % 3, (selected // 3 + seed) % 3, (selected // 3 + seed + selected) % 3)
            native = tree_from_text(text)
            mixed = topology([f"v{i}" for i in rng.sample(range(100), 9)], *layout)
            omitted = f"k0x{layout[0]}"
            suffix = f"k1x{layout[1]}"
            native_routes = [path for path, _, _ in leaves if path[0] != omitted and path[1] != suffix]
            mixed_routes = [path for path, _, _ in leaf_entries(serialize(mixed)) if len(path) == 3]
            mixed_shallow = [path for path, _, _ in leaf_entries(serialize(mixed)) if len(path) == 2]
            assert len(native_routes) == len(mixed_routes) == len(mixed_shallow) == 4
            ordered_mixed = serialize(mixed)
            reorder = serialize(shuffle_tree(native, rng))
            reorder_mixed = serialize(shuffle_tree(mixed, rng))
            contexts = {text, reorder, ordered_mixed, reorder_mixed}
            if len(contexts) != 4 or known.intersection(contexts):
                continue
            n = pack(text, native_routes, tok)
            p = pack(reorder, native_routes, tok)
            d = pack(ordered_mixed, mixed_routes, tok)
            r = pack(reorder_mixed, mixed_routes, tok)
            m = pack(ordered_mixed, mixed_shallow, tok)
            assert len({len(q["ids"]) for case in (n, p) for q in case["rows"]}) == 1
            assert len({len(q["ids"]) for case in (d, r) for q in case["rows"]}) == 1
            if not all(any(a["expected"] != b["expected"] for a, b in zip(left["rows"], right["rows"], strict=True))
                       for left, right in ((n, p), (d, r))):
                continue
            blocks.append(dict(seed=seed, index=selected, native=n, reordered=p, mixed2=m, depth3=d, reordered3=r))
            known.update(contexts)
            selected += 1
            if selected == 12:
                break
        assert selected == 12
    assert len(blocks) == 36 and len(known) == 34088
    write(output, dict(blocks=blocks, tokenizer_sha256=digest(tokenizer_path(reference) / "tokenizer.json")))
    print({cell: sorted({len(block[cell]["rows"][0]["ids"]) for block in blocks})
           for cell in ("native", "reordered", "mixed2", "depth3", "reordered3")}, flush=True)


def tree_index(case):
    routes = list(map(tuple, case["edge_paths"]))
    siblings = {}
    for key, route in enumerate(routes):
        siblings.setdefault(route[:-1], []).append(key)
    return routes, siblings


def load_base(prior, expected_tokenizer):
    run = prior / "seed-32" / "runs" / "augmented"
    checkpoint = run / "checkpoints"
    summary = read(run / "summary.json")
    model, meta, step = _load_eval_checkpoint(checkpoint, None, torch.device("cpu"), fingerprint_weights=True)
    assert step == 2047 and not summary["provenance"]["tainted"]
    assert summary["provenance"]["git_sha"] == "594fd4358a6820998ab16156d165041715b652ca"
    assert summary["weights_sha256"] == meta["weights_sha256"]
    assert digest(checkpoint / "location_head.pt") == summary["location_head_sha256"]
    tok_dir = checkpoint / "tokenizer"
    assert digest(tok_dir / "tokenizer.json") == expected_tokenizer
    model.requires_grad_(False)
    head = LocationHead().eval()
    head.load_state_dict(torch.load(checkpoint / "location_head.pt", weights_only=True))
    return model, head, HuggingFaceTokenizer.from_directory(str(tok_dir)), summary


def pair_scores(head, query, keys):
    return (head.query(query).unsqueeze(-2) * head.key(keys)).sum(-1) / math.sqrt(32)


@torch.no_grad()
def features(model, prior, tok):
    base = prior / "seed-32"
    schedule_file = base / "permuted.pt"
    assert digest(schedule_file) == read(base / "preflight.json")["permuted_sha256"]
    schedule = torch.load(schedule_file, weights_only=True)
    rows = []
    for offset in range(0, FIT_ROWS, BATCH):
        items = []
        for row in range(offset, offset + BATCH):
            stop = int(schedule["queries"][row])
            expected = schedule["targets"][row, stop:]
            complete = schedule["inputs"][row, :stop+1].tolist() + expected[expected != -1].tolist()
            document = tok.decode(complete[1:])
            path = tuple(document.split(" PATH ", 1)[1].split(" OUT ", 1)[0].split())
            case = pack(tree_of(document), [path], tok)
            packed, = case["rows"]
            assert len(path) == 2 and packed["ids"] == complete[:stop+1]
            assert packed["expected"] == int(schedule["labels"][row])
            items.append(case)
        padded = torch.full((BATCH, 128), tok.get_bos_token_id(), dtype=torch.long)
        for i, case in enumerate(items):
            ids = case["rows"][0]["ids"]
            padded[i, :len(ids)] = torch.tensor(ids)
        _, hidden = states(model, padded)
        for i, case in enumerate(items):
            row, = case["rows"]
            path = row["route"]
            edges, siblings = tree_index(case)
            edge_keys = torch.zeros((2, 3, 128))
            edge_mask = torch.zeros((2, 3), dtype=torch.bool)
            edge_labels = []
            for level in range(2):
                group = siblings[path[:level]]
                positions = [case["edge_positions"][j] for j in group]
                edge_keys[level, :len(group)] = hidden[i, positions]
                edge_mask[level, :len(group)] = True
                edge_labels.append(group.index(edges.index(path[:level+1])))
            leaf_keys = torch.zeros((9, 128))
            leaves = case["leaf_positions"]
            leaf_keys[:len(leaves)] = hidden[i, leaves]
            rows.append((hidden[i, row["query_keys"]], edge_keys, edge_mask, torch.tensor(edge_labels),
                         hidden[i, len(row["ids"])-1], leaf_keys, torch.arange(9) < len(leaves), torch.tensor(row["expected"])))
    return tuple(torch.stack(column) for column in zip(*rows, strict=True))


def fit(cached, seed):
    arms = []
    for start in (0, 4):
        torch.manual_seed(seed)
        head = LocationHead()
        opt = torch.optim.AdamW(head.parameters(), lr=.003)
        for offset in range(0, FIT_ROWS, BATCH):
            q, k, mask, label = [field[offset:offset+BATCH] for field in cached[start:start+4]]
            scores = pair_scores(head, q, k).masked_fill(~mask, -torch.inf)
            loss = F.cross_entropy(scores.flatten(0, -2), label.flatten())
            assert math.isfinite(float(loss.detach()))
            opt.zero_grad(set_to_none=True)
            loss.backward()
            opt.step()
        arms.append(head.eval())
    return tuple(arms)


@torch.inference_mode()
def measure(model, incumbent, heads, data):
    outcomes = []
    for i, block in enumerate(data):
        results = {}
        for cell in ("native", "reordered", "mixed2", "depth3", "reordered3"):
            case = block[cell]
            rows = case["rows"]
            inputs = torch.tensor([row["ids"] for row in rows])
            _, hidden = states(model, inputs)
            edge = hidden[:, case["edge_positions"]]
            leaves = hidden[:, case["leaf_positions"]]
            qk = hidden[torch.arange(4)[:, None], torch.tensor([row["query_keys"] for row in rows])]
            row_results = {}
            for seed, (hop, flat) in heads.items():
                scores = pair_scores(hop, qk, edge[:, None]).tolist()
                row_results[str(seed)] = dict(edge_scores=scores,
                                             flat_scores=pair_scores(flat, hidden[:, -1], leaves).tolist())
            row_results["incumbent"] = pair_scores(incumbent, hidden[:, -1], leaves).tolist()
            results[cell] = row_results
        outcomes.append(results)
        if (i + 1) % 12 == 0:
            print(f"Evaluated {i+1}/{len(data)} blocks", flush=True)
    return outcomes


def experiment(panel_path, prior, destination):
    data = read(panel_path)
    model, incumbent, tok, lineage = load_base(prior, data["tokenizer_sha256"])
    cached = features(model, prior, tok)
    heads = {seed: fit(cached, seed) for seed in HEAD_SEEDS}
    results = measure(model, incumbent, heads, data["blocks"])
    write(destination, dict(panel_sha256=digest(panel_path), trunk_weights_sha256=lineage["weights_sha256"],
                            incumbent_head_sha256=lineage["location_head_sha256"], fit_rows=FIT_ROWS,
                            head_seeds=HEAD_SEEDS, logits=results))


if __name__ == "__main__":
    command, *args = sys.argv[1:]
    paths = list(map(Path, args))
    if command == "prepare":
        panel(paths[0], paths[1], paths[2:])
    elif command == "experiment":
        experiment(*paths)
    else:
        raise ValueError(command)
