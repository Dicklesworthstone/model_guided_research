"""Build the same exact catalogue with fewer canonical traversals."""

import json
import sys
from itertools import product
from pathlib import Path
from time import monotonic_ns, process_time_ns

import numpy as np
from catalogue_replay import read
from catalogue_study import ANCHORS, canonical
from four_anchor import INVENTORY, case_inputs, digest, measure, prepare, shape_inventory

from scripts.group_student_probe import _lattice_action

ARMS = ("exhaustive", "conjugacy", "combined")


def orbit_representatives(table):
    """Take first-mark conjugacy minima and second-mark stabilizer minima."""
    states = np.arange(len(table))
    inverses = np.argmax(table == 0, axis=1)
    conjugates = table[table, inverses[:, None]]
    first = np.flatnonzero(conjugates.min(axis=0) == states)
    for a in first:
        fixed = conjugates[conjugates[:, a] == a]
        second = np.flatnonzero((fixed.min(axis=0) == states) & (table[a, :] != table[:, a]))
        for b in second:
            yield int(a), int(b)


def reduced_shapes(raw, *, lattices, inventory=INVENTORY):
    gap, smallgrp, tables = raw
    expected = [(n, i) for n, count in inventory.items() for i in range(1, count + 1)]
    if (gap, smallgrp) != ("4.16.1", "1.7.0") or [tuple(row[:2]) for row in tables] != expected:
        raise ValueError("Wrong catalogue versions or incomplete finite inventory")
    shapes = {n: set() for n in inventory}
    stats = []
    for n, index, table in tables:
        matrix = np.asarray(table, dtype=np.intp)
        abelian = np.array_equal(matrix, matrix.T)
        if abelian and lattices:
            stats.append(dict(order=n, index=index, abelian=True, traversals=0, representatives=None, generating=None))
            continue
        reps = None if abelian else list(orbit_representatives(matrix))
        choices = product(range(n), repeat=2) if reps is None else reps
        traversals = generating = 0
        for a, b in choices:
            graph = canonical(table, a, b)
            traversals += 1
            if len(graph) == n:
                shapes[n].add(graph)
                generating += 1
        stats.append(dict(order=n, index=index, abelian=abelian, traversals=traversals,
                          representatives=reps, generating=generating))
    coordinates = {}
    if lattices:
        for n in inventory:
            coords = [(w, s, n // w) for w in range(1, n + 1) if n % w == 0 for s in range(w)]
            shapes[n].update(_lattice_action(*triple) for triple in coords)
            coordinates[n] = coords
    return {n: sorted(graphs) for n, graphs in shapes.items()}, stats, coordinates


def replay(shapes, cases):
    started_cpu, started_wall = process_time_ns(), monotonic_ns()
    indices = {n: prepare(graphs) for n, graphs in shapes.items()}
    prepared = dict(cpu_ns=process_time_ns() - started_cpu, wall_ns=monotonic_ns() - started_wall)
    rows = []
    for n, evaluate, i, control in cases:
        anchor_cpu, anchor_wall = process_time_ns(), monotonic_ns()
        anchors = {word: evaluate(word) for word in ANCHORS}
        anchors_timing = dict(cpu_ns=process_time_ns() - anchor_cpu, wall_ns=monotonic_ns() - anchor_wall)
        result = measure(n, evaluate, indices[n], anchors, distances=None)
        rows.append(dict(index=i, order=n, control=control, anchors=anchors, anchor_timing=anchors_timing, result=result))
    return dict(prepared=prepared, indexed_words={n: len(index.columns) for n, index in indices.items()}, rows=rows)


def run(cohort, library, prior, output, reverse):
    parse_cpu, parse_wall = process_time_ns(), monotonic_ns()
    raw = read(library)
    parsed = dict(cpu_ns=process_time_ns() - parse_cpu, wall_ns=monotonic_ns() - parse_wall)
    order = tuple(reversed(ARMS)) if reverse else ARMS
    arms = {}
    reference = None
    compiled = {}
    for arm in order:
        start_cpu, start_wall = process_time_ns(), monotonic_ns()
        if arm == "exhaustive":
            shapes = shape_inventory(raw)
            stats = None
            coords = {}
            traversals = sum(n * n for n, _, _ in raw[2])
        else:
            shapes, stats, coords = reduced_shapes(raw, lattices=arm == "combined")
            traversals = sum(item["traversals"] for item in stats)
        arms[arm] = dict(cpu_ns=process_time_ns() - start_cpu, wall_ns=monotonic_ns() - start_wall,
                         traversals=traversals, lattice_constructions=sum(map(len, coords.values())),
                         stats=stats, coordinates=coords)
        if reference is None:
            reference = shapes
        elif shapes != reference:
            raise ValueError("The cold builder changed the exact rooted inventory")
        if arm != "conjugacy":
            compiled[arm] = shapes
    cases = list(case_inputs(raw[2], cohort, read(prior)))
    online = {arm: replay(compiled[arm], cases) for arm in order if arm in compiled}
    with output.open("x", encoding="utf-8") as file:
        json.dump(dict(
            parsed=parsed, arms=arms, shape_digest=digest(compiled["combined"]),
            shape_counts={n: len(s) for n, s in compiled["combined"].items()}, online=online,
        ), file, sort_keys=True)
        file.write("\n")


if __name__ == "__main__":
    run(*map(Path, sys.argv[1:5]), reverse=sys.argv[5] == "reverse")
