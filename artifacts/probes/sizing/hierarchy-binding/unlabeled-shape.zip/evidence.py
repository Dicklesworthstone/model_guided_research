import json
import math
import random
import statistics
import sys
from functools import cache
from pathlib import Path

import posterior as post
from address_fixtures import DIM, POOLS, encode, sha_json

SEEDS = (19011, 19012, 19013)
TRUTHS = (("catalan", 0), ("half", 0.5), ("yule", 1))
PHASES = (("train", 12), ("test", 16))
ARMS = ("uniform", "terminal", "unlabeled", "oracle")


def logsumexp(values):
    values = tuple(values)
    peak = max(values)
    return peak + math.log(math.fsum(math.exp(x - peak) for x in values))


@cache
def log_partition(beta):
    log_z = [0.0]
    for size in range(1, post.INTERNAL + 1):
        total = logsumexp(log_z[left] + log_z[size - left - 1] for left in range(size))
        log_z.append(total - beta * math.log(size))
    return tuple(log_z)


def half_leaves(rng):
    log_z = log_partition(.5)

    def descend(size, prefix):
        if size == 0:
            yield prefix
            return
        odds = [log_z[left] + log_z[size - left - 1] for left in range(size)]
        peak = max(odds)
        weights = [math.exp(logit - peak) for logit in odds]
        left = size - 1
        draw = rng.random() * math.fsum(weights)
        for i, weight in enumerate(weights[:-1]):
            draw -= weight
            if draw < 0:
                left = i
                break
        yield from descend(left, prefix + (0,))
        yield from descend(size - 1 - left, prefix + (1,))

    return set(descend(post.INTERNAL, ()))


def fresh():
    for seed in SEEDS:
        for family_id, (family, _beta) in enumerate(TRUTHS):
            for phase_id, (phase, size) in enumerate(PHASES):
                rng = random.Random(seed + 73304 + 1938 * family_id + 6532 * phase_id)
                for index in range(size):
                    leaves = half_leaves(rng) if family == "half" else post.generate_leaves(rng, family)
                    nodes = sorted({leaf[:i] for leaf in leaves for i in range(len(leaf) + 1)})
                    assert len(leaves) == 64 and len(nodes) == 127
                    namespace = tuple(rng.sample(range(DIM), DIM)), rng.randrange(1 << DIM)
                    keys = dict(zip(nodes, rng.sample(POOLS[1], len(nodes)), strict=True))
                    pointers = {path: encode(key, *namespace) for path, key in keys.items()}
                    rows = {keys[path]: () if path in leaves else (pointers[path + (0,)], pointers[path + (1,)])
                            for path in rng.sample(nodes, len(nodes))}
                    query = rng.choice(sorted(leaves))
                    yield seed, family, phase, index, rows, pointers[()], query, keys[query], namespace


def relative_log_likelihood(versions, beta):
    return (logsumexp(math.log(count) - beta * math.log(hooks) for _key, hooks, count in versions)
            - log_partition(beta)[post.INTERNAL])


def estimate_evidence(catalogs):
    # Deliberately receives no terminal training labels or family identity.
    scores = [statistics.mean(relative_log_likelihood(versions, beta) for versions in catalogs)
              for beta in post.GRID]
    chosen = max(range(len(scores)), key=lambda i: (scores[i], -post.GRID[i]))
    return post.GRID[chosen], scores


def compare(train, test, beta):
    from_answers, train_nll = post.fit(train)
    catalogs = [row["versions"] for row in train]
    from_evidence, train_evidence = estimate_evidence(catalogs)
    evaluated = {arm: post.evaluate(test, exponent) for arm, exponent in
                 zip(ARMS, (0, from_answers, from_evidence, beta), strict=True)}
    return dict(terminal_beta=from_answers, unlabeled_beta=from_evidence, relative_evidence=train_evidence,
                terminal_grid_nll=train_nll, metrics=evaluated)


def run(path):
    raw = []
    for seed, family, phase, index, records, root, query, target, _namespace in fresh():
        census = post.catalog(records, root, query)
        assert target in {key for key, _, _ in census["versions"]}
        raw.append(dict(seed=seed, family=family, phase=phase, index=index, target=target,
                        fixture=sha_json([records, root, query]), **census))
        if phase == "test" and index == 15:
            print(seed, family, "completed 12 fit and 16 test cases", flush=True)
    assert len(raw) == 252
    fits = {}
    for seed in SEEDS:
        fits[seed] = {}
        for family, oracle in TRUTHS:
            cohort = [row for row in raw if (row["seed"], row["family"]) == (seed, family)]
            train = [row for row in cohort if row["phase"] == "train"]
            test = [row for row in cohort if row["phase"] == "test"]
            fits[seed][family] = compare(train, test, oracle)
    with path.open("x", encoding="utf-8") as file:
        json.dump(dict(rows=raw, fits=fits), file, allow_nan=False, separators=(",", ":"))


if __name__ == "__main__":
    run(Path(sys.argv[1]))
