import json
import math
import random
import statistics
import sys
from collections import Counter, defaultdict
from fractions import Fraction
from functools import cache
from pathlib import Path

from address_fixtures import DIM, POOLS, encode, sha_json
from topology import isometries

SEEDS = (17011, 17012, 17013)
FAMILIES = ("yule", "catalan")
PHASES = ("train", "test")
CASES = 16
INTERNAL = 63
GRID = tuple(i / 4 for i in range(9))


@cache
def catalan(size):
    return math.comb(2 * size, size) // (size + 1)


def generate_leaves(rng, family):
    if family == "yule":
        leaves = {()}
        for _ in range(INTERNAL):
            split = rng.choice(sorted(leaves))
            leaves.remove(split)
            leaves.update((split + (0,), split + (1,)))
        return leaves

    def sample(size, prefix):
        if size == 0:
            yield prefix
            return
        target = rng.randrange(catalan(size))
        for left in range(size):
            right = size - 1 - left
            target -= catalan(left) * catalan(right)
            if target < 0:
                yield from sample(left, prefix + (0,))
                yield from sample(right, prefix + (1,))
                return
        raise AssertionError("Catalan split allocation")

    assert family == "catalan"
    return set(sample(INTERNAL, ()))


def fresh():
    for seed in SEEDS:
        for i, family in enumerate(FAMILIES):
            for j, phase in enumerate(PHASES):
                rng = random.Random(seed + 51051 + 1301 * i + 2707 * j)
                for index in range(CASES):
                    leaves = generate_leaves(rng, family)
                    nodes = sorted({leaf[:i] for leaf in leaves for i in range(len(leaf) + 1)})
                    assert len(leaves) == INTERNAL + 1 and len(nodes) == 2 * INTERNAL + 1
                    namespace = tuple(rng.sample(range(DIM), DIM)), rng.randrange(1 << DIM)
                    keys = dict(zip(nodes, rng.sample(POOLS[1], len(nodes)), strict=True))
                    pointers = {node: encode(key, *namespace) for node, key in keys.items()}
                    records = {keys[node]: () if node in leaves else
                               (pointers[node + (0,)], pointers[node + (1,)]) for node in rng.sample(nodes, len(nodes))}
                    query = rng.choice(sorted(leaves))
                    outcome = keys[query]
                    yield seed, family, phase, index, records, pointers[()], query, outcome, namespace


def catalog(records, root, query):
    keys = set(records)
    slots = [root, *(ptr for row in records.values() for ptr in row)]
    pointers = set(slots)
    assert len(slots) == len(pointers) == len(keys) == 127
    assert sum(len(row) == 2 for row in records.values()) == INTERNAL
    count, rooted = 0, 0
    versions = Counter()
    for table, x0, p0 in isometries(keys, pointers, ()):
        count += 1

        def decode(pointer):
            return table[pointer ^ p0] ^ x0

        start = decode(root)
        seen_order = [start]
        for key in seen_order:
            seen_order.extend(decode(ptr) for ptr in records[key])
        if len(seen_order) != len(keys):
            continue
        rooted += 1
        node = start
        for alias in query:
            links = records[node]
            if not links:
                break
            node = decode(links[alias])
        else:
            if not records[node]:
                subtree = {}
                product = 1
                for key in reversed(seen_order):
                    links = records[key]
                    if not links:
                        subtree[key] = 0
                    else:
                        size = 1 + subtree[decode(links[0])] + subtree[decode(links[1])]
                        product *= size
                        subtree[key] = size
                assert subtree[start] == INTERNAL
                versions[node, product] += 1
    assert count == 40320 and sum(versions.values()) <= rooted
    return dict(bank_maps=count, rooted_maps=rooted,
                versions=[[endpoint, hooks, weight] for (endpoint, hooks), weight in sorted(versions.items())])


def probabilities(versions, beta):
    support = {key for key, _, _ in versions}
    assert support
    if beta in (0, 1):
        ways = defaultdict(int)
        factorial = math.factorial(INTERNAL)
        for key, hook, count in versions:
            assert factorial % hook == 0
            ways[key] += count * (factorial // hook if beta == 1 else 1)
        total = sum(ways.values())
        return {key: float(Fraction(amount, total)) for key, amount in ways.items()}
    lo = min(hooks for _, hooks, _ in versions)
    weights = defaultdict(list)
    for key, hooks, count in versions:
        weights[key].append(count * (lo / hooks) ** beta)
    amounts = {key: math.fsum(parts) for key, parts in weights.items()}
    total = math.fsum(amounts.values())
    return {key: amount / total for key, amount in amounts.items()}


def evaluate(rows, beta):
    nlls, briers, correct = [], [], 0
    for row in rows:
        p = probabilities(row["versions"], beta)
        target = row["target"]
        nlls.append(-math.log(p[target]))
        briers.append(math.fsum((prob - (key == target)) ** 2 for key, prob in p.items()))
        correct += min(p, key=lambda key: (-p[key], key)) == target
    return dict(nll=statistics.mean(nlls), brier=statistics.mean(briers), correct=correct)


def fit(rows):
    values = [evaluate(rows, beta)["nll"] for beta in GRID]
    chosen = min(range(len(GRID)), key=lambda i: (values[i], GRID[i]))
    return GRID[chosen], values


def run(output):
    raw = []
    for seed, family, phase, index, records, root, query, target, _namespace in fresh():
        counted = catalog(records, root, query)
        assert target in {word for word, _, _ in counted["versions"]}
        raw.append(dict(seed=seed, family=family, phase=phase, index=index,
                        fixture=sha_json([records, root, query]), target=target, **counted))
        if index == CASES - 1:
            print(seed, family, phase, f"{CASES} cases", flush=True)
    assert len(raw) == 192
    fitting = {}
    for seed in SEEDS:
        fitting[seed] = {}
        for family in FAMILIES:
            train = [row for row in raw if (row["seed"], row["family"], row["phase"]) == (seed, family, "train")]
            test = [row for row in raw if (row["seed"], row["family"], row["phase"]) == (seed, family, "test")]
            beta, table = fit(train)
            fitting[seed][family] = dict(beta=beta, train_grid_nll=table,
                                         uniform=evaluate(test, 0), yule=evaluate(test, 1),
                                         learned=evaluate(test, beta))
    with output.open("x", encoding="utf-8") as stream:
        json.dump(dict(rows=raw, fitted=fitting), stream, separators=(",", ":"), allow_nan=False)


if __name__ == "__main__":
    run(Path(sys.argv[1]))
