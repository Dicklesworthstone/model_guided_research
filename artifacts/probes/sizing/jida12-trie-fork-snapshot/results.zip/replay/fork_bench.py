import json
import os
import platform
import random
import statistics
import sys
import time
from pathlib import Path

from gqa_trie import (
    GRID, HEADS, LAYERS, PAYLOAD, WIDTH, digest, exact, load_candidate, models, torch,
)
from nanochat.engine import KVCache as IncumbentCache


SAMPLES = 7
METRICS = ("prefill", "fork", "first", "fork_first", "steady")


def cache(cls, heads, batch, capacity):
    return cls(batch_size=batch, num_heads=heads, seq_len=capacity,
               head_dim=WIDTH // HEADS, num_layers=LAYERS)


def layer_states(model, kv):
    if hasattr(kv, "ultrametric_tries"):
        return tuple(kv.ultrametric_tries.values())
    states = []
    for block in model._blocks():
        entries = getattr(block.attn, "_trie_cache", None)
        if entries is not None and kv in entries:
            states.append(entries[kv])
    return tuple(states)


def bytes_for(model, kv):
    dense = kv.kv_cache.untyped_storage().nbytes()
    trie = sum(getattr(head, name).untyped_storage().nbytes() for state in layer_states(model, kv)
               for row in state.tries for head in row for name in PAYLOAD)
    return dict(dense=dense, trie=trie, total=dense + trie)


def independent_prefix(src, dst, batch):
    assert len(src.ultrametric_tries) == len(dst.ultrametric_tries) == LAYERS
    copies = 0
    for owner, original in src.ultrametric_tries.items():
        cloned = dst.ultrametric_tries[owner]
        assert original.seen_Tk == cloned.seen_Tk == src.pos == dst.pos
        assert len(cloned.tries) == batch
        ptrs = set()
        for i, row in enumerate(cloned.tries):
            previous = original.tries[i if len(original.tries) == batch else 0]
            for old, new in zip(previous, row, strict=True):
                assert old is not new and old._cap == new._cap and old._size == new._size
                for attr in PAYLOAD:
                    a, b = getattr(old, attr), getattr(new, attr)
                    assert torch.equal(a, b)
                    assert a.untyped_storage().data_ptr() != b.untyped_storage().data_ptr()
                    assert b.untyped_storage().data_ptr() not in ptrs
                    ptrs.add(b.untyped_storage().data_ptr())
                    copies += 1
    return copies


def cycle(model, cls, heads, prompt, next_tokens, *, validate=False):
    n = prompt.shape[1]
    batch = next_tokens.shape[0]
    src = cache(cls, heads, prompt.shape[0], n)
    start = time.perf_counter_ns()
    outputs = [model(chunk, kv_cache=src) for chunk in prompt.split(64, dim=1)]
    prefill = time.perf_counter_ns() - start
    dst = cache(cls, heads, batch, n + next_tokens.shape[1])
    start = time.perf_counter_ns()
    dst.prefill(src)
    fork = time.perf_counter_ns() - start
    overlap = None
    copies = 0
    if validate:
        overlap = bytes_for(model, src)["total"] + bytes_for(model, dst)["total"]
        if hasattr(dst, "ultrametric_tries"):
            copies = independent_prefix(src, dst, batch)
        else:
            assert not layer_states(model, dst)
        # Keep the destination valid even when the source is reset and reused.
        src.reset()
        model((prompt[:, :1] + 11) % 128, kv_cache=src)
    del src
    start = time.perf_counter_ns()
    outputs.append(model(next_tokens[:, :1], kv_cache=dst))
    first = time.perf_counter_ns() - start
    start = time.perf_counter_ns()
    outputs.extend(model(token, kv_cache=dst) for token in next_tokens[:, 1:].split(1, dim=1))
    steady = time.perf_counter_ns() - start
    data = dict(overlap=overlap, resident=bytes_for(model, dst), verified_buffer_copies=copies) if validate else None
    return dict(prefill=prefill, fork=fork, first=first, fork_first=fork + first, steady=steady), outputs, data


def ratios(pairs):
    return {metric: statistics.median(pair["incumbent"][metric] / pair["snapshot"][metric] for pair in pairs)
            for metric in METRICS}


def measure(candidate, candidate_cache, heads, n):
    native = models(candidate, heads)
    arms = {"incumbent": (native["incumbent"], IncumbentCache), "snapshot": (native["shared"], candidate_cache)}
    generation = torch.Generator().manual_seed(82400 + heads + n)
    prompt = torch.randint(128, (1, n), generator=generation)
    next_tokens = torch.randint(128, (2, 9), generator=generation)
    old, new = (cycle(*args, heads, prompt, next_tokens, validate=True) for args in arms.values())
    for a, b in zip(old[1], new[1], strict=True):
        exact(a, b)
    rng = random.Random(994 + n + heads)
    samples = []
    for _ in range(SAMPLES):
        order = rng.sample(tuple(arms), 2)
        results = {arm: cycle(*arms[arm], heads, prompt, next_tokens)[0] for arm in order}
        samples.append(dict(order=order, **results))
    assert old[2]["resident"] == new[2]["resident"]
    assert new[2]["verified_buffer_copies"] == 2 * LAYERS * heads * len(PAYLOAD)
    peak = {arm: max(report["overlap"], report["resident"]["total"])
            for arm, report in (("incumbent", old[2]), ("snapshot", new[2]))}
    return dict(heads=heads, context=n, incumbent=old[2], snapshot=new[2], pairs=samples, ratios=ratios(samples),
                peak_ratio=peak["snapshot"] / peak["incumbent"], logit_elements=sum(x.numel() for x in old[1]))


def fallback(candidate, candidate_cache):
    native = models(candidate, 2)
    old, new = native["incumbent"], native["shared"]
    g = torch.Generator().manual_seed(91210)
    tokens = torch.randint(128, (1, 18), generator=g)
    next_tokens = torch.randint(128, (2, 3), generator=g)
    outcomes = {}
    for reason in ("rewound", "reset-and-kernel"):
        arms = []
        for model, cls in ((old, IncumbentCache), (new, candidate_cache)):
            src = cache(cls, 2, 1, 24)
            model(tokens, kv_cache=src)
            if reason == "rewound":
                src.pos -= 1
            else:
                src.reset()
                for block in model._blocks():
                    block.attn.ultrametric_mode = "kernel"
                model((tokens + 1) % 128, kv_cache=src)
                for block in model._blocks():
                    block.attn.ultrametric_mode = "trie"
            dst = cache(cls, 2, 2, 40)
            dst.prefill(src)
            assert not layer_states(model, dst)
            arms.append(model(next_tokens[:, :1], kv_cache=dst))
        exact(*arms)
        outcomes[reason] = arms[0].numel()

    # A foreign attention instance can use the dense prefix, but must rebuild
    # its own trie because it owns a different projection object.
    fresh = models(candidate, 2)["shared"]
    src = cache(candidate_cache, 2, 1, 24)
    new(tokens, kv_cache=src)
    dst = cache(candidate_cache, 2, 2, 40)
    dst.prefill(src)
    assert all(block.attn not in dst.ultrametric_tries for block in fresh._blocks())
    old_src = cache(IncumbentCache, 2, 1, 24)
    old(tokens, kv_cache=old_src)
    old_dst = cache(IncumbentCache, 2, 2, 40)
    old_dst.prefill(old_src)
    exact(old(next_tokens[:, :1], kv_cache=old_dst), fresh(next_tokens[:, :1], kv_cache=dst))
    outcomes["foreign-owner"] = 2 * 128
    return outcomes


def other_controls(candidate, candidate_cache):
    outcomes = {}
    for mode, schedule, hard, digits in (
        ("trie", "ultrametric", False, 3),
        ("trie", "ultrametric,standard", True, 3),
        ("kernel", "ultrametric", True, None),
        ("balltree", "ultrametric", True, 3),
    ):
        native = models(candidate, 2, mode, schedule, hard, digits)
        g = torch.Generator().manual_seed(91301)
        prompt = torch.randint(128, (2, 18), generator=g)
        continuation = torch.randint(128, (2, 6), generator=g)
        data = []
        for model, cls in ((native["incumbent"], IncumbentCache), (native["shared"], candidate_cache)):
            src = cache(cls, 2, 2, 18)
            initial = model(prompt, kv_cache=src)
            dst = cache(cls, 2, 2, 20)
            dst.prefill(src)
            # The third appended token forces dense cache growth.
            first = model(continuation[:, :1], kv_cache=dst)
            chunk = model(continuation[:, 1:4], kv_cache=dst)
            last = model(continuation[:, 4:5], kv_cache=dst)
            assert dst.kv_cache.shape[4] > 20
            data.append((initial, first, chunk, last))
        for old, new in zip(*data, strict=True):
            exact(old, new)
        outcomes[str((mode, schedule, hard, digits))] = sum(v.numel() for v in data[0])
    return outcomes


def digits_near_boundary(candidate):
    tested = 0
    for heads in (1, 2, 4):
        module = models(candidate, heads)["shared"]._blocks()[0].attn
        for dtype in (torch.float32, torch.bfloat16):
            module.to(dtype=dtype)
            module.to_digits_k.weight[0].fill_(1)
            for n in (17, 64, 129, 511):
                g = torch.Generator().manual_seed(n + 210 * heads)
                prefix = torch.randn(1, heads, n, 16, generator=g).to(dtype)
                prefix[..., 1::2] = -prefix[..., ::2]
                suffix = torch.randn(2, heads, 1, 16, generator=g).to(dtype)
                copy = prefix.expand(2, -1, -1, -1)
                old = module._digits_hard_int(module.to_digits_k(torch.cat((copy, suffix), dim=2)))
                front = torch.cat([module._digits_hard_int(module.to_digits_k(k))
                                   for k in prefix.split(64, dim=2)], dim=2).expand(2, -1, -1, -1)
                tail = module._digits_hard_int(module.to_digits_k(suffix))
                assert torch.equal(old, torch.cat((front, tail), dim=2))
                tested += old.numel()
    return tested


def main(engine, attention, out):
    cpu = max(os.sched_getaffinity(0))
    os.sched_setaffinity(0, {cpu})
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    engine_cls = load_module("fork_candidate_engine", engine).KVCache
    candidate = load_candidate(attention)
    with torch.inference_mode():
        recovery = fallback(candidate, engine_cls)
        extras = other_controls(candidate, engine_cls)
        digits = digits_near_boundary(candidate)
        rows = []
        for heads, n in GRID:
            row = measure(candidate, engine_cls, heads, n)
            print(heads, n, row["ratios"], row["peak_ratio"], flush=True)
            rows.append(row)
    criteria = dict(faster_first_token_after_fork=all(row["ratios"]["fork_first"] >= 1.5 for row in rows if row["context"] == 512),
                    no_prefill_or_steady_regression=all(row["ratios"][metric] >= .90 for row in rows
                                                       for metric in ("prefill", "steady")),
                    bounded_overlap=all(row["peak_ratio"] <= 1.55 for row in rows))
    result = dict(host=platform.node(), cpu=cpu, model_layers=LAYERS, width=WIDTH, query_heads=HEADS,
                  candidate_engine_sha256=digest(engine), candidate_attention_sha256=digest(attention),
                  incumbent_engine_sha256=digest(Path(sys.modules[IncumbentCache.__module__].__file__)),
                  incumbent_attention_sha256=digest(Path(sys.modules["nanochat.ultrametric_attention_torch"].__file__)),
                  fallback=recovery, other_controls=extras, exact_digit_elements=digits, samples=SAMPLES,
                  workloads=rows, criteria=criteria, advance=all(criteria.values()))
    with out.open("x") as handle:
        json.dump(result, handle, indent=2)


def load_module(name, path):
    import importlib.util

    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


if __name__ == "__main__":
    main(*map(Path, sys.argv[1:]))
