# Route Observatory Report (`mgr.bench.routes.v2`)

- **Mechanism**: `tropical`
- **Task**: `hier`
- **Checkpoint**: `/private/tmp/mgr-jida44-consumer.x8L7T1AV/runs/joined/training/baseline/nanochat/native-41/checkpoints` (step `1`)
- **Samples**: `8` (seed `43`)
- **Brute-force cross-check verified**: `True`

## 1. Route Reuse & Consolidation

- **Route entropy (bits)**: `3.4528` (first `3.4528` -> last `3.4528`, delta `0.0000`)
- **Program reuse ratio**: `0.2500` (first `0.2500` -> last `0.2500`, delta `0.0000`)
- **Top-5 program share**: `0.5625`

## 2. Perturbation & Paraphrase Stability (`vdc.1` Probe Spec)

- **Probe spec**: `vdc.1-linf-embedding-v1` (`default_eps=0.05`)
- **Margin aggregation**: `min` (tightest decision along route)
- **Spearman rho(gamma_min, stability)**: `unavailable`
- **Unchanged perturbation draws**: 1 / 64
- **Mean perturbation stability**: `0.0156`
- **Mean paraphrase stability**: `0.8848` (8 measured)

## 3. Unsupervised Trace Clustering vs Attention-Entropy Baseline

- **Latent task classes (`K=2`)**: `['1', '3']`
- **Trace clustering ARI**: `-0.1538`
- **Attention-entropy baseline ARI**: `0.1724`
- **Prompt-only control ARI**: `1.0000`
- **ARI gain (trace - baseline)**: `-0.3263`
