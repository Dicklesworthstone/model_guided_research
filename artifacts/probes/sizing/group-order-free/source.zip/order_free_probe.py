"""Compare equality-only exploration with a checked proposal, without group size."""
import argparse
import itertools
import json
import random
import time
from pathlib import Path
from zipfile import ZipFile

from audit_compact import check_closure, check_transport
from size_free import check_normal_closure

from scripts.group_rewrite_probe import rooted_graph
from scripts.group_student_probe import (
    acquire_with_memo,
    cancelled_key,
    digest,
    distinct_words,
    graph_digest,
    identify_known_family,
    pair_key,
    save,
    walk_action,
)

SIZING = Path("artifacts/probes/sizing")
PRIOR = (
    SIZING / "group-congruence/coverage.json",
    SIZING / "group-congruence/proposal-coverage.json",
    SIZING / "group-certificate/coverage.json",
)
LIBRARY = SIZING / "group-certificate/verification.zip"
SEED = 2026112323
CALL_LIMIT = 150_000
SIZES = {"s5": 120, "s4": 24, "a6": 360, "c1": 1, "c2": 2}


def even(p):
    return sum(a > b for i, a in enumerate(p) for b in p[i + 1:]) % 2 == 0


def preflight(output):
    first, *later = (json.loads(path.read_bytes()) for path in PRIOR)
    seen = set(first["spent"]) | {row["graph_sha"] for row in first["presentations"]}
    seen.update(row["graph_sha"] for file in later for row in file["cases"])
    cases = []
    rng = random.Random(SEED)
    for family, degree, quota in (("s5", 5, 6), ("s4", 4, 4), ("a6", 6, 4)):
        population = [p for p in itertools.permutations(range(degree)) if family != "a6" or even(p)]
        remaining = quota
        for _ in range(10_000):
            pair = rng.choice(population), rng.choice(population)
            graph = rooted_graph(family, pair)
            fingerprint = graph_digest(graph)
            if len(graph) != SIZES[family] or fingerprint in seen:
                continue
            seen.add(fingerprint)
            cases.append(dict(family=family, generators=pair, graph_sha=fingerprint, fresh=True))
            remaining -= 1
            if not remaining:
                break
        else:
            raise ValueError(f"Only {quota - remaining} of {quota} fresh {family} actions")
    for family, pair in (
        ("c1", ((0,), (0,))),
        ("c2", ((0, 1), (1, 0))),
        ("c2", ((1, 0), (0, 1))),
        ("c2", ((1, 0), (1, 0))),
    ):
        graph = rooted_graph(family, pair)
        cases.append(dict(family=family, generators=pair, graph_sha=graph_digest(graph), fresh=False))
    save(output, dict(
        producer=digest(Path(__file__)), library=digest(LIBRARY),
        prior=[digest(path) for path in PRIOR], seed=SEED, call_limit=CALL_LIMIT, cases=cases,
    ))


def checked_catalog():
    with ZipFile(LIBRARY) as archive:
        earlier = json.loads(archive.read("run.json"))
        normal_closure = json.loads(archive.read("normal-closure.json"))
    check_closure(earlier["closure"])
    check_normal_closure(normal_closure)
    graphs = {}
    certificates = {}
    for fingerprint, witness in sorted(earlier["transports"].items()):
        positive = tuple((a, b, True) for a, b in check_transport(witness, fingerprint))
        first, second, *_ = witness["forward"]
        negative = (*pair_key(first + second, second + first), False)
        graphs[fingerprint] = rooted_graph("s5", tuple(tuple(g) for g in witness["generators"]))
        certificates[fingerprint] = (*positive, negative)
    if len(graphs) != 57:
        raise ValueError("Incomplete proof library")
    return graphs, certificates


def propose(equal, catalog, certificates):
    proposal = identify_known_family(catalog, equal)
    candidate = proposal["marked_class"]
    seen = {tuple(event["pair"]): event["answer"] for event in proposal["queries"]}
    checked = []
    for left, right, expected in certificates[candidate]:
        reused = (left, right) in seen
        actual = seen[left, right] if reused else equal(left, right)
        checked.append(dict(pair=[left, right], expected=expected, answer=actual, reused=reused))
        if actual != expected:
            return proposal, checked, False
    return proposal, checked, True


def arm(graph, catalog=None, certificates=None):
    paid = []
    oracle_seconds = 0.0

    def equal(left, right):
        nonlocal oracle_seconds
        if len(paid) >= CALL_LIMIT:
            raise RuntimeError(f"Oracle exhausted its {CALL_LIMIT:,} comparison budget before closure")
        before = time.perf_counter()
        answer = walk_action(left, graph) == walk_action(right, graph)
        oracle_seconds += time.perf_counter() - before
        paid.append([left, right, answer])
        return answer

    start = time.perf_counter()
    proposal, checks, accepted = None, [], False
    if catalog is not None:
        proposal, checks, accepted = propose(equal, catalog, certificates)
    acquisition = None
    if accepted:
        recovered = catalog[proposal["marked_class"]]
    else:
        acquisition = acquire_with_memo(None, equal, cancelled_key)
        recovered = tuple(tuple(row) for row in acquisition["edges"])
    seconds = time.perf_counter() - start
    if recovered != graph:
        raise ValueError("A recovered table disagrees with the hidden action")
    return dict(
        accepted=accepted, acquisition=acquisition, proposal=proposal, checks=checks,
        paid=paid, seconds=seconds, oracle_seconds=oracle_seconds,
    )


def run(coverage, output):
    population = json.loads(coverage.read_bytes())
    if (
        population["producer"] != digest(Path(__file__))
        or population["library"] != digest(LIBRARY)
        or population["prior"] != [digest(path) for path in PRIOR]
    ):
        raise ValueError("Source or panel history differs from the frozen inputs")
    start = time.perf_counter()
    catalog, certificates = checked_catalog()
    catalog_seconds = time.perf_counter() - start
    results = []
    for i, case in enumerate(population["cases"]):
        graph = rooted_graph(case["family"], tuple(tuple(g) for g in case["generators"]))
        if graph_digest(graph) != case["graph_sha"]:
            raise ValueError("Case does not reconstruct to its preregistered digest")
        baseline = arm(graph)
        treatment = arm(graph, catalog, certificates)
        rng = random.Random(98290 + i)
        used = set()
        samples = [(w, walk_action(w, graph)) for n in (16, 32, 64, 128) for w in distinct_words(rng, used, 48, n)]
        results.append(dict(index=i, **case, baseline=baseline, treatment=treatment, samples=samples))
    save(output, dict(
        coverage_sha256=digest(coverage), catalog=len(catalog), catalog_seconds=catalog_seconds,
        results=results,
    ))


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("phase", choices=("cover", "run"))
    ap.add_argument("--coverage", type=Path)
    ap.add_argument("--output", type=Path, required=True)
    args = ap.parse_args()
    if args.phase == "cover":
        preflight(args.output)
    elif args.coverage:
        run(args.coverage, args.output)
    else:
        ap.error("run requires a frozen coverage manifest")
