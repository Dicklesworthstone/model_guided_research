set -eu
cd '/Volumes/SANDISK_SSD/scratch/mgr-compact.YZNnf6vb'
jq -cS 'walk(if type=="object" then del(.seconds,.oracle_seconds,.index_seconds,.proof_seconds,.verification_seconds) else . end)' '/Volumes/SANDISK_SSD/scratch/mgr-compact.YZNnf6vb/run.json' > '/Volumes/SANDISK_SSD/scratch/mgr-compact.YZNnf6vb/run-stable.json'
jq -cS 'walk(if type=="object" then del(.seconds,.oracle_seconds,.index_seconds,.proof_seconds,.verification_seconds) else . end)' '/Volumes/SANDISK_SSD/scratch/mgr-compact.YZNnf6vb/linux-copy/run.json' > '/Volumes/SANDISK_SSD/scratch/mgr-compact.YZNnf6vb/linux-copy/run-stable.json'
cmp run-stable.json linux-copy/run-stable.json
cmp normal-closure.json linux-copy/normal-closure.json
cmp <(rg '^\{' gates/compact-matched/*/check-2.log) <(rg '^\{' linux-copy/linux-compact/*/check-2.log)
cmp <(rg '^\{' gates/size-free-kernel/*/check-2.log) <(rg '^\{' linux-copy/linux-kernel/*/check-2.log)
{
  print 'Sorted JSON after removing exactly seconds, oracle_seconds, index_seconds, proof_seconds, verification_seconds.'
  print 'macOS and Linux matched query tapes and summaries, and kernel proof witnesses and summaries, match byte-for-byte.'
  shasum -a 256 run-stable.json linux-copy/run-stable.json normal-closure.json linux-copy/normal-closure.json
} > '/Volumes/SANDISK_SSD/scratch/mgr-compact.YZNnf6vb/cross-platform.txt'
cat cross-platform.txt
