import hashlib
import json
import math
import statistics
import sys
from collections import defaultdict
from functools import cache
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import evidence as experiment
import posterior as post
from address_fixtures import sha_json
from posterior_replay import independent_catalog, oracle_fixture

SOURCE = "39cc6d3aa4575a807316a715032d2954d60a2482"
LOCK = "734ba95e7c9de521fba8e4f394c1ecec831ad63f8e7306492111a5de08799c5c"
SHADOW = "03c66dc47b91756fd082ed775d56f9ed741b7b434f887fdd4a1c46a2a1471793"
FILES = ("address_fixtures.py", "topology.py", "posterior.py", "posterior_replay.py", "evidence.py",
         "evidence.yaml", "frozen.sha256", "protocol.txt", "evidence-raw.json", "evidence_replay.py",
         "argument.md", "replay.yaml")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def verify_receipt(read, files):
    path, = (name for name in files if name.endswith("/receipt.json"))
    receipt = json.loads(read(path))
    assert receipt["tool"] == "hierarchy-unlabeled-shape" and receipt["status"] == "passed"
    assert receipt["passed"] == receipt["executed"] == receipt["total"] == 1
    assert not receipt["dry_run"] and not receipt["skipped"]
    check, = receipt["checks"]
    assert check["passed"] and check["executed"] and check["exit_code"] == 0
    log = Path(path).with_name(Path(check["log_path"]).name).as_posix()
    assert digest(read(log)) == check["log_sha256"]
    config = Path(path).with_name("checks-config.yaml").as_posix()
    assert read(config) == read("evidence.yaml")
    assert digest(read(config)) == receipt["config_sha256"] == receipt["config_sha256_after"]
    return Path(path).parent.name


@cache
def shapes(size):
    if size == 0:
        return [()]
    return [(left, right) for count in range(size) for left in shapes(count)
            for right in shapes(size - 1 - count)]


def hooks(shape):
    if not shape:
        return 0, 1
    left, right = map(hooks, shape)
    size = 1 + left[0] + right[0]
    return size, size * left[1] * right[1]


def linear_normalizers():
    result = {}
    for beta in post.GRID:
        values = [1.0]
        for size in range(1, post.INTERNAL + 1):
            values.append(size ** -beta * math.fsum(values[left] * values[size - 1 - left] for left in range(size)))
        expected = experiment.log_partition(beta)
        assert all(math.isclose(math.log(value), log, abs_tol=1e-12, rel_tol=0)
                   for value, log in zip(values, expected, strict=True))
        for size in range(7):
            actual = math.fsum(hooks(tree)[1] ** -beta for tree in shapes(size))
            assert math.isclose(actual, values[size], rel_tol=2e-14, abs_tol=0)
        if beta == 0:
            assert all(math.isclose(value, math.comb(2 * size, size) // (size + 1), rel_tol=1e-15, abs_tol=0)
                       for size, value in enumerate(values))
        if beta == 1:
            assert all(math.isclose(value, 1, abs_tol=1e-14, rel_tol=0) for value in values)
        result[beta] = values[post.INTERNAL]
    return result


def check_likelihoods(train, inferred, normalizers):
    for beta, expected in zip(post.GRID, inferred, strict=True):
        values = [math.log(math.fsum(count * hooks ** (-beta) for _, hooks, count in row["versions"])
                           / normalizers[beta]) for row in train]
        assert math.isclose(statistics.mean(values), expected, rel_tol=0, abs_tol=1e-12)
    aliased = [[(0, hook, count) for _, hook, count in row["versions"]] for row in train]
    _, blind_scores = experiment.estimate_evidence(aliased)
    assert blind_scores == inferred


def replay(read, files, validate_catalogs=False):
    manifest = read("frozen.sha256")
    assert digest(manifest) == LOCK
    for line in manifest.decode().splitlines():
        sha, path = line.split()
        assert digest(read(path)) == sha
    assert digest(read("posterior_replay.py")) == SHADOW
    normalizers = linear_normalizers()
    raw = json.loads(read("evidence-raw.json"))
    rows = raw["rows"]
    assert len(rows) == len({row["fixture"] for row in rows}) == 252
    counts = defaultdict(list)
    audit_cases = []
    for row, (seed, family, phase, index, records, root, query, gold, namespace) in zip(
        rows, experiment.fresh(), strict=True
    ):
        assert (row["seed"], row["family"], row["phase"], row["index"]) == (seed, family, phase, index)
        assert row["fixture"] == sha_json([records, root, query]) and row["target"] == gold
        oracle_fixture(records, root, query, gold, namespace)
        versions = row["versions"]
        assert row["bank_maps"] == 40320 and 1 <= sum(count for _, _, count in versions) <= row["rooted_maps"] <= 40320
        assert gold in {key for key, _, _ in versions}
        assert all(key in records and not records[key] and count > 0 and hook > 0 and math.factorial(63) % hook == 0
                   for key, hook, count in versions)
        assert len(versions) == len({(key, hook) for key, hook, _ in versions})
        if phase == "test" and index == 0:
            audit_cases.append([seed, family])
            if validate_catalogs:
                counted = independent_catalog(records, root, query)
                assert all(row[key] == value for key, value in counted.items())
        counts[seed, family, phase].append(row)
    assert len(audit_cases) == 9
    details = {}
    pooled = {}
    gates = {}
    for family, beta in experiment.TRUTHS:
        fits = {}
        for seed in experiment.SEEDS:
            train, test = (counts[seed, family, phase] for phase in ("train", "test"))
            assert len(train) == 12 and len(test) == 16
            fit = experiment.compare(train, test, beta)
            check_likelihoods(train, fit["relative_evidence"], normalizers)
            assert fit == raw["fits"][str(seed)][family]
            fits[str(seed)] = fit
        details[family] = fits
        beta_mae = {arm: statistics.mean(abs(fit[f"{arm}_beta"] - beta) for fit in fits.values())
                    for arm in ("terminal", "unlabeled")}
        per_arm = {arm: {metric: (
            sum(fit["metrics"][arm][metric] for fit in fits.values()) if metric == "correct"
            else statistics.mean(fit["metrics"][arm][metric] for fit in fits.values())
        ) for metric in ("nll", "brier", "correct")} for arm in experiment.ARMS}
        pooled[family] = dict(true_beta=beta, beta_mae=beta_mae, scores=per_arm, cases=48,
                              ambiguous=sum(len({key for key, _, _ in row["versions"]}) > 1
                                            for seed in experiment.SEEDS for row in counts[seed, family, "test"]))
        gates[family + "_beta"] = beta_mae["unlabeled"] <= .25
        gates[family + "_oracle"] = per_arm["unlabeled"]["nll"] <= per_arm["oracle"]["nll"] + .15
        if beta:
            gates[family + "_uniform"] = per_arm["uniform"]["nll"] - per_arm["unlabeled"]["nll"] >= .10
    return dict(source=SOURCE, receipt=verify_receipt(read, files), train=108, test=144, audit_cases=audit_cases,
                gates=gates, pass_all=all(gates.values()), pooled=pooled, details=details)


def verify(path):
    with ZipFile(path) as archive:
        names = archive.namelist()
        assert archive.testzip() is None and len(names) == len(set(names))
        decision = replay(archive.read, names, validate_catalogs=True)
        assert decision == json.loads(archive.read("decision.json"))
    print(json.dumps(decision))


def build(root, bundle):
    files = {name: root / name for name in FILES}
    receipt, = (root / "receipts").glob("*/*/receipt.json")
    for name in ("receipt.json", "check-1.log", "checks-config.yaml"):
        path = receipt.with_name(name)
        files[path.relative_to(root).as_posix()] = path
    result = replay(lambda name: files[name].read_bytes(), files.keys())
    with ZipFile(bundle, "x", compression=ZIP_DEFLATED) as archive:
        for name, path in files.items():
            archive.write(path, name)
        archive.writestr("decision.json", json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    action, *paths = sys.argv[1:]
    {"build": build, "verify": verify}[action](*map(Path, paths))
