"""Check the raw train / sample outputs and the native DSR gate receipts."""

import hashlib
import json
from pathlib import Path
import sys

root = Path(sys.argv[1])
cpu_cert, gpu_cert = (json.loads(Path(p).read_bytes()) for p in sys.argv[2:4])
assert cpu_cert["mechanisms"] == gpu_cert["mechanisms"] and len(gpu_cert["mechanisms"]) == 13
source = "95e8d4741890dd8dab3fa451064b2f9d1926bcdd"
receipt = json.loads((root / "receipt.json").read_bytes())
assert receipt["source_before"] == receipt["source_after"] and receipt["source_before"].split("|")[0] == source
assert not receipt["dry_run"] and receipt["executed"] == receipt["total"] == 7
assert receipt["status"] == "passed" and receipt["passed"] == 7 and receipt["failed"] == 0
assert hashlib.sha256((root / "checks-config.yaml").read_bytes()).hexdigest() == receipt["config_sha256"] == receipt["config_sha256_after"]
for i, check in enumerate(receipt["checks"], 1):
    raw = (root / f"check-{i}.log").read_bytes()
    assert hashlib.sha256(raw).hexdigest() == check["log_sha256"] and check["passed"]
    if i in (5, 6):
        assert b"12 passed in " in raw and b"skipped in " not in raw
    if i == 7:
        assert b"1 passed" in raw and b"1 skipped" not in raw
report = json.loads((root / "e2e/reports/determinism/e2e_report.json").read_bytes())
assert report["ok"] and all(s["status"] == "pass" for s in report["stages"])
assert len(report["stages"]) == 1 + 6 * len(gpu_cert["mechanisms"])
rows = []
for mech in gpu_cert["mechanisms"]:
    run = root / "e2e/artifacts/e2e/loop" / f"e2e-det-{mech}"
    train = json.loads((run / "summary.json").read_bytes())
    assert train["meta"]["git"]["commit_full"] == source and not train["meta"]["git"]["dirty"]
    assert train["meta"]["device"] == "cuda" and train["config"]["attention_type"] == mech
    assert train["budget"]["max_steps"] == len(train["results"]["losses"]) == 12
    outputs = []
    for n in (1, 2):
        payload = json.loads((root / "e2e/logs/determinism" / f"sample-{mech}-{n}.log").read_bytes())
        assert payload["device"] == "cuda" and payload["temperature"] == 0 and payload["seed"] == 3
        result, = payload["results"]
        assert result["step"] == 11 and result["n_tokens"] == 8 and result["attention_type"] == mech
        outputs.append(result["text"].encode("utf-8"))
    assert outputs[0] == outputs[1]
    rows.append({"mechanism": mech, "training_steps": 12, "checkpoint_step": 11,
                 "tokens_per_sample": 8, "utf8_sha256": hashlib.sha256(outputs[0]).hexdigest()})
print(json.dumps({"source": source, "device": "cuda", "mechanisms": rows,
                  "matched_text_pairs": len(rows), "stages_passed": len(report["stages"]),
                  "dsr_gate_exit_codes": [c["exit_code"] for c in receipt["checks"]]}, indent=2))
