"""Check the exact census and compare charges across deterministic relabelings."""

import hashlib
import json
import sys
from collections import Counter

import numpy as np
from check_four_anchor import ANCHORS, access, movement_floor, position, reconstruct
from check_replay import load

ARMS = ("square", "length")


def canonical_named(action):
    root, rows = action
    states = [root]
    lookup = {root: 0}
    edges = []
    for state in states:
        pair = []
        for target in rows[int(state)]:
            if target not in lookup:
                lookup[target] = len(lookup)
                states.append(target)
            pair.append(lookup[target])
        edges.append(tuple(pair))
    return tuple(edges)


class Columns:
    """Independent endpoint partitions for checking structural handoff."""

    def __init__(self, shapes):
        self.edges = np.asarray(shapes, dtype=np.uint8)
        self.cases = np.arange(len(shapes))
        self.cached = {"": np.zeros(len(shapes), dtype=np.uint8)}

    def word(self, value):
        if value not in self.cached:
            for i, mark in enumerate(value):
                prefix = value[:i + 1]
                if prefix not in self.cached:
                    self.cached[prefix] = self.edges[self.cases, self.cached[value[:i]], int(mark)]
        return self.cached[value]

    def survivors(self, paid):
        refs: dict[int, str] = {}
        live = self.cases
        for word, label in paid:
            current = self.word(word)[live]
            if label in refs:
                keep = current == self.word(refs[label])[live]
            else:
                keep = np.ones(len(live), dtype=np.bool_)
                for reference in refs.values():
                    keep &= current != self.word(reference)[live]
                refs[label] = word
            live = live[keep]
            if not len(live):
                break
        return live.tolist()


def naming_check(result, words, initial, graph, n, slot, columns):
    events = result["events"]
    if [(e["word"], e["answer"]) for e in events] != [(w, label) for w, label in result["tape"][:len(events)]]:
        raise ValueError("Trace does not match its paid oracle calls")
    structure = []
    naming = []
    for event, (word, state) in zip(events, words):
        if event["phase"] == "structure" and not naming:
            structure.append((word, state))
        elif event["phase"] == "naming":
            naming.append((word, state))
        else:
            raise ValueError("Wrong structure-to-naming order")
    before_naming = initial + structure
    survivors = columns.survivors(before_naming)
    if result["terminal"] == "cap":
        if len(survivors) < 2 or slot not in survivors or len(before_naming) != n + 24 or naming:
            raise ValueError("Fallback occurred at the wrong version-space boundary")
        return
    if result["terminal"] != "unique" or survivors != [slot] or len(words) != len(events):
        raise ValueError("Incorrect uniqueness at naming handoff")
    named = {state for _, state in before_naming}
    expected_naming = [(word, state) for state, word in access(graph) if state not in named][:-1]
    if naming != expected_naming:
        raise ValueError("Incorrect shortest naming suffix")


def run_names(n, slot, renamed):
    multiplier = 19 if renamed else 17
    intercept = 7 * slot + 11 if renamed else 13 * slot + 7
    labels = [str((i * multiplier + intercept) % n) for i in range(n)]
    if len(set(labels)) != n:
        raise ValueError("A replay did not use a naming permutation")
    return labels


def verify_row(row, graph, renamed, columns):
    n, slot = row["order"], row["slot"]
    names = run_names(n, slot, renamed)
    invert = {name: state for state, name in enumerate(names)}
    anchors = {word: names[position(graph, word)] for word in ANCHORS}
    if row["anchors"] != anchors or set(row["arms"]) != set(ARMS):
        raise ValueError("Wrong anchors or study arms")
    labelled = [None] * n
    for state, (a, b) in enumerate(graph):
        labelled[int(names[state])] = [names[a], names[b]]
    truth = [names[0], labelled]
    read_floor = n + 3 - len(set(anchors.values()))
    symbol_floor = movement_floor(truth, anchors)
    canonical_anchors = [(word, invert[name]) for word, name in anchors.items()]
    normalized = {}
    costs = {}
    for arm, result in row["arms"].items():
        tape = result["tape"]
        paid = [*anchors.items(), *tape]
        if (result["action"] != truth or len(paid) < read_floor or len({word for word, _ in paid}) != len(paid)
                or any(len(word) < 2 or names[position(graph, word)] != value for word, value in paid)):
            raise ValueError("An exact action, oracle answer, or read floor failed")
        words = [(word, invert[value]) for word, value in tape]
        if arm == "length" and columns is not None:
            naming_check(result, words, canonical_anchors, graph, n, slot, columns)
        zeros = sum(word.count("0") for word, _ in paid)
        ones = sum(word.count("1") for word, _ in paid)
        if zeros + ones < symbol_floor:
            raise ValueError("A tape undershot the exact movement floor")
        costs[arm] = dict(reads=len(paid), zeros=zeros, ones=ones, symbols=zeros + ones,
                          fallback=int(result["terminal"] == "cap"), cpu_ns=result["cpu_ns"], wall_ns=result["wall_ns"])
        normalized[arm] = dict(tape=words, terminal=result["terminal"],
                               events=[dict(e, answer=invert[e["answer"]]) for e in result["events"]])
    return normalized, costs, read_floor, symbol_floor, canonical_anchors


def relation(deltas):
    if not any(deltas):
        return "tie"
    if all(delta >= 0 for delta in deltas):
        return "length"
    if all(delta <= 0 for delta in deltas):
        return "square"
    return "mixed"


def audit(library_path, previous_path, first_path, replay_path):
    library, previous, first, second = map(load, (library_path, previous_path, first_path, replay_path))
    shapes = reconstruct(library)
    independent = hashlib.sha256(json.dumps(shapes, separators=(",", ":"), sort_keys=True).encode()).hexdigest()
    expected_count = {str(n): len(s) for n, s in shapes.items()}
    if first["renamed"] or not second["renamed"]:
        raise ValueError("The naming permutation replay was skipped")
    for sample in (first, second):
        if (sample["shape_digest"] != independent or sample["shape_counts"] != expected_count
                or len(sample["rows"]) != sum(expected_count.values())):
            raise ValueError("The complete marked census is missing or has duplicates")
    prior_panel = {canonical_named(row["arms"]["length_first"]["action"]) for row in previous["rows"]}
    if len(prior_panel) != 30 or not prior_panel.issubset({graph for s in shapes.values() for graph in s}):
        raise ValueError("The original 30 marked cases could not be recovered")
    groups = {}
    timings = {n: {arm: Counter() for arm in ARMS} for n in shapes}
    examples = {}
    relation_rows = zip(first["rows"], second["rows"], strict=True)
    transitions = 0
    for n, forms in shapes.items():
        partitions = Columns(forms)
        for slot, graph in enumerate(forms):
            original, renamed = next(relation_rows)
            if any((row["order"], row["slot"]) != (n, slot) for row in (original, renamed)):
                raise ValueError("The complete census was reordered")
            norm, costs, read_floor, symbol_floor, anchors = verify_row(original, graph, False, partitions)
            replay, replay_costs, _, _, permutation = verify_row(renamed, graph, True, None)
            if norm != replay or anchors != permutation:
                raise ValueError("A renamed case gave a different canonical tape or terminal state")
            for arm, charge in replay_costs.items():
                timings[n][arm].update(cpu_ns=charge["cpu_ns"], wall_ns=charge["wall_ns"])
            if graph in prior_panel:
                panel = "prior-30"
            else:
                panel = "remainder"
            first_seen: dict[int, int] = {}
            anchor_pattern = "".join(str(first_seen.setdefault(vertex, len(first_seen))) for _, vertex in anchors)
            abelian = graph[graph[0][0]][1] == graph[graph[0][1]][0]
            wins2 = relation(tuple(costs["square"][k] - costs["length"][k] for k in ("reads", "symbols")))
            wins3 = relation(tuple(costs["square"][k] - costs["length"][k] for k in ("reads", "zeros", "ones")))
            for key in (
                "all", str(n), panel, f"{n}-{'abelian' if abelian else 'nonabelian'}", f"{n}-anchors-{anchor_pattern}",
            ):
                group = groups.setdefault(key, dict(shapes=0, floors=Counter(), square=Counter(), length=Counter(),
                                                    pareto2=Counter(), pareto3=Counter()))
                group["shapes"] += 1
                group["floors"].update(reads=read_floor, symbols=symbol_floor)
                group["pareto2"][wins2] += 1
                group["pareto3"][wins3] += 1
                for arm in ARMS:
                    group[arm].update(costs[arm])
            for key, metric in (("max_additional_reads", "reads"), ("max_additional_symbols", "symbols")):
                delta = costs["length"][metric] - costs["square"][metric]
                if key not in examples or delta > examples[key]["delta"]:
                    examples[key] = dict(order=n, slot=slot, delta=delta, anchor_pattern=anchor_pattern)
            transitions += 8 * n
    gates = {
        str(n): all(groups[str(n)]["length"][k] < groups[str(n)]["square"][k] for k in ("reads", "symbols"))
        for n in shapes
    }
    print(json.dumps(dict(
        groups=groups, gates=gates, passed=all(gates.values()), worst_cases=examples,
        second_timings=timings, shape_counts=expected_count, checked_transitions=transitions,
        build=[{k: sample[k] for k in ("builder", "preparation")} for sample in (first, second)],
    ), sort_keys=True))


if __name__ == "__main__":
    audit(*sys.argv[1:])
