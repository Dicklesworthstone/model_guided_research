"""Compare verdicts, refusal reasons, selected observations and confidence intervals."""
from collections import Counter
import json
from pathlib import Path
import sys

root = Path(sys.argv[1])
read = lambda path: json.loads(path.read_bytes())
old = read(root/"charge-controls-out/adjudications/v10-historical/verdicts.json")
new = read(root/"eval-eligibility-tests/adjudications/v11-historical/verdicts.json")
live = read(root/"eval-eligibility-tests/adjudications/v11-live/verdicts.json")
prior = {r["id"]:r for r in old["verdicts"]}
assert old["policy_version"] == "ci-v10" and new["policy_version"] == live["policy_version"] == "ci-v11"
assert len(prior) == len(new["verdicts"]) == 75
rows = []
for v in new["verdicts"]:
    o = prior[v["id"]]
    a, b = o.get("arms", {}), v.get("arms", {})
    old_arms = {k:{m:arm.get(m) for m in ("effect","ci95","n_candidate","n_baseline","budget_flops")} for k,arm in a.items()}
    new_arms = {k:{m:arm.get(m) for m in ("effect","ci95","n_candidate","n_baseline","budget_flops")} for k,arm in b.items()}
    changed_paths = set(o.get("artifacts",[])) != set(v.get("artifacts",[]))
    rows.append(dict(id=v["id"], previous=o["verdict"], current=v["verdict"], previous_reason=o.get("reason_code"),
                     current_reason=v.get("reason_code"), paths_changed=changed_paths, estimates_changed=old_arms!=new_arms))
counts = lambda rr: dict(sorted(Counter(v["verdict"] for v in rr).items()))
summary = dict(frozen_source="4db6657e80d6cd657d8ca85ef86ca01380c2e9c0",
               producer="bc470ab5b476ba2cf5bfe19e5a7ae9797da4a527", previous_policy="ci-v10", policy="ci-v11",
               historical=counts(new["verdicts"]), live=counts(live["verdicts"]), historic_count=len(rows),
               changed_verdicts=sum(r["previous"]!=r["current"] for r in rows),
               changed_reasons=sum(r["previous_reason"]!=r["current_reason"] for r in rows),
               changed_selected_paths=sum(r["paths_changed"] for r in rows), changed_estimates=sum(r["estimates_changed"] for r in rows),
               live_owner_holds=sorted(r["id"] for r in live["verdicts"] if r.get("reason_code")=="manual_hold"), rows=rows)
assert len(live["verdicts"])==76 and len(summary["live_owner_holds"])==4
print(json.dumps(summary,indent=2))
