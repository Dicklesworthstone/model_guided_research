set -eu
cd '/Volumes/SANDISK_SSD/scratch/mgr-order-free.fsO3T8Z0'
jq -cS 'walk(if type=="object" then del(.seconds,.oracle_seconds,.catalog_seconds) else . end)' run.json > '/Volumes/SANDISK_SSD/scratch/mgr-order-free.fsO3T8Z0/run-stable.json'
jq -cS 'walk(if type=="object" then del(.seconds,.oracle_seconds,.catalog_seconds) else . end)' linux-copy/run.json > '/Volumes/SANDISK_SSD/scratch/mgr-order-free.fsO3T8Z0/linux-copy/run-stable.json'
cmp run-stable.json linux-copy/run-stable.json
cmp <(rg '^\{' gates/order-free-matched/*/check-2.log) <(rg '^\{' linux-copy/independent.log)
cmp <(rg '^\{' gates/order-free-schedule/*/check-1.log | jq -cS 'del(.source_sha256)') <(rg '^\{' linux-copy/linux-order-free-schedule/*/check-1.log | jq -cS 'del(.source_sha256)')
{
  print 'Matched tapes and audit summaries are byte-identical on macOS and Linux after sorting JSON and excluding only seconds, oracle_seconds and catalog_seconds.'
  print 'Scheduling replay summaries match after removal of the input transcript hash, which includes timing.'
  shasum -a 256 run-stable.json linux-copy/run-stable.json
} > '/Volumes/SANDISK_SSD/scratch/mgr-order-free.fsO3T8Z0/cross-platform.txt'
cat cross-platform.txt
