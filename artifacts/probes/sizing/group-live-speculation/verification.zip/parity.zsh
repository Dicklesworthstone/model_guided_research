set -eu
cd '/Volumes/SANDISK_SSD/scratch/mgr-live-speculation.AOXx4yNo'
jq -cS 'walk(if type=="object" then del(.seconds,.oracle_seconds,.catalog_seconds) else . end)' run.json > '/Volumes/SANDISK_SSD/scratch/mgr-live-speculation.AOXx4yNo/run-stable.json'
jq -cS 'walk(if type=="object" then del(.seconds,.oracle_seconds,.catalog_seconds) else . end)' linux-copy/run.json > '/Volumes/SANDISK_SSD/scratch/mgr-live-speculation.AOXx4yNo/linux-copy/run-stable.json'
cmp run-stable.json linux-copy/run-stable.json
cmp <(rg '^\{' gates/live-speculation-matched/*/check-2.log) <(rg '^\{' linux-copy/audit.log)
shasum -a 256 run-stable.json linux-copy/run-stable.json
