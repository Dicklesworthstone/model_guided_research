import json
import math
import random
import statistics
import sys
from pathlib import Path

from depth_cross import topology
from nanochat.gpt import norm
from one_hop import BATCH, FIT_ROWS, HEAD_SEEDS, pack, pair_scores, tree_index
from sibling_order import (
    F, HuggingFaceTokenizer, LocationHead, SPEC, _load_eval_checkpoint, corpus,
    digest, leaf_entries, read, serialize, shuffle_tree, states, tokenizer_path,
    torch, tree_from_text, tree_of,
)

CELLS = ("native", "reordered", "mixed2", "depth3", "reordered3")
DEEP = CELLS[-2:]
ARMS = ("context", "embedding")
BACKBONES = (30, 31, 32)
PANEL_SEEDS = (94, 95, 96)
TOKENIZER_SHA = "a0ef2918fdde08e8b518226e8deb3099834d3c4bc91abd00948f07a0991a5c40"
TRAINING_SHA = "594fd4358a6820998ab16156d165041715b652ca"
WEIGHTS = (
    "fb80da1f48010a9a4faeb186e0783f06f6effd2a7d50523cd4541c5a3e55d7a9",
    "2d9235a9e1a54636c8371f35bf4f643c09e8117b61fc629a05554912a7bb185d",
    "a7614775276c41a2a299c8e8793d5a408680b771c4157801183260b8cbfcf511",
)
SCHEDULES = (
    "272de9b16b4e0ceff49dfc05fc320a02a2b6c76fba911540dc86b62d3669a185",
    "4acab34814f30ad2e9e0524342b969921f4c4b76cd0a4cd5a84fad383a2d99c1",
    "71804d484922c2c097f8d6ce14795cd2853bca86b5da3b77f96f73fd61eb46f9",
)


def write(path, data):
    with path.open("x", encoding="utf-8") as out:
        json.dump(data, out, allow_nan=False, separators=(",", ":"))
        out.write("\n")


def identity(text):
    return tuple(sorted((path, value) for path, value, _ in leaf_entries(text)))


def prepare(reference, previous_panel, destination):
    known_texts, _ = corpus(reference)
    known = {identity(text) for text in known_texts}
    known.update(identity(block[cell]["text"]) for block in read(previous_panel)["blocks"] for cell in CELLS)
    excluded = len(known)
    tok_dir = tokenizer_path(reference)
    assert digest(tok_dir / "tokenizer.json") == TOKENIZER_SHA
    tok = HuggingFaceTokenizer.from_directory(str(tok_dir))
    rng = random.Random(91048)
    blocks = []
    for seed in PANEL_SEEDS:
        count = 0
        for doc in SPEC.generate(4800, seed, SPEC.resolve_dials(None))["train"][::2]:
            native = tree_of(doc)
            leaves = leaf_entries(native)
            if identity(native) in known or len(leaves) != 9 or len({value for _, value, _ in leaves}) != 9:
                continue
            layout = (count % 3, (count // 3 + seed) % 3, (count // 3 + seed + count) % 3)
            mixed = topology([f"v{i}" for i in rng.sample(range(100), 9)], *layout)
            nested = serialize(mixed)
            reordered = serialize(shuffle_tree(tree_from_text(native), rng))
            reordered_nested = serialize(shuffle_tree(mixed, rng))
            if identity(nested) in known or native == reordered or nested == reordered_nested:
                continue
            native_paths = [path for path, _, _ in leaves
                            if path[0] != f"k0x{layout[0]}" and path[1] != f"k1x{layout[1]}"]
            nested_paths = [path for path, _, _ in leaf_entries(nested)]
            shallow = [path for path in nested_paths if len(path) == 2]
            deep = [path for path in nested_paths if len(path) == 3]
            assert len(native_paths) == len(shallow) == len(deep) == 4
            block = dict(seed=seed, index=count, native=pack(native, native_paths, tok),
                         reordered=pack(reordered, native_paths, tok), mixed2=pack(nested, shallow, tok),
                         depth3=pack(nested, deep, tok), reordered3=pack(reordered_nested, deep, tok))
            for left, right in (("native", "reordered"), DEEP):
                a, b = block[left]["rows"], block[right]["rows"]
                assert identity(block[left]["text"]) == identity(block[right]["text"])
                assert [len(row["ids"]) for row in a] == [len(row["ids"]) for row in b]
                if all(x["expected"] == y["expected"] for x, y in zip(a, b, strict=True)):
                    break
            else:
                known.update((identity(native), identity(nested)))
                blocks.append(block)
                count += 1
                if count == 12:
                    break
        assert count == 12, (seed, count)
    assert len(blocks) == 36 and len(known) == excluded + 72
    write(destination, dict(blocks=blocks, excluded_tree_identities=excluded,
                            tokenizer_sha256=TOKENIZER_SHA, previous_panel_sha256=digest(previous_panel)))
    print(f"Prepared 36 blocks with 72 fresh tree identities. Excluded {excluded} prior identities.", flush=True)


def load_inputs(root, seed, weight_hash, schedule_hash):
    run = root / f"seed-{seed}" / "runs" / "augmented"
    ckpt = run / "checkpoints"
    info = read(run / "summary.json")
    model, meta, step = _load_eval_checkpoint(ckpt, None, torch.device("cpu"), fingerprint_weights=True)
    assert step == 2047 and model.config.n_embd == 128 and model.config.sequence_len == 320
    assert info["provenance"]["git_sha"] == TRAINING_SHA and not info["provenance"]["tainted"]
    assert info["weights_sha256"] == meta["weights_sha256"] == weight_hash
    tok_dir = ckpt / "tokenizer"
    assert digest(tok_dir / "tokenizer.json") == TOKENIZER_SHA
    schedule = root / f"seed-{seed}" / "permuted.pt"
    assert digest(schedule) == schedule_hash == read(schedule.parent / "preflight.json")["permuted_sha256"]
    return model.eval().requires_grad_(False), HuggingFaceTokenizer.from_directory(str(tok_dir)), schedule


def features(model, ids):
    _, context = states(model, ids)
    embeddings = norm(model._token_embedding()(ids))
    assert context.shape == embeddings.shape and context.shape[-1] == 128
    return context.float(), embeddings.float()


@torch.no_grad()
def fit_features(model, tok, schedule_path, forbidden):
    schedule = torch.load(schedule_path, weights_only=True)
    examples = {arm: [] for arm in ARMS}
    terminal_types = set()
    for start in range(0, FIT_ROWS, BATCH):
        batch = schedule["inputs"][start:start + BATCH]
        activations = dict(zip(ARMS, features(model, batch), strict=True))
        for i, index in enumerate(range(start, start + BATCH)):
            stop = int(schedule["queries"][index])
            targets = schedule["targets"][index, stop:]
            prompt = batch[i, :stop + 1].tolist()
            doc = tok.decode(prompt[1:] + targets[targets != -1].tolist())
            text = tree_of(doc)
            assert identity(text) not in forbidden
            path = tuple(doc.split(" PATH ", 1)[1].split(" OUT ", 1)[0].split())
            case = pack(text, [path], tok)
            row, = case["rows"]
            assert len(path) == 2 and row["ids"] == prompt and row["expected"] == int(schedule["labels"][index])
            terminal_types.update(prompt[pos] for pos in row["query_keys"])
            edges, siblings = tree_index(case)
            groups = [siblings[path[:hop]] for hop in range(2)]
            labels = torch.tensor([group.index(edges.index(path[:hop + 1])) for hop, group in enumerate(groups)])
            mask = torch.arange(3)[None, :] < torch.tensor([len(group) for group in groups])[:, None]
            for arm, hidden in activations.items():
                keys = torch.zeros(2, 3, 128)
                for hop, group in enumerate(groups):
                    keys[hop, :len(group)] = hidden[i, [case["edge_positions"][j] for j in group]]
                examples[arm].append((hidden[i, row["query_keys"]], keys, mask, labels))
    return {arm: tuple(torch.stack(col) for col in zip(*rows, strict=True)) for arm, rows in examples.items()}, terminal_types


def fit(cached, seed):
    torch.manual_seed(seed)
    head = LocationHead()
    opt = torch.optim.AdamW(head.parameters(), lr=.003)
    losses = []
    for start in range(0, FIT_ROWS, BATCH):
        q, k, mask, label = [col[start:start + BATCH] for col in cached]
        score = pair_scores(head, q, k).masked_fill(~mask, -torch.inf)
        loss = F.cross_entropy(score.flatten(0, -2), label.flatten())
        assert math.isfinite(float(loss.detach()))
        opt.zero_grad(set_to_none=True)
        loss.backward()
        opt.step()
        losses.append(float(loss.detach()))
    return head.eval(), [losses[0], losses[-1]]


@torch.inference_mode()
def score(model, heads, blocks):
    results = []
    for block in blocks:
        outputs = {}
        for cell in CELLS:
            case = block[cell]
            ids = torch.tensor([row["ids"] for row in case["rows"]])
            assert ids.shape[0] == 4 and ids.shape[1] <= 128
            qidx = torch.tensor([row["query_keys"] for row in case["rows"]])
            positions = case["edge_positions"]
            out = {"token": (ids.gather(1, qidx)[:, :, None] == ids[:, None, positions]).float().tolist()}
            for arm, hidden in zip(ARMS, features(model, ids), strict=True):
                edge = hidden[:, positions]
                query = hidden[torch.arange(4)[:, None], qidx]
                for seed, head in heads[arm].items():
                    out[f"{arm}_{seed}"] = pair_scores(head, query, edge[:, None]).tolist()
                if arm == "embedding":
                    out["cosine"] = torch.einsum("bhd,bnd->bhn", F.normalize(query, dim=-1),
                                                F.normalize(edge, dim=-1)).tolist()
            outputs[cell] = out
        results.append(outputs)
    return results


def trace(edges, siblings, route, scores):
    selected = ()
    diagnostics = []
    for hop, values in enumerate(scores):
        correct = edges.index(route[:hop + 1])
        siblings_of_gold = siblings[route[:hop]]
        competing = [values[ix] for ix in siblings_of_gold if ix != correct]
        gap = values[correct] - max(competing) if competing else None
        candidates = siblings.get(selected, ())
        chosen = max(candidates, key=values.__getitem__) if candidates else None
        selected = edges[chosen] if chosen is not None else selected
        diagnostics.append(dict(gold_parent_correct=max(siblings_of_gold, key=values.__getitem__) == correct,
                                gap=gap, chosen=chosen))
    return selected == route, diagnostics


def count_scores(blocks, results):
    totals, misses = {}, []
    for block, outputs in zip(blocks, results, strict=True):
        for cell in CELLS:
            case = block[cell]
            edges, siblings = tree_index(case)
            for arm, scores in outputs[cell].items():
                counts = totals.setdefault(arm, {}).setdefault(
                    cell, dict(all_four=0, correct=0, gold_parent=[0] * len(scores[0]))
                )
                correct_rows = 0
                for index, (row, hop_scores) in enumerate(zip(case["rows"], scores, strict=True)):
                    correct, diagnostics = trace(edges, siblings, tuple(row["route"]), hop_scores)
                    correct_rows += correct
                    for hop, diag in enumerate(diagnostics):
                        counts["gold_parent"][hop] += diag["gold_parent_correct"]
                        if arm in ("cosine", "token"):
                            assert diag["gold_parent_correct"] and (diag["gap"] is None or diag["gap"] > 0)
                    if not correct:
                        misses.append(dict(seed=block["seed"], block=block["index"], cell=cell, arm=arm,
                                           row=index, expected=row["route"], diagnostics=diagnostics))
                counts["all_four"] += correct_rows == 4
                counts["correct"] += correct_rows
    for arm in ("cosine", "token"):
        assert all(totals[arm][cell]["all_four"] == 36 for cell in CELLS)
    return totals, misses


def experiment(panel_path, prior, dest):
    panel = read(panel_path)
    blocks = panel["blocks"]
    assert panel["tokenizer_sha256"] == TOKENIZER_SHA
    assert [b["seed"] for b in blocks] == [seed for seed in PANEL_SEEDS for _ in range(12)]
    forbidden = {identity(block[cell]["text"]) for block in blocks for cell in CELLS}
    assert len(forbidden) == 72
    medians, deltas = {}, {}
    for seed, weight_hash, schedule_hash in zip(BACKBONES, WEIGHTS, SCHEDULES, strict=True):
        model, tok, schedule = load_inputs(prior, seed, weight_hash, schedule_hash)
        cached, fitted_types = fit_features(model, tok, schedule, forbidden)
        fits = {arm: {key: fit(cached[arm], key) for key in HEAD_SEEDS} for arm in ARMS}
        heads = {arm: {key: result[0] for key, result in items.items()} for arm, items in fits.items()}
        scores = score(model, heads, blocks)
        counts, misses = count_scores(blocks, scores)
        unseen = {cell: sum(row["ids"][row["query_keys"][-1]] not in fitted_types
                            for block in blocks for row in block[cell]["rows"]) for cell in DEEP}
        write(dest / f"backbone-{seed}.json",
              dict(panel_sha256=digest(panel_path), training_sha=TRAINING_SHA, weight_sha256=weight_hash,
                   schedule_sha256=schedule_hash, fit_rows=FIT_ROWS, terminal_fit_types=sorted(fitted_types),
                   third_hop_unseen_query_tokens=unseen, counts=counts, misses=misses, scores=scores,
                   losses={arm: {key: result[1] for key, result in items.items()} for arm, items in fits.items()}))
        all_four = {arm: {cell: [counts[f"{arm}_{key}"][cell]["all_four"] for key in HEAD_SEEDS]
                          for cell in CELLS} for arm in ARMS}
        medians[seed] = {arm: {cell: statistics.median(values) for cell, values in cells.items()}
                         for arm, cells in all_four.items()}
        deltas[seed] = {cell: statistics.median(a - b for a, b in zip(
            all_four["context"][cell], all_four["embedding"][cell], strict=True
        )) for cell in CELLS}
        print(f"Scored all 720 queries for backbone {seed}", flush=True)
    eligible = all(row[arm]["native"] >= 32 for row in medians.values() for arm in ARMS)
    context_advances = eligible and all(
        medians[seed]["context"][cell] >= 32 and deltas[seed][cell] >= 4 for seed in BACKBONES for cell in DEEP
    )
    embedding_suffices = eligible and all(
        medians[seed]["embedding"][cell] >= 32 and deltas[seed][cell] <= 2 for seed in BACKBONES for cell in DEEP
    )
    result = dict(eligible=eligible, contextual_advantage=context_advances, embedding_suffices=embedding_suffices,
                  medians=medians, paired_median_deltas=deltas, layouts_per_cell=36, queries_per_cell=144)
    write(dest / "decision.json", result)
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    mode, *args = sys.argv[1:]
    torch.set_num_threads(2)
    if mode == "prepare":
        prepare(*map(Path, args))
    elif mode == "experiment":
        experiment(*map(Path, args))
    else:
        raise ValueError(mode)
