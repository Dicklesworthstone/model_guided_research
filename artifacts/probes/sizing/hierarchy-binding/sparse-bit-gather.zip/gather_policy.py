import itertools
import json
import os
import platform
import random
import statistics
import sys
import time
from dataclasses import dataclass
from pathlib import Path

from compile_policy import QUERIES, SAMPLES, actual, decode, digest, load_panel, make_packed
from project_policy import compile_projection, read_projected, support
from recount import parse

DEPTHS = (12, 13, 16)
COUNTS = (4, 8)
SEEDS = (121, 122)
SPARSE = ("regular", "random", "skewed")
CONTROLS = ("contiguous", "iid")


def addresses(mask):
    return tuple(bit for bit in range(16) if mask & (1 << bit))


def index_maps(mask):
    active = addresses(mask)
    assert 1 <= len(active) <= 8
    low = tuple((bit, j) for j, bit in enumerate(active) if bit < 8)
    high = tuple((bit - 8, j) for j, bit in enumerate(active) if bit >= 8)
    return tuple(bytes(sum(((word >> at) & 1) << to for at, to in bits) for word in range(256))
                 for bits in (low, high))


@dataclass(frozen=True, slots=True)
class Gather:
    mask: int
    low: bytes
    high: bytes
    values: bytes

    def lookup(self, address):
        return self.values[self.low[address & 255] | self.high[address >> 8]]

    def wire(self):
        return b"X" + self.mask.to_bytes(2, "little") + make_packed(self.values).data

    def resident(self):
        return sum(sys.getsizeof(obj) for obj in (self, self.mask, self.low, self.high, self.values))


def load_gather(wire, maps=None):
    assert wire[:1] == b"X"
    mask = int.from_bytes(wire[1:3], "little")
    size = 1 << mask.bit_count()
    payload = wire[3:]
    assert 2 <= size <= 256 and len(payload) == (size + 7) // 8
    low, high = index_maps(mask) if maps is None else maps
    values = bytes((payload[i >> 3] >> (i & 7)) & 1 for i in range(size))
    return Gather(mask, low, high, values)


def make_gather(f, relevant, maps=None):
    mask = sum(1 << bit for bit in relevant)
    values = bytes(f[sum(((i >> j) & 1) << bit for j, bit in enumerate(relevant))]
                   for i in range(1 << len(relevant)))
    wire = b"X" + mask.to_bytes(2, "little") + make_packed(values).data
    dec = load_gather(wire, maps)
    assert dec.wire() == wire and all(dec.lookup(i) == v for i, v in enumerate(f))
    return dec


def load_previous(wire):
    return read_projected(wire) if wire[:1] == b"S" else decode(wire)


def compile_scattered(f, depth):
    previous, relevant, _before, mode = compile_projection(f, depth)
    incumbent = previous["projected"]
    selected = mode
    result = load_previous(incumbent.wire())
    candidate = None
    if relevant and len(relevant) <= 8 and len(relevant) < relevant[-1] - relevant[0] + 1:
        candidate = make_gather(f, relevant)
        if len(candidate.wire()) < len(incumbent.wire()) and candidate.resident() < previous["packed"].resident():
            result = candidate
            selected = "gather"
    assert all(result.lookup(i) == v for i, v in enumerate(f))
    return dict(packed=previous["packed"], runs=previous["runs"], incumbent=incumbent, scattered=result), {
        "relevant": relevant, "before": mode, "selected": selected,
        "candidate_resident": candidate.resident() if candidate is not None else None,
    }


def positions(family, depth, count, rng):
    if family == "regular":
        return [j * (depth - 1) // (count - 1) for j in range(count)]
    if family == "skewed":
        return [*range(count - 1), depth - 1]
    if family == "random":
        return [0, *sorted(rng.sample(range(1, depth - 1), count - 2)), depth - 1]
    assert family == "contiguous"
    start = (depth - count) // 2
    return list(range(start, start + count))


def synthesize(family, depth, count, seed):
    rng = random.Random(99183 + 17 * depth + 31 * count + seed)
    if family == "iid":
        return bytes(rng.getrandbits(1) for _ in range(1 << depth)), list(range(depth))
    relevant = positions(family, depth, count, rng)
    motif = [rng.getrandbits(1) for _ in range(1 << count)]
    motif[0] = 0
    motif[3] = 1
    for bit in range(count):
        motif[1 << bit] = 1
    data = bytes(motif[sum(((i >> bit) & 1) * (2**j) for j, bit in enumerate(relevant))]
                 for i in range(1 << depth))
    return data, relevant


def grid():
    for depth in DEPTHS:
        yield from ((depth, family, count, seed) for family, count, seed in itertools.product(SPARSE, COUNTS, SEEDS))
        yield from ((depth, family, 8 if family == "contiguous" else depth, seed)
                    for family, seed in itertools.product(CONTROLS, SEEDS))


def time_lookups(f, depth, seed, decoders):
    rng = random.Random(47097 + depth * 100 + seed)
    queries = [rng.randrange(len(f)) for _ in range(QUERIES)]
    expected = sum(f[i] for i in queries)
    handlers = {name: decoder.lookup for name, decoder in decoders.items()}
    times = {name: [] for name in handlers}
    for method in handlers.values():
        assert sum(map(method, queries)) == expected
    orders = []
    for _ in range(SAMPLES):
        order = list(handlers)
        rng.shuffle(order)
        orders.append(order)
        for name in order:
            start = time.perf_counter_ns()
            observed = sum(map(handlers[name], queries))
            times[name].append((time.perf_counter_ns() - start) / QUERIES)
            assert observed == expected
    return dict(times=times, orders=orders, checksum=expected, ratios={
        name: statistics.median(a/b for a, b in zip(times["scattered"], times[name], strict=True))
        for name in ("packed", "runs", "incumbent")
    })


def bank(depth):
    aggregate, unshared, packed = [], [], []
    prior_maps = None
    for seed in range(170, 186):
        data, relevant = synthesize("regular", depth, 8, seed)
        assert support(data, depth) == relevant
        common = make_gather(data, relevant, prior_maps)
        if prior_maps is None:
            prior_maps = common.low, common.high
        assert common.low is prior_maps[0] and common.high is prior_maps[1]
        separate = make_gather(data, relevant)
        var = make_packed(data)
        assert all(var.lookup(i) == val for i, val in enumerate(data))
        aggregate.append(common)
        unshared.append(separate)
        packed.append(var)

    def memory(group):
        objects = {id(group): group}
        for dec in group:
            objects[id(dec)] = dec
            for attr in dec.__slots__:
                member = getattr(dec, attr)
                objects[id(member)] = member
        return sum(sys.getsizeof(obj) for obj in objects.values())

    assert len({id(dec.low) for dec in aggregate}) == len({id(dec.high) for dec in aggregate}) == 1
    assert len({id(dec.low) for dec in unshared}) == len({id(dec.high) for dec in unshared}) == len(aggregate)
    return dict(tables=len(aggregate), verified_slots=len(aggregate) * (1 << depth),
                packed=memory(packed), unshared=memory(unshared), shared=memory(aggregate))


def archived(input_archive):
    panel = load_panel(input_archive)
    previous = actual(panel)
    assert previous["selected"] == {"packed": 648}
    for cells in panel.values():
        for docs in cells.values():
            for doc in docs:
                query, gold, rows, _ = parse(doc)
                address = 0
                for depth, (alias, want) in enumerate(zip(query, gold, strict=True)):
                    values = bytes(a ^ k for scope, (a, k, _, _) in sorted(rows.items()) if len(scope) == depth)
                    decoders, case = compile_scattered(values, depth)
                    assert case["selected"] == "packed"
                    assert decoders["scattered"].wire() == decoders["packed"].wire()
                    child = alias ^ decoders["scattered"].lookup(address)
                    assert child == want
                    address = 2 * address + child
    return previous


def run(input_archive, output):
    core = min(os.sched_getaffinity(0))
    os.sched_setaffinity(0, {core})
    previous = archived(input_archive)
    rows = []
    for depth, family, count, seed in grid():
        f, relevant = synthesize(family, depth, count, seed)
        decoders, case = compile_scattered(f, depth)
        assert case["relevant"] == relevant
        rows.append(dict(depth=depth, family=family, count=count, seed=seed, truth=digest(f), **case,
                         wire={name: len(decoder.wire()) for name, decoder in decoders.items()},
                         resident={name: decoder.resident() for name, decoder in decoders.items()},
                         **time_lookups(f, depth, seed, decoders)))
        print(f"{depth} bits {family} {count} {seed}: {case['before']} -> {case['selected']}", flush=True)
    f, relevant = synthesize("regular", 16, 8, 121)
    changed = bytearray(f)
    omitted = next(bit for bit in range(16) if bit not in relevant)
    changed[1 << omitted] ^= 1
    assert omitted in support(changed, 16) and compile_scattered(changed, 16)[1]["selected"] != "gather"
    with output.open("x", encoding="utf-8") as out:
        json.dump(dict(core=core, host=platform.node(), machine=platform.machine(), python=platform.python_version(),
                       queries=QUERIES, samples=SAMPLES, actual=previous,
                       single_off_mask_flip_rejected=True, rows=rows, banks={d: bank(d) for d in (12, 16)}),
                  out, allow_nan=False)


if __name__ == "__main__":
    run(*map(Path, sys.argv[1:]))
