import sys
from importlib.metadata import distribution
from pathlib import Path
from zipfile import ZipFile

from nanochat import group_acquisition as solver

wheel, tables = map(Path, sys.argv[1:])
module = Path(solver.__file__).resolve()
assert module.is_relative_to(sys.prefix)
assert wheel.resolve().as_uri() in distribution("model-guided-research").read_text("direct_url.json")
with ZipFile(wheel) as archive:
    assert archive.read("nanochat/group_acquisition.py") == module.read_bytes()
roster = [f"opaque {i}" for i in range(32)]
policy = solver.compile_policy(solver.load_catalogue(tables, len(roster)))
seen = []

def endpoint(word):
    seen.append(word)
    return roster[(word.count("0") + 3 * word.count("1")) % len(roster)]

result = solver.acquire(roster, endpoint, catalogue=policy)
assert result.root == roster[0]
assert result.terminal == "unique"
assert result.transitions == {
    label: (roster[(i + 1) % 32], roster[(i + 3) % 32]) for i, label in enumerate(roster)
}
assert len(seen) == len(set(seen))
print(f"Installed compiled API recovered 64 transitions on {len(seen)} paid replies")
