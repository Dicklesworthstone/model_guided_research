"""Produce and check the single-query S5 kernel witness."""
import argparse
import itertools
import json
from copy import deepcopy
from pathlib import Path

from audit_compact import check_closure, check_transport, expect_failure

IDENTITY = tuple(range(5))
PERMUTATIONS = list(itertools.permutations(IDENTITY))
INDEX = {p: i for i, p in enumerate(PERMUTATIONS)}
SWAP01 = (1, 0, 2, 3, 4)
SWAP12 = (0, 2, 1, 3, 4)


def product(left, right):
    return tuple(left[i] for i in right)


def inverse(p):
    return tuple(p.index(i) for i in IDENTITY)


TARGET = product(product(SWAP12, SWAP01), product(SWAP12, SWAP01))


def generate():
    witnesses = {}
    for g in PERMUTATIONS[1:]:
        conjugates = {}
        for i, h in enumerate(PERMUTATIONS):
            conjugates.setdefault(product(h, product(g, inverse(h))), i)
        seen = {IDENTITY}
        frontier = [(IDENTITY, [])]
        for state, path in frontier:
            if state == TARGET:
                witnesses[str(INDEX[g])] = path
                break
            for factor, conjugator in conjugates.items():
                nxt = product(state, factor)
                if nxt not in seen:
                    seen.add(nxt)
                    frontier.append((nxt, path + [conjugator]))
        else:
            raise ValueError("The target is absent from a nontrivial normal closure")
    return witnesses


def check_normal_closure(witnesses):
    assert set(witnesses) == {str(i) for i in range(1, 120)}
    assert TARGET == (1, 2, 0, 3, 4)
    for source, conjugators in witnesses.items():
        g = PERMUTATIONS[int(source)]
        assert conjugators and all(0 <= i < 120 for i in conjugators)
        for point in IDENTITY:
            image = point
            for index in reversed(conjugators):
                h = PERMUTATIONS[index]
                image = h[g[h.index(image)]]
            assert image == TARGET[point]


def check_quotients(transports):
    counters = {name: 0 for name in ("s5", "sign", "trivial")}
    checks = 0
    for candidate, witness in sorted(transports.items()):
        equations = check_transport(witness, candidate)
        marks = witness["generators"]
        sign = [sum(a > b for j, a in enumerate(g) for b in g[j + 1:]) % 2 for g in marks]
        assert any(sign)
        u, v, *_ = witness["forward"]

        def evaluate(word):
            output = IDENTITY
            for letter in word:
                mark = marks[int(letter)]
                output = tuple(mark[x] for x in output)
            return output

        left, right = evaluate(u + v), evaluate(v + u)
        points = witness["point_order"]
        assert left != right
        for k in IDENTITY:
            assert left[right.index(points[k])] == points[TARGET[k]]

        evaluators = {
            "s5": evaluate,
            "sign": lambda word: sum(sign[int(x)] for x in word) % 2,
            "trivial": lambda _word: 0,
        }
        for name, evaluator in evaluators.items():
            assert all(evaluator(a) == evaluator(b) for a, b in equations)
            assert (evaluator(u + v) != evaluator(v + u)) is (name == "s5")
            counters[name] += 1
            checks += 1
    assert all(count == 57 for count in counters.values())
    return dict(
        witnesses=119,
        quotient_checks=checks,
        positive_only_false_accepts=counters["sign"] + counters["trivial"],
        exact_s5_accepts=counters["s5"],
        proper_quotient_rejections=counters["sign"] + counters["trivial"],
    )


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("phase", choices=("produce", "check"))
    cli.add_argument("proof", type=Path)
    cli.add_argument("--matched", type=Path)
    args = cli.parse_args()
    if args.phase == "produce":
        args.proof.write_text(json.dumps(generate(), sort_keys=True))
    else:
        witnesses = json.loads(args.proof.read_bytes())
        check_normal_closure(witnesses)
        corrupt = deepcopy(witnesses)
        corrupt["1"] = corrupt["1"][:-1]
        expect_failure(check_normal_closure, corrupt)
        matched = json.loads(args.matched.read_bytes())
        check_closure(matched["closure"])
        result = check_quotients(matched["transports"])
        result.update(max_closure_length=max(map(len, witnesses.values())), tamper_rejections=1)
        print(json.dumps(result, sort_keys=True))
