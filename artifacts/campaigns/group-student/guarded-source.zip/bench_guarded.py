"""Verify finite-catalogue safe switches against both live continuations."""

import argparse
import hashlib
import json
from functools import partial
from pathlib import Path
from time import monotonic_ns, process_time_ns
from zipfile import ZipFile

from nanochat import group_acquisition as current

ORDERS = {32: 151, 64: 503, 128: 1799}
MODES = ("square", "shortlist", "frontier", "componentwise", "priced")
GUARDS = ("componentwise", "priced")
PRICES = (16, 1, 1)
METRICS = ("calls", "zeros", "ones")


def timed(function, *args, **kwargs):
    cpu, wall = process_time_ns(), monotonic_ns()
    result = function(*args, **kwargs)
    return result, {"cpu_ns": process_time_ns() - cpu, "wall_ns": monotonic_ns() - wall}


def read_zip(archive, member):
    with ZipFile(archive) as source:
        return json.loads(source.read(member))


def decode_catalogue(archive):
    result = {}
    for row in read_zip(archive, "scored.json")["orders"]:
        shapes = []
        for profile in row["profiles"].values():
            for packed in profile["full"]:
                value = bytes.fromhex(packed)
                shapes.append(tuple(zip(value[::2], value[1::2], strict=True)))
        if len(set(shapes)) != ORDERS[row["order"]] or len(shapes) != ORDERS[row["order"]]:
            raise ValueError("Unexpected marked inventory")
        result[row["order"]] = sorted(shapes)
    if set(result) != set(ORDERS):
        raise ValueError("Incomplete marked inventory")
    return result


def labels_for(n, slot, reverse):
    multiplier, offset = (19, 7 * slot + 11) if reverse else (17, 13 * slot + 7)
    return [str((multiplier * state + offset) % n) for state in range(n)]


def fingerprint(value):
    return hashlib.sha256(json.dumps(value, separators=(",", ":")).encode()).hexdigest()


def measure_one(learner, roster, graph, labels, truth, mode):
    tape = []

    def oracle(word):
        state = 0
        for mark in word:
            state = graph[state][int(mark)]
        reply = labels[state]
        tape.append((word, reply))
        return reply

    result, cost = timed(learner, roster, oracle)
    if (result.root, result.transitions) != (labels[0], truth):
        raise ValueError(f"{mode} changed a named action")
    zeros = sum(word.count("0") for word, _ in tape)
    ones = sum(word.count("1") for word, _ in tape)
    return dict(**cost, calls=len(tape), symbols=zeros + ones, zeros=zeros, ones=ones,
                terminal=result.terminal, tape_sha=fingerprint(tape),
                word_sha=fingerprint([word for word, _ in tape]))


def witnesses(work, reverse):
    member = "replay.json" if reverse else "scored.json"
    root = work / "artifacts/campaigns/group-student"
    published = read_zip(root / "transfer-results.zip", member)["rows"]
    rows = {(row["order"], row["slot"]): row for row in published}
    if len(rows) != sum(ORDERS.values()) or len(rows) != len(published):
        raise ValueError("Missing or duplicate archived tape")
    frontier = read_zip(root / "frontier-results.zip", member)["orders"]
    if {int(n): len(cases["cases"]) for n, cases in frontier.items()} != ORDERS:
        raise ValueError("Wrong archived frontier population")
    return rows, frontier


def run(work, output, reverse):
    if not Path(current.__file__).resolve().is_relative_to(work):
        raise ValueError("The candidate comes from a different checkout")
    archive = work / "artifacts/probes/sizing/group-solver-baseline/anchor-results.zip"
    actual = decode_catalogue(archive)
    measured = {}
    for n, shapes in actual.items():
        baseline, baseline_load = timed(current.load_bundled_policy, n)
        index, catalogue_load = timed(current.load_catalogue, archive, n)
        policy, compilation = timed(current.compile_policy, index, exhaustive_frontier=True)
        if reverse:
            priced, priced_compile = timed(current.compile_guarded_policy, baseline, policy, prices=PRICES)
            componentwise, component_compile = timed(current.compile_guarded_policy, baseline, policy)
        else:
            componentwise, component_compile = timed(current.compile_guarded_policy, baseline, policy)
            priced, priced_compile = timed(current.compile_guarded_policy, baseline, policy, prices=PRICES)
        setup = {"shortlist_load": baseline_load, "frontier_load": catalogue_load, "frontier_compile": compilation,
                 "componentwise_compile": component_compile, "priced_compile": priced_compile}
        learners = {
            "square": current.acquire,
            "shortlist": partial(current.acquire, catalogue=baseline),
            "frontier": partial(current.acquire, catalogue=policy),
            "componentwise": partial(current.acquire, catalogue=componentwise),
            "priced": partial(current.acquire, catalogue=priced),
        }
        roster = list(map(str, range(n)))
        if reverse:
            roster.reverse()
        scores = []
        for slot, graph in enumerate(shapes):
            rotation = slot % len(MODES)
            order = MODES[rotation:] + MODES[:rotation]
            if reverse:
                order = tuple(reversed(order))
            labels = labels_for(n, slot, reverse)
            truth = {label: (labels[a], labels[b]) for label, (a, b) in zip(labels, graph, strict=True)}
            sampled = {mode: measure_one(learners[mode], roster, graph, labels, truth, mode) for mode in order}
            scores.append(sampled)
        measured[n] = {"setup": setup, "cases": scores}
        print(f"Order {n}: {len(scores)} exact cases scored", flush=True)
    with output.open("x", encoding="utf-8") as handle:
        json.dump({"reverse": reverse, "orders": measured}, handle, separators=(",", ":"), sort_keys=True)
        handle.write("\n")


def audit_case(row, transfer, frontier):
    anchors = [list(pair) for pair in transfer["anchors"].items()]
    expected = {
        "square": (anchors + transfer["arms"]["square"]["tape"], "square"),
        "shortlist": (anchors + transfer["arms"]["tiered"]["tape"], transfer["arms"]["tiered"]["terminal"]),
        "frontier": (frontier["tape"], frontier["terminal"]),
    }
    identities = {(fingerprint(tape), terminal): tape for tape, terminal in expected.values()}
    control_keys = {mode: (fingerprint(tape), terminal) for mode, (tape, terminal) in expected.items()}
    guard_keys = {control_keys["shortlist"], control_keys["frontier"]}
    for mode in MODES:
        paid = row[mode]
        key = paid["tape_sha"], paid["terminal"]
        if (mode in expected and key != control_keys[mode]) or (mode in GUARDS and key not in guard_keys):
            raise ValueError(f"{mode} paid a tape outside its certified continuation")
        tape = identities[key]
        counts = (len(tape), sum(word.count("0") for word, _ in tape),
                  sum(word.count("1") for word, _ in tape))
        if counts != tuple(paid[metric] for metric in METRICS) or paid["symbols"] != sum(counts[1:]):
            raise ValueError("A paid tape was miscounted")
        if paid["word_sha"] != fingerprint([word for word, _ in tape]):
            raise ValueError("A paid word sequence did not match the certified continuation")
    baseline = row["shortlist"]
    results = {}
    for mode in GUARDS:
        candidate = row[mode]
        delta = tuple(candidate[metric] - baseline[metric] for metric in METRICS)
        paid_delta = sum(change * price for change, price in zip(delta, PRICES, strict=True))
        if (mode == "componentwise" and max(delta) > 0) or (mode == "priced" and paid_delta > 0):
            raise ValueError(f"{mode} exceeded the incumbent's cost on a known action")
        results[mode] = dict(switched=candidate["tape_sha"] != baseline["tape_sha"],
                             improved=(min(delta) < 0 if mode == "componentwise" else paid_delta < 0),
                             priced_savings=-paid_delta)
    return results


def summarize(work, first_path, second_path):
    samples = [json.loads(path.read_text(encoding="utf-8")) for path in (first_path, second_path)]
    if [sample["reverse"] for sample in samples] != [False, True]:
        raise ValueError("Expected both preregistered replay directions")
    for n in ORDERS:
        first, second = (sample["orders"][str(n)]["cases"] for sample in samples)
        for forward, reverse in zip(first, second, strict=True):
            for mode in GUARDS:
                if (forward[mode]["word_sha"] != reverse[mode]["word_sha"]
                        or forward[mode]["terminal"] != reverse[mode]["terminal"]):
                    raise ValueError(f"{mode} changed under the second endpoint labeling")
    totals = []
    checked = 0
    for sample in samples:
        transfer, frontier = witnesses(work, sample["reverse"])
        per_order = {}
        for n, cells in sample["orders"].items():
            if len(cells["cases"]) != ORDERS[int(n)]:
                raise ValueError("Incomplete acquisition census")
            checked += sum(len(row) for row in cells["cases"])
            cases = [audit_case(row, transfer[int(n), slot], frontier[n]["cases"][slot]["frontier"])
                     for slot, row in enumerate(cells["cases"])]
            arms = {
                mode: {measure: sum(row[mode][measure] for row in cells["cases"])
                       for measure in ("cpu_ns", "wall_ns", "calls", "symbols", "zeros", "ones")}
                for mode in MODES
            }
            guards = {
                mode: {key: sum(result[mode][key] for result in cases)
                       for key in ("switched", "improved", "priced_savings")}
                for mode in GUARDS
            }
            per_order[n] = dict(arms=arms, setup=cells["setup"], guards=guards)
        if set(map(int, per_order)) != set(ORDERS):
            raise ValueError("An order was omitted")
        totals.append(per_order)
    priced_passed = all(row["guards"]["priced"]["improved"] > 0 for run in totals for row in run.values())
    component_passed = all(any(row["guards"]["componentwise"]["improved"] > 0 for row in run.values()) for run in totals)
    print(json.dumps({"orders": totals, "priced_prediction_passed": priced_passed,
                      "componentwise_prediction_passed": component_passed, "checked_acquisitions": checked},
                     sort_keys=True))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(required=True, dest="operation")
    score = commands.add_parser("score")
    score.add_argument("work", type=Path)
    score.add_argument("output", type=Path)
    score.add_argument("--reverse", action="store_true")
    summary = commands.add_parser("summary")
    summary.add_argument("work", type=Path)
    summary.add_argument("first", type=Path)
    summary.add_argument("second", type=Path)
    args = parser.parse_args()
    if args.operation == "score":
        run(args.work, args.output, args.reverse)
    else:
        summarize(args.work, args.first, args.second)
