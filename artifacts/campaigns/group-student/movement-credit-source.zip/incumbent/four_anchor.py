"""Acquire a rooted regular action from four paid endpoints and live queries."""

import hashlib
import json
import sys
from dataclasses import dataclass
from itertools import product
from pathlib import Path
from time import monotonic_ns, process_time_ns

import numpy as np
from catalogue_replay import read
from catalogue_study import ANCHORS, access_words, canonical, distinguishing_pair, endpoint
from label_floor import oracle

from scripts.group_rewrite_probe import teach_panel_case

ARMS = ("square", "full", "short")
SHORT = tuple("".join(chars) for n in range(2, 5) for chars in product("01", repeat=n))
INVENTORY = {60: 13, 120: 47}


@dataclass
class Catalogue:
    shapes: list
    edges: np.ndarray
    access: list[tuple[str, ...]]
    columns: dict[str, np.ndarray]


def shape_inventory(raw):
    version, smallgrp, tables = raw
    expected = [(n, i) for n, count in INVENTORY.items() for i in range(1, count + 1)]
    if (version, smallgrp) != ("4.16.1", "1.7.0") or [tuple(row[:2]) for row in tables] != expected:
        raise ValueError("The complete input catalogue must have all order-60 and order-120 groups")
    unique = {n: set() for n in INVENTORY}
    for n, _, table in tables:
        for a, b in product(range(n), repeat=2):
            shape = canonical(table, a, b)
            if len(shape) == n:
                unique[n].add(shape)
    return {n: sorted(shapes) for n, shapes in unique.items()}


def digest(shapes):
    return hashlib.sha256(json.dumps(shapes, separators=(",", ":"), sort_keys=True).encode()).hexdigest()


def prepare(shapes):
    edges = np.asarray(shapes, dtype=np.uint8)
    access = [tuple(access_words(shape)) for shape in shapes]
    wanted = {*SHORT, *(word for row in access for word in row)}
    prefixes = {word[:i] for word in wanted for i in range(1, len(word) + 1)}
    rows = np.arange(len(edges))
    columns = {"": np.zeros(len(edges), dtype=np.uint8)}
    for word in sorted(prefixes, key=lambda w: (len(w), w)):
        columns[word] = edges[rows, columns[word[:-1]], int(word[-1])]
    return Catalogue(shapes, edges, access, {word: columns[word] for word in wanted})


def states_for(index, live, word):
    if word in index.columns:
        return index.columns[word][live]
    state = np.zeros(len(live), dtype=np.uint8)
    for mark in word:
        state = index.edges[live, state, int(mark)]
    return state


def shortlist(index, live, state_names, facts, n, *, short):
    if short:
        words = {*SHORT, *index.access[int(live[0])]}
    else:
        words = {word for i in live for word in index.access[int(i)]}

    def completion(i):
        return index.shapes[i], {state: int(label) for state, label in enumerate(state_names[i]) if label >= 0}

    words.add(distinguishing_pair(completion(int(live[0])), completion(int(live[1])), set(range(n))))
    free = max(1, n - len(set(facts.values())))
    best = None
    for word in words - facts.keys():
        buckets = np.bincount(state_names[live, states_for(index, live, word)] + 1, minlength=n + 1)
        worst = max(int(buckets[0]), free * int(buckets[1:].max()))
        score = (worst, len(word), word)
        if best is None or score < best:
            best = score
    if best is None or best[0] >= len(live) * free:
        raise ValueError("No informative probe while multiple rooted actions remain")
    return best[2], best[0]


def square(initial, roster, ask):
    table, _ = teach_panel_case(initial, roster, ask, squares=True)
    root = table.maps["r0"][table.maps["r0"][initial["00"]]]
    edges = [(table.maps["R0"][str(i)], table.maps["R1"][str(i)]) for i in range(len(roster))]
    return root, edges


def acquire(index, initial, roster, ask, *, short, cap):
    n = len(roster)
    shape_count = len(index.shapes)
    live = np.arange(shape_count)
    state_names = np.full((shape_count, n), -1, dtype=np.int16)
    name_states = np.full_like(state_names, -1)
    facts = dict(initial)
    events = []

    def learn(word, label):
        nonlocal live
        name = int(label)
        state = states_for(index, live, word)
        own_name, own_state = state_names[live, state], name_states[live, name]
        keep = ((own_name == -1) | (own_name == name)) & ((own_state == -1) | (own_state == state))
        live, state = live[keep], state[keep]
        if not len(live):
            raise ValueError("The exact catalogue contains no action for the observed endpoints")
        state_names[live, state] = name
        name_states[live, name] = state

    for word in ANCHORS:
        learn(word, initial[word])
    while len(live) > 1 and len(facts) < cap:
        word, worst = shortlist(index, live, state_names, facts, n, short=short)
        answer = ask(word)
        before = len(live)
        learn(word, answer)
        facts[word] = answer
        events.append(dict(word=word, answer=answer, before=before, after=len(live), worst=worst, phase="structure"))
    if len(live) > 1:
        return square(facts, roster, ask), events, "cap"
    i = int(live[0])
    missing = [word for word in index.access[i] if state_names[i, endpoint(index.shapes[i], word)] < 0]
    for word in missing[:-1]:
        answer = ask(word)
        learn(word, answer)
        events.append(dict(word=word, answer=answer, before=1, after=1, phase="naming"))
    names = [str(int(name)) if name >= 0 else None for name in state_names[i]]
    if missing:
        (last,) = roster.difference(names)
        names[endpoint(index.shapes[i], missing[-1])] = last
    rows = {names[state]: (names[a], names[b]) for state, (a, b) in enumerate(index.shapes[i])}
    action = (names[0], [rows[str(state)] for state in range(n)])
    return action, events, "unique"


def case_inputs(tables, cohort, prior):
    for i in range(24):
        case = read(cohort / f"{i:02}.json")
        yield case["label_count"], oracle(case), i, None
    by_id = {(n, index): table for n, index, table in tables}
    for key, point in sorted(prior["control_pairs"].items()):
        n = 60 if int(key) < 3 else 120
        index, a, b = point
        table = by_id[n, index]

        def evaluate(word, table=table, marks=(a, b), size=n):
            state = 0
            for mark in word:
                state = table[state][marks[int(mark)]]
            return str((17 * state + 5) % size)

        yield n, evaluate, 24 + int(key), (index, a, b)


def measure(n, evaluate, index, initial, arm, *, cap=None):
    tape = []
    roster = set(map(str, range(n)))

    def ask(word):
        answer = evaluate(word)
        tape.append((word, answer))
        return answer

    wall_start, cpu_start = monotonic_ns(), process_time_ns()
    if arm == "square":
        action, events, terminal = square(initial, roster, ask), [], "closure"
    else:
        action, events, terminal = acquire(index, initial, roster, ask, short=arm == "short",
                                           cap=n + 24 if cap is None else cap)
    return dict(action=action, tape=tape, events=events, terminal=terminal,
                cpu_ns=process_time_ns() - cpu_start, wall_ns=monotonic_ns() - wall_start)


def run(cohort, library, prior, output, reverse):
    start_cpu, start_wall = process_time_ns(), monotonic_ns()
    raw = read(library)
    shapes = shape_inventory(raw)
    build = dict(shape_cpu_ns=process_time_ns() - start_cpu, shape_wall_ns=monotonic_ns() - start_wall)
    start_cpu, start_wall = process_time_ns(), monotonic_ns()
    indices = {n: prepare(forms) for n, forms in shapes.items()}
    build.update(index_cpu_ns=process_time_ns() - start_cpu, index_wall_ns=monotonic_ns() - start_wall)
    rows = []
    fallback = None
    for n, evaluate, case, control in case_inputs(raw[2], cohort, read(prior)):
        initial = {word: evaluate(word) for word in ANCHORS}
        shift = case % len(ARMS)
        order = ARMS[shift:] + ARMS[:shift]
        if reverse:
            order = tuple(reversed(order))
        sample = {arm: measure(n, evaluate, indices[n], initial, arm) for arm in order}
        if case == 0:
            fallback = measure(n, evaluate, indices[n], initial, "full", cap=4)
            if fallback["terminal"] != "cap":
                raise ValueError("The forced fallback control did not reach the cap")
        rows.append(dict(index=case, order=n, control=control, anchors=initial, arms=sample))
    with output.open("x", encoding="utf-8") as file:
        json.dump(dict(rows=rows, shape_digest=digest(shapes), shape_counts={n: len(v) for n, v in shapes.items()},
                       word_counts={n: len(v.columns) for n, v in indices.items()}, build=build,
                       fallback=fallback), file, sort_keys=True)
        file.write("\n")


if __name__ == "__main__":
    run(*map(Path, sys.argv[1:5]), reverse=sys.argv[5] == "reverse")
