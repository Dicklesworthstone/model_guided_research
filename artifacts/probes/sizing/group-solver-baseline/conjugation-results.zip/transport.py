"""Test reuse of a fitting model after a known, recorded oracle response."""

import json
from itertools import product
from pathlib import Path

from verify import witness_endpoint


def transpose(model, size, a, b):
    swap = list(range(size))
    swap[a], swap[b] = b, a
    return {
        "root": swap[model["root"]],
        **{key: [swap[model[key][swap[i]]] for i in range(size)] for key in ("R0", "R1", "L0", "L1")},
    }


def fit_reply(event, names, observations):
    first, second = event["first"], event["second"]
    word, answer = event["word"], event["answer"]
    first_label = witness_endpoint(first, names, observations, word)
    second_label = witness_endpoint(second, names, observations, word)
    if first_label == answer:
        return first, "first-model"
    if second_label == answer:
        return second, "second-model"
    exposed = observations.values()
    if answer not in exposed:
        for model, predicted in ((first, first_label), (second, second_label)):
            if predicted not in exposed:
                return transpose(model, len(names), names.index(predicted), names.index(answer)), "new-name-transposition"
    return None, "need-new-model"


def next_query(model, names, observations):
    unseen = set(names) - set(observations.values())
    if len(unseen) < 2:
        raise ValueError("No second naming witness for this saved case")
    for width in range(3, len(names) + 3):
        for symbols in product("01", repeat=width):
            state = model["root"]
            for a in symbols:
                state = model["R" + a][state]
            if names[state] not in unseen:
                continue
            word = "".join(symbols)
            other = min(unseen - {names[state]})
            second = transpose(model, len(names), state, names.index(other))
            endpoints = [witness_endpoint(candidate, names, observations, word) for candidate in (model, second)]
            if word in observations or endpoints[0] == endpoints[1]:
                raise ValueError("Reused model did not give a new distinguishing query")
            return {"word": word, "predictions": endpoints, "second_model": second}
    raise ValueError("Fitting model did not reach an unseen name")


def check(record):
    rows = []
    continued = None
    for case in record["cases"]:
        names = sorted(case["labels"])
        observations = dict(case["initial"])
        events = case["arms"]["conjugation"]["events"]
        for index, event in enumerate(events):
            if "word" not in event:
                continue
            transported, method = fit_reply(event, names, observations)
            observations[event["word"]] = event["answer"]
            if transported is not None:
                if witness_endpoint(transported, names, observations, event["word"]) != event["answer"]:
                    raise ValueError("Transported witness differs from the observed response")
            rows.append({"case": case["case"], "word": event["word"], "method": method})
            if index + 1 < len(events) and events[index + 1]["base"]["status"] == "unknown":
                if transported is None or continued is not None:
                    raise ValueError("Expected one transportable base exhaustion after a paid answer")
                continued = {
                    "case": case["case"], "reused_model": transported,
                    "after": event["word"], "continued": next_query(transported, names, observations),
                }
    if continued is None:
        raise ValueError("The paid-then-exhausted case is missing")
    return {
        "rows": rows,
        "any_model_reused": sum(row["method"] != "need-new-model" for row in rows),
        "paid_calls": len(rows),
        "saved_case": continued,
        "extra_solver_checks": 0,
        "extra_oracle_reads": 0,
    }


if __name__ == "__main__":
    raw = json.loads(Path("scored.json").read_text(encoding="utf-8"))
    print(json.dumps(check(raw), indent=2))
