import hashlib
import json
import math
import sys
from collections import Counter
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


REGISTRATION = "2e2b9a06df276256ad9c3bfffee40ab8ab148f40"
LOCK = "b618f8603a3ae2a2c9db0e1785f2ee9017037db2f4167ad619c9eae37b1f13ed"
PANEL = "b84376c593dc5f185bed53d9ebe17c3cc3246956196c51df52fa6bb8dab08eb4"
CELLS = {"native": (2, 104), "reordered": (2, 104), "mixed2": (2, 110),
         "depth3": (3, 114), "reordered3": (3, 114)}
SEEDS = ("101", "102", "103")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def argmax(scores, candidates):
    assert candidates and all(math.isfinite(scores[i]) for i in candidates)
    return max(candidates, key=scores.__getitem__)


def recount(read, names, before):
    frozen = read("replay/frozen.sha256")
    assert sha(frozen) == LOCK and sha(read("panel.json")) == PANEL
    for line in frozen.decode().splitlines():
        expected, name = line.split()
        assert sha(read(name if name == "panel.json" else f"replay/{name}")) == expected
    panel = json.loads(read("panel.json"))
    scores = json.loads(read("scores.json"))
    trunk = json.loads(before.read("seed-32/runs/augmented/summary.json"))
    assert scores["trunk_weights_sha256"] == trunk["weights_sha256"]
    assert scores["incumbent_head_sha256"] == trunk["location_head_sha256"]
    assert scores["panel_sha256"] == PANEL and scores["fit_rows"] == 1536 and scores["head_seeds"] == list(map(int, SEEDS))
    assert panel["tokenizer_sha256"] == sha(before.read("tokenizer.json"))
    blocks = panel["blocks"]
    assert len(blocks) == 36 and Counter(block["seed"] for block in blocks) == {91: 12, 92: 12, 93: 12}
    assert len({block[cell]["text"] for block in blocks for cell in CELLS}) == 144
    algorithms = ("incumbent", "token_oracle", *(f"{arm}_{seed}" for seed in SEEDS for arm in ("hop", "flat", "sum")))
    counters = {name: {cell: Counter() for cell in CELLS} for name in algorithms}
    hop_counters = {seed: {cell: Counter() for cell in CELLS} for seed in SEEDS}
    for block, raw in zip(blocks, scores["logits"], strict=True):
        assert set(raw) == set(CELLS)
        for cell, (depth, prompt_length) in CELLS.items():
            case, results = block[cell], raw[cell]
            leaves = list(map(tuple, case["leaves"]))
            edges = list(map(tuple, case["edge_paths"]))
            parents = {}
            for i, edge in enumerate(edges):
                parents.setdefault(edge[:-1], []).append(i)
            assert len(leaves) == len(case["leaf_positions"]) == 9
            assert len(edges) == len(set(edges)) == len(case["edge_positions"])
            assert len(case["rows"]) == len(results["incumbent"]) == 4
            assert len({tuple(row["route"]) for row in case["rows"]}) == 4
            correct = {name: [] for name in algorithms}
            for i, row in enumerate(case["rows"]):
                ids, route, expected = row["ids"], tuple(row["route"]), row["expected"]
                assert len(ids) == prompt_length and len(route) == len(row["query_keys"]) == depth
                assert leaves[expected] == route and len(results["incumbent"][i]) == 9
                assert case["text"] in row["document"] and row["document"].split(" PATH ")[1].split(" OUT ")[0].split() == list(route)
                incumbent = argmax(results["incumbent"][i], range(9))
                correct["incumbent"].append(incumbent == expected)

                oracle = ()
                for j in row["query_keys"]:
                    matches = [index for index in parents[oracle] if ids[case["edge_positions"][index]] == ids[j]]
                    assert len(matches) == 1
                    oracle = edges[matches[0]]
                correct["token_oracle"].append(oracle == route)

                for seed in SEEDS:
                    evidence = results[seed]
                    assert len(evidence["edge_scores"]) == len(evidence["flat_scores"]) == 4
                    matrix = evidence["edge_scores"][i]
                    assert len(evidence["flat_scores"][i]) == 9 and len(matrix) == depth
                    assert all(len(row) == len(edges) and all(map(math.isfinite, row)) for row in matrix)
                    flat = argmax(evidence["flat_scores"][i], range(9))
                    correct[f"flat_{seed}"].append(flat == expected)
                    current = ()
                    for level, logits in enumerate(matrix):
                        if current in parents:
                            current = edges[argmax(logits, parents[current])]
                        else:
                            break
                    correct[f"hop_{seed}"].append(current == route)
                    for level, logits in enumerate(matrix):
                        gold_parent = route[:level]
                        picked = edges[argmax(logits, parents[gold_parent])]
                        hop_counters[seed][cell][f"gold_parent_hop_{level + 1}_correct"] += picked == route[:level + 1]
                    hop_counters[seed][cell]["wrong_final_parent"] += current[:-1] != route[:-1]
                    eligible = [leaf for leaf in leaves if len(leaf) == depth]
                    summed = [sum(matrix[level][edges.index(leaf[:level+1])] for level in range(depth))
                              for leaf in eligible]
                    correct[f"sum_{seed}"].append(eligible[argmax(summed, range(len(eligible)))] == route)
            for name, events in correct.items():
                assert len(events) == 4
                counters[name][cell]["all_four"] += all(events)
                counters[name][cell]["individual_correct"] += sum(events)
    counts = {name: {cell: dict(counter) for cell, counter in cells.items()} for name, cells in counters.items()}
    hops = {seed: {cell: dict(counter) for cell, counter in cells.items()} for seed, cells in hop_counters.items()}
    oracle_ok = all(score["all_four"] == 36 for score in counts["token_oracle"].values())
    eligible = oracle_ok and counts["incumbent"]["native"]["all_four"] >= 27
    criteria = {
        seed: dict(all_local_cells_27=all(counts[f"hop_{seed}"][cell]["all_four"] >= 27 for cell in CELLS),
                   gain_on_both_depth3_cells=all(
                       counts[f"hop_{seed}"][cell]["all_four"] >= max(
                           counts[f"flat_{seed}"][cell]["all_four"], counts["incumbent"][cell]["all_four"]
                       ) + 9 for cell in ("depth3", "reordered3")))
        for seed in SEEDS
    }
    passed = eligible and all(all(control.values()) for control in criteria.values())
    receipts = sorted(name for name in names if name.endswith("/receipt.json"))
    assert len(receipts) == 2
    assert {name.split("/")[1] for name in receipts} == {"hierarchy-one-hop-prepare", "hierarchy-one-hop-fit-evaluate"}
    for path in receipts:
        item = json.loads(read(path))
        assert item["status"] == "passed" and len(item["checks"]) == 1
        check = item["checks"][0]
        assert sha(read(path.removesuffix("receipt.json") + Path(check["log_path"]).name)) == check["log_sha256"]
    return dict(registration=REGISTRATION, layouts_per_cell=36, queries_per_cell=144, eligible=eligible,
                fixed_gate_passed=passed, counts=counts, hop_diagnostics=hops, criteria=criteria,
                receipt_ids=[path.split("/")[-2] for path in receipts])


def bundle(root, lineage, dest):
    frozen = root / "frozen.sha256"
    files = {"replay/frozen.sha256": frozen, "replay/hop_archive.py": root / "hop_archive.py",
             "scores.json": root / "scores.json"}
    for line in frozen.read_text().splitlines():
        _, name = line.split()
        files[name if name == "panel.json" else f"replay/{name}"] = root / name
    for receipt in (root / "receipts").glob("*/*/receipt.json"):
        for name in ("receipt.json", "check-1.log", "checks-config.yaml"):
            path = receipt.with_name(name)
            files[str(path.relative_to(root))] = path
    with ZipFile(lineage) as before:
        data = recount(lambda name: files[name].read_bytes(), files, before)
    with ZipFile(dest, "x", compression=ZIP_DEFLATED) as archive:
        for name, path in files.items():
            archive.write(path, name)
        archive.writestr("decision.json", json.dumps(data, indent=2) + "\n")


def verify(dest, lineage):
    with ZipFile(dest) as archive, ZipFile(lineage) as before:
        assert archive.testzip() is None
        names = archive.namelist()
        assert len(names) == len(set(names))
        assert not any(name.endswith((".pt", ".parquet", ".safetensors")) for name in names)
        data = recount(archive.read, names, before)
        assert data == json.loads(archive.read("decision.json"))
    print(json.dumps(data))


if __name__ == "__main__":
    command, *paths = sys.argv[1:]
    {"bundle": bundle, "verify": verify}[command](*map(Path, paths))
