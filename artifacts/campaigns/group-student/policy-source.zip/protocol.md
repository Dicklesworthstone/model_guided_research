# Compiled shortest-tier acquisition

Bead `model_guided_research-qvx5`. This freezes the reusable policy
comparison before timing any arm.

The fitting catalogue rows and the set of paid words depend only on the
partition of observations by label equality. Renaming permutes known-label
bucket counts and preserves the unnamed bucket, unused-roster size and score
ordering. The extra disagreement search completes both fits from the same
sorted unused roster. Two unobserved endpoints have equal completed labels
precisely when their positions in the two lists of unmapped states agree.
A known label and an unused label never agree. Thus the breadth-first test
for disagreement depends on the equality partition as well. The ordered
shortlist and its deterministic tie break remain fixed. Once the shape is
unique, shortest access and last-name inference use the same named states.

The compiler starts from the already audited full marked inventory and
splits surviving shapes by each possible reply class. A reply either equals
one previously seen label, identified by its first occurrence, or supplies a
new name. Children have disjoint shape rows. A single naming matrix can be
reused across the disjoint branches. Each leaf records the chosen shape and
how to map the observed names onto its states, or the existing cap and
square-closure continuation. The deployed compiler takes no oracle replies
and no recorded tapes as input.

## Matched study

- Execute over every one of the 151, 503 and 1,799 distinct marked actions at
  orders 32, 64 and 128. Use the published direct shape archive as oracle truth
  and the two raw transfer runs as independent fixed tape and action witnesses.
- Compare live installed-release square closure, live installed-release dynamic
  shortest-tier selection, and the current compiled traversal. Capture the
  exact source of the two released arms at `c65736e`. All arms execute the
  same callback and validation contract. This study measures host work on
  an immediate software oracle. Hardware commands and GAP export are outside
  the benchmark.
- Run both archived deterministic renamings and hash seeds 0 and 991. The
  second run also reverses the supplied label roster order. Rotate arm order
  by case and reverse it in the replay. Report all paid words including the
  four initial observations. Require exact equality of both baselines with
  their archived words, replies and named tables and the compiled arm with
  the original shortest-tier on every case in both runs. Validate the exact
  named table against the independent rooted shape too. The diagnostics tests
  exercise the new API and reject an unsupported equality pattern.
- Time the whole invocation of each online learner with process CPU and wall
  clocks. Time each catalogue loading and compilation separately per order.
  Price reuse with the observed preparation divided by the measured mean
  online savings under the same equally weighted case mix. State the cold
  aggregate as well. Treat case mix and host timing as finite scope.
- The warm prediction requires at least 2× lower aggregate online CPU than
  dynamic shortest-tier at every order in each run, and strictly lower
  aggregate online CPU than live square closure at every order in each run.
  Report both comparisons in all six cells and keep cold cost as a
  countermetric. Stop after two full runs with no adaptive tuning. DSR is an
  execution and validity gate; the reported performance predicate can fail.
  This finite exhaustive timing experiment has no learned accuracy floor,
  seed-power calculation or mechanism claim.
