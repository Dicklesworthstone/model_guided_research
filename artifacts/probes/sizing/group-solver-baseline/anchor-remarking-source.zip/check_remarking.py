"""Check which four-distinct profiles admit an exact short re-marking."""

import argparse
import json
from pathlib import Path

from catalogue_study import canonical, endpoint


def decode(item):
    edges = bytes.fromhex(item)
    return tuple(zip(edges[::2], edges[1::2], strict=True))


def remark(action, keep):
    """Use (a, ab) or (b, ba), ordered by the chosen first mark."""
    return canonical([(row[keep], action[row[keep]][1 - keep]) for row in action], 0, 1)


def restore(action, keep):
    inverse = {row[0]: state for state, row in enumerate(action)}
    restored = []
    for state, row in enumerate(action):
        other = action[inverse[state]][1]
        restored.append((row[0], other) if keep == 0 else (other, row[0]))
    return canonical(restored, 0, 1)


def inspect(row):
    distinct = [decode(shape) for shape in row["profiles"]["0123"]["full"]]
    expected = {decode(shape) for shape in row["profiles"]["0120"]["full"]}
    maps = ({}, {})
    for action in distinct:
        for keep, (initial, probe) in enumerate((("00", "0101"), ("11", "1010"))):
            if endpoint(action, initial) == endpoint(action, probe):
                transformed = remark(action, keep)
                if restore(transformed, keep) != action or transformed in maps[keep]:
                    raise ValueError("Re-marking is not injective on the positive class")
                maps[keep][transformed] = action
    overlap = set(maps[0].values()) & set(maps[1].values())
    if overlap or any(set(mapping) != expected for mapping in maps):
        raise ValueError("The two re-marking classes do not partition the predicted successes")
    return {
        "order": row["order"], "four_distinct": len(distinct), "equal_squares": len(expected),
        "probe_0101_hits": len(maps[0]), "probe_1010_hits": len(maps[1]), "either_hits": sum(map(len, maps)),
    }


def read(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        raise ValueError(f"Invalid finite input {path}") from error


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("scored", type=Path)
    parser.add_argument("replay", type=Path)
    args = parser.parse_args()
    first, second = ([inspect(row) for row in read(path)["orders"]] for path in (args.scored, args.replay))
    if first != second:
        raise ValueError("Structural probe counts changed on replay")
    print(json.dumps({"exact_replay": True, "rows": first}, indent=2))


if __name__ == "__main__":
    main()
