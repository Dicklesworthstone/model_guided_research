# Small language-modeling comparison on real Python files

The placebo sizing experiment reached its declared stop before any
mechanism runs. This separately frozen comparison targets the same
coordinate question on real data. It does not reopen the placebo run.
Use Python 3.13.0 standard-library source and the exact file lists in
the experiment. Record per-file hashes. Split by file. Both validation
and test come from modules never used in that cohort's training.
Sizing and comparison have disjoint file lists. Sample fixed nonoverlapping
49-byte windows within each file and discard exact cross-split repetitions.

The common outcome is mean held-out next-byte NLL over 48 scored targets
per window. Sizing uses model seeds 91 through 93 and standard attention
at 192, 384 and 768 steps. Select the first rung where all three validation
losses beat a train-only smoothed unigram predictor by 0.02 nats. If none
passes, stop. After selecting a rung, use seeds 300 through 307 and the
new, disjoint comparison corpus. No seed extension or retuning.

The five arms, common initialization procedure, perturbation controls,
training batch, model size, AdamW recipe and time accounting are
unchanged from the preceding frozen protocol. The primary contrast
is log gain minus linear gain at matched effective initialization.
Use a 95% paired Student interval, 0.10 nats as the minimum worthwhile
effect, and 0.07 nats as the planning standard deviation. Require all
eight fresh standard models to clear the same unigram margin. Treat
all other contrasts and the later held-out modules as descriptive.
Report CPU cost along with matched tokens and parameter counts.

The comparison measures a small, fixed-recipe byte model and does not
qualify an optimizer, prove a scaling law, or adjudicate the historical
placebo claim. Results are retained in sizing quarantine.
