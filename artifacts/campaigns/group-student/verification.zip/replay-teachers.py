"""Replay acquisitions from recorded paid labels and score the recovered actions."""
import json
import sys
from pathlib import Path
from scripts.group_rewrite_probe import teach_panel_case

root = Path(sys.argv[1])
evaluated = 0
charged = 0
for path in sorted(root.glob("*.json")):
    case = json.loads(path.read_bytes())
    initial = dict(case["arms"]["short_only"]["rows"][:508])
    tape = iter(case["arms"]["active"]["paid"])
    def ask(word):
        paid, target = next(tape)
        assert paid == word
        return target
    table, queries = teach_panel_case(initial, set(case["opaque_names"]), ask, squares=True)
    assert next(tape, None) is None
    charged += len(queries)
    for word, target, _ in case["primary"]:
        assert table.read_right(initial, word) == target
        evaluated += 1
assert evaluated == 2304 and charged == 184
print(f"Replayed all {charged} paid labels and all {evaluated} blind held-out endpoints from acquired tables.")
