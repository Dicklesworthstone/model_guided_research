import hashlib
import json
import math
import statistics
import sys
from collections import Counter, defaultdict
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import discovery as trial
import evidence
import posterior as post
from address_fixtures import sha_json
from posterior_replay import independent_catalog, oracle_fixture

SOURCE = "713fdd468ddc4187351b1e1cce27034bc1905a83"
LOCK = "52ca5849d73022e4ab33b5210ee2f0a0498658699ee01b2b4f44c84f10d5af56"
SHADOW = "03c66dc47b91756fd082ed775d56f9ed741b7b434f887fdd4a1c46a2a1471793"
FILES = ("address_fixtures.py", "topology.py", "posterior.py", "posterior_replay.py", "evidence.py",
         "mixture.py", "discovery.py", "discovery.yaml", "frozen.sha256", "protocol.txt", "discovery-raw.json",
         "discovery_replay.py", "argument.md", "replay.yaml")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def verify_receipt(read, files):
    path, = (name for name in files if name.endswith("/receipt.json"))
    receipt = json.loads(read(path))
    assert receipt["tool"] == "hierarchy-unknown-shape-laws" and receipt["status"] == "passed"
    assert receipt["passed"] == receipt["executed"] == receipt["total"] == 1
    assert not receipt["dry_run"] and not receipt["skipped"]
    check, = receipt["checks"]
    assert check["passed"] and check["executed"] and check["exit_code"] == 0
    log = Path(path).with_name(Path(check["log_path"]).name).as_posix()
    assert digest(read(log)) == check["log_sha256"]
    config = Path(path).with_name("checks-config.yaml").as_posix()
    assert read(config) == read("discovery.yaml")
    assert digest(read(config)) == receipt["config_sha256"] == receipt["config_sha256_after"]
    return Path(path).parent.name


def linear_normalizers():
    totals = []
    for beta in trial.BETA:
        r = [1.0]
        for m in range(1, post.INTERNAL + 1):
            r.append(m ** -beta * math.fsum(r[i] * r[m - 1 - i] for i in range(m)))
        assert math.isclose(math.log(r[-1]), evidence.log_partition(beta)[-1], abs_tol=1e-12, rel_tol=0)
        totals.append(r[-1])
    return totals


def direct_tables(versions, totals):
    result = []
    for beta, z in zip(trial.BETA, totals, strict=True):
        by_leaf = defaultdict(list)
        for leaf, hooks, count in versions:
            by_leaf[leaf].append(count / (hooks ** beta * z))
        result.append({key: math.fsum(weights) for key, weights in by_leaf.items()})
    return result


def independent_evidence(data, normalizers):
    docs = []
    for row in data:
        masses = [math.fsum(pdf.values()) for pdf in direct_tables(row["versions"], normalizers)]
        scale = max(masses)
        docs.append([value / scale for value in masses])
    return docs


def independent_score(masses, model):
    return statistics.mean(math.log(math.fsum(doc[index] * (weight / 20.) for index, weight in model))
                           for doc in masses)


def verify_models(train, select, fits, norm):
    obs = independent_evidence(train, norm)
    val = independent_evidence(select, norm)
    for kind, target in (("single", 9), ("pair", 324)):
        grid = fits["fit"][kind + "_grid"]
        assert len(grid) == len({model for model, _ in grid}) == target
        for model, likelihood in grid:
            check = independent_score(obs, model)
            assert math.isclose(check, likelihood, rel_tol=0, abs_tol=1e-12)
        assert fits["fit"][kind] == max(grid, key=lambda item: item[1])[0]
    fixed = fits["fit"]["fixed_grid"]
    assert len(fixed) == 171
    for weights, likelihood in fixed:
        model = tuple(zip((0, 4, 8), weights, strict=True))
        assert math.isclose(independent_score(obs, model), likelihood, abs_tol=1e-12, rel_tol=0)
    first, second = (independent_score(val, fits["fit"][model]) for model in ("single", "pair"))
    assert math.isclose(second - first, fits["val_gain"], abs_tol=1e-12, rel_tol=0)
    assert ("pair" if second - first >= .05 else "single") == fits["selected"]


def check_prediction(row, model, normalizers):
    tables = direct_tables(row["versions"], normalizers)
    masses = [math.fsum(pdf.values()) for pdf in tables]
    actual = trial.posterior(row["versions"], trial.relative_evidence(row["versions"]), model)
    denominator = math.fsum(masses[index] * count for index, count in model)
    assert math.isclose(math.fsum(actual.values()), 1, abs_tol=1e-14, rel_tol=0)
    for leaf, result in actual.items():
        reference = math.fsum(tables[index][leaf] * count for index, count in model) / denominator
        assert math.isclose(reference, result, abs_tol=1e-13, rel_tol=0)


def transport(model, truth):
    # Integrate the absolute CDF gap over adjacent grid cells.
    m, t = dict(model), dict(truth)
    difference = 0
    total = 0
    for index in range(len(trial.BETA) - 1):
        difference += m.get(index, 0) - t.get(index, 0)
        total += abs(difference)
    return total / 160


def describe(model):
    return [{"beta": trial.BETA[i], "weight": w / 20} for i, w in model]


def replay(read, files, full_audit=False):
    lock = read("frozen.sha256")
    assert digest(lock) == LOCK
    for line in lock.decode().splitlines():
        sha, path = line.split()
        assert digest(read(path)) == sha
    assert digest(read("posterior_replay.py")) == SHADOW
    normalizers = linear_normalizers()
    raw = json.loads(read("discovery-raw.json"))
    rows = raw["rows"]
    assert len(rows) == len({row["fixture"] for row in rows}) == 312
    groups = defaultdict(list)
    audit_cases = []
    for row, case in zip(rows, trial.fresh(), strict=True):
        seed, regime, phase, index, records, root, query, gold, latent, namespace = case
        assert (row["seed"], row["regime"], row["phase"], row["index"]) == (seed, regime, phase, index)
        assert row["fixture"] == sha_json([records, root, query]) and (row["target"], row["family"]) == (gold, latent)
        oracle_fixture(records, root, query, gold, namespace)
        assert row["bank_maps"] == 40320 and 1 <= sum(count for _, _, count in row["versions"]) <= row["rooted_maps"] <= 40320
        assert gold in {key for key, _, _ in row["versions"]}
        assert all(hooks > 0 and count > 0 and not records[key] for key, hooks, count in row["versions"])
        if phase == "test" and index == 0:
            audit_cases.append([seed, regime])
            if full_audit:
                ref = independent_catalog(records, root, query)
                assert all(row[key] == value for key, value in ref.items())
        groups[seed, regime, phase].append(row)
    assert len(audit_cases) == 6
    fits = trial.compare(rows)
    assert json.loads(json.dumps(fits)) == raw["fits"]
    pooled = {}
    gates = {}
    for regime, truth in trial.REGIMES:
        results = []
        for seed in trial.SEEDS:
            train, selection, test = (groups[seed, regime, phase] for phase, _ in trial.PHASES)
            report = fits[seed][regime]
            verify_models(train, selection, report, normalizers)
            chosen = report["fit"][report["selected"]]
            for row in test:
                check_prediction(row, chosen, normalizers)
                check_prediction(row, truth, normalizers)
            results.append(dict(seed=seed, validation_gain=report["val_gain"], selected=report["selected"],
                                selected_law=describe(chosen), candidate_pair=describe(report["fit"]["pair"]),
                                fixed_law=describe(report["fit"]["fixed"]),
                                w1=transport(chosen, truth), scores=report["scores"]))
        scores = {arm: {key: sum(row["scores"][arm][key] for row in results) if key == "correct"
                        else statistics.mean(row["scores"][arm][key] for row in results)
                        for key in results[0]["scores"][arm]} for arm in trial.ARMS}
        target = "pair" if len(truth) == 2 else "single"
        correct = sum(row["selected"] == target for row in results)
        w1 = statistics.mean(row["w1"] for row in results)
        test_origins = Counter(row["family"] for seed in trial.SEEDS for row in groups[seed, regime, "test"])
        pooled[regime] = dict(pairs_selected=sum(row["selected"] == "pair" for row in results),
                              truth=describe(truth), cases=48, w1=w1, scores=scores, fits=results,
                              test_origins={str(trial.BETA[index]): count for index, count in sorted(test_origins.items())})
        gates[regime] = dict(order=correct >= 2, support_error=w1 <= .2,
                             answer_oracle=scores["selected"]["nll"] <= scores["oracle"]["nll"] + .2)
    return dict(source=SOURCE, receipt=verify_receipt(read, files), train=144, selection=72, test=96,
                audit_cases=audit_cases, pooled=pooled, gates=gates, pass_all=all(all(v.values()) for v in gates.values()))


def verify(bundle):
    with ZipFile(bundle) as archive:
        names = archive.namelist()
        assert archive.testzip() is None and len(names) == len(set(names))
        result = replay(archive.read, names, full_audit=True)
        assert result == json.loads(archive.read("decision.json"))
    print(json.dumps(result))


def build(root, bundle):
    files = {name: root / name for name in FILES}
    receipt, = (root / "receipts").glob("*/*/receipt.json")
    for name in ("receipt.json", "check-1.log", "checks-config.yaml"):
        path = receipt.with_name(name)
        files[path.relative_to(root).as_posix()] = path
    result = replay(lambda name: files[name].read_bytes(), files.keys())
    with ZipFile(bundle, "x", compression=ZIP_DEFLATED) as archive:
        for name, path in files.items():
            archive.write(path, name)
        archive.writestr("decision.json", json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    action, *paths = sys.argv[1:]
    {"build": build, "verify": verify}[action](*map(Path, paths))
