# Exact reach of one extra endpoint query

This is a structural diagnostic over the already frozen shape sets.
The two tests were specified without inspecting the counts of the
four-distinct bucket. The diagnostic uses the two saved executions
and does not alter the original decision or simulate a new learner.

If the four original labels are distinct, query `0101` and compare
with the paid answer to `00`. Equality says that marks (a,ab) have
equal squares. They generate the same group because b=a⁻¹(ab).
Since the group is nonabelian, this is an instance of the inversion
constructor. Given the right actions A and H for a and ab, recover
the original b action by applying A⁻¹ followed by H. The mirrored
test uses `1010` versus `11` and the marks (b,ba).

For the first positive test, the original b is the cyclic element
r of the inversion parametrization. The old squares can coincide
only when d=2 and c=2 modulo m, because the image of a in the cyclic
quotient has order d. With m≥3 and 2c=0 modulo m this forces m=4,
c=2 and n=8. Thus at orders 32, 64 and 128, every inversion shape
is the re-marking of one four-distinct shape. The two positive
classes are disjoint there. If a and b invert each other, then
(ab)²=a² and (ba)²=b², but a² is central and ab and ba are
conjugate, so a²=b².

Independently scan the exact frozen four-distinct graphs for each
word equality. Require each positive class to map bijectively
onto the equal-squares class and restore every passing graph
exactly. Require no overlap, identical counts on replay, and
publish the whole denominator. Each successful test would cost
one additional endpoint query, but coverage among distinct
marked graphs gives no frequency estimate for real hardware.
