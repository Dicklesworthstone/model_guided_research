# Extend the acquisition lower bound through six replies

The first two depths ran within 3,556 work units per class and depth.
Keep their evidence. Evaluate every remaining depth through six using
the original prices, anchors, actions, and GBS feasible upper bounds.
Charge the same diagnostic cap of 300,000 per anchor class and depth.
Report every partial or exhausted depth. These are separate lower-bound
calculations, not additional budget for the original exact planner.

The relaxation lets a learner learn the exact shape for free after a
fixed number of informative post-anchor queries, or earlier if those
queries already identify the shape. For subsequent naming a paid query
reveals at most one label. The roster determines the last label and
the cheapest access words minimize all other costs. Every feasible
policy in the actual oracle is also feasible within this relaxation.
Increasing the number of required real replies yields a nondecreasing
lower bound. If any depth attains the cost of a verified feasible
policy, the optimum for that anchor class is certified.
