"""Identify rooted regular actions using only short endpoint observations."""

import argparse
import json
import time
from collections import defaultdict
from itertools import product
from pathlib import Path

from scripts.group_rewrite_probe import Actions, infer_actions, teach_panel_case

WORDS = tuple("".join(symbols) for n in range(2, 9) for symbols in product("01", repeat=n))
SPLITS = ("primary", "secondary")

type Labelled = tuple[str, tuple[tuple[str, str], ...]]
type Table = list[list[int]]


def read(path):
    return json.loads(path.read_bytes())


def signature(values) -> tuple[int, ...]:
    first = {}
    return tuple(first.setdefault(value, len(first)) for value in values)


def reach(table: Table, a: int, b: int) -> int:
    reached = [0]
    seen = {0}
    for state in reached:
        for target in (table[state][a], table[state][b]):
            if target not in seen:
                seen.add(target)
                reached.append(target)
    return len(reached)


def named_action(table: Table, a: int, b: int, names: dict[int, str]) -> Labelled | None:
    roster = tuple(map(str, range(len(table))))
    unseen = set(range(len(table))).difference(names)
    if len(unseen) > 1:
        return None
    if unseen:
        (state,) = unseen
        (name,) = set(roster).difference(names.values())
        names[state] = name
    successors = {name: (names[table[state][a]], names[table[state][b]]) for state, name in names.items()}
    return names[0], tuple(successors[name] for name in roster)


def catalogue_matches(tables, observations):
    short: dict[tuple[int, tuple[int, ...]], dict[tuple[int, ...], list[int]]] = defaultdict(lambda: defaultdict(list))
    labels = {i: tuple(observed[word] for word in WORDS) for i, (_, observed) in observations.items()}
    for i, (order, _) in observations.items():
        pattern = signature(labels[i])
        short[order, pattern[:12]][pattern].append(i)
    matches: dict[int, list[tuple[int, int, int]]] = {i: [] for i in observations}
    actions: dict[int, set[Labelled]] = {i: set() for i in observations}
    stats = []
    for n, index, table in tables:
        surviving_prefix = 0
        generating = 0
        for a, b in product(range(n), repeat=2):
            second = (table[a][a], table[a][b], table[b][a], table[b][b])
            third = [value for state in second for value in (table[state][a], table[state][b])]
            profile = short.get((n, signature([*second, *third])))
            if profile is None:
                continue
            surviving_prefix += 1
            layer = third
            endpoints = [*second, *third]
            for _ in range(4, 9):
                layer = [value for state in layer for value in (table[state][a], table[state][b])]
                endpoints.extend(layer)
            fitting = profile.get(signature(endpoints))
            if fitting is None or reach(table, a, b) != n:
                continue
            generating += 1
            for i in fitting:
                matches[i].append((index, a, b))
                candidate = named_action(table, a, b, dict(zip(endpoints, labels[i], strict=True)))
                if candidate is not None:
                    actions[i].add(candidate)
        stats.append(dict(order=n, index=index, ordered_pairs=n * n, prefix=surviving_prefix, fitting_generating=generating))
    return matches, actions, stats


def labelled_prediction(model: Labelled, word: str) -> str:
    name, rows = model
    for mark in word:
        name = rows[int(name)][int(mark)]
    return name


def square_closure(initial, order, tape, requests):
    roster = set(map(str, range(order)))
    started = time.process_time_ns()
    partial = Actions(roster)
    infer_actions(partial, initial, squares=True)
    predictions = {
        split: [partial.read_right(initial, word) for word in words] for split, words in requests.items()
    }
    partial_edges = sum(len(partial.maps["R" + mark]) for mark in "01")
    partial_ns = time.process_time_ns() - started

    expected = iter(tape)

    def ask(word):
        request, label = next(expected)
        if word != request:
            raise ValueError(f"Frozen square-closure request {request} changed to {word}")
        return label

    started = time.process_time_ns()
    full, paid = teach_panel_case(initial, roster, ask, squares=True)
    full_ns = time.process_time_ns() - started
    if next(expected, None) is not None:
        raise ValueError("Square closure skipped a request from its frozen tape")
    root = full.maps["r0"][full.maps["r0"][initial["00"]]]
    rows = tuple(tuple(full.maps["R" + mark][str(i)] for mark in "01") for i in range(order))
    return dict(
        partial_edges=partial_edges,
        partial_answers=predictions,
        partial_cpu_ns=partial_ns,
        paid=paid,
        full_cpu_ns=full_ns,
        action=(root, rows),
    )


def run(cohort: Path, library: Path, output: Path) -> None:
    gap, smallgrp, tables = read(library)
    cases = [read(cohort / f"{i:02}.json") for i in range(24)]
    observations = {}
    requests = {}
    for i, case in enumerate(cases):
        order = case["label_count"]
        # Duplicated rows used to equalize SGD steps add no exact observations.
        observed = dict(case["arms"]["short_only"]["rows"])
        if set(observed) != set(WORDS) or not set(observed.values()) <= set(map(str, range(order))):
            raise ValueError("Wrong short observations")
        observations[i] = (order, observed)
        requests[i] = {split: [word for word, _, _ in case[split]] for split in SPLITS}
    order, first = observations[0]
    contradictory = dict(first, **{"01": first["00"]})
    if contradictory["10"] == contradictory["00"]:
        raise ValueError("The equality contradiction does not hold for this control")
    observations[-1] = (order, contradictory)

    started = time.process_time_ns()
    matches, actions, stats = catalogue_matches(tables, observations)
    build_ns = time.process_time_ns() - started
    # Two equally legal opaque names remain even when the group and marks are known.
    control_index, a, b = matches[0][0]
    control_table = next(table for n, index, table in tables if n == order and index == control_index)
    ambiguous = named_action(
        control_table, a, b, {state: str(state) for state in range(order - 2)}
    )
    if ambiguous is not None:
        raise ValueError("Named an action with two missing names")
    results = []
    for i, case in enumerate(cases):
        n, observed = observations[i]
        square = square_closure(observed, n, case["arms"]["active"]["paid"], requests[i])
        started = time.process_time_ns()
        candidate = next(iter(actions[i])) if len(actions[i]) == 1 else None
        named_answers = {
            split: [None if candidate is None else labelled_prediction(candidate, word) for word in words]
            for split, words in requests[i].items()
        }
        results.append(dict(index=i, order=n, seen=len(set(observed.values())), catalogue=dict(
            witnesses=matches[i], distinct_named_actions=len(actions[i]), action=candidate, answers=named_answers,
            cpu_ns=time.process_time_ns() - started,
        ), square=square))
    with output.open("x", encoding="utf-8") as file:
        json.dump(dict(gap=gap, smallgrp=smallgrp, build_cpu_ns=build_ns, enumeration=stats,
                       contradiction=matches[-1], ambiguity_refused=ambiguous is None, results=results),
                  file, sort_keys=True)
        file.write("\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cohort", "library", "output"):
        parser.add_argument(name, type=Path)
    args = parser.parse_args()
    run(args.cohort, args.library, args.output)
