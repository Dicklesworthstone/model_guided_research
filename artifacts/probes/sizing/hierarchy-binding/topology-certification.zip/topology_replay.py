import hashlib
import itertools
import json
import sys
from collections import Counter
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import topology as topo
from address_fixtures import DIM, sha_json

SOURCE = "944c6703372aa067b9d547f4c8b68a52285f7f52"
LOCK = "513f2d38df6effec33045584304eb700a9bf1866cb6d0050e66e9a729da8c982"
FILES = ("topology.py", "address_fixtures.py", "topology.yaml", "frozen.sha256", "protocol.txt",
         "topology-raw.json", "argument.md", "topology_replay.py", "replay.yaml")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def tuple_lists(value):
    return json.loads(json.dumps(value))


def replay_receipt(read, names):
    path, = (name for name in names if name.endswith("/receipt.json"))
    receipt = json.loads(read(path))
    assert receipt["tool"] == "hierarchy-topology-certification"
    assert receipt["status"] == "passed" and not receipt["dry_run"] and not receipt["skipped"]
    assert receipt["passed"] == receipt["executed"] == receipt["total"] == 1
    check, = receipt["checks"]
    assert check["exit_code"] == 0 and check["passed"]
    log = Path(path).with_name(Path(check["log_path"]).name).as_posix()
    assert digest(read(log)) == check["log_sha256"]
    config = Path(path).with_name("checks-config.yaml").as_posix()
    assert read(config) == read("topology.yaml")
    assert digest(read(config)) == receipt["config_sha256"] == receipt["config_sha256_after"]
    return Path(path).parent.name


def independent(observations, anchors=()):
    records, root, _ = observations[0]
    words = set(records)
    ptrs = {root, *(ptr for links in records.values() for ptr in links)}
    dense = len(words) == 127
    if dense:
        # Directly enumerate the full stabilizer of the missing word, with no count filters.
        bases = [tuple(next(word for word in range(256) if word.bit_count() % 2 == min(bank).bit_count() % 2
                            and word not in bank) for bank in (words, ptrs))]
    elif anchors:
        bases = [anchors[0]]
    else:
        bases = [(word, min(ptrs)) for word in sorted(words)]
    bank_maps = 0
    paths = [Counter() for _ in observations]
    for x0, q0 in bases:
        for order in itertools.permutations(tuple(1 << i for i in range(DIM))):
            def decode(ptr):
                bits = ptr ^ q0
                return x0 ^ sum(weight for i, weight in enumerate(order) if bits & (1 << i))

            if any(decode(q) != key for key, q in anchors):
                continue
            if not dense and not all(decode(ptr) in words for ptr in ptrs):
                continue
            bank_maps += 1
            for (rows, ptr, query), log in zip(observations, paths, strict=True):
                seen = set()

                def check(symbol, remaining):
                    key = decode(symbol)
                    if key in seen or bool(rows[key]) != bool(remaining):
                        return False
                    seen.add(key)
                    return all(check(ptr, remaining - 1) for ptr in rows[key])

                if not check(ptr, len(query)) or seen != words:
                    continue
                path = [decode(ptr)]
                for alias in query:
                    path.append(decode(rows[path[-1]][alias]))
                log[tuple(path)] += 1

    return dict(bank_maps=bank_maps, orientations=[dict(
        maps=sum(log.values()), routes=[dict(path=route, maps=count) for route, count in sorted(log.items())])
        for log in paths])


def oracle(doc, namespace):
    order, flips = namespace
    key_by_ptr = {}
    for key in doc["keys"]:
        word = format(key, "08b")[::-1]
        encoded = int("".join(word[i] for i in reversed(order)), 2) ^ flips
        key_by_ptr[encoded] = key
    rec = {key: [key_by_ptr[ptr] for ptr in row] for key, row in
           zip(doc["keys"], doc["link"], strict=True)}
    result = [key_by_ptr[doc["root"]]]
    for alias in doc["query"]:
        result.append(rec[result[-1]][alias])
    assert result == [doc["keys"][i] for i in doc["chain"]]
    return result


def replay(read, names):
    lock = read("frozen.sha256")
    assert digest(lock) == LOCK
    for line in lock.decode().splitlines():
        sha, path = line.split()
        assert digest(read(path)) == sha
    raw = json.loads(read("topology-raw.json"))
    cases = {str(depth): dict(pairs=0, route_pairs=0, endpoint_pairs=0, single_map_pairs=0,
                              ambiguous_maps_fixed_route=0, geometry_counts=[]) for depth, _ in topo.CELLS}
    brute_cases = []
    for recorded, (seed, depth, ix, namespace, pair) in zip(raw["rows"], topo.fresh(), strict=True):
        want = dict(seed=seed, depth=depth, pair=ix, namespace=namespace, fixture=sha_json(pair))
        assert all(recorded[key] == tuple_lists(value) for key, value in want.items())
        inputs = [(topo.observe(doc), doc["root"], tuple(doc["query"])) for doc in pair]
        solved = topo.solve(inputs)
        assert all(recorded[key] == tuple_lists(value) for key, value in solved.items())
        alternatives = recorded["orientations"]
        for doc, measured in zip(pair, alternatives, strict=True):
            gold = oracle(doc, namespace)
            routes = measured["routes"]
            assert gold in [case["path"] for case in routes]
            assert measured["maps"] == sum(case["maps"] for case in routes)
            assert 1 <= measured["maps"] <= recorded["bank_maps"]
            assert all(len(case["path"]) == depth + 1 for case in routes)
        if seed == topo.SEEDS[0] and ix == 0 and depth in (2, 6):
            assert independent(inputs) == solved
            brute_cases.append(depth)
        cell = cases[str(depth)]
        cell["pairs"] += 1
        cell["geometry_counts"].append(solved["bank_maps"])
        exact_routes = all(len(o["routes"]) == 1 for o in alternatives)
        exact_map = all(o["maps"] == 1 for o in alternatives)
        cell["route_pairs"] += exact_routes
        cell["endpoint_pairs"] += all(len({r["path"][-1] for r in o["routes"]}) == 1 for o in alternatives)
        cell["single_map_pairs"] += exact_map
        cell["ambiguous_maps_fixed_route"] += exact_routes and not exact_map
    assert brute_cases == [2, 6]
    assert {key: cell["pairs"] for key, cell in cases.items()} == {"2": 48, "3": 48, "4": 48, "6": 24}
    for name, (inputs, anchors) in topo.controls().items():
        assert tuple_lists(independent(inputs, anchors)) == raw["controls"][name]
    controls = {}
    for name, measurements in raw["controls"].items():
        one, = measurements["orientations"]
        controls[name] = dict(maps=one["maps"], paths=len(one["routes"]),
                              leaves=sorted({case["path"][-1] for case in one["routes"]}))
    assert controls == {"distinct_answers": {"maps": 2, "paths": 2, "leaves": [8, 32]},
                        "same_answer": {"maps": 2, "paths": 1, "leaves": [8]}}
    dense = cases["6"]
    gates = dict(dense_bank_symmetry=set(dense["geometry_counts"]) == {40320},
                 dense_coverage=dense["route_pairs"] >= 20)
    for cell in cases.values():
        raw_counts = cell.pop("geometry_counts")
        cell["bank_map_range"] = [min(raw_counts), max(raw_counts)]
    return dict(source=SOURCE, receipt=replay_receipt(read, names), pairs=168, cells=cases, gates=gates,
                controls=controls, independent_depths=brute_cases, pass_all=all(gates.values()))


def verify(path):
    with ZipFile(path) as archive:
        names = archive.namelist()
        assert archive.testzip() is None and len(names) == len(set(names))
        decision = replay(archive.read, names)
        assert decision == json.loads(archive.read("decision.json"))
    print(json.dumps(decision))


def build(root, bundle):
    files = {name: root / name for name in FILES}
    receipt, = (root / "receipts").glob("*/*/receipt.json")
    for name in ("receipt.json", "check-1.log", "checks-config.yaml"):
        path = receipt.with_name(name)
        files[path.relative_to(root).as_posix()] = path
    decision = replay(lambda name: files[name].read_bytes(), files.keys())
    with ZipFile(bundle, "x", compression=ZIP_DEFLATED) as archive:
        for name, path in files.items():
            archive.write(path, name)
        archive.writestr("decision.json", json.dumps(decision, indent=2) + "\n")
    print(json.dumps(decision))


if __name__ == "__main__":
    action, *paths = sys.argv[1:]
    {"build": build, "verify": verify}[action](*map(Path, paths))
