import hashlib
import json
import math
import sys
from collections import Counter
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


PANEL_HASH = "60b2079c1791866c29ebb744e4a318d14fabc2b45928623d843981abdd559235"
EVAL_HASH = "945803b20f0220230c51ba27ffe0285315e43bbd6b153a15d2bd42b13018ce01"
HELPER_HASH = "1b39baf09dd902d3356a21a88cdc4eef0027094fdb11769d4132ad964aeb27e6"
REGISTRATION = "e519974671cf34f81b2a3371d0a507d7722fca99"
SLOTS = {"a2": 114, "b3": 114, "b2": 110, "a3": 118}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def evaluate_files(read, prior):
    assert sha(read("panel.json")) == PANEL_HASH
    assert sha(read("replay/depth_cross.py")) == EVAL_HASH
    assert sha(read("replay/leaf_position.py")) == HELPER_HASH
    panel = json.loads(read("panel.json"))
    assert panel["panel_seed"] == 7019 and panel["distinct_input_trees"] == 32396
    assert len(panel["blocks"]) == 36
    assert panel["tokenizer_sha256"] == sha(prior.read("tokenizer.json"))
    assert len({block[variant]["tree"] for variant in ("a", "b") for block in panel["blocks"]}) == 72
    for axis in range(3):
        assert Counter(block["layout"][axis] for block in panel["blocks"]) == {0: 12, 1: 12, 2: 12}
    for block in panel["blocks"]:
        a, b = block["a"], block["b"]
        collapsed, _, _ = block["layout"]
        marker = f"k0x{collapsed}"
        widened = next(leaf["path"][0] for leaf in a["leaves"] if len(leaf["path"]) == 1)
        assert widened != marker and a["tree"].replace(f" {widened} ", f" {marker} ", 1) == b["tree"]
        assert [item["value"] for item in a["leaves"]] == [item["value"] for item in b["leaves"]]
        for cell, n in SLOTS.items():
            tree = block[cell[0]]
            rows = tree["records"][cell[1]]
            leaves = tree["leaves"]
            assert len(tree["candidates"]) == len(leaves) == 9 and len({leaf["value"] for leaf in leaves}) == 9
            assert len({row["label"] for row in rows}) == len(rows) == 4
            assert len({row["path"][0] for row in rows}) == len({tuple(row["path"][1:]) for row in rows}) == 2
            assert len({(row["path"][0], tuple(row["path"][1:])) for row in rows}) == 4
            for row in rows:
                assert len(row["prompt_ids"]) == n and n < row["full_tokens"] <= 120
                assert row["path"] == leaves[row["label"]]["path"] and row["value"] == leaves[row["label"]]["value"]
                assert row["document"] == f'{tree["tree"]} PATH {" ".join(row["path"])} OUT {row["value"]}'
    original = json.loads(prior.read("decision.json"))
    report = {}
    for seed in ("30", "31", "32"):
        for arm in ("detached", "joint"):
            name = f"seed-{seed}-{arm}"
            raw = json.loads(read(f"evals/{name}.json"))
            assert (raw["seed"], raw["arm"], raw["panel_sha256"]) == (int(seed), arm, PANEL_HASH)
            hashes = original["per_seed"][seed]["checkpoint_hashes"][arm]
            assert raw["weights_sha256"] == hashes["model_sha256"]
            assert raw["location_head_sha256"] == hashes["head_sha256"]
            report[name] = {}
            for cell, n in SLOTS.items():
                counts = Counter()
                for block, results in zip(panel["blocks"], raw["rows"], strict=True):
                    case = block[cell[0]]
                    queries = case["records"][cell[1]]
                    logits = results[cell]
                    assert len(logits) == 4 and all(len(scores) == 9 and all(map(math.isfinite, scores))
                                                     for scores in logits)
                    picks = [max(range(9), key=scores.__getitem__) for scores in logits]
                    correct = [pick == query["label"] for pick, query in zip(picks, queries, strict=True)]
                    counts["all_four"] += all(correct)
                    counts["single_correct"] += sum(correct)
                    counts["within_root_pairs_correct"] += sum(all(correct[i:i + 2]) for i in (0, 2))
                    counts["within_root_pairs_same_pick"] += sum(picks[i] == picks[i + 1] for i in (0, 2))
                    counts["right_root"] += sum(case["leaves"][pick]["path"][0] == query["path"][0]
                                                for pick, query in zip(picks, queries, strict=True))
                    counts["right_depth"] += sum(len(case["leaves"][pick]["path"]) == int(cell[1]) for pick in picks)
                report[name][cell] = dict(counts, prompts=n, blocks=36, within_root_pairs=72, queries=144)
    chosen = [report[f"seed-{seed}-joint"] for seed in (31, 32)]
    eligible = all(row["a2"]["all_four"] >= 18 for row in chosen)
    low_transfer = all(row["b3"]["all_four"] <= 3 for row in chosen)
    verdict = "unqualified" if not eligible else "gap_at_test_coordinate" if low_transfer else "low_transfer_rule_failed"
    return dict(registration=REGISTRATION, panel_sha256=PANEL_HASH, eligible=eligible, low_transfer=low_transfer,
                disposition=verdict, metrics=report)


def check_receipts(names, read):
    receipts = sorted(path for path in names if path.startswith("receipts/") and path.endswith("/receipt.json"))
    assert len(receipts) == 2
    assert {path.split("/")[1] for path in receipts} == {"hierarchy-depth-cross-preflight", "hierarchy-depth-cross-eval"}
    for path in receipts:
        data = json.loads(read(path))
        assert data["status"] == "passed" and len(data["checks"]) == 1
        for check in data["checks"]:
            log = path.removesuffix("receipt.json") + Path(check["log_path"]).name
            assert sha(read(log)) == check["log_sha256"]
    return [path.split("/")[-2] for path in receipts]


def bundle(scratch, previous, destination):
    paths = {"panel.json": scratch / "panel.json"}
    for name in ("depth_cross.py", "leaf_position.py", "depth_archive.py", "campaign.yaml"):
        paths[f"replay/{name}"] = scratch / name
    for ev in (scratch / "evals").glob("seed-*.json"):
        paths[f"evals/{ev.name}"] = ev
    assert len([name for name in paths if name.startswith("evals/")]) == 6
    for receipt in (scratch / "receipts").glob("*/*/receipt.json"):
        for name in ("receipt.json", "check-1.log", "checks-config.yaml"):
            path = receipt.with_name(name)
            paths[str(path.relative_to(scratch))] = path

    def read(name):
        return paths[name].read_bytes()

    with ZipFile(previous) as prior:
        decision = evaluate_files(read, prior)
    decision["dsr_receipts"] = check_receipts(paths, read)
    with ZipFile(destination, "x", compression=ZIP_DEFLATED) as archive:
        for name, path in paths.items():
            archive.write(path, name)
        archive.writestr("decision.json", json.dumps(decision, indent=2) + "\n")


def verify(destination, previous):
    with ZipFile(destination) as archive, ZipFile(previous) as prior:
        assert archive.testzip() is None
        names = archive.namelist()
        assert len(names) == len(set(names))
        assert not any(name.endswith((".pt", ".parquet", ".safetensors")) for name in names)
        decision = evaluate_files(archive.read, prior)
        decision["dsr_receipts"] = check_receipts(names, archive.read)
        assert decision == json.loads(archive.read("decision.json"))
    print(json.dumps(decision))


if __name__ == "__main__":
    command, *paths = sys.argv[1:]
    if command == "bundle":
        bundle(*map(Path, paths))
    elif command == "verify":
        verify(*map(Path, paths))
    else:
        raise ValueError(command)
