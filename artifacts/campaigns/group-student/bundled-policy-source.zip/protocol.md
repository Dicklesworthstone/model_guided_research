# Bundled compiled policy for the installed endpoint command

Bead `model_guided_research-xm2t`. Ship the data needed to reuse the audited
compiled selector from fresh processes. The archive is a fixed ordered ZIP of
per-order JSON, containing the tree and rooted shape rows. A probe encodes
the word and branches indexed by first-seen reply rank. A leaf encodes the
shape and its observed-name positions, or the capped square continuation.
The loader checks the complete archive hash and format, parses the chosen
order and builds its shortest naming walks. It creates no dynamic endpoint
index. The generator consumes only the audited graph archive and compiles its
complete shape inventory. Two generations with hash seeds 0 and 991 must be
byte identical. No prior oracle tapes are generator inputs.

## Frozen comparison

- Compare the published square implementation, the published Python compiler
  and acquisition API at `0fcc1eb`, and the new bundled loader and acquisition
  API. Measure all three live in paired arm order. Each arm solves all 151,
  503 and 1,799 marked actions at orders 32, 64 and 128 under each of the
  published affine renamings. Reverse the arm rotation and supplied roster in
  the second process. The oracle derives labels from the independently audited
  shapes. Require exact agreement with the previously archived paid tapes,
  action and terminal status before reporting any CPU results.
- Time host process CPU and elapsed in each arm. For the published compiler
  arm record audited archive load and compilation separately. For the
  bundled arm record its archive load, checksum, tree decoding and shortest
  naming preparation together. Each prepared object is used for the complete
  census of its order. Square uses no preparation. Report online costs and
  their sums with preparation. All comparisons start with existing exported
  data and charge the relevant runtime preparation. Report the bundle size
  and generator work separately. Hardware latencies, GAP export, and Python
  startup are outside these timed stages.
- The primary prediction fixes at least **2× faster setup process CPU** than
  live audited-load-plus-compile at every order and both process executions.
  Online CPU, square closure, and total preparation-inclusive CPU are
  countermetrics. Stop after the two complete executions. A DSR execution
  gate can pass when the preregistered timing predicate fails.
- Validate the release's normal CLI by installing its wheel in isolation.
  Drive all three supported orders through JSON-lines pipes, validating each
  named table independently and checking the recorded mode and replies.
  Exercise unsupported order, incompatible options and corrupted resource
  as negative controls. These runs use a software oracle. No hosted provider,
  device, or new model-training result is claimed.
