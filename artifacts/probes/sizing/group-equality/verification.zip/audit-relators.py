"""Independently validate all memo decisions, topology, and held-out endpoints."""
import hashlib
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

path = Path(sys.argv[1])
data = Path(sys.argv[2])
result = json.loads(path.read_text())
groups = ["s5"] * 6 + ["a6"] * 6 + ["z60"] * 6
assert result["seed"] == 2026112307
assert [c["group"] for c in result["results"]] == groups
historical = json.loads(Path("artifacts/probes/sizing/group-query-completion/panel.json").read_text())
seen = {c["graph_digest"] for c in historical["cases"]}
seen.update(json.loads(p.read_text())["graph_sha"] for p in data.glob("*.json"))
assert len(result["excluded_incomplete_s5"]) == 6
seen.update(result["excluded_incomplete_s5"])
totals = defaultdict(lambda: defaultdict(Counter))
per_case = []


def normalize(a, b, arm):
    if arm == "raw":
        return min((a, b), (b, a))
    if arm == "cancelled":
        while a and b and a[0] == b[0]:
            a, b = a[1:], b[1:]
        while a and b and a[-1] == b[-1]:
            a, b = a[:-1], b[:-1]
        return min((a, b), (b, a))
    marked = a.translate(str.maketrans("01", "ab")) + b[::-1].translate(str.maketrans("01", "AB"))
    normal = ""
    for letter in marked:
        normal = normal[:-1] if normal.endswith(letter.swapcase()) else normal + letter
    while len(normal) > 1 and normal[-1] == normal[0].swapcase():
        normal = normal[1:-1]
    reverse = normal[::-1].swapcase()
    return min([w[k:] + w[:k] for w in (normal, reverse) for k in range(len(w))], default="")


def audit_arm(row, arm, graph, action, links):
    t = row["strategies"][arm]
    assert t["edges"] == graph and t["representatives"] == links
    state_count = len(links)
    known = 1
    used = [set(), set()]
    memo = {normalize("", "", arm): True}
    counts = Counter()
    next_query = iter(t["trace"])
    for w, row_edges in zip(links, graph, strict=True):
        for digit, known_target in enumerate(row_edges):
            event = next(next_query)
            word = w + str(digit)
            assert event["word"] == word and event["target"] == known_target
            choices = set(range(known)) - used[digit]
            trials = event["trials"]
            prior_candidate = None
            called = 0
            if known == state_count and len(choices) == 1:
                assert not trials and known_target == next(iter(choices))
                counts["forced"] += 1
            else:
                for i, (candidate, channel, expected) in enumerate(trials):
                    assert candidate in choices
                    ref = links[candidate]
                    counts_delta = [abs(word.count(g) - ref.count(g)) for g in "01"]
                    order = (144 * sum(v % 2 for v in counts_delta) + sum(counts_delta), candidate)
                    assert prior_candidate is None or prior_candidate < order
                    prior_candidate = order
                    choices.remove(candidate)
                    key = normalize(word, ref, arm)
                    independently_equal = action(word) == action(ref)
                    assert expected is independently_equal
                    assert channel == ("cache" if key in memo else "oracle")
                    if channel == "oracle":
                        memo[key] = expected
                        called += 1
                    else:
                        assert memo[key] is expected
                    counts[f"{channel}_{'equal' if expected else 'different'}"] += 1
                    if expected:
                        assert i == len(trials) - 1 and candidate == known_target
                if not trials or not trials[-1][2]:
                    assert not choices
                    assert known_target == known and links[known] == word
                    known += 1
                    counts["new"] += 1
                    counts["paid_new"] += called
            used[digit].add(known_target)
    assert next(next_query, None) is None
    assert known == state_count and t["memo_entries"] == len(memo)
    assert {k: n for k, n in counts.items() if k != "paid_new"} == t["counts"]
    counts["paid"] = counts["oracle_equal"] + counts["oracle_different"]
    return counts


for i, row in enumerate(result["results"]):
    name = row["group"]
    generators = row["generators"]
    ident = (0,) if name == "z60" else tuple(range(len(generators[0])))

    def apply(state, digit):
        g = generators[digit]
        if name == "z60":
            return ((state[0] + g[0]) % 60,)
        return tuple(g[index] for index in state)

    def action(word):
        state = ident
        for digit in word:
            state = apply(state, int(digit))
        return state

    states = [ident]
    refs = [""]
    graph = []
    for j, state in enumerate(states):
        edges = []
        for digit in (0, 1):
            nxt = apply(state, digit)
            if nxt not in states:
                refs.append(refs[j] + str(digit))
                states.append(nxt)
            edges.append(states.index(nxt))
        graph.append(edges)
    assert len(states) == {"s5": 120, "a6": 360, "z60": 60}[name]
    fingerprint = hashlib.sha256(json.dumps(graph).encode()).hexdigest()
    assert fingerprint == row["graph_sha"] and fingerprint not in seen
    seen.add(fingerprint)
    assert Counter(len(w) for w, _ in row["samples"]) == {16: 48, 32: 48, 64: 48, 128: 48}
    assert len({word for word, _ in row["samples"]}) == 192
    assert all(states.index(action(word)) == output for word, output in row["samples"])
    case = {"group": name, "index": i, "counts": {}}
    for arm in ("raw", "cancelled", "relator"):
        counts = audit_arm(row, arm, graph, action, refs)
        totals[name][arm].update(counts)
        case["counts"][arm] = dict(counts)
    per_case.append(case)
    if i == 0:
        event = next(e for e in row["strategies"]["relator"]["trace"] if any(t[1] == "cache" for t in e["trials"]))
        j = next(j for j, t in enumerate(event["trials"]) if t[1] == "cache")
        candidate, channel, truth = event["trials"][j]
        event["trials"][j] = (candidate, channel, not truth)
        try:
            audit_arm(row, "relator", graph, action, refs)
        except AssertionError:
            pass
        else:
            raise AssertionError("Corrupted cached truth value passed the audit")
        event["trials"][j] = (candidate, channel, truth)
joined = {k: totals["s5"][k] + totals["a6"][k] for k in ("raw", "cancelled", "relator")}
raw, rel = joined["raw"], joined["relator"]
gate = 100 * rel["paid"] <= 80 * raw["paid"] and 100 * rel["paid_new"] <= 85 * raw["paid_new"]
print(json.dumps(dict(
    totals=totals, primary=joined, gate=gate, cases=per_case,
    verified_edges=3 * 2 * 6 * (120 + 360 + 60), verified_words=3 * 18 * 192,
), sort_keys=True))
