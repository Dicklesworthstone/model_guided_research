# eval-tasks — std-10-full

- checkpoint: `/data/ssd/tmp/mgr-cong.g50qfshI/dqpo/control/test_checkpoint_sweeps_adjudic0/weights/std-10/checkpoints` @ step 1
- attention_type: standard
- n_params: 32,768
- seeds: [0] · examples/seed: 2 · decode: ['greedy']

| task | EM in-range | EM held-out | ppl in/held | slope held-out [CI95] | curve |
|---|---|---|---|---|---|
| arith | 0.000 | 0.000 | 319.8/319.4 | - | [curve](curve_arith.png) |

See `summary.json` (schema mgr.evaltasks.v4) for the full contract output and `generations.jsonl` for per-example receipts.
