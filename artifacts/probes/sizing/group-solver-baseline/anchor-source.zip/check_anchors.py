"""Check exact profile equality, graph domains, and unchanged acquisition."""

import argparse
import copy
import json
import math
import statistics
from itertools import combinations, product
from pathlib import Path

from check_base_study import expected_action
from check_catalogue import verify_catalogue
from check_study import ANCHORS, rooted, walk

INVENTORY = {32: (51, 20), 64: (267, 54), 128: (2328, 163)}
LEGAL = {"0000", "0110", "0112", "0120", "0123"}
LATTICE = {"0000", "0110", "0112"}
EXPECTED_PROBES = (
    ("dihedral-32", "ring", (16,), ("T", "FT")),
    ("four-by-eight", "torus", (4, 8), ("F", "F")),
)


def read(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        raise ValueError(f"Invalid JSON file {path}") from error


def inspect_tables(raw):
    gap, smallgrp, inventory, tables = raw
    if (gap, smallgrp) != ("4.16.1", "1.7.0") or [row[0] for row in inventory] != list(INVENTORY):
        raise ValueError("Unexpected GAP export or support")
    ids = []
    for n, total, rank_one, rank_two in inventory:
        if (total, len(rank_one) + len(rank_two)) != INVENTORY[n] or len(rank_one) != 1:
            raise ValueError("Wrong rank inventory")
        if any(size != n or not 1 <= group <= total for size, group in rank_one + rank_two):
            raise ValueError("Invalid SmallGrp IDs")
        ids.extend((size, group, rank) for rank, found in enumerate((rank_one, rank_two), start=1) for size, group in found)
    if ids != [tuple(row[:3]) for row in tables] or len(set(ids)) != len(ids):
        raise ValueError("Incomplete GAP rank inventory")
    for n, _, _, abelian, table in tables:
        domain = list(range(n))
        if (len(table) != n or table[0] != domain or [r[0] for r in table] != domain
                or any(sorted(row) != domain for row in table)
                or any(sorted(col) != domain for col in zip(*table, strict=True))
                or abelian != all(table[a][b] == table[b][a] for a, b in combinations(domain, 2))):
            raise ValueError("Invalid multiplication-table domain or commutation flag")


def decode(graph, n):
    data = bytes.fromhex(graph)
    if len(data) != 2 * n or max(data) >= n:
        raise ValueError("Wrong edge count or range")
    return {mark: dict(enumerate(data[int(mark)::2])) for mark in "01"}


def validate_profile(code, value):
    return all((code[a] == code[b]) == (value[a] == value[b]) for a, b in combinations(range(4), 2))


def inversion_parameters(graph, n):
    inverse_first = {target: source for source, target in graph["0"].items()}
    rotations = [0]
    state = graph["1"][inverse_first[0]]
    while state:
        rotations.append(state)
        state = graph["1"][inverse_first[state]]
    m = len(rotations)
    d, remainder = divmod(n, m)
    if remainder:
        raise ValueError("Rotation order does not divide the group order")
    c = rotations.index(walk(0, graph, "0" * d))
    return m, d, c


def verify_probe(probe, forms, expected):
    name, kind, dims, primitives = probe["spec"]
    spec = (name, kind, tuple(dims), tuple(primitives))
    labels = probe["labels"]
    root = labels[0]
    truth = expected_action((*spec, False), labels)
    initial = {word: walk(root, truth, word) for word in ANCHORS}
    if (spec != expected or name != probe["case"] or probe["initial"] != initial
            or not validate_profile(probe["profile"], list(initial.values()))
            or sorted(labels) != [f"opaque{i:02d}" for i in range(32)]):
        raise ValueError("Wrong online integration case or anchors")
    original, routed = (probe["rows"][arm] for arm in ("full", "routed"))
    if original != routed or original["terminal"] != "unique-catalogue" or original["right"] != truth:
        raise ValueError("Selected catalogue changed the oracle tape or final table")
    if probe["profile"] == "0120" and probe["rows"].get("inversion") != original:
        raise ValueError("Direct inversion catalogue changed its oracle tape")
    seen = set(initial)
    for word, answer in original["paid"]:
        if word in seen or walk(root, truth, word) != answer:
            raise ValueError("Invalid paid tape in integration")
        seen.add(word)
    verify_catalogue(original, initial, set(labels), forms)
    return len(seen)


def verify_order(row):
    n = row["order"]
    if row["groups"] != INVENTORY[n][1] or row["full_work"]["calls"] != row["groups"] * n * n:
        raise ValueError("Changed baseline denominator")
    expected_profiles = {
        "".join(map(str, values)) for values in product(range(4), repeat=4)
        if values[0] == 0 and all(val <= max(values[:i]) + 1 for i, val in enumerate(values[1:], start=1))
    }
    if set(row["profiles"]) != expected_profiles:
        raise ValueError("Incomplete anchor-partition audit")
    results, families = {}, {}
    for code, build in row["profiles"].items():
        full = build["full"]
        if sorted(set(full)) != full or full != build["filtered"] or bool(full) != (code in LEGAL):
            raise ValueError("Filtered catalogue changed the exact version space")
        if build["filter_work"]["calls"] > row["full_work"]["calls"] or (code not in LEGAL and build["filter_work"]["calls"]):
            raise ValueError("Invalid traversal counts")
        families[code] = []
        for packed in full:
            graph = decode(packed, n)
            target = tuple(zip(*(g.values() for g in graph.values()), strict=True))
            if (rooted(graph, 0) != target or any(set(g.values()) != set(range(n)) for g in graph.values())
                    or not validate_profile(code, [walk(0, graph, w) for w in ANCHORS])):
                raise ValueError("Canonical graph, bijections or anchor signature failed")
            families[code].append(graph)
        routed_key = "filter_work"
        if code in LATTICE:
            if full != build["lattice"] or build["lattice_work"]["calls"] != len(full):
                raise ValueError("The algebraic abelian construction changed the catalogue")
            routed_key = "lattice_work"
        results[code] = {
            "shapes": len(full), "full_calls": row["full_work"]["calls"],
            "filter_calls": build["filter_work"]["calls"],
            "full_cpu_ns": row["full_work"]["cpu_ns"],
            "filter_cpu_ns": build["filter_work"]["cpu_ns"], "route_cpu_ns": build[routed_key]["cpu_ns"],
        }
    divisor_sum = sum(d for d in range(1, n + 1) if n % d == 0)
    counts = {code: results[code]["shapes"] for code in LATTICE}
    if counts != {"0000": 1, "0110": 2, "0112": divisor_sum - 3}:
        raise ValueError("The abelian shape counts differ from the subgroup-index and order-two formulas")
    parameters = {(m, n // m, c) for m in range(3, n + 1) if n % (2 * m) == 0
                  for c in range(m) if 2 * c % m == 0}
    only_squares = row["profiles"]["0120"]
    recovered = [inversion_parameters(graph, n) for graph in families["0120"]]
    if (only_squares["inversion"] != only_squares["full"] or only_squares["inversion_work"]["calls"] != len(parameters)
            or len(recovered) != len(parameters) or set(recovered) != parameters):
        raise ValueError("Direct inversion catalogue or independently recovered parameters differ")
    results["0120"]["inversion_cpu_ns"] = only_squares["inversion_work"]["cpu_ns"]
    examples = row["integrations"]
    if n == 32:
        reads = {
            case["case"]: verify_probe(case, families[case["profile"]], spec)
            for case, spec in zip(examples, EXPECTED_PROBES, strict=True)
        }
    else:
        if examples:
            raise ValueError("Unexpected extra scored integration case")
        reads = {}
    return {"order": n, "profiles": results, "integration_reads": reads}


def validate(record):
    if [row["order"] for row in record["orders"]] != list(INVENTORY):
        raise ValueError("Unexpected size ladder")
    return [verify_order(row) for row in record["orders"]]


def without_timings(record):
    compact = copy.deepcopy(record)
    for row in compact["orders"]:
        timing_entries = [row["full_work"]]
        for profile in row["profiles"].values():
            timing_entries.extend(
                profile[prop] for prop in ("filter_work", "lattice_work", "inversion_work") if prop in profile
            )
        for timing in timing_entries:
            del timing["cpu_ns"], timing["wall_ns"]
    return compact


def expect_failure(row, replacement):
    target = copy.deepcopy(row)
    removal = target["profiles"]["0000"]
    if replacement:
        removal["full"] = target["profiles"]["0123"]["full"]
        removal["filtered"] = removal["lattice"] = removal["full"]
        removal["lattice_work"]["calls"] = len(removal["full"])
    else:
        removal["filtered"].pop()
    try:
        verify_order(target)
    except ValueError:
        return True
    raise ValueError("Checker did not reject corrupted exact output")


def speed(rows):
    ratios = [
        entry["full_cpu_ns"] / entry["route_cpu_ns"]
        for row in rows if row["order"] >= 64
        for code, entry in row["profiles"].items() if code in LEGAL
    ]
    return statistics.median(ratios)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("tables", type=Path)
    parser.add_argument("scored", type=Path)
    parser.add_argument("replay", type=Path)
    args = parser.parse_args()
    raw, scored, replay = (read(p) for p in (args.tables, args.scored, args.replay))
    inspect_tables(raw)
    first, second = validate(scored), validate(replay)
    if without_timings(scored) != without_timings(replay):
        raise ValueError("Nontiming replay changed")
    ratios = [speed(rows) for rows in (first, second)]
    if any(not math.isfinite(ratio) for ratio in ratios):
        raise ValueError("Invalid timing")
    print(json.dumps({
        "original_tapes_identical": True,
        "forgery_rejected": {
            "omitted_shape": expect_failure(scored["orders"][0], replacement=False),
            "wrong_anchor_class": expect_failure(scored["orders"][0], replacement=True),
        },
        "median_cold_cpu_ratio": ratios,
        "twofold_gate": min(ratios) >= 2,
        "scored": first,
        "replay": second,
    }, indent=2))


if __name__ == "__main__":
    main()
