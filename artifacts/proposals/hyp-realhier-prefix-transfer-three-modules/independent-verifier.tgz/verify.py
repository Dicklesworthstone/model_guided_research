"""Independent preregistered AST feasibility audit. Invoke from the pinned clean checkout."""

import ast
from collections import Counter
import hashlib
import importlib.metadata
import json
import platform
import random
import subprocess
import sys
import sysconfig
from pathlib import Path


REVISION = "e063ee21147049a1a6baf373aca30cf1d4d100cb"
PROPOSAL = Path("artifacts/proposals/hyp-realhier-prefix-transfer-three-modules")
SPLITS = {
    "train": ("json", "ast", "dataclasses", "argparse", "logging", "unittest.case"),
    "development": ("fractions", "configparser", "statistics"),
    "held_out": ("contextlib", "enum", "textwrap"),
}
WINDOW = 256


def digest(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(["git", *args], text=True).strip()


def definitions(container):
    tree = {}
    for member in container.body:
        if isinstance(member, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            children = definitions(member)
            tree[member.name] = children or ("cls" if isinstance(member, ast.ClassDef) else "fn")
    return tree


def visit(tree, ancestors=()):
    """Emit the generator's spaced tree and its leaf paths in source order."""
    words, leaves = [], []
    for name, value in tree.items():
        path = (*ancestors, name)
        words.extend(("(", name))
        if isinstance(value, dict):
            child_words, child_leaves = visit(value, path)
            words.extend(child_words)
            leaves.extend(child_leaves)
        else:
            words.append(value)
            leaves.append((path, value))
        words.append(")")
    return words, leaves


def document(tree, path, answer):
    return f"TASK hier TREE {tree} PATH {' '.join(path)} OUT {answer}"


def main():
    checkout = Path.cwd().resolve()
    assert git("rev-parse", "HEAD") == REVISION and git("status", "--porcelain") == ""
    pins_file = PROPOSAL / "source-pins.json"
    pins = json.loads(pins_file.read_bytes())
    assert platform.python_version() == pins["python"] == "3.13.0"
    names = tuple(module for split in SPLITS.values() for module in split)
    assert len(names) == len(set(names)) == 12 and set(names) == pins["sha256"].keys()
    stdlib = Path(sysconfig.get_path("stdlib"))
    serial, leaves, measured = {}, {}, {}
    for module in names:
        base = stdlib.joinpath(*module.split("."))
        filename = base / "__init__.py" if base.is_dir() else base.with_suffix(".py")
        raw = filename.read_bytes()
        actual = digest(raw)
        assert actual == pins["sha256"][module], (module, actual, pins["sha256"][module])
        words, paths = visit(definitions(ast.parse(raw, filename=str(filename))))
        assert paths and len(paths) == len({path for path, _ in paths})
        serial[module] = " ".join(words)
        leaves[module] = paths
        measured[module] = {
            "stdlib_path": str(filename.relative_to(stdlib)),
            "source_sha256": actual,
            "tree_sha256": digest(serial[module].encode()),
            "all_leaf_paths": len(paths),
        }
    assert len({row["source_sha256"] for row in measured.values()}) == 12
    assert len({row["tree_sha256"] for row in measured.values()}) == 12

    rand = random.Random(int.from_bytes(hashlib.sha256(b"realhier:train:42").digest()[:8], "big"))
    draws = rand.choices(SPLITS["train"], k=960)
    texts = [document(serial[name], *rand.choice(leaves[name])) for name in draws]
    assert len(texts) == 960 and set(draws) == set(SPLITS["train"])
    sys.path.insert(0, str(checkout))
    from nanochat import tokenizer as production

    assert Path(production.__file__).resolve() == checkout / "nanochat/tokenizer.py"
    tokenizer = production.HuggingFaceTokenizer.train_from_iterator(iter(texts), 512)
    assert tokenizer.get_vocab_size() == 512
    bos = tokenizer.get_bos_token_id()
    result = {}
    for name in SPLITS["held_out"]:
        ordered = sorted(leaves[name], key=lambda leaf: len(leaf[0]))
        selected = ordered[-max(1, len(ordered) // 4):]
        counts = Counter(answer for _, answer in selected)
        lengths = []
        for path, answer in selected:
            doc = document(serial[name], path, answer)
            tokens = tokenizer.encode(doc, prepend=bos)
            prompt = doc[:-(len(answer)+1)]
            split_ids = tokenizer.encode(prompt, prepend=bos) + tokenizer.encode(" " + answer)
            assert tokens == split_ids and tokens[0] == bos
            lengths.append(len(tokens))
        within = sum(length <= WINDOW for length in lengths)
        n = len(lengths)
        highest = max(counts.values())
        result[name] = {
            "eligible": n, "within_256": within, "coverage": within/n,
            "tokens_min": min(lengths), "tokens_max": max(lengths),
            "labels": dict(counts), "majority_count": highest, "majority_fraction": highest/n,
            "coverage_pass": 5*within >= 4*n, "majority_pass": 10*highest <= 9*n,
        }
    eligible = all(row["coverage_pass"] and row["majority_pass"] for row in result.values())
    report = {
        "revision": REVISION, "python": platform.python_version(), "platform": platform.platform(),
        "source_pin_file_sha256": digest(pins_file.read_bytes()), "source_pin_matches": 12,
        "unique_source_digests": 12, "unique_tree_digests": 12, "splits": SPLITS, "modules": measured,
        "document_format": "TASK hier TREE <serialization> PATH <space-separated path> OUT <answer>",
        "training": {"requested_documents": 1200, "tokenizer_training_documents": len(texts),
                     "dataset_seed": 42, "module_counts": dict(Counter(draws)),
                     "newline_delimited_texts_sha256": digest(("\n".join(texts)+"\n").encode()),
                     "tokenizer_implementation": "nanochat.tokenizer.HuggingFaceTokenizer.train_from_iterator",
                     "tokenizers_version": importlib.metadata.version("tokenizers"),
                     "vocabulary": tokenizer.get_vocab_size(), "bos_id": bos,
                     "tokenizer_json_sha256": digest(tokenizer.tokenizer.to_str().encode())},
        "held_out": result, "context_tokens": WINDOW, "minimum_coverage": 0.8,
        "maximum_majority": 0.9, "outcome": "pass_input_gates" if eligible else "stop_before_model_inference",
        "training_runs": 0, "model_predictions": 0, "development_power": "not_run",
        "script_sha256": digest(Path(__file__).read_bytes()),
    }
    assert git("status", "--porcelain") == ""
    destination = Path(__file__).with_name("report.json")
    destination.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"outcome": report["outcome"], "held_out": result, "sources_matched": 12,
                      "tokenizer_training_documents": len(texts), "report": str(destination)}, sort_keys=True))


if __name__ == "__main__":
    main()
