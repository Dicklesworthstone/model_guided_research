import json
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path.cwd()))
from nanochat.diagnostics_data import TASKS
from nanochat.tokenizer import HuggingFaceTokenizer

root = Path(sys.argv[1])
panel = json.loads((root / "panel.json").read_bytes())
task = TASKS["hier_paired"]
results = {}
for eval_path in sorted((root / "evals" / "tasks").glob("*/recount.json")):
    name = eval_path.parent.name
    directory = root / "runs" / "standard" / name / "checkpoints" / "tokenizer"
    tokenizer = HuggingFaceTokenizer.from_directory(str(directory))
    rows = {}
    for line in (eval_path.parent / "generations.jsonl").read_text().splitlines():
        record = json.loads(line)
        rows[record["region"], record["eval_seed"], record["doc_index"]] = record
    regions = {}
    for region, pairs in panel["evaluation"].items():
        counts = Counter({"same_first_answer": 0, "different_first_answers": 0, "missing_generation": 0})
        matched_lengths = 0
        for pair in pairs:
            key = region, pair["eval_seed"]
            index = pair["pair_index"] * 2
            lengths = [
                len(tokenizer.encode(task.split_prompt(doc)[0], prepend=tokenizer.get_bos_token_id()))
                for doc in pair["documents"]
            ]
            matched_lengths += lengths[0] == lengths[1]
            replies = [rows.get((*key, index + i), {}).get("got", "").split() for i in (0, 1)]
            if not all(replies):
                counts["missing_generation"] += 1
            elif replies[0][0] == replies[1][0]:
                counts["same_first_answer"] += 1
            else:
                counts["different_first_answers"] += 1
        assert sum(counts.values()) == len(pairs)
        regions[region] = dict(pairs=len(pairs), same_prompt_token_length=matched_lengths, **counts)
    results[name] = regions
output = root / "query-sensitivity-descriptive.json"
with output.open("x", encoding="utf-8") as handle:
    handle.write(json.dumps(results, indent=2) + "\n")
print(json.dumps(results))
