# Forced-exhaustion harness repair

The first DSR attempt at `d99ae72` printed terminal outcomes for seven ordinary cases. It stopped before writing a raw result file. Under the one-unit control, Z3 canceled `push` before it received a satisfiability check, then exited with a protocol error. The failed receipt and both check logs are retained. The original producer and preregistration remain available at `d99ae72`.

The recovery changes scoped setup and cleanup for the one-unit control only. Open the rank scope with the ordinary limit, set one unit immediately before the check, restore the ordinary limit and pop the scope. The replay verifier requires this exact sequence. All ordinary action specs, arm policies, command sequences, budgets and preregistered evaluation criteria are preserved. Replay will produce the first full tapes, witnesses, costs and independent correctness and scope checks.
