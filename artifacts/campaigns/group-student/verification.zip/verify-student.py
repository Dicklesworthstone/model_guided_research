"""Recount the paired study using pointwise permutations and independent arithmetic."""
import hashlib
import json
import math
import statistics
import sys
from collections import Counter
from pathlib import Path

root = Path(sys.argv[1])
old = json.loads(Path("artifacts/probes/sizing/group-query-completion/panel.json").read_text())
excluded = {c["graph_digest"] for c in old["cases"]}
cases = []
for i in range(24):
    path = root / f"{i:02}.json"
    c = json.loads(path.read_bytes())
    assert c["index"] == i and c["train_seed"] == 91001 + i
    assert c["group"] == ("s5" if i < 12 else "a5")
    gs = c["generator_pair"]
    names = c["opaque_names"]
    states = [tuple(range(5))]
    edges = []
    for state in states:
        row = []
        for gen in gs:
            next_state = tuple(gen[k] for k in state)
            if next_state not in states:
                states.append(next_state)
            row.append(states.index(next_state))
        edges.append(row)
    assert len(set(names)) == len(states) == (120 if i < 12 else 60)
    assert set(names) == set(map(str, range(len(states))))
    digest = hashlib.sha256(json.dumps(edges).encode()).hexdigest()
    assert c["graph_sha"] == digest and digest not in excluded
    excluded.add(digest)

    def oracle(word):
        state = 0
        for a in word:
            state = edges[state][int(a)]
        return names[state]

    arms = c["arms"]
    active = arms["active"]["paid"]
    random = arms["random"]["paid"]
    assert len(active) == len(random)
    assert [len(w) for w, _ in active] == [len(w) for w, _ in random]
    assert not arms["short_only"]["paid"]
    base = arms["short_only"]["rows"][:508]
    assert len({w for w, _ in base}) == 508 and all(2 <= len(w) <= 8 for w, _ in base)
    train_words = {w for arm in arms.values() for w, _ in arm["rows"]}
    for arm in arms.values():
        assert len(arm["rows"]) == 508 + len(active) + 1536
        assert arm["rows"][:508] == base
        assert len({w for w, _ in arm["paid"]}) == len(arm["paid"])
        assert len({w for w, _ in arm["rows"]}) == 508 + len(arm["paid"]) + arm["inferred"]
        assert all(9 <= len(w) <= 23 and oracle(w) == y for w, y in arm["paid"])
        assert all(2 <= len(w) <= 23 and oracle(w) == y for w, y in arm["rows"])
    for section, n in (("primary", 96), ("secondary", 128)):
        rows = c[section]
        words = {w for w, _, _ in rows}
        assert len(rows) == len(words) == n and not train_words.intersection(words)
        assert all(oracle(w) == y for w, y, _ in rows)
        majority = Counter(y for _, y in base).most_common(1)[0][0]
        assert all(pred == majority for _, _, pred in rows)
    assert Counter(len(w) for w, _, _ in c["primary"]) == {32: 32, 48: 32, 64: 32}
    assert all(9 <= len(w) <= 15 for w, _, _ in c["secondary"])
    cases.append(c)
assert len(list(root.glob("*.json"))) == 24
print("Verified 24 unique presentations, independently composed every train and eval label, and checked query parity.")

if len(sys.argv) > 2:
    experiment = json.loads(Path(sys.argv[2]).read_bytes())
    assert len(experiment["results"]) == len(cases)
    effects = []
    above_prior = []
    initial_hashes = set()
    model_hashes = set()
    aggregates = Counter()
    for i, (c, row) in enumerate(zip(cases, experiment["results"])):
        assert row["index"] == i and row["graph_sha"] == c["graph_sha"]
        prior = Counter(y for _, y, _ in c["primary"]).most_common(1)[0][1]
        assert row["prior"] == prior and row["n"] == row["symbolic"] == 96
        assert row["lookup"] == sum(y == v for _, y, v in c["primary"])
        aggregates["prior"] += prior
        aggregates["lookup"] += row["lookup"]
        counts = {}
        inits = set()
        for arm_name, result in row["arms"].items():
            training = result["training"]
            assert training["arm"] == arm_name and training["steps"] == 900
            assert training["batch"] == 64 and training["dense_positions"] == 900 * 64 * 25
            assert training["cuda_ms"] > 0 and all(math.isfinite(v) for _, v in training["losses"])
            assert training["data_sha"] == hashlib.sha256((root / f"{i:02}.json").read_bytes()).hexdigest()
            assert training["weights_sha"] not in model_hashes
            model_hashes.add(training["weights_sha"])
            inits.add(training["init_sha"])
            for split, scores in result["splits"].items():
                assert len(scores["answers"]) == len(c[split])
                correct = sum(str(answer) == y for answer, (_, y, _) in zip(scores["answers"], c[split]))
                assert correct == scores["correct"]
                aggregates[f"{arm_name}_{split}"] += correct
                if split == "primary":
                    counts[arm_name] = correct
        assert len(inits) == 1 and not initial_hashes.intersection(inits)
        initial_hashes.update(inits)
        effects.append((counts["active"] - counts["random"]) / 96)
        above_prior.append((counts["random"] - prior) / 96)

    def interval(values):
        average = statistics.mean(values)
        width = 1.7138715277470473 * statistics.stdev(values) / math.sqrt(24)
        return {"mean": average, "lower": average - width, "upper": average + width}

    diff, floor = interval(effects), interval(above_prior)
    for computed, logged in ((diff, experiment["delta"]), (floor, experiment["baseline_above_floor"])):
        assert all(math.isclose(v, logged[k], abs_tol=1e-10) for k, v in computed.items())
    verdict = "inconclusive"
    if floor["lower"] > 0 and diff["lower"] > 0.03:
        verdict = "supported"
    elif floor["lower"] > 0 and diff["upper"] < 0.03:
        verdict = "refuted"
    assert verdict == experiment["verdict"]
    print(json.dumps({"totals": aggregates, "delta": diff, "floor": floor, "verdict": verdict}, sort_keys=True))
