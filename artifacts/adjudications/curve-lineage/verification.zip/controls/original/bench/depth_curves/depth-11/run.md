# depth-curve — depth-11

- task arith · seed pairing 11 · L1 vs L2
- digit AUC 1.0000 (L1) vs 1.0000 (L2) -> |deep/shallow - 1| = 0.0000

| arm | depth | fraction | quality |
|---|---|---|---|
| digit | L1 | 0.250 | 1.0000 |
| digit | L1 | 1.000 | 1.0000 |
| digit | L2 | 0.250 | 1.0000 |
| digit | L2 | 1.000 | 1.0000 |
