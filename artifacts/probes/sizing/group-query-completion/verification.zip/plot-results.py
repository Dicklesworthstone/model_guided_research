"""Plot the fixed transfer prompts and per-presentation non-solvable query counts."""
import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

base = Path(sys.argv[1])
outfile = Path(sys.argv[2])
models = json.loads((base / 'group-rewrite/summary.json').read_bytes())['transfer']
cases = [c for c in json.loads((base / 'group-query-completion/panel.json').read_bytes())['cases'] if c['group'] in ('a5','s5')]
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,
                     'axes.titlesize':13,'axes.titleweight':'semibold','axes.labelcolor':'#25334a','text.color':'#172b45',
                     'axes.edgecolor':'#8090a1','xtick.color':'#33475c','ytick.color':'#33475c'})
fig, (ax,bx) = plt.subplots(1,2,figsize=(10.7,4.65),gridspec_kw={'width_ratios':[1.03,1.1]})
colors=['#087e73','#704ba0','#b65b24']
arms=[('Raw prompt','blind','raw'),('Verified rewrites','supervised','rewrite'),('Dictionary lookup','supervised','lookup_correct'),
      ('Self-labeled rewrites','blind','rewrite'),('Self-labeled shuffle','blind','sham')]
for y,(_,treatment,arm) in enumerate(arms):
    for j,seed in enumerate(('0','1','2')):
        row=models[seed][treatment]['s5_a5']
        assert row['n']==73
        ax.scatter(row[arm],y+(j-1)*.14,s=39,c=colors[j],edgecolors='white',linewidths=.55,zorder=3)
ax.set_yticks(range(len(arms)),[a[0] for a in arms])
ax.set_ylim(len(arms)-.5,-.5)
ax.set_xlim(-2,73)
ax.set_xticks([0,20,40,60,73])
ax.set_xlabel('Correct answers on the same 73 fresh words',labelpad=9)
ax.set_title('What survives neural transfer?',loc='left',pad=14)
ax.grid(axis='x',color='#dfe4e8',linewidth=.65)
ax.set_axisbelow(True)
ax.legend(handles=[Line2D([],[],marker='o',linestyle='',color=c,label=f'Seed {j}',markersize=5) for j,c in enumerate(colors)],
          loc='upper left',bbox_to_anchor=(-.03,-.21),ncol=3,frameon=False,handletextpad=.2,columnspacing=1)
for j,c in enumerate(cases):
    x=c['lower_bound']
    ablated=len(c['arms']['ablation']['queries'])
    complete=len(c['arms']['commuting']['queries'])
    bx.plot([x,x],[complete,ablated],color='#bcc7cf',linewidth=1,zorder=1)
    marker='o' if c['group']=='s5' else '^'
    bx.scatter(x,ablated,s=44,marker=marker,facecolors='white',edgecolors='#aa571e',linewidth=1.4,zorder=2)
    bx.scatter(x,complete,s=29,marker=marker,c='#087e73',linewidths=0,zorder=3)
bx.plot([0,33],[0,33],ls='--',color='#60728a',lw=1,zorder=0)
bx.set_xlim(-1.5,34)
bx.set_ylim(-3.5,119)
bx.set_xticks([0,5,10,15,20,25,30])
bx.set_xlabel('Lower bound from unseen label names',labelpad=9)
bx.set_ylabel('Additional endpoint labels per presentation')
bx.set_title('Cost of recovering the entire action',loc='left',pad=14)
bx.grid(axis='y',color='#dfe4e8',linewidth=.65)
bx.set_axisbelow(True)
bx.legend(handles=[Line2D([],[],marker='o',linestyle='',markerfacecolor='white',markeredgecolor='#aa571e',label='Without squares'),
                   Line2D([],[],marker='o',linestyle='',color='#087e73',label='With squares')],
          loc='upper left',bbox_to_anchor=(-.03,-.21),ncol=2,frameon=False,handletextpad=.2,columnspacing=1)
fig.subplots_adjust(left=.15,right=.982,bottom=.235,top=.88,wspace=.34)
fig.savefig(outfile,dpi=190,facecolor='white',metadata={'Software':'model_guided_research'})
