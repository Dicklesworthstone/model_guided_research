if LoadPackage("smallgrp") <> true then
  Error("SmallGrp must be loaded");
fi;
SizeScreen([4096, 100]);;
Print("[\"", GAPInfo.Version, "\",\"", PackageInfo("smallgrp")[1].Version, "\", [\n");
GroupMultiplicationTable := function(order, index)
  local group, identity, elements;
  group := SmallGroup(order, index);
  identity := One(group);
  elements := Concatenation([identity], Filtered(AsList(group), g -> g <> identity));
  return List(elements, a -> List(elements, b -> Position(elements, a * b) - 1));
end;;
first := true;;
for order in [60, 120] do
  if not SmallGroupsAvailable(order) then Error("Group order unavailable"); fi;
  for index in [1 .. NumberSmallGroups(order)] do
    if not first then Print(",\n"); fi;
    first := false;
    Print([order, index, GroupMultiplicationTable(order, index)]);
  od;
od;
Print("\n]]\n");
QUIT;
