import hashlib
import json
import sys
import zipfile
from pathlib import Path

campaign, root, destination = map(Path, sys.argv[1:])
arms = ("detached", "joint")
preflight = json.loads((root / "preflight.json").read_bytes())
panel = json.loads((root / "panel.json").read_bytes())
train, evaluation, metrics = {}, {}, {}
for arm in arms:
    train[arm] = json.loads((root / "runs" / arm / "summary.json").read_bytes())
    evaluation[arm] = json.loads((root / "evals" / arm / "summary.json").read_bytes())
    assert not train[arm]["provenance"]["tainted"]
    assert train[arm]["provenance"]["git_sha"] == evaluation[arm]["source_revision"]
    assert train[arm]["location_head_sha256"] == evaluation[arm]["location_head_sha256"]
    assert hashlib.sha256((root / "runs" / arm / "checkpoints" / "model_002047.pt").read_bytes()).hexdigest() == (
        evaluation[arm]["weights_sha256"]
    )
    metrics[arm] = {}
    for region, result in evaluation[arm]["regions"].items():
        rows = result["rows"]
        assert len(rows) == len(panel[region]) == 36
        for row, expected in zip(rows, panel[region], strict=True):
            assert row["seed"] == expected["seed"] and row["pair_index"] == expected["pair_index"]
            leaves = expected["leaves"]
            for index, query in enumerate(row["queries"]):
                assert query["actual_leaf"] == expected["labels"][index]
                assert query["actual_token_position"] == expected["candidates"][query["actual_leaf"]]
                assert query["predicted_token_position"] == expected["candidates"][query["predicted_leaf"]]
                assert query["expected"] == leaves[query["actual_leaf"]]["value"]
                assert query["position_value"] == leaves[query["predicted_leaf"]]["value"]
                words = query["expected"].split()
                assert query["greedy_correct"] == (query["greedy_reply"].split()[:len(words)] == words)
        for key, predicate in (
            ("both_positions", lambda query: query["actual_leaf"] == query["predicted_leaf"]),
            ("both_pointed_values", lambda query: query["expected"] == query["position_value"]),
            ("both_greedy", lambda query: query["greedy_correct"]),
        ):
            assert result[key] == sum(all(predicate(query) for query in row["queries"]) for row in rows)
        metrics[arm][region] = {key: value for key, value in result.items() if key != "rows"}

base, joint = (train[arm] for arm in arms)
assert base["initial_parameters_sha256"] == joint["initial_parameters_sha256"]
assert base["model_flops_est"] == joint["model_flops_est"]
assert base["settings"]["schedule_sha256"] == joint["settings"]["schedule_sha256"] == preflight["schedule_sha256"]
assert (base["settings"]["location_gradient_multiplier"], joint["settings"]["location_gradient_multiplier"]) == (0, 1)
assert all(base["settings"][key] == value for key, value in joint["settings"].items()
           if key not in {"location_gradient_multiplier", "run_id"})
control, treatment = (metrics[arm]["in_range"]["both_positions"] for arm in arms)
criteria = {"joint_at_least_18": treatment >= 18, "gain_at_least_9": treatment - control >= 9}
decision = dict(training_pairs=1, training_flops_per_arm=joint["model_flops_est"], metrics=metrics,
                criteria=criteria, advance=all(criteria.values()))
with zipfile.ZipFile(destination, "x", compression=zipfile.ZIP_DEFLATED) as archive:
    for file in ("leaf_position.py", "campaign.yaml", "run.sh", "archive.py"):
        archive.write(campaign / file, f"replay/{file}")
    for file in ("manifest.json", "panel.json", "preflight.json"):
        archive.write(root / file, file)
    for arm in arms:
        for file in (f"runs/{arm}/summary.json", f"runs/{arm}/checkpoints/meta_002047.json",
                     f"evals/{arm}/summary.json"):
            archive.write(root / file, file)
    tokenizer = root / "runs" / "joint" / "checkpoints" / "tokenizer" / "tokenizer.json"
    assert hashlib.sha256(tokenizer.read_bytes()).hexdigest() == preflight["tokenizer_sha256"]
    archive.write(tokenizer, "tokenizer.json")
    for receipt in sorted((campaign / "receipts").glob("*/*/receipt.json")):
        data = json.loads(receipt.read_bytes())
        assert data["status"] == "passed"
        for check in data["checks"]:
            path = Path(check["log_path"])
            assert hashlib.sha256(path.read_bytes()).hexdigest() == check["log_sha256"]
            archive.write(path, str(path.relative_to(campaign)))
        archive.write(receipt, str(receipt.relative_to(campaign)))
        snapshot = receipt.with_name("checks-config.yaml")
        archive.write(snapshot, str(snapshot.relative_to(campaign)))
    archive.writestr("decision.json", json.dumps(decision, indent=2) + "\n")
print(json.dumps(decision, indent=2))
