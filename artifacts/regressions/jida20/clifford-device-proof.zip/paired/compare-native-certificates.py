import json
from pathlib import Path
import sys

previous, fixed, cpu = (json.loads(Path(p).read_bytes()) for p in sys.argv[1:])
assert previous["device"] == fixed["device"] == "cuda" and cpu["device"] == "cpu"
assert previous["git"]["commit"] == "bc470ab" and fixed["git"]["commit"] == cpu["git"]["commit"] == "95e8d47"
assert all(not item["git"]["dirty"] and item["dtype"] == "fp32" and item["seed"] == 42 for item in (previous, fixed, cpu))
assert previous["mechanisms"] == fixed["mechanisms"] == cpu["mechanisms"] and len(cpu["mechanisms"]) == 13

def by_check(certificate):
    checks = {(row["mechanism"], row["check"]): row for row in certificate["checks"]}
    assert len(checks) == len(certificate["checks"]) == 72
    return checks

old, new, reference = map(by_check, (previous, fixed, cpu))
assert set(old) == set(new) == set(reference)
errors = {key for key, check in old.items() if check["status"] != "pass"}
assert len(errors) == 5 and all(key[0] == "clifford" and old[key]["status"] == "error" for key in errors)
for key in old:
    for field in ("tolerance", "comparator", "family"):
        assert old[key][field] == new[key][field] == reference[key][field]
    assert new[key]["status"] == reference[key]["status"] == "pass"
print("Replayed 72 check definitions, comparators and tolerances across all three certificates.")
print("Five Clifford CUDA errors became passes. All 67 previous passes held. CPU passed 72/72.")
