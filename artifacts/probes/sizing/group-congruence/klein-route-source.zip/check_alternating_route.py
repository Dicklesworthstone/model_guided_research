"""Freeze the matched panel and independently audit the A5 x C2 branch."""

import argparse
import hashlib
import json
import random
from collections import Counter
from itertools import product
from pathlib import Path

from check_short_certificate import action, answers, checksum, elements, plain, read, validate_tape

SEED = 251753
PANEL = Path("artifacts/probes/sizing/group-congruence")
PRIOR = tuple(Path("artifacts/probes/sizing") / name for name in (
    "group-live-speculation/coverage.json", "group-order-free/coverage.json",
    "group-certificate/coverage.json", "group-query-completion/panel.json",
    "group-congruence/coverage.json", "group-congruence/proposal-coverage.json",
    "group-congruence/short-certificate-coverage.json", "group-congruence/abelian-route-coverage.json",
))
FRESH = ("a5xc2", "s3xc20")
CONTROLS = ("c120", "s5")


def digests(value):
    if isinstance(value, str) and len(value) == 64 and all(symbol in "0123456789abcdef" for symbol in value):
        yield value
    elif isinstance(value, list):
        for item in value:
            yield from digests(item)
    elif isinstance(value, dict):
        for item in value.values():
            yield from digests(item)


def make_panel(root):
    excluded = {identifier for path in PRIOR for identifier in digests(read(root / path))}
    rng = random.Random(SEED)
    cases = []
    for family in FRESH:
        pool = elements(family)
        found = 0
        for _ in range(10_000):
            marks = [rng.choice(pool), rng.choice(pool)]
            table, _ = action(family, marks)
            identifier = checksum(table)
            if len(table) != 120 or identifier in excluded:
                continue
            cases.append(dict(family=family, marks=list(map(list, marks)), graph=table, graph_sha=identifier))
            excluded.add(identifier)
            found += 1
            if found == 6:
                break
        if found != 6:
            raise ValueError(f"Insufficient fresh cases for {family}")
    previous = read(root / PANEL / "abelian-route-coverage.json")["cases"]
    for family in CONTROLS:
        cases.extend([row for row in previous if row["family"] == family][:4])
    return dict(seed=SEED, cases=cases)


def key(left, right):
    while left and right and left[0] == right[0]:
        left, right = left[1:], right[1:]
    while left and right and left[-1] == right[-1]:
        left, right = left[:-1], right[:-1]
    return tuple(sorted((left, right)))


def witness_questions(witness):
    a, b, z = witness["basis"]
    u, v = witness["bindings"]
    return list(dict.fromkeys(key(x, y) for x, y in (
        (a * 2, ""), (b * 3, ""), ((a + b) * 5, ""), (z * 2, ""),
        (a + z, z + a), (b + z, z + b), ("0", u), ("1", v),
    ) if x != y))


def catalogue(family):
    found = {}
    triples = {}
    for marks in product(elements(family), repeat=2):
        table, _ = action(family, marks)
        if len(table) != 120:
            continue
        identifier = checksum(table)
        found[identifier] = table
        if family == "a5xc2":
            projection, _ = action(family, tuple(p[:-1] + (0,) for p in marks))
            triples.setdefault(checksum(projection), set()).add(identifier)
    return found, triples


def audit_attempt(graph, attempt, tables, certificates):
    remaining = set(tables)
    paid = []
    observed = {}
    for row in attempt["proposal"]["queries"]:
        left, right = row["pair"]
        yes = {identifier for identifier in remaining if answers(tables[identifier], row["pair"])}
        answer = answers(graph, row["pair"])
        if not 0 < len(yes) < len(remaining) or row != dict(
            pair=[left, right], candidates=len(remaining), predicted_yes=len(yes), answer=answer,
        ):
            raise ValueError("Invalid selection split")
        remaining = yes if answer else remaining - yes
        paid.append([left, right, answer])
        observed[tuple(sorted((left, right)))] = answer
    identifier = attempt["proposal"]["marked_class"]
    if remaining != {identifier} or len(paid) > 7:
        raise ValueError("Selection failed to identify a unique leaf within seven calls")
    expected = []
    for left, right in certificates[identifier]:
        reused = (left, right) in observed
        answer = answers(graph, (left, right))
        expected.append(dict(pair=[left, right], answer=answer, reused=reused))
        if not reused:
            paid.append([left, right, answer])
        if not answer:
            break
    if not expected or attempt["checks"] != expected or attempt["accepted"] != expected[-1]["answer"]:
        raise ValueError("Incorrect verified certificate trace")
    return paid


def audit_selector(tables):
    from scripts.group_student_probe import compile_known_family, plan_compiled_family

    ordered = dict(sorted(tables.items()))
    try:
        compile_known_family(ordered)
    except ValueError as error:
        if "could not attain the binary bound" not in str(error):
            raise
    else:
        raise ValueError("The preflight failure at six calls did not reproduce")
    tree = compile_known_family(ordered, max_depth=7)
    depths = Counter()
    for expected, table in tables.items():
        plan = plan_compiled_family(tree)
        paid = 0
        try:
            question = next(plan)
            while True:
                paid += 1
                question = plan.send(answers(table, question))
        except StopIteration as entry:
            if entry.value["marked_class"] != expected or paid != len(entry.value["queries"]) or paid > 7:
                raise ValueError("The full catalogue failed to replay within seven queries") from entry
        depths[paid] += 1
    return dict(sorted(depths.items()))


def audit(root, coverage, scored, replay, incumbent, prior):
    manifest, scored, replay, incumbent, prior = map(read, (coverage, scored, replay, incumbent, prior))
    if manifest != make_panel(root) or scored["coverage_sha256"] != hashlib.sha256(coverage.read_bytes()).hexdigest():
        raise ValueError("Scored the wrong cohort")
    current, repeat = plain(scored), plain(replay)
    del current["alternating_cpu_ns"], repeat["alternating_cpu_ns"]
    if current != repeat:
        raise ValueError("Hash-seed replay mismatch")
    witnesses = current.pop("alternating_certificates")
    alternating, triples = catalogue("a5xc2")
    s5, _ = catalogue("s5")
    if len(s5) != len(alternating) or len(alternating) != 57 or set(witnesses) != set(alternating):
        raise ValueError("Exhaustive catalogue differs from the producer")
    observed_triples = set().union(*triples.values())
    if len(triples) != 19 or any(len(triple) != 3 for triple in triples.values()) or observed_triples != set(alternating):
        raise ValueError("The central-lift fibres are not 19 disjoint triples")
    controls = {case["graph_sha"]: case["graph"] for case in manifest["cases"] if case["family"] in {"s3xc20", "c120"}}
    targets = alternating | s5 | controls
    wrong = 0
    certificates = {}
    for identifier, witness in witnesses.items():
        questions = witness_questions(witness)
        if not 1 <= len(questions) <= 7 or list(map(list, questions)) != witness["questions"]:
            raise ValueError("Transport lost or replaced a presentation equation")
        certificates[identifier] = questions
        for target, graph in targets.items():
            if all(answers(graph, pair) for pair in questions) != (identifier == target):
                raise ValueError("The certificate accepted a wrong marking or rejected its own")
            wrong += identifier != target

    old_arms = {row["graph_sha"]: row["arms"]["routed"] for row in plain(prior)["results"]}
    arms = ("fallback", "edge", "short", "routed", "extended")
    totals = {family: {arm: Counter() for arm in arms} for family in (*FRESH, *CONTROLS)}
    for item, row in zip(manifest["cases"], scored["results"], strict=True):
        family, identifier = item["family"], item["graph_sha"]
        graph, _ = action(family, item["marks"])
        if graph != item["graph"] or checksum(graph) != identifier or (family, identifier) != (row["family"], row["graph_sha"]):
            raise ValueError("Input cannot be reconstructed")
        if set(row["arms"]) != set(arms):
            raise ValueError("Missing comparison arm")
        for arm in row["arms"].values():
            validate_tape(graph, arm["paid"])
            if arm["right"] != graph:
                raise ValueError("Wrong output table")
        for name, cost in totals[family].items():
            arm = row["arms"][name]
            cost.update(calls=len(arm["paid"]), symbols=sum(len(a) + len(b) for a, b, _ in arm["paid"]), cpu_ns=arm["cpu_ns"])

    case_costs = []
    for row in current["results"]:
        extended = row["arms"].pop("extended")
        routed = row["arms"]["routed"]
        family = row["family"]
        if family in CONTROLS:
            if extended != routed or routed != old_arms[row["graph_sha"]]:
                raise ValueError("A previously solved control changed")
            continue
        tail = row["arms"]["fallback"]["paid"]
        previous_prefix = routed["paid"][:-len(tail)]
        accepted = family == "a5xc2"
        attempt = extended["alternating"]
        paid = audit_attempt(extended["right"], attempt, alternating, certificates)
        if (not previous_prefix or previous_prefix[0] != ["01", "10", False] or routed["accepted"]
                or routed["paid"] != previous_prefix + tail or attempt["accepted"] is not accepted
                or any(extended[field] != routed[field] for field in ("proposal", "checks", "accepted"))):
            raise ValueError("Incorrect order or fallback use for a non-S5 case")
        if extended["paid"] != previous_prefix + paid + ([] if accepted else tail) or len(paid) > 14:
            raise ValueError("Unaccounted paid comparison or excessive overhead")
        if accepted and attempt["proposal"]["marked_class"] != row["graph_sha"]:
            raise ValueError("Certified a different marking")
        case_costs.append(dict(family=family, routed=len(routed["paid"]), extended=len(extended["paid"]), extra=len(paid)))
    if current != plain(incumbent):
        raise ValueError("Opt-in changed the incumbent outputs")

    left, right, answer = current["results"][0]["arms"]["routed"]["paid"][0]
    try:
        validate_tape(manifest["cases"][0]["graph"], [[left, right, not answer]])
    except ValueError:
        pass
    else:
        raise ValueError("A corrupted oracle reply passed")
    target = totals["a5xc2"]
    print(json.dumps(dict(
        exact_replay=True, incumbent_unchanged=True, corrupted_reply_rejected=True,
        checked_transitions=20 * 120 * 2 * 5, triples=len(triples), marked_actions=len(alternating),
        wrong_certificates_rejected=wrong, gate=10 * target["extended"]["calls"] <= target["routed"]["calls"],
        totals=totals, case_costs=case_costs, selector_depths=audit_selector(alternating),
    ), indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    modes = parser.add_subparsers(dest="mode", required=True)
    for name in ("cover", "audit"):
        mode = modes.add_parser(name)
        mode.add_argument("root", type=Path)
        mode.add_argument("coverage", type=Path)
    for name in ("scored", "replay", "incumbent", "prior"):
        mode.add_argument(name, type=Path)
    args = parser.parse_args()
    if args.mode == "cover":
        with args.coverage.open("x", encoding="utf-8") as file:
            json.dump(make_panel(args.root), file, sort_keys=True)
            file.write("\n")
    else:
        audit(args.root, args.coverage, args.scored, args.replay, args.incumbent, args.prior)
