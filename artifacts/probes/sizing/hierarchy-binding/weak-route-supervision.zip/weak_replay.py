import json
import math
import random
import statistics
import sys
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

from recount import CELLS, chosen, local_gate, parse, sha

SOURCE = "6e7ca48165363a1c0cef29d39f5e908d55c9c0df"
FROZEN = "a9adc9ad3ac39fd4b79ce3a8e9b4993cb879bd255363bcf2ce1b14bf7d643cf2"
WEIGHTS = {
    "8831": "3ef4f613c2f2bfb372013d53490e918140fba01208afdf07070cc4c9a602d27f",
    "8832": "4a44f1fe1baa6adf1aba38f1cb8a7edc9e534e85df75c20d51fb0cc93b32c1e7",
    "8833": "ebd4a8d25e102c08f03dbddd7ef271b08693fb55ec76f372c439d0eaf867f19a",
}
PANEL = ("7401", "7402", "7403")
ARMS = ("initial", "exact", "marginal", "hard")
FILES = (
    "addressed.py", "binding_score.py", "recount.py", "weak_route.py", "weak_replay.py", "weak.yaml",
    "weak.sha256", "protocol.txt", "panel.json", "panel.sha256", "identifiability.md",
    *(f"fit-{seed}.json" for seed in WEIGHTS),
)


def check_receipt(read, names):
    path, = (name for name in names if name.endswith("/receipt.json"))
    receipt = json.loads(read(path))
    assert receipt["tool"] == "hierarchy-weak-terminal" and receipt["status"] == "passed"
    assert receipt["executed"] == receipt["passed"] == receipt["total"] == 2
    assert not receipt["dry_run"] and not receipt["skipped"]
    for entry in receipt["checks"]:
        assert entry["passed"] and entry["executed"] and entry["exit_code"] == 0
        log = Path(path).with_name(Path(entry["log_path"]).name).as_posix()
        assert sha(read(log)) == entry["log_sha256"]
    config = Path(path).with_name("checks-config.yaml").as_posix()
    assert read(config) == read("weak.yaml")
    assert sha(read(config)) == receipt["config_sha256"] == receipt["config_sha256_after"]
    return Path(path).parent.name


def run_route(book, query, gold):
    greedy = 0
    correct = 0
    output = []
    nll = 0.0
    for alias, target in zip(query, gold, strict=True):
        pick = chosen(book[greedy][alias])
        output.append(pick)
        nll -= book[correct][alias][target]
        greedy = 2 * greedy + 1 + pick
        correct = 2 * correct + 1 + target
    return tuple(output) == gold, nll


def validate_docs(docs, depth):
    cases = [parse(doc) for doc in docs]
    assert len(cases) == 72
    for left, right in zip(cases[::2], cases[1::2], strict=True):
        query, gold, before, _ = left
        other_query, other_gold, after, _ = right
        assert len(query) == len(gold) == len(other_gold) == depth
        assert query == other_query and gold != other_gold
        edited, = (scope for scope in before if before[scope] != after[scope])
        hop = len(edited)
        assert gold[:hop] == edited == other_gold[:hop]
        assert gold[hop] != other_gold[hop]
        a, k, b, v = before[edited]
        assert after[edited] == (a, v, b, k)
    return cases


def verify_cell(cases, raw, exhaustive):
    books, erased = raw["rows"], raw["erased"]
    assert len(books) == len(erased) == len(cases)
    assert erased[::2] == erased[1::2]
    exact, unbound, nlls = [], [], []
    for (query, gold, _by_scope, ordered), book, broken in zip(cases, books, erased, strict=True):
        assert len(book) == len(ordered) == len(broken)
        for table, (a, k, b, j), erased_table in zip(book, ordered, broken, strict=True):
            assert {a, b} == {k, j} == {0, 1}
            assert table == exhaustive[2 * a + (a ^ k)]
            assert erased_table == exhaustive[2 * a]
            for matrix in (table, erased_table):
                assert len(matrix) == 2 and all(len(row) == 2 and all(map(math.isfinite, row)) and
                                               abs(sum(map(math.exp, row)) - 1) <= 2e-6 for row in matrix)
        good, nll = run_route(book, query, gold)
        blind, _ = run_route(broken, query, gold)
        exact.append(good)
        unbound.append(blind)
        nlls.append(nll)
    pairs = sum(a and b for a, b in zip(exact[::2], exact[1::2], strict=True))
    blind_pairs = sum(a and b for a, b in zip(unbound[::2], unbound[1::2], strict=True))
    return dict(routes=sum(exact), pairs=pairs, erased_pairs=blind_pairs, true_route_nll=statistics.mean(nlls))


def replay(read, names):
    lock = read("weak.sha256")
    assert sha(lock) == FROZEN
    for row in lock.decode().splitlines():
        digest, path = row.split()
        assert sha(read(path)) == digest
    panel_bytes = read("panel.json")
    panel_hash = sha(panel_bytes)
    assert panel_hash == read("panel.sha256").decode().split()[0]
    panel = json.loads(panel_bytes)
    assert tuple(panel) == PANEL and all(tuple(panel[seed]) == CELLS for seed in PANEL)
    cases = {cell: validate_docs([doc for seed in PANEL for doc in panel[seed][cell]], index + 2)
             for index, cell in enumerate(CELLS)}
    coloring_rng = random.Random(80761)
    colorings = bytearray()
    for _ in range(768):
        members = coloring_rng.sample(range(4), 2)
        colorings.extend([int(leaf in members) for leaf in range(4)] * 2)
    results = {}
    same_colors = None
    for seed, weights in WEIGHTS.items():
        raw = json.loads(read(f"fit-{seed}.json"))
        assert raw["checkpoint"] == weights and raw["panel_sha256"] == panel_hash
        assert raw["train_rows"] == 1536 and raw["updates"] == 288
        assert raw["colorings_sha256"] == sha(colorings)
        if same_colors is None:
            same_colors = raw["paired_same_color"]
        assert raw["paired_same_color"] == same_colors and 0 < same_colors < 768
        assert tuple(raw["outcomes"]) == ARMS
        per_arm = {}
        for name, fit in raw["outcomes"].items():
            local, _ = local_gate(fit)
            measured = {cell: verify_cell(cases[cell], fit["cells"][cell], fit["exhaustive"]) for cell in CELLS}
            gain = per_arm["initial"]["cells"]["depth2"]["true_route_nll"] - measured["depth2"]["true_route_nll"] if name != "initial" else 0.0
            passed = local["passes"] and gain >= .10 and all(
                row["pairs"] >= 34 and row["erased_pairs"] == 0 for row in measured.values()
            )
            per_arm[name] = dict(local=local, cells=measured, depth2_nll_gain=gain, passed=passed)
        results[seed] = per_arm
    exact_pass = all(arms["exact"]["passed"] for arms in results.values())
    marginal_pass = all(arms["marginal"]["passed"] for arms in results.values())
    return dict(source=SOURCE, fit_receipt=check_receipt(read, names), panel_hash=panel_hash, trees=108,
                pair_denom_per_arm=324, train_pairs_same_color=same_colors, exact_pass=exact_pass,
                marginal_pass=marginal_pass, eligible=exact_pass and marginal_pass, results=results)


def verify(bundle):
    with ZipFile(bundle) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names)) and archive.testzip() is None
        decision = replay(archive.read, names)
        assert decision == json.loads(archive.read("decision.json"))
    print(json.dumps(decision))


def build(root, bundle):
    files = {name: root / name for name in FILES}
    receipt, = (root / "receipts").glob("*/*/receipt.json")
    for name in ("receipt.json", "check-1.log", "check-2.log", "checks-config.yaml"):
        path = receipt.with_name(name)
        files[path.relative_to(root).as_posix()] = path
    decision = replay(lambda name: files[name].read_bytes(), files.keys())
    with ZipFile(bundle, "x", compression=ZIP_DEFLATED) as archive:
        for name, path in files.items():
            archive.write(path, name)
        archive.writestr("decision.json", json.dumps(decision, indent=2) + "\n")
    print(json.dumps(decision))


if __name__ == "__main__":
    mode, *args = sys.argv[1:]
    {"build": build, "verify": verify}[mode](*map(Path, args))
