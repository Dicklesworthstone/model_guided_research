import hashlib
import json
import math
import statistics
import sys
from collections import Counter
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

CELLS = ("native", "reordered", "mixed2", "depth3", "reordered3")
BACKBONES = (30, 31, 32)
ARMS = ("context", "embedding")
STARTS = (101, 102, 103)
TOOLS = {"routing-feature-panel": ["failed", "passed"], "routing-feature-transfer": ["failed"],
         "routing-feature-transfer-v2": ["passed"]}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def route(edges, matrix):
    prefix = []
    for scores in matrix:
        candidates = [index for index, edge in enumerate(edges) if edge[:-1] == prefix]
        if not candidates:
            return None
        winner = sorted(candidates, key=lambda index: (-scores[index], index))[0]
        prefix = edges[winner]
    return prefix


def recalculate(panel, scored):
    names = ("token", "cosine", *(f"{arm}_{seed}" for arm in ARMS for seed in STARTS))
    counts = {name: {cell: {"all_four": 0, "correct": 0, "gold_parent": [0] * (3 if cell in CELLS[-2:] else 2)}
                     for cell in CELLS} for name in names}
    planted_negative = False
    for block, logits in zip(panel["blocks"], scored["scores"], strict=True):
        assert set(logits) == set(CELLS)
        for cell, results in logits.items():
            assert set(results) == set(names)
            case = block[cell]
            paths, pos, rows = case["edge_paths"], case["edge_positions"], case["rows"]
            assert len(paths) == len(pos) == len({tuple(path) for path in paths})
            assert len(rows) == 4 and len(case["leaves"]) == 9
            for name, matrices in results.items():
                hit_count = 0
                total = counts[name][cell]
                for row, matrix in zip(rows, matrices, strict=True):
                    ids, path = row["ids"], row["route"]
                    assert len(ids) <= 128 and case["leaves"][row["expected"]] == path
                    assert len(matrix) == len(path) == len(row["query_keys"]) == len(total["gold_parent"])
                    assert all(len(scores) == len(paths) and all(map(math.isfinite, scores)) for scores in matrix)
                    if name == "token":
                        expected = [[int(ids[query] == ids[p]) for p in pos] for query in row["query_keys"]]
                        assert matrix == expected
                        if not planted_negative:
                            wrong = next(i for i, edge in enumerate(paths) if len(edge) == 1 and edge[0] != path[0])
                            corrupt = [[2 if i == wrong else score for i, score in enumerate(matrix[0])], *matrix[1:]]
                            assert route(paths, matrix) == path and route(paths, corrupt) != path
                            planted_negative = True
                    hit_count += route(paths, matrix) == path
                    for hop, scores in enumerate(matrix):
                        options = [i for i, edge in enumerate(paths) if edge[:-1] == path[:hop]]
                        winner = sorted(options, key=lambda i: (-scores[i], i))[0]
                        total["gold_parent"][hop] += paths[winner] == path[:hop + 1]
                total["correct"] += hit_count
                total["all_four"] += hit_count == 4
    assert planted_negative and counts == scored["counts"]
    assert all(counts[arm][cell]["correct"] == 144 for arm in ("cosine", "token") for cell in CELLS)
    return counts


def verify(archive, history):
    names = archive.namelist()
    assert archive.testzip() is None and len(names) == len(set(names))
    assert not any(name.endswith((".pt", ".parquet", ".safetensors")) for name in names)
    read = archive.read
    loads = lambda name: json.loads(read(name))
    for manifest, expected in (
        ("frozen.sha256", "65764cbc6c87476955db7ac4e3712a52eeab189002845eff185907fa1610cc7a"),
        ("frozen-v2.sha256", "7c4353414ffaafbf9bd0d399d91ce96c2c71182117b5ae9cee5ba5f3b5c6fe41"),
    ):
        assert sha(read(manifest)) == expected
        for item in read(manifest).decode().splitlines():
            digest, path = item.split()
            assert sha(read(path)) == digest
    panel_hash = sha(read("panel.json"))
    assert panel_hash == "fade49af8fd01544e7206bff8b152521d6e41f486a9305aa43a342177b49513e"
    panel = loads("panel.json")
    assert Counter(block["seed"] for block in panel["blocks"]) == {94: 12, 95: 12, 96: 12}
    assert len({block[cell]["text"] for block in panel["blocks"] for cell in CELLS}) == 144
    terminal = {tool: [] for tool in TOOLS}
    for name in names:
        if not name.endswith("/receipt.json"):
            continue
        tool = name.split("/")[1]
        receipt = loads(name)
        assert len(receipt["checks"]) == 1
        check = receipt["checks"][0]
        assert sha(read(str(Path(name).with_name(Path(check["log_path"]).name)))) == check["log_sha256"]
        terminal[tool].append(receipt["status"])
    assert {tool: sorted(states) for tool, states in terminal.items()} == TOOLS
    medians, deltas = {}, {}
    for backbone in BACKBONES:
        raw = loads(f"backbone-{backbone}.json")
        assert raw["panel_sha256"] == panel_hash and raw["fit_rows"] == 1536
        branch = f"seed-{backbone}"
        training = json.loads(history.read(f"{branch}/runs/augmented/summary.json"))
        schedule = json.loads(history.read(f"{branch}/preflight.json"))
        assert sha(history.read("tokenizer.json")) == panel["tokenizer_sha256"] == schedule["tokenizer_sha256"]
        assert training["weights_sha256"] == raw["weight_sha256"]
        assert training["provenance"]["git_sha"] == raw["training_sha"] and not training["provenance"]["tainted"]
        assert schedule["permuted_sha256"] == raw["schedule_sha256"]
        counts = recalculate(panel, raw)
        columns = {arm: {cell: [counts[f"{arm}_{seed}"][cell]["all_four"] for seed in STARTS]
                         for cell in CELLS} for arm in ARMS}
        medians[str(backbone)] = {arm: {cell: statistics.median(values) for cell, values in cells.items()}
                                  for arm, cells in columns.items()}
        deltas[str(backbone)] = {cell: statistics.median(
            x - y for x, y in zip(columns["context"][cell], columns["embedding"][cell], strict=True)
        ) for cell in CELLS}
    result = loads("decision.json")
    assert result["medians"] == medians and result["paired_median_deltas"] == deltas
    competence = all(arm["native"] >= 32 for row in medians.values() for arm in row.values())
    deep = CELLS[-2:]
    assert result["eligible"] == competence
    assert result["contextual_advantage"] == (competence and min(
        min(medians[b]["context"][c] - 32, deltas[b][c] - 4) for b in medians for c in deep
    ) >= 0)
    assert result["embedding_suffices"] == (competence and min(
        min(medians[b]["embedding"][c] - 32, 2 - deltas[b][c]) for b in medians for c in deep
    ) >= 0)
    print(json.dumps(dict(recounted_backbones=3, cells_per_backbone=5, layouts_per_cell=36,
                          queries_per_cell=144, scorers_per_cell=8, planted_negatives=3,
                          terminal=terminal, decision=result)))


def bundle(root, target, history_path):
    paths = [root / name for name in (
        "campaign.yaml", "run.sh", "transfer-v2.yaml", "panel.json", "panel.sha256",
        "frozen.sha256", "frozen-v2.sha256", "protocol.txt", "recount.py", "decision.json", "REPLAY.md",
    )]
    for pattern in ("replay/*.py", "replay-v2/*.py", "receipts/*/*/receipt.json",
                    "receipts/*/*/check-1.log", "receipts/*/*/checks-config.yaml", "backbone-*.json"):
        paths.extend(sorted(root.glob(pattern)))
    with ZipFile(target, "x", compression=ZIP_DEFLATED) as out:
        for path in paths:
            out.write(path, path.relative_to(root))
    with ZipFile(target) as out, ZipFile(history_path) as history:
        verify(out, history)


if __name__ == "__main__":
    mode, *paths = sys.argv[1:]
    if mode == "bundle":
        bundle(*map(Path, paths))
    elif mode == "verify":
        with ZipFile(paths[0]) as archive, ZipFile(paths[1]) as history:
            verify(archive, history)
    else:
        raise ValueError(mode)
