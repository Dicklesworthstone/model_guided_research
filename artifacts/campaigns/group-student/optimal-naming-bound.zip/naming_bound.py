"""Bound the remaining value of planning by giving the true shape away."""

import argparse
import json
from pathlib import Path
from zipfile import ZipFile

from bench_optimal import ANCHORS, READ_PRICE, inventory, summary

RESULTS = "artifacts/campaigns/group-student/optimal-initial-results.zip"


def bound(graph):
    reached = set()
    for first, second in ANCHORS:
        reached.add(graph[second][graph[first][0]])
    layer = reached
    naming = []
    length = 2
    size = len(graph["0"])
    while len(reached) < size:
        layer = {graph[mark][state] for mark in ("0", "1") for state in layer} - reached
        if not layer:
            raise ValueError("Action is not reachable from its anchors")
        length += 1
        naming.extend([READ_PRICE + length] * len(layer))
        reached |= layer
    return len(ANCHORS) * (READ_PRICE + 2) + sum(naming[:-1])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("work", type=Path)
    args = parser.parse_args()
    with ZipFile(args.work / RESULTS) as archive:
        forward = json.loads(archive.read("scored.json"))
        replay = json.loads(archive.read("replay.json"))
    verified = summary(args.work, forward, replay)
    output = {}
    for n, graphs in inventory(args.work).items():
        entry = verified["orders"][str(n)]
        floor = sum(map(bound, graphs))
        greedy = min(entry["arms"][arm]["cost"] for arm in ("shortlist", "frontier"))
        exact = entry["arms"]["optimal"].get("cost")
        if floor > greedy or (exact is not None and not floor <= exact <= greedy):
            raise ValueError(f"Inconsistent lower bound at order {n}")
        output[n] = {
            "shapes": len(graphs),
            "known_shape_minimum": floor,
            "greedy_cost": greedy,
            "maximum_savings_from_greedy": greedy - floor,
            "closed_oracle_optimum": exact,
        }
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
