"""Check a canonical DSR run against the checkout, the certificate, and recorded logs."""
import hashlib
import json
from pathlib import Path
import re
import sys

logs, repo, cert, status, expected_source = sys.argv[1:6]
fast, full, fast_skips, full_skips = map(int, sys.argv[6:] or (837, 929, 2, 3))
root = Path(logs)
repo = Path(repo)
receipt = json.loads((root / "receipt.json").read_bytes())
assert receipt["status"] == "passed" and receipt["failed"] == 0
assert not receipt["dry_run"] and not receipt["skipped"]
assert receipt["observed"] == receipt["total"] == receipt["executed"] == receipt["passed"] == 11
assert receipt["source_before"] == receipt["source_after"]
assert receipt["source_before"].split("|")[0] == expected_source
snapshot = (root / "checks-config.yaml").read_bytes()
assert receipt["config_sha256"] == receipt["config_sha256_after"] == hashlib.sha256(snapshot).hexdigest()
assert snapshot == (repo / "dsr.yaml").read_bytes()
outputs = {}
assert len(receipt["checks"]) == 11
for i, check in enumerate(receipt["checks"], 1):
    filename = f"check-{i}.log"
    log = (root / filename).read_bytes()
    assert Path(check["log_path"]).name == filename and hashlib.sha256(log).hexdigest() == check["log_sha256"]
    assert check["passed"] and check["executed"] and check["exit_code"] == 0
    outputs[i] = log.decode()

assert f"{fast} passed, {fast_skips} skipped, 93 deselected" in outputs[4]
assert f"{full} passed, {full_skips} skipped" in outputs[5]
if expected_source == "bc470ab5b476ba2cf5bfe19e5a7ae9797da4a527":
    assert (fast, full, fast_skips, full_skips) == (827, 919, 14, 15)
    for run_name, expected_passes in (("pinned-trajectories", 12), ("pinned-eval", 1)):
        lane = root / run_name
        evidence = json.loads((lane / "receipt.json").read_bytes())
        assert evidence["source_before"] == evidence["source_after"]
        assert evidence["source_before"].split("|")[0] == expected_source
        assert evidence["status"] == "passed" and evidence["failed"] == 0
        assert hashlib.sha256((lane / "checks-config.yaml").read_bytes()).hexdigest() == evidence["config_sha256"]
        for index, check in enumerate(evidence["checks"], 1):
            raw = (lane / f"check-{index}.log").read_bytes()
            assert check["passed"] and hashlib.sha256(raw).hexdigest() == check["log_sha256"]
        assert f"{expected_passes} passed in " in raw.decode()
certificate = json.loads((repo / cert).read_bytes())
assert certificate["git"]["commit_full"] == expected_source and not certificate["git"]["dirty"]
assert certificate["counts"] == {"pass": 72, "fail": 0, "error": 0} and len(certificate["mechanisms"]) == 13
for mech in certificate["mechanisms"]:
    assert re.search(rf"│ determinism-{mech}\s+│ pass", outputs[8]), mech
for scenario in ("full-loop", "resume", "determinism", "regression-gate", "scorecard", "word-problem", "symplectic"):
    assert re.search(rf"│ {scenario}\s+│ PASS", outputs[8]), scenario
for result in ("Successful: 13", "Failed: 0", "Attempted: 13", "Skipped: 0", "Total: 13"):
    assert result in outputs[9].splitlines()
axioms = (root / "axioms.txt").read_text()
assert "sorryAx" not in axioms and sum(("depends on axioms" in line or "does not depend on any axioms" in line)
                                      for line in axioms.splitlines()) == 13
assert "Installed mechanisms exercised: 13" in outputs[11].splitlines()
public = json.loads(Path(status).read_bytes())
assert not public["git"]["dirty"]
selected = public["certificates"]
assert {r["mechanism"] for r in selected} == set(certificate["mechanisms"]) and len(selected) == 13
assert all(r["cert_path"] == cert and not r["stale"] for r in selected)
print(f"Verified all 11 commands and SHA256s, {fast} fast and {full} full passes, 72 algebra checks, "
      "7 E2E scenarios, 13 determinism checks, demos, Lean declarations and installed mechanisms, "
      "and public certificate selection for all 13.")
