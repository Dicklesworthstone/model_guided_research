"""Match a catalogue using exact partial right-action constraints."""

from collections import defaultdict
from dataclasses import dataclass

import numpy as np
from catalogue_replay import WORDS, Labelled, named_action, reach

from scripts.group_rewrite_probe import transitions

PERIOD_WORDS = ("0", "1", "01", "001", "011")


@dataclass(frozen=True)
class Constraints:
    labels: tuple[str, ...]
    anchors: tuple[int, ...]
    steps: tuple[tuple[int, int, int], ...]
    edges: np.ndarray
    periods: tuple[tuple[int, int | None], ...]


def path_period(mapping):
    """Use the disjoint paths and cycles of an injective partial map."""
    pending = set(mapping)
    longest = 1
    for start in pending.difference(mapping.values()):
        length = 1
        while start in pending:
            pending.remove(start)
            start = mapping[start]
            length += 1
        longest = max(longest, length)
    periods = set()
    while pending:
        start = next(iter(pending))
        length = 0
        while start in pending:
            pending.remove(start)
            start = mapping[start]
            length += 1
        periods.add(length)
    exact = next(iter(periods)) if periods else None
    if len(periods) > 1 or (exact is not None and exact < longest):
        return None
    return longest, exact


def partial_word(columns, word):
    mapped = columns[int(word[0])]
    for mark in word[1:]:
        column = columns[int(mark)]
        mapped = {src: column[mid] for src, mid in mapped.items() if mid in column}
    return mapped


def compile_constraints(observed):
    try:
        edges = transitions(observed)
    except ValueError:
        return None
    columns = tuple({source: dest for (source, letter), dest in edges.items() if letter == mark} for mark in "01")
    if any(len(set(column.values())) != len(column) for column in columns):
        return None
    periods = tuple(path_period(partial_word(columns, word)) for word in PERIOD_WORDS)
    if any(bound is None for bound in periods):
        return None
    names: dict[str, int] = {}
    steps = []
    for word in WORDS:
        label = observed[word]
        if label in names:
            continue
        names[label] = len(names)
        if len(word) > 2:
            steps.append((names[observed[word[:-1]]], int(word[-1]), names[label]))
    roots = tuple(names[observed[word]] for word in WORDS[:4])
    forest = set(steps)
    constraints = [(names[src], int(mark), names[dst]) for (src, mark), dst in edges.items()]
    checks = np.asarray([edge for edge in constraints if edge not in forest], dtype=np.intp).reshape(-1, 3).T
    return Constraints(tuple(names), roots, tuple(steps), checks, tuple(bound for bound in periods if bound is not None))


def element_periods(table):
    marks = np.arange(len(table))
    current = marks
    periods = np.zeros(len(table), dtype=np.intp)
    for power in range(1, len(table) + 1):
        periods[(current == 0) & (periods == 0)] = power
        if periods.all():
            return periods
        current = table[current, marks]
    raise ValueError("The supplied multiplication table has an element with no period")


def meets_bound(values, bounds):
    minimum, exact = bounds
    return values >= minimum if exact is None else values == exact


def prune(table, orders, constraints):
    left = np.flatnonzero(meets_bound(orders, constraints.periods[0]))
    right = np.flatnonzero(meets_bound(orders, constraints.periods[1]))
    a, b = np.repeat(left, len(right)), np.tile(right, len(left))
    for word, bounds in zip(PERIOD_WORDS[2:], constraints.periods[2:], strict=True):
        if not len(a):
            break
        marks = (a, b)
        element = marks[int(word[0])]
        for mark in word[1:]:
            element = table[element, marks[int(mark)]]
        keep = meets_bound(orders[element], bounds)
        a, b = a[keep], b[keep]
    return a, b


def compatible(table, a, b, rules):
    marks = np.stack((a, b))
    endpoints = np.empty((len(rules.labels), len(a)), dtype=np.intp)
    anchor_values = (table[a, a], table[a, b], table[b, a], table[b, b])
    for label, values in zip(rules.anchors, anchor_values, strict=True):
        endpoints[label] = values
    valid = (endpoints[list(rules.anchors)] == np.stack(anchor_values)).all(axis=0)
    if not valid.any():
        return valid, endpoints
    for source, mark, destination in rules.steps:
        endpoints[destination] = table[endpoints[source], marks[mark]]
    sorted_endpoints = np.sort(endpoints, axis=0)
    valid &= (sorted_endpoints[1:] != sorted_endpoints[:-1]).all(axis=0)
    source, mark, destination = rules.edges
    valid &= (table[endpoints[source], marks[mark]] == endpoints[destination]).all(axis=0)
    return valid, endpoints


def partial_matches(tables, observations):
    compiled: dict[int, list[tuple[int, Constraints]]] = defaultdict(list)
    periods = {}
    for i, (n, observed) in observations.items():
        rules = compile_constraints(observed)
        periods[i] = None if rules is None else rules.periods
        if rules is not None:
            compiled[n].append((i, rules))

    matches: dict[int, list[tuple[int, int, int]]] = {i: [] for i in observations}
    actions: dict[int, set[Labelled]] = {i: set() for i in observations}
    surviving_slots = 0
    for n, index, table in tables:
        matrix = np.asarray(table, dtype=np.intp)
        orders = element_periods(matrix)
        for i, rules in compiled[n]:
            a, b = prune(matrix, orders, rules)
            surviving_slots += len(a)
            if not len(a):
                continue
            valid, endpoints = compatible(matrix, a, b, rules)
            for column in np.flatnonzero(valid):
                left, right = int(a[column]), int(b[column])
                if 2 * len(rules.labels) <= n and reach(table, left, right) != n:
                    continue
                matches[i].append((index, left, right))
                if len(rules.labels) >= n - 1:
                    names = dict(zip(endpoints[:, column].tolist(), rules.labels, strict=True))
                    action = named_action(table, left, right, names)
                    if action is not None:
                        actions[i].add(action)
    return matches, actions, dict(surviving_case_pair_slots=surviving_slots, periods=periods)
