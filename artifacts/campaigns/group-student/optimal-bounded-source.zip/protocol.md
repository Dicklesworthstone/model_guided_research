# Exact planning with a certified word-length cutoff

The initial and name-quotiented searches at a765bfc and 7168e2c both
hit 300,000 work units at orders 10 and 12. Keep that same cap, all arms,
weights, and cases. The prediction is that deferring product expansion
and stopping at a certified word-length cutoff will preserve order 6's
minimum of 1,917 and solve order 10 within the cap. Run the fixed order-12
stress panel and retain both earlier outcomes.

Reuse each product traversal across the Bellman states with that row set.
Request candidates in shortlex order. The traversal expands only as many
nodes as necessary to supply the requested candidate. For each shape let
the sorted list of shortest access costs to the unseen positions be
`a1, ..., ak`. A query can reveal at most one such position, and the last
unused roster label can be inferred. After a next query, at least the
cheapest `max(0, k-2)` naming costs are still due. Sum this lower bound over
the shapes. Once the current word's cost plus the sum reaches the best
complete continuation, every later word has at least that cost. The
unexpanded tail cannot improve the best objective or its shortlex tie.
The previous candidate-specific bound remains valid and unchanged.

The DSR checks and scoring script are byte-identical to the initial
study. The manifest pins the new compiler and the preceding result.
