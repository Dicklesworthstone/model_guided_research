import hashlib
import json
import math
import sys
from collections import Counter
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


PANEL_HASH = "1b9311beccc81dfd57b5a80a9bd9b228615a8d08236ba2a9c8dd30cb088959bb"
SCRIPT_HASH = "3e535ff5a44e7f1b14f8479a5597fa5b9b971b64f6c9bff29f5fe9f9ed2af38a"
HELPER_HASH = "1b39baf09dd902d3356a21a88cdc4eef0027094fdb11769d4132ad964aeb27e6"
REGISTRATION = "b1a80d5b2efc11b594bea8ec6f4647e0bb17ce74"
PROMPTS = {"normal": 104, "length_only": 110, "nested": 110}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def recount(read, names, lineage):
    panel = json.loads(read("panel.json"))
    assert digest(read("panel.json")) == PANEL_HASH
    assert digest(read("replay/distractor.py")) == SCRIPT_HASH
    assert digest(read("replay/leaf_position.py")) == HELPER_HASH
    assert panel["distinct_input_trees"] == 32504 and len(panel["blocks"]) == 36
    assert panel["tokenizer_sha256"] == digest(lineage.read("tokenizer.json"))
    blocks = panel["blocks"]
    assert Counter(block["seed"] for block in blocks) == {61: 12, 62: 12, 63: 12}
    assert len({block[key]["tree"] for key in PROMPTS for block in blocks}) == 108
    for block in blocks:
        original, alias, nested = (block[key] for key in PROMPTS)
        root = block["root"]
        alias_root = next(leaf["path"][0] for leaf in alias["leaves"]
                          if leaf["path"][0] not in {item["path"][0] for item in original["leaves"]})
        assert alias["tree"].replace(f" {alias_root} ", f" {root} ", 1) == original["tree"]
        for item, longer, inner in zip(original["leaves"], alias["leaves"], nested["leaves"], strict=True):
            assert item["value"] == longer["value"] == inner["value"]
            first, second = item["path"]
            if first == root:
                assert longer["path"] == [alias_root, second]
                assert inner["path"] == [root, "k1x0", f"k2x{second[-1]}"]
            else:
                assert longer["path"] == inner["path"] == item["path"]
        labels = [query["label"] for query in original["queries"]]
        assert len(set(labels)) == 4
        assert len({item["path"][0] for item in original["queries"]}) == 2
        assert len({item["path"][1] for item in original["queries"]}) == 2
        for name, length in PROMPTS.items():
            case = block[name]
            assert len(case["leaves"]) == len(case["candidates"]) == 9
            assert len({leaf["value"] for leaf in case["leaves"]}) == 9
            assert [item["label"] for item in case["queries"]] == labels
            for query in case["queries"]:
                assert len(query["ids"]) == length and query["path"][0] != root
                assert query["path"][1] != block["omitted_suffix"]
                expected = case["leaves"][query["label"]]
                assert query["path"] == expected["path"] and query["value"] == expected["value"]
                assert query["doc"] == f'{case["tree"]} PATH {" ".join(query["path"])} OUT {query["value"]}'
        for short, long in zip(alias["queries"], nested["queries"], strict=True):
            assert short["ids"][-10:] == long["ids"][-10:]
        assert all(alias["candidates"][i] == nested["candidates"][i] for i in labels)

    before = json.loads(lineage.read("decision.json"))
    metrics = {}
    for seed in (30, 31, 32):
        for arm in ("detached", "joint"):
            run = f"seed-{seed}-{arm}"
            score = json.loads(read(f"evals/{run}.json"))
            assert (score["seed"], score["arm"], score["panel_sha256"]) == (seed, arm, PANEL_HASH)
            hashes = before["per_seed"][str(seed)]["checkpoint_hashes"][arm]
            assert score["weights_sha256"] == hashes["model_sha256"] and score["head_sha256"] == hashes["head_sha256"]
            metrics[run] = {}
            for name in PROMPTS:
                four, single, pairs = 0, 0, 0
                for block, raw in zip(blocks, score["rows"], strict=True):
                    rows = raw[name]
                    assert len(rows) == 4 and all(len(row) == 9 and all(map(math.isfinite, row)) for row in rows)
                    correct = [
                        max(range(9), key=row.__getitem__) == query["label"]
                        for row, query in zip(rows, block[name]["queries"], strict=True)
                    ]
                    four += all(correct)
                    single += sum(correct)
                    pairs += all(correct[:2]) + all(correct[2:])
                metrics[run][name] = dict(four_correct=four, individual_correct=single, within_root_pairs_correct=pairs)
    selected = [metrics[f"seed-{seed}-joint"] for seed in (31, 32)]
    eligible = all(row[cell]["four_correct"] >= 18 for row in selected for cell in ("normal", "length_only"))
    loss = all(row["length_only"]["four_correct"] - row["nested"]["four_correct"] >= 9 for row in selected)
    outcome = "unqualified" if not eligible else "distractor_cost" if loss else "fixed_cost_rule_failed"
    receipts = sorted(path for path in names if path.endswith("/receipt.json"))
    assert len(receipts) == 2
    assert {path.split("/")[1] for path in receipts} == {"hierarchy-distractor-preflight", "hierarchy-distractor-eval"}
    for path in receipts:
        receipt = json.loads(read(path))
        assert receipt["status"] == "passed" and len(receipt["checks"]) == 1
        check = receipt["checks"][0]
        assert digest(read(path.removesuffix("receipt.json") + Path(check["log_path"]).name)) == check["log_sha256"]
    return dict(registration=REGISTRATION, blocks_per_cell=36, queries_per_cell=144, within_root_pairs_per_cell=72,
                eligible=eligible, loss_rule=loss, disposition=outcome, metrics=metrics,
                receipt_ids=[path.split("/")[-2] for path in receipts])


def bundle(scratch, lineage, dest):
    files = {"panel.json": scratch / "panel.json"}
    for key in ("distractor.py", "leaf_position.py", "distractor_archive.py", "campaign.yaml"):
        files[f"replay/{key}"] = scratch / key
    for path in (scratch / "evals").glob("seed-*.json"):
        files[f"evals/{path.name}"] = path
    assert len([key for key in files if key.startswith("evals/")]) == 6
    for receipt in (scratch / "receipts").glob("*/*/receipt.json"):
        for name in ("receipt.json", "check-1.log", "checks-config.yaml"):
            path = receipt.with_name(name)
            files[str(path.relative_to(scratch))] = path
    with ZipFile(lineage) as previous:
        data = recount(lambda key: files[key].read_bytes(), files, previous)
    with ZipFile(dest, "x", compression=ZIP_DEFLATED) as archive:
        for key, path in files.items():
            archive.write(path, key)
        archive.writestr("decision.json", json.dumps(data, indent=2) + "\n")


def verify(dest, lineage):
    with ZipFile(dest) as archive, ZipFile(lineage) as previous:
        assert archive.testzip() is None
        names = archive.namelist()
        assert len(names) == len(set(names))
        assert not any(name.endswith((".pt", ".parquet", ".safetensors")) for name in names)
        data = recount(archive.read, names, previous)
        assert data == json.loads(archive.read("decision.json"))
    print(json.dumps(data))


if __name__ == "__main__":
    command, *paths = sys.argv[1:]
    if command == "bundle":
        bundle(*map(Path, paths))
    elif command == "verify":
        verify(*map(Path, paths))
    else:
        raise ValueError(command)
