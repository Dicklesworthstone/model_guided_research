import dataclasses
import hashlib
import itertools
import json
import math
import os
import random
import re
import sys
import time
from pathlib import Path

import pyarrow.parquet as pq
import torch
from torch import nn
from torch.nn import functional as F

sys.path.insert(0, str(Path.cwd()))
from cli import _eval_score_doc, _load_eval_checkpoint
from nanochat.checkpoint_manager import save_checkpoint
from nanochat.diagnostics_data import TASKS
from nanochat.gpt import GPT, GPTConfig
from nanochat.report import build_provenance
from nanochat.tokenizer import HuggingFaceTokenizer, padded_vocab_size

SEED = int(os.environ["MGR_LEAF_TRAIN_SEED"])
EVAL_SEEDS = (40, 41, 44)
TERMINAL_SEEDS = (50, 51, 52)
STEPS, BATCH, WIDTH, CONTEXT = 2048, 8, 128, 320
SPEC = TASKS["hier_paired"]
TREE = "TASK hier TREE "

def read(path):
    return json.loads(path.read_bytes())

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as handle:
        handle.write(json.dumps(value, indent=2) + "\n")

def digest(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()

def tree_of(doc):
    return doc.split(" PATH ", 1)[0]

def leaf_entries(tree):
    assert tree.startswith(TREE)
    matches = re.compile(r"\S+").finditer(tree, len(TREE))
    path = []
    entries = []
    for item in matches:
        word = item.group()
        if word == "(":
            key = next(matches).group()
            assert re.fullmatch(r"k\d+x\d+", key)
            path.append(key)
        elif word == ")":
            path.pop()
        else:
            assert path and re.fullmatch(r"v\d+", word)
            entries.append((tuple(path), word, item.end()))
    assert not path and len({row[0] for row in entries}) == len(entries)
    return entries

def pack_pair(tree, depth, tokenizer, picker=None, terminal_change=False):
    leaves = leaf_entries(tree)
    eligible = sorted(
        (a, b)
        for a, b in itertools.combinations(range(len(leaves)), 2)
        if len(leaves[a][0]) == len(leaves[b][0]) == depth
        and (leaves[a][0][0] == leaves[b][0][0] if terminal_change else leaves[a][0][1:] == leaves[b][0][1:])
        and leaves[a][1] != leaves[b][1]
    )
    if not eligible:
        return None
    chosen = picker.choice(eligible) if picker is not None else eligible[0]
    bos = tokenizer.get_bos_token_id()
    positions = [len(tokenizer.encode(tree[:end], prepend=bos)) - 1 for _, _, end in leaves]
    assert positions == sorted(set(positions))
    docs, tokens, prompts = [], [], []
    for index in chosen:
        path, value, _ = leaves[index]
        doc = f"{tree} PATH {' '.join(path)} OUT {value}"
        assert SPEC.checker(doc) is True
        prompt, expected = SPEC.split_prompt(doc)
        ids = tokenizer.encode(doc, prepend=bos)
        prefix = tokenizer.encode(prompt, prepend=bos)
        assert ids[:len(prefix)] == prefix and expected == value
        assert len(prefix) < len(ids) and all(position < len(prefix) - 1 for position in positions)
        for (_, _, end), position in zip(leaves, positions, strict=True):
            assert tokenizer.encode(tree[:end], prepend=bos) == ids[:position + 1]
        docs.append(doc)
        tokens.append(ids)
        prompts.append(len(prefix) - 1)
    assert chosen[0] != chosen[1]
    first, second = (leaves[index][0] for index in chosen)
    if terminal_change:
        assert first[0] == second[0] and first[1:] != second[1:]
    else:
        assert first[0] != second[0] and first[1:] == second[1:]
    return dict(documents=docs, ids=tokens, query=prompts, candidates=positions, labels=list(chosen),
                leaves=[{"path": leaf[0], "value": leaf[1], "character_end": leaf[2]} for leaf in leaves])

class LocationHead(nn.Module):
    def __init__(self):
        super().__init__()
        self.query = nn.Linear(128, 32, bias=False)
        self.key = nn.Linear(128, 32, bias=False)

    def forward(self, hidden, query, candidates):
        batch = torch.arange(hidden.size(0))[:, None]
        keys = self.key(hidden[batch, candidates.clamp_min(0)])
        q = self.query(hidden[batch.flatten(), query]).unsqueeze(1)
        return ((keys * q).sum(dim=-1) / math.sqrt(32)).masked_fill(candidates < 0, -torch.inf)

def model_and_head(tokenizer):
    torch.manual_seed(SEED)
    config = GPTConfig(sequence_len=CONTEXT, vocab_size=padded_vocab_size(tokenizer.get_vocab_size()),
                       n_layer=4, n_embd=128, n_head=8, n_kv_head=4, attention_type="standard")
    model = GPT(config)
    model.init_weights()
    return model, LocationHead()

def states(model, inputs):
    captured = []
    def receive(_module, args):
        captured.append(args[0])
    handle = model.lm_head.register_forward_pre_hook(receive)
    try:
        logits = model(inputs)
    finally:
        handle.remove()
    (hidden,) = captured
    return logits, hidden

def routed(hidden, multiplier):
    past = hidden.detach()
    return past + multiplier * (hidden - past)

def controls(tok, row):
    model, head = model_and_head(tok)
    model.eval()
    position = row["query"][0]
    query = torch.tensor([position])
    candidates = torch.tensor([row["candidates"]])
    tokens = row["ids"][0]
    with torch.inference_mode():
        before = head(states(model, torch.tensor([tokens[:position + 1]]))[1], query, candidates)
        after = head(states(model, torch.tensor([tokens]))[1], query, candidates)
    gap = (before - after).abs().max()
    assert gap <= 1e-5
    hidden = torch.randn(1, position + 1, 128, requires_grad=True)
    label = torch.tensor([row["labels"][0]])
    parameters = (hidden, *head.parameters())
    zero = torch.autograd.grad(F.cross_entropy(head(routed(hidden, 0), query, candidates), label), parameters)
    one = torch.autograd.grad(F.cross_entropy(head(routed(hidden, 1), query, candidates), label), parameters)
    assert torch.count_nonzero(zero[0]) == 0 and torch.count_nonzero(one[0]) > 0
    assert all(torch.equal(a, b) for a, b in zip(zero[1:], one[1:], strict=True))
    return dict(causal_max_score_delta=float(gap), detached_hidden_grad_norm=float(zero[0].norm()),
                joint_hidden_grad_norm=float(one[0].norm()), identical_position_head_gradients=True)

def tokenizer_path(reference):
    return reference / "runs" / "standard" / "b5-s0" / "checkpoints" / "tokenizer"

def preflight(root, ref, older, pilot):
    directory = ref / "data" / "hier_paired"
    manifest = read(directory / "manifest.json")
    assert manifest["task"] == "hier_paired" and manifest["seed"] == 42 and manifest["size"] == 64000
    tok = HuggingFaceTokenizer.from_directory(str(tokenizer_path(ref)))
    seen = set()
    training = []
    for filename, sha in manifest["sha256"].items():
        source = directory / filename
        assert digest(source) == sha
        docs = pq.read_table(source, columns=["text"]).column("text").to_pylist()
        for left, right in zip(docs[::2], docs[1::2], strict=True):
            tree = tree_of(left)
            assert tree == tree_of(right) and tree not in seen
            seen.add(tree)
            if filename == "train_000.parquet":
                training.append(tree)
    assert len(seen) == 32000 and len(training) == 25600
    prior = set()
    for panel in (read(ref / "panel.json")["evaluation"], read(older / "panel.json"), read(pilot / "panel.json")):
        prior.update(tree_of(row["documents"][0]) for rows in panel.values() for row in rows)
    assert len(prior) == 216 and not seen.intersection(prior)

    panels = (
        ("in_range", "train", 2, EVAL_SEEDS),
        ("held_out", "test", 3, EVAL_SEEDS),
        ("terminal_change", "train", 2, TERMINAL_SEEDS),
    )
    panel = {region: [] for region, _, _, _ in panels}
    for region, split, depth, seeds in panels:
        for seed in seeds:
            splits = SPEC.generate(1200, seed, SPEC.resolve_dials(None))
            n = 0
            docs = splits[split]
            for doc in docs[::2]:
                tree = tree_of(doc)
                packed = pack_pair(tree, depth, tok, terminal_change=region == "terminal_change")
                if packed is None or max(map(len, packed["ids"])) > CONTEXT + 1 or len(set(packed["query"])) != 1:
                    continue
                assert tree not in seen and tree not in prior
                seen.add(tree)
                panel[region].append(dict(seed=seed, pair_index=n, **packed))
                n += 1
                if n == 12:
                    break
            assert n == 12
    assert len(seen) == 32108
    trial = controls(tok, panel["in_range"][0])

    rng = random.Random(SEED)
    order = list(range(len(training)))
    rng.shuffle(order)
    total = STEPS * BATCH
    inputs = torch.full((total, WIDTH), tok.get_bos_token_id(), dtype=torch.long)
    targets = torch.full_like(inputs, -1)
    queries = torch.zeros(total, dtype=torch.long)
    candidates = torch.full((total, 9), -1, dtype=torch.long)
    labels = torch.zeros(total, dtype=torch.long)
    selection = []
    for index in order:
        packed = pack_pair(training[index], 2, tok, picker=rng)
        if packed is None or max(map(len, packed["ids"])) > WIDTH + 1:
            continue
        offset = 2 * len(selection)
        positions = packed["candidates"]
        assert len(positions) <= 9
        for j, tokens in enumerate(packed["ids"]):
            k = offset + j
            q = packed["query"][j]
            inputs[k, :len(tokens) - 1] = torch.tensor(tokens[:-1])
            targets[k, q:len(tokens) - 1] = torch.tensor(tokens[q + 1:])
            queries[k] = q
            candidates[k, :len(positions)] = torch.tensor(positions)
            labels[k] = packed["labels"][j]
        selection.append(index)
        if len(selection) == total // 2:
            break
    assert len(selection) == len(set(selection)) == 8192
    root.mkdir(parents=True, exist_ok=True)
    torch.save(dict(inputs=inputs, targets=targets, queries=queries, candidates=candidates, labels=labels),
               root / "schedule.pt")
    write(root / "manifest.json", manifest)
    write(root / "panel.json", panel)
    report = dict(schedule_sha256=digest(root / "schedule.pt"), training_tree_indices=selection,
                  tokenizer_sha256=digest(tokenizer_path(ref) / "tokenizer.json"), previous_eval_trees=len(prior),
                  unique_current_trees=len(seen), positive_control=trial,
                  oracle_both={region: len(rows) for region, rows in panel.items()},
                  deterministic_shared_path_only_both={region: sum(all(label == 0 for label in row["labels"])
                                                      for row in rows) for region, rows in panel.items()},
                  max_document_tokens={region: max(max(map(len, row["ids"])) for row in rows)
                                       for region, rows in panel.items()})
    write(root / "preflight.json", report)
    print(json.dumps({key: value for key, value in report.items() if key != "training_tree_indices"}), flush=True)

def parameter_hash(parameters):
    hash_value = hashlib.sha256()
    for param in parameters:
        hash_value.update(param.detach().numpy().tobytes())
    return hash_value.hexdigest()

def train(root, reference):
    lock = read(root / "preflight.json")
    assert digest(root / "schedule.pt") == lock["schedule_sha256"]
    assert digest(tokenizer_path(reference) / "tokenizer.json") == lock["tokenizer_sha256"]
    tok = HuggingFaceTokenizer.from_directory(str(tokenizer_path(reference)))
    schedule = torch.load(root / "schedule.pt", weights_only=True)
    starting = None
    for name, multiplier in (("detached", 0), ("joint", 1)):
        model, head = model_and_head(tok)
        parameters = (*model.parameters(), *head.parameters())
        initial = parameter_hash(parameters)
        if starting is None:
            starting = initial
        assert initial == starting
        optimizer = torch.optim.AdamW(parameters, lr=0.0006)
        start = time.perf_counter()
        for step in range(STEPS):
            part = slice(step * BATCH, (step + 1) * BATCH)
            optimizer.zero_grad(set_to_none=True)
            logits, hidden = states(model, schedule["inputs"][part])
            answer_ce = F.cross_entropy(logits.float().flatten(0, 1), schedule["targets"][part].flatten(),
                                        ignore_index=-1)
            location = head(routed(hidden, multiplier), schedule["queries"][part], schedule["candidates"][part])
            location_ce = F.cross_entropy(location, schedule["labels"][part])
            loss = answer_ce + location_ce
            if not math.isfinite(float(loss.detach())):
                raise ValueError(f"{name}: nonfinite training loss at {step}")
            loss.backward()
            torch.nn.utils.clip_grad_norm_(parameters, 1.0)
            optimizer.step()
            if step == 0 or (step + 1) % 256 == 0:
                rate = float((location.argmax(1) == schedule["labels"][part]).float().mean())
                print(f"{name} {step+1}/{STEPS} answer_ce={float(answer_ce.detach()):.5f} "
                      f"position_ce={float(location_ce.detach()):.5f} batch_position_accuracy={rate:.3f}", flush=True)
        elapsed = time.perf_counter() - start
        model_flops = float(model.estimate_flops() * (BATCH * WIDTH * STEPS))
        checkpoint = root / "runs" / name / "checkpoints"
        checkpoint.mkdir(parents=True)
        tok.save(str(checkpoint / "tokenizer"))
        save_checkpoint(str(checkpoint), STEPS - 1, model.state_dict(), None,
                        dict(model_config=dataclasses.asdict(model.config), optimizer_type="adamw", scheduler_type="none",
                             seed=SEED, tokenizer={"kind": "task", "dir": "tokenizer"},
                             budget={"target_flops": model_flops, "max_steps": STEPS},
                             lineage={"run_id": name, "parent_run_ids": []}), rank=0)
        head_file = checkpoint / "location_head.pt"
        torch.save(head.state_dict(), head_file)
        settings = dict(run_id=name, location_gradient_multiplier=multiplier, seed=SEED, steps=STEPS, batch=BATCH,
                        train_width=WIDTH, lr=0.0006, clip=1.0, schedule_sha256=lock["schedule_sha256"])
        summary = dict(provenance=build_provenance(settings), settings=settings, initial_parameters_sha256=initial,
                       final_parameters_sha256=parameter_hash(parameters), model_flops_est=model_flops,
                       elapsed_seconds=elapsed, location_head_sha256=digest(head_file))
        write(checkpoint.parent / "summary.json", summary)
        print(json.dumps(summary), flush=True)

@torch.inference_mode()
def evaluate(root, name):
    checkpoint = root / "runs" / name / "checkpoints"
    training = read(checkpoint.parent / "summary.json")
    assert not training["provenance"]["tainted"]
    device = torch.device("cpu")
    model, metadata, step = _load_eval_checkpoint(checkpoint, None, device, fingerprint_weights=True)
    assert step == STEPS - 1
    head_file = checkpoint / "location_head.pt"
    assert digest(head_file) == training["location_head_sha256"]
    head = LocationHead().eval()
    head.load_state_dict(torch.load(head_file, weights_only=True))
    tok = HuggingFaceTokenizer.from_directory(str(checkpoint / "tokenizer"))
    coverage = {}
    for region, rows in read(root / "panel.json").items():
        results = []
        for row in rows:
            outputs = []
            for i in (0, 1):
                index = row["query"][i]
                prompt = torch.tensor([row["ids"][i][:index + 1]])
                _, hidden = states(model, prompt)
                location = head(hidden, torch.tensor([index]), torch.tensor([row["candidates"]]))
                chosen = int(location.argmax(1).item())
                actual = row["labels"][i]
                got_value = row["leaves"][chosen]["value"]
                correct_value = row["leaves"][actual]["value"]
                scored = _eval_score_doc(model, tok, SPEC, row["documents"][i], device=device, temperature=0.0,
                                         seed=row["seed"])
                assert scored is not None
                correct, expected, reply, _ = scored
                assert expected == correct_value
                outputs.append(dict(actual_leaf=actual, predicted_leaf=chosen, actual_token_position=row["candidates"][actual],
                                    predicted_token_position=row["candidates"][chosen], expected=expected,
                                    position_value=got_value, greedy_reply=reply, greedy_correct=correct))
            results.append(dict(seed=row["seed"], pair_index=row["pair_index"], queries=outputs))
        coverage[region] = dict(
            pairs=len(results),
            both_positions=sum(all(q["actual_leaf"] == q["predicted_leaf"] for q in row["queries"]) for row in results),
            both_pointed_values=sum(all(q["expected"] == q["position_value"] for q in row["queries"]) for row in results),
            both_greedy=sum(all(q["greedy_correct"] for q in row["queries"]) for row in results),
            single_positions=sum(q["actual_leaf"] == q["predicted_leaf"] for row in results for q in row["queries"]),
            single_greedy=sum(q["greedy_correct"] for row in results for q in row["queries"]),
            rows=results,
        )
    report = dict(run_id=name, weights_sha256=metadata["weights_sha256"],
                  location_head_sha256=training["location_head_sha256"],
                  source_revision=training["provenance"]["git_sha"], regions=coverage)
    write(root / "evals" / name / "summary.json", report)
    print(json.dumps({region: {key: value for key, value in stats.items() if key != "rows"}
                      for region, stats in coverage.items()}), flush=True)

if __name__ == "__main__":
    command, root, *arguments = sys.argv[1:]
    if command == "preflight":
        preflight(Path(root), *map(Path, arguments))
    elif command == "train":
        train(Path(root), Path(arguments[0]))
    elif command == "eval":
        evaluate(Path(root), arguments[0])
    else:
        raise ValueError(command)
