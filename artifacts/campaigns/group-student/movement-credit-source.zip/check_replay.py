"""Reconstruct the historical actions and independently audit the finite search."""

import json
import sys
from collections import Counter, defaultdict
from itertools import product
from pathlib import Path

import numpy as np


def load(path):
    return json.loads(Path(path).read_bytes())


def without_timings(value):
    if isinstance(value, dict):
        return {k: without_timings(v) for k, v in value.items() if not k.endswith("_ns")}
    if isinstance(value, list):
        return [without_timings(item) for item in value]
    return value


def independently_named(case):
    root = tuple(range(5))
    waiting = [root]
    visited = {root: 0}
    rows = {}
    labels = case["opaque_names"]
    for element in waiting:
        output = []
        for mark in case["generator_pair"]:
            moved = tuple(mark[point] for point in element)
            if moved not in visited:
                visited[moved] = len(waiting)
                waiting.append(moved)
            output.append(labels[visited[moved]])
        rows[labels[visited[element]]] = output
    if len(rows) != case["label_count"]:
        raise ValueError("Independent permutation action has the wrong size")
    return labels[0], [rows[str(i)] for i in range(len(rows))]


def follow(action, word):
    root, edges = action
    state = root
    for mark in word:
        state = edges[int(state)][int(mark)]
    return state


def allowed_orders(n, observed, mark):
    label = observed[mark * 2]
    return [k for k in range(1, n + 1) if n % k == 0
            and all((observed[mark * (2 + t)] == label) == (t % k == 0) for t in range(1, 7))]


def group_is_valid(n, matrix):
    roster = set(range(n))
    if (len(matrix) != n or any(set(row) != roster for row in matrix)
            or matrix[0] != list(range(n)) or any(row[0] != a for a, row in enumerate(matrix))):
        return False
    if any(set(column) != roster for column in zip(*matrix, strict=True)):
        return False
    table = np.asarray(matrix, dtype=np.intp)
    return all(np.array_equal(table[table[a]], table[a, table]) for a in range(n))


def element_order(matrix, mark):
    value = mark
    for order in range(1, len(matrix) + 1):
        if value == 0:
            return order
        value = matrix[value][mark]
    raise ValueError("Element has no order")


def label_matching(columns, labels):
    # Binary heap indices are the order of the 508 given words, plus the root and the marks.
    reached = [0, columns[0][0], columns[1][0]]
    forward: dict[int, str] = {}
    reverse: dict[str, int] = {}
    for node, label in enumerate(labels, 3):
        target = columns[(node - 1) % 2][reached[(node - 1) // 2]]
        if forward.setdefault(target, label) != label or reverse.setdefault(label, target) != target:
            return None
        reached.append(target)
    return forward


def spans(columns):
    visited = {0}
    todo = [0]
    while todo:
        state = todo.pop()
        for column in columns:
            target = column[state]
            if target not in visited:
                todo.append(target)
                visited.add(target)
    return len(visited) == len(columns[0])


def verify_exhaustion(groups, cases, rows):
    wanted = defaultdict(list)
    reported = {}
    observed = {}
    for case, row in zip(cases, rows, strict=True):
        i, n = row["index"], row["order"]
        pairs = case["arms"]["short_only"]["rows"][:508]
        observed[i] = tuple(label for _, label in pairs)
        for a, b in product(*(allowed_orders(n, dict(pairs), mark) for mark in "01")):
            wanted[n, a, b].append(i)
        reported[i] = {tuple(entry) for entry in row["catalogue"]["witnesses"]}
        if len(reported[i]) != len(row["catalogue"]["witnesses"]):
            raise ValueError("Catalogue reported duplicate witnesses")

    checked = {i: set() for i in observed}
    named = {i: set() for i in observed}
    inventory = defaultdict(list)
    for n, number, table in groups:
        if not group_is_valid(n, table):
            raise ValueError(f"Invalid multiplication table {n}, {number}")
        inventory[n].append(number)
        columns = list(zip(*table, strict=True))
        orders = [element_order(table, mark) for mark in range(n)]
        for a, b in product(range(n), repeat=2):
            for i in wanted.get((n, orders[a], orders[b]), ()):
                moves = (columns[a], columns[b])
                mapping = label_matching(moves, observed[i])
                if mapping is None or not spans(moves):
                    continue
                checked[i].add((number, a, b))
                remaining = set(range(n)).difference(mapping)
                if len(remaining) > 1:
                    continue
                for state, label in zip(remaining, set(map(str, range(n))).difference(mapping.values()), strict=True):
                    mapping[state] = label
                by_name = {name: state for state, name in mapping.items()}
                edges = tuple((mapping[moves[0][by_name[str(j)]]], mapping[moves[1][by_name[str(j)]]]) for j in range(n))
                named[i].add((mapping[0], edges))
    if inventory != {60: list(range(1, 14)), 120: list(range(1, 48))}:
        raise ValueError("Missing or unexpected SmallGrp index")
    if checked != reported or any(not witnesses for witnesses in checked.values()):
        raise ValueError("The compatible generating pairs differ from the independent search")
    for row in rows:
        actions = named[row["index"]]
        result = row["catalogue"]
        action = result["action"]
        if len(actions) != result["distinct_named_actions"] or (action is None) != (len(actions) != 1):
            raise ValueError("Catalogue chose the wrong ambiguity disposition")
        if action is not None and (action[0], tuple(map(tuple, action[1]))) not in actions:
            raise ValueError("Catalogue claimed a different candidate")
    return sum(map(len, checked.values()))


def audit(library, cohort, primary, replay):
    gap, package, groups = load(library)
    first, second = load(primary), load(replay)
    if without_timings(first) != without_timings(second):
        raise ValueError("Hash seed changed the non-timing result")
    if (gap, package) != ("4.16.1", "1.7.0") or first["contradiction"] or not first["ambiguity_refused"]:
        raise ValueError("Wrong versions or a negative control was accepted")
    cases = [load(Path(cohort) / f"{i:02}.json") for i in range(24)]
    witness_count = verify_exhaustion(groups, cases, first["results"])
    totals = Counter()
    ambiguity = False
    for case, row in zip(cases, first["results"], strict=True):
        i, n = row["index"], row["order"]
        if (i, n) != (case["index"], case["label_count"]):
            raise ValueError("Wrong result order")
        expected_root, expected_edges = independently_named(case)
        model = [expected_root, expected_edges]
        baseline = row["square"]
        candidate = row["catalogue"]
        if baseline["action"] != model or baseline["paid"] != case["arms"]["active"]["paid"]:
            raise ValueError("Square closure returned the wrong action or tape")
        totals["square_exact_before"] += baseline["partial_edges"] == 2 * n
        totals["square_paid"] += len(baseline["paid"])
        totals["square_symbols"] += sum(len(word) for word, _ in baseline["paid"])
        if candidate["action"] is not None:
            if candidate["action"] != model:
                raise ValueError("False catalogue certificate")
            totals["catalogue_exact"] += 1
        for split in ("primary", "secondary"):
            for (word, want, _), a, b in zip(case[split], baseline["partial_answers"][split], candidate["answers"][split], strict=True):
                if want != follow(model, word) or any(reply is not None and reply != want for reply in (a, b)):
                    raise ValueError("An endpoint is wrong")
                if (b is None) != (candidate["action"] is None):
                    raise ValueError("Prediction escaped the catalogue abstention boundary")
                totals[f"square_{split}"] += a is not None
                totals[f"catalogue_{split}"] += b is not None
        totals["checked_transitions"] += 2 * n
        if i == 0:
            left, right = "0", "1"
            rename = {str(j): str(j) for j in range(n)}
            rename[left], rename[right] = right, left
            alternate = [rename[expected_root], [[rename[dst] for dst in expected_edges[int(rename[str(j)])]] for j in range(n)]]
            retained = [(word, label) for word, label in case["arms"]["short_only"]["rows"][:508]
                        if label not in (left, right)]
            ambiguity = alternate != model and all(follow(alternate, word) == label for word, label in retained)
    if not ambiguity:
        raise ValueError("Two unseen names did not produce distinguishable labelled tables")
    print(json.dumps(dict(totals, verified_compatible_pairs=witness_count, ambiguity_witness=ambiguity,
                          gate=totals["catalogue_exact"] >= 20, actions=len(cases)), sort_keys=True))


if __name__ == "__main__":
    audit(*sys.argv[1:])
