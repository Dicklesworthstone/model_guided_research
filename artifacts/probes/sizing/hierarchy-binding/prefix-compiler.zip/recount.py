import hashlib
import itertools
import json
import math
import sys
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

SOURCE = "5197c9b33f3ae67e5cfe8018e0072ebe211e5989"
MANIFEST = "4cbe494e600a430c4d5d769f7d7b18d751aa87ee0052d7e05678ffc2f26a6cad"
PRIOR = "242946b74774e2bbaac837e9426c80924e715b410d95a608d91019f2c093ea74"
TRAIN = ("8831", "8832", "8833")
PANEL = ("5401", "5402", "5403")
CELLS = ("depth2", "depth3", "depth4")
MODES = ("addressed", "pooled", "wrong_scope", "erased")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def parse(doc):
    tree, section = doc.split(" BIND ")
    tables, query_answer = section.split(" PATH ")
    query, answer = query_answer.split(" OUT ")
    path, values = [], {}
    words = iter(tree.split()[3:])
    for word in words:
        if word == "(":
            path.append(int(next(words)[-1]))
        elif word == ")":
            path.pop()
        else:
            values[tuple(path)] = word
    assert not path
    rows = {}
    for r, a, k, b, v in (row.split() for row in tables.split(" ; ")):
        rows[tuple(int(bit) for bit in r[1:])] = (int(a[-1]), int(k[-1]), int(b[-1]), int(v[-1]))
    aliases = tuple(int(a[-1]) for a in query.split())
    gold, = (path for path, value in values.items() if value == answer)

    # Independent path oracle using the explicit relation at each scope.
    true_path = ()
    for alias in aliases:
        a, k, b, v = rows[true_path]
        true_path += ({a: k, b: v}[alias],)
    assert true_path == gold
    ordered = [rows[scope] for scope in sorted(rows, key=lambda key: (len(key), key))]
    return aliases, gold, rows, ordered


def chosen(p):
    return int(p[1] > p[0])


def route(book, query, gold, mode):
    walk = []
    node, gold_node = 0, 0
    local = []
    for hop, (alias, want) in enumerate(zip(query, gold, strict=True)):
        base = 2**hop - 1
        if mode == "pooled":
            level = book[base:2*base+1]
            pick = chosen([sum(math.exp(row[alias][k]) for row in level) for k in (0, 1)])
            gold_pick = pick
        else:
            if mode == "wrong_scope" and hop:
                p = base + ((node - base) ^ 1)
                q = base + ((gold_node - base) ^ 1)
            else:
                p, q = node, gold_node
            pick = chosen(book[p][alias])
            gold_pick = chosen(book[q][alias])
        walk.append(pick)
        local.append(gold_pick == want)
        node = 2 * node + 1 + pick
        gold_node = 2 * gold_node + 1 + want
    return walk == list(gold), local


def local_gate(fit):
    cases = fit["exhaustive"]
    margins, compact = [], {}
    for i, (first, swap) in enumerate(itertools.product((0, 1), repeat=2)):
        matrix = cases[i]
        margins += [matrix[a][a ^ swap] - matrix[a][1 - (a ^ swap)] for a in (0, 1)]
        other = cases[(1 - first) * 2 + swap]
        assert len(matrix) == len(other) == 2
        for l, r in zip(matrix, other, strict=True):
            assert len(l) == len(r) == 2
        compact[(first, first ^ swap)] = chosen(matrix[0])
    equivariance = max(abs(cases[swap][a][k] - cases[2 + swap][a][k])
                       for swap, a, k in itertools.product((0, 1), repeat=3))
    passing = min(margins) >= .1 and equivariance <= 1e-6
    orientations = {role: [chosen(row) for row in fit[key]] for role, key in (
        ("query_to_alias", "alias_scores"), ("value_to_child", "key_scores")
    )}
    return dict(min_margin_nats=min(margins), row_order_error=equivariance, orientations=orientations,
                correct=sum(margin > 0 for margin in margins), passes=passing), compact if passing else None


def verify_one_cell(docs, addressed, pooled, compact):
    modes = dict(addressed=addressed["rows"], pooled=pooled["rows"],
                 wrong_scope=addressed["rows"], erased=addressed["erased"])
    assert set(map(len, modes.values())) == {72}
    totals = {mode: dict(individual=0, both=0, both_at_edit=0, nonroot_at_edit=0) for mode in modes}
    compiled_queries, compiled_local, edits_nonroot = 0, 0, 0
    for index in range(0, len(docs), 2):
        left, right = [parse(doc) for doc in docs[index:index + 2]]
        same_tree = [doc.split(" BIND ")[0] for doc in docs[index:index + 2]]
        assert same_tree[0] == same_tree[1] and left[0] == right[0] and left[1] != right[1]
        edited, = [scope for scope in left[2] if left[2][scope] != right[2][scope]]
        hop = len(edited)
        assert left[1][:hop] == edited == right[1][:hop] and left[1][hop] != right[1][hop]
        assert addressed["erased"][index] == addressed["erased"][index + 1]
        edits_nonroot += bool(hop)
        for mode, books in modes.items():
            correct, local = [], []
            for i, (query, gold, _rows, ordered) in enumerate((left, right), index):
                book = books[i]
                assert len(book) == len(ordered)
                for table in book:
                    assert len(table) == 2 and all(
                        len(row) == 2 and all(map(math.isfinite, row)) and
                        abs(sum(map(math.exp, row)) - 1) <= 2e-6 for row in table
                    )
                solved, gold_flags = route(book, query, gold, mode)
                correct.append(solved)
                local.append(gold_flags[hop])
                if mode == "addressed" and compact is not None:
                    for table, (a, k, b, v) in zip(book, ordered, strict=True):
                        bit = compact[a, k]
                        assert a != b and k != v
                        assert all(chosen(table[alias]) == (alias ^ bit) for alias in (0, 1))
                        compiled_local += 2
                    node = 0
                    compiled = []
                    for alias in query:
                        a, k, _, _ = ordered[node]
                        side = alias ^ compact[a, k]
                        compiled.append(side)
                        node = 2 * node + 1 + side
                    assert tuple(compiled) == gold and solved
                    compiled_queries += 1
            totals[mode]["individual"] += sum(correct)
            totals[mode]["both"] += all(correct)
            totals[mode]["both_at_edit"] += all(local)
            totals[mode]["nonroot_at_edit"] += bool(hop) and all(local)
    assert totals["erased"]["both"] == 0 and totals["erased"]["both_at_edit"] == 0
    assert totals["wrong_scope"]["nonroot_at_edit"] == 0
    return dict(modes=totals, compiled_queries=compiled_queries,
                compiled_local_decisions=compiled_local, nonroot_edits=edits_nonroot)


def recount(read, names, prior):
    manifest = read("frozen.sha256")
    assert sha(manifest) == MANIFEST
    for row in manifest.decode().splitlines():
        key, name = row.split()
        assert sha(read(name)) == key
    panel_hash = read("panel.sha256").decode().split()[0]
    assert sha(read("panel.json")) == panel_hash
    panel = json.loads(read("panel.json"))
    assert set(panel) == set(PANEL)
    assert sha(prior.read_bytes()) == PRIOR
    with ZipFile(prior) as old:
        baseline = json.loads(old.read("baseline-result.json"))["seeds"]
    unit = [[(0, -1), (-1, 0)], [(0, -1), (-1, 0)], [(-1, 0), (0, -1)]]
    assert route(unit, [0, 1], [0, 1], "addressed") == (True, [True, True])
    assert route(unit, [0, 1], [0, 1], "wrong_scope") == (False, [True, False])
    outcomes, accept = {}, []
    for seed in TRAIN:
        data = json.loads(read(f"fit-{seed}.json"))
        assert data["checkpoint"] == baseline[seed]["checkpoint_sha256"] and data["panel_sha256"] == panel_hash
        assert data["train_rows"] == 1536 and data["updates"] == 288
        addr, pool = [data["outcomes"][name] for name in ("addressed", "pooled")]
        local, compact = local_gate(addr)
        pool_local, _ = local_gate(pool)
        cells = {}
        for cell in CELLS:
            docs = [doc for eval_seed in PANEL for doc in panel[eval_seed][cell]]
            cells[cell] = verify_one_cell(docs, addr["cells"][cell], pool["cells"][cell], compact)
        accept.append(local["passes"] and all(c["modes"]["addressed"]["both"] >= 34 for c in cells.values()) and all(
            cells[cell]["modes"]["addressed"]["both"] - cells[cell]["modes"][control]["both"] >= 18
            for cell in ("depth3", "depth4") for control in ("pooled", "wrong_scope")
        ))
        outcomes[seed] = dict(local=local, pooled_local=pool_local, cells=cells,
                              token_lengths=data["document_token_lengths"],
                              epoch_loss={"addressed": addr["epoch_loss"], "pooled": pool["epoch_loss"]})
    receipts = [name for name in names if name.endswith("/receipt.json")]
    assert len(receipts) == 4
    for name in receipts:
        data = json.loads(read(name))
        assert data["status"] == "passed" and len(data["checks"]) == 1
        check, = data["checks"]
        log = str(Path(name).with_name(Path(check["log_path"]).name))
        assert sha(read(log)) == check["log_sha256"]
    return dict(source=SOURCE, panel=panel_hash, fixed_gate=all(accept), outcomes=outcomes,
                receipts=sorted(Path(name).parent.name for name in receipts))


def verify(path, prior):
    with ZipFile(path) as archive:
        assert archive.testzip() is None and len(archive.namelist()) == len(set(archive.namelist()))
        result = recount(archive.read, archive.namelist(), prior)
        assert json.dumps(result, sort_keys=True) == json.dumps(json.loads(archive.read("decision.json")), sort_keys=True)
    print(json.dumps(result))


def bundle(root, destination, prior):
    files = {name: root / name for name in (
        "addressed.py", "binding_score.py", "addressed.yaml", "frozen.sha256", "protocol.txt", "recount.py",
        "panel.json", "panel.sha256", "fit-8831.json", "fit-8832.json", "fit-8833.json",
    )}
    for receipt in (root / "receipts").glob("*/*/receipt.json"):
        for name in ("receipt.json", "check-1.log", "checks-config.yaml"):
            path = receipt.with_name(name)
            files[path.relative_to(root).as_posix()] = path
    result = recount(lambda name: files[name].read_bytes(), files, prior)
    with ZipFile(destination, "x", compression=ZIP_DEFLATED) as archive:
        for name, path in files.items():
            archive.write(path, name)
        archive.writestr("decision.json", json.dumps(result, indent=2) + "\n")
    verify(destination, prior)


if __name__ == "__main__":
    mode, *args = sys.argv[1:]
    {"bundle": bundle, "verify": verify}[mode](*map(Path, args))
