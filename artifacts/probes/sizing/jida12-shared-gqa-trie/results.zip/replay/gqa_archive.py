import hashlib
import json
import statistics
import sys
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


REGISTRATION = "b8fb99e8920a5661e8a50f9e7fabfe2ccdbfade4"
LOCK = "6000222853c691c6847cf7174ad0a9be119e7d8431226957d8f8c81ccabef239"
SHIPPED = "dacc4e61d678007e11b7be311e4d0573bdca6c280d506443cc20ae0631790c19"
GRID = {(1, 128), (1, 512), (2, 128), (2, 512), (4, 512)}
STAGES = ("prefill", "fork", "first", "steady")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def recount(read, paths):
    lock = read("replay/frozen.sha256")
    assert digest(lock) == LOCK
    for line in lock.decode().splitlines():
        expected, name = line.split()
        assert digest(read(f"replay/{name}")) == expected
    incumbent = digest(read("replay/incumbent_trie.py"))
    assert incumbent == SHIPPED
    receipts = [name for name in paths if name.endswith("/receipt.json")]
    assert len(receipts) == 1 and "/hierarchy-shared-gqa-trie/" in receipts[0]
    proof = json.loads(read(receipts[0]))
    assert len(proof["checks"]) == 1
    check = proof["checks"][0]
    log = receipts[0].removesuffix("receipt.json") + Path(check["log_path"]).name
    assert digest(read(log)) == check["log_sha256"]
    receipt = dict(registration=REGISTRATION, receipt_id=receipts[0].split("/")[-2], status=proof["status"])
    if proof["status"] != "passed":
        return dict(**receipt, advance=False)
    data = json.loads(read("results.json"))
    assert (data["heads"], data["layers"], data["width"], data["K"], data["samples"]) == (4, 2, 64, 8, 7)
    assert data["incumbent_sha256"] == incumbent
    assert data["candidate_sha256"] == digest(read("replay/candidate_trie.py"))
    assert data["exact_digit_comparisons"] == 100992
    assert len(data["lifecycle"]) == 5 and all(count == 5760 for count in data["lifecycle"].values())
    workloads = {(row["kv_heads"], row["context"]): row for row in data["workloads"]}
    assert len(data["workloads"]) == 5 and set(workloads) == GRID
    for (kv_heads, n), row in workloads.items():
        assert row["bitwise_logit_elements"] == (n + 18) * 128
        for stage, batch, capacity in (("prefill_storage", 1, n), ("decode_storage", 2, n + 9)):
            old, new = (row[arm][stage] for arm in ("incumbent", "shared"))
            assert old["dense"] == new["dense"] == 2 * 2 * batch * kv_heads * capacity * 16 * 4
            assert old["tries"] == 2 * batch * 4 and new["tries"] == 2 * batch * kv_heads
            assert old["trie"] * kv_heads == new["trie"] * 4
            assert all(arm["total"] == arm["dense"] + arm["trie"] for arm in (old, new))
        assert row["fraction_saved"] == 1 - row["shared"]["decode_storage"]["total"] / row["incumbent"]["decode_storage"]["total"]
        paired = row["paired"]
        assert len(paired) == 7 and all(set(item["order"]) == {"incumbent", "shared"} for item in paired)
        for item in paired:
            for arm in ("incumbent", "shared"):
                assert set(item[arm]) == set(STAGES) and all(t > 0 for t in item[arm].values())
        ratios = {phase: statistics.median(item["incumbent"][phase] / item["shared"][phase] for item in paired)
                  for phase in STAGES}
        assert ratios == row["speedup"]
    criteria = dict(physical_gqa_saving=all(row["fraction_saved"] >= .15 for (h, _), row in workloads.items() if h < 4),
                    mha_no_growth=workloads[(4, 512)]["fraction_saved"] == 0,
                    long_fork_decode_gain=all(workloads[(h, 512)]["speedup"]["first"] >= 1.15 for h in (1, 2)),
                    no_large_latency_regression=all(row["speedup"][metric] >= .90 for row in workloads.values()
                                                    for metric in ("prefill", "steady")))
    assert criteria == data["criteria"] and data["advance"] == all(criteria.values())
    return dict(**receipt, **data)


def bundle(root, out):
    frozen = root / "frozen.sha256"
    files = {"replay/frozen.sha256": frozen, "replay/gqa_archive.py": root / "gqa_archive.py",
             "replay/incumbent_trie.py": root / "source/nanochat/ultrametric_attention_torch.py"}
    for line in frozen.read_text().splitlines():
        _, name = line.split()
        files[f"replay/{name}"] = root / name
    result = root / "results.json"
    if result.is_file():
        files["results.json"] = result
    for receipt in (root / "receipts").glob("*/*/receipt.json"):
        for name in ("receipt.json", "check-1.log", "checks-config.yaml"):
            path = receipt.with_name(name)
            files[str(path.relative_to(root))] = path
    decision = recount(lambda name: files[name].read_bytes(), files)
    with ZipFile(out, "x", compression=ZIP_DEFLATED) as archive:
        for name, path in files.items():
            archive.write(path, name)
        archive.writestr("decision.json", json.dumps(decision, indent=2) + "\n")


def verify(out):
    with ZipFile(out) as archive:
        assert archive.testzip() is None
        names = archive.namelist()
        assert len(names) == len(set(names))
        assert not any(name.endswith((".pt", ".parquet", ".safetensors")) for name in names)
        decision = recount(archive.read, names)
        assert decision == json.loads(archive.read("decision.json"))
    print(json.dumps(decision))


if __name__ == "__main__":
    command, *paths = sys.argv[1:]
    {"bundle": bundle, "verify": verify}[command](*map(Path, paths))
