"""Pair live setup costs and independently check the compiled policy CLI."""

import argparse
import copy
import json
import statistics
import subprocess
import sys
import time
from collections import Counter
from pathlib import Path

from check_alternating_route import witness_questions
from check_short_certificate import action, answers, checksum, plain, read, validate_tape

from scripts.group_student_probe import export_alternating_policy, proposal_panel


def untimed(data):
    result = plain(data)
    del result["alternating_cpu_ns"]
    return result


def write(path, value):
    with path.open("x", encoding="utf-8") as output:
        json.dump(value, output, indent=2, sort_keys=True)
        output.write("\n")


def paid_totals(report, arm):
    tapes = [row["arms"][arm]["paid"] for row in report["results"]]
    return dict(calls=sum(map(len, tapes)), symbols=sum(len(a) + len(b) for tape in tapes for a, b, _ in tape))


def paired(coverage, run):
    previous = untimed(read(run / "prior.json"))
    policy = run / "bench-policy.json"
    start = time.process_time_ns()
    export_alternating_policy(policy)
    export_ns = time.process_time_ns() - start
    metrics = []
    for index in range(7):
        order = ("compile", "load") if index % 2 == 0 else ("load", "compile")
        trial = {}
        for mode in order:
            path = run / f"pair-{index}-{mode}.json"
            proposal_panel(coverage, path, alternating_route=mode == "compile", alternating_policy=policy if mode == "load" else None)
            report = read(path)
            if untimed(report) != previous:
                raise ValueError(f"Non-timing fields changed in pair {index}, {mode}")
            trial[mode] = dict(
                setup_ns=report["alternating_cpu_ns"], common_ns=report["common_cpu_ns"], short_ns=report["short_cpu_ns"],
                online_extended_ns=sum(row["arms"]["extended"]["cpu_ns"] for row in report["results"]),
                online_routed_ns=sum(row["arms"]["routed"]["cpu_ns"] for row in report["results"]),
            )
        metrics.append(trial)
    compile_ns = statistics.median(row["compile"]["setup_ns"] for row in metrics)
    load_ns = statistics.median(row["load"]["setup_ns"] for row in metrics)
    variable_delta_ns = statistics.median(
        row["load"]["setup_ns"] + row["load"]["online_extended_ns"] - row["load"]["online_routed_ns"] for row in metrics
    )
    write(run / "timings.json", dict(
        paired_runs=[dict(index=index, order=list(trial), **trial) for index, trial in enumerate(metrics)],
        export_ns=export_ns, policy_bytes=policy.stat().st_size,
        median_compile_ns=compile_ns, median_load_ns=load_ns, median_cold_delta_ns=variable_delta_ns,
        extended=paid_totals(previous, "extended"), routed=paid_totals(previous, "routed"),
        sixty_percent_gate=5 * load_ns <= 2 * compile_ns, exact_comparison=True,
    ))


def verify_full_policy(policy, certificates):
    if len(policy["entries"]) != 57 or set(certificates) != set(policy["entries"]):
        raise ValueError("Wrong policy dimensions")
    depths = Counter()
    for identifier, entry in policy["entries"].items():
        # Decode the last permutation points as arithmetic modulo two. The
        # reference constructs a graph without the producer's permutation orbit code.
        marks = [mark[:5] + [int(mark[5] == 6)] for mark in entry["marks"]]
        graph, _ = action("a5xc2", marks)
        if len(graph) != 120 or checksum(graph) != identifier:
            raise ValueError("Asset entry does not reconstruct its graph")
        questions = list(map(list, witness_questions(entry)))
        if certificates[identifier] != dict(basis=entry["basis"], bindings=entry["bindings"], questions=questions):
            raise ValueError("Loaded certificate did not preserve the authored witness")
        if not 1 <= len(questions) <= 7 or not all(answers(graph, pair) for pair in questions):
            raise ValueError("The reconstructed certificate did not hold")
        node = policy["tree"]
        depth = 0
        while isinstance(node, list):
            depth += 1
            node = node[2] if answers(graph, node[:2]) else node[3]
        if node != identifier or depth > 7:
            raise ValueError("Selector reaches wrong leaf")
        depths[depth] += 1
    return dict(sorted(depths.items()))


def rejected(command, reason):
    result = subprocess.run(command, check=False, text=True, capture_output=True)
    if result.returncode == 0 or reason not in result.stderr:
        raise ValueError(f"Expected command to refuse with {reason}: {result.stderr}")
    return dict(exit_code=result.returncode, stdout=result.stdout, stderr=result.stderr)


def verify_cli(coverage, run):
    path = run / "policy.json"
    policy = read(path)
    for repeat in ("policy-repeat.json", "bench-policy.json"):
        if path.read_bytes() != (run / repeat).read_bytes():
            raise ValueError("Policy export changed across invocations")
    old = untimed(read(run / "prior.json"))
    cli = read(run / "loaded.json")
    if untimed(cli) != old:
        raise ValueError("Policy CLI changed the paid evidence")
    depths = verify_full_policy(policy, cli["alternating_certificates"])

    manifest = read(coverage)
    arms = ("fallback", "edge", "short", "routed", "extended")
    for case, row in zip(manifest["cases"], cli["results"], strict=True):
        graph, _ = action(case["family"], case["marks"])
        if checksum(graph) != row["graph_sha"] or set(row["arms"]) != set(arms):
            raise ValueError("The CLI coverage changed")
        for arm in row["arms"].values():
            validate_tape(graph, arm["paid"])
            if arm["right"] != graph:
                raise ValueError("An independently constructed graph differs")

    cli_without_route = plain(read(run / "default.json"))
    del old["alternating_certificates"]
    for row in old["results"]:
        del row["arms"]["routed"], row["arms"]["extended"]
    if cli_without_route != old:
        raise ValueError("The default proposal CLI differs from the original")

    cli_base = [sys.executable, "-m", "scripts.group_student_probe"]
    first, second, *_ = policy["entries"]
    failures = {}
    for kind, reason in (
        ("changed-marking", "The marked graph digest does not match"),
        ("omitted-binding", "Invalid presentation words"),
        ("false-binding", "The presentation does not certify its marked graph"),
        ("swapped-branch", "selector"),
        ("foreign-schema", "Unknown alternating policy schema"),
        ("malformed-json", "Invalid compiled alternating policy"),
    ):
        mutation = copy.deepcopy(policy)
        match kind:
            case "changed-marking":
                mutation["entries"][first]["marks"] = mutation["entries"][second]["marks"]
            case "omitted-binding":
                mutation["entries"][first]["bindings"].pop()
            case "false-binding":
                mutation["entries"][first]["bindings"][0] = "1"
            case "swapped-branch":
                mutation["tree"][2], mutation["tree"][3] = mutation["tree"][3], mutation["tree"][2]
            case "foreign-schema":
                mutation["schema"] = "foreign.v1"
        bad, output = run / f"{kind}.json", run / f"{kind}-output.json"
        if kind == "malformed-json":
            with bad.open("x", encoding="utf-8") as file:
                file.write("{")
        else:
            write(bad, mutation)
        failures[kind] = rejected([*cli_base, "proposal", "--data", ".", "--coverage", str(coverage),
                                   "--alternating-policy", str(bad), "--output", str(output)], reason)
        if output.exists():
            raise ValueError(f"Invalid policy {kind} produced a result")
    original = path.read_bytes()
    failures["overwrite"] = rejected([*cli_base, "compile-alternating-policy", "--data", ".", "--output", str(path)], "File exists")
    if path.read_bytes() != original:
        raise ValueError("Compilation overwrote the existing policy")
    timing = read(run / "timings.json")
    write(run / "verified.json", dict(
        exact=True, default_unchanged=True, validated_markings=57, selector_depths=depths,
        checked_transitions=20 * 120 * 2 * len(arms), rejected_inputs=failures, timing=timing,
    ))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("paired", "verify"))
    parser.add_argument("coverage", type=Path)
    parser.add_argument("run", type=Path)
    args = parser.parse_args()
    selected = paired if args.mode == "paired" else verify_cli
    selected(args.coverage, args.run)
