#!/bin/bash
set -euo pipefail
export PATH="/home/ubuntu/.local/bin:$PATH"
export MGR_PAIR_SHA=ff0d9f45a8be54e607957ec843a54fda37da17e4
export DSR_REPOS_FILE=/data/ssd/tmp/mgr-paired-answer.0v90pl7G/campaign.yaml DSR_QUALITY_LOG_DIR=/data/ssd/tmp/mgr-paired-answer.0v90pl7G/receipts
export UV_PROJECT_ENVIRONMENT=/data/ssd/tmp/mgr-eval-ci.bevt3nLW/qualified-venv
export OMP_NUM_THREADS=4 MKL_NUM_THREADS=4
dsr quality --tool paired-answer-preflight --work-dir /data/ssd/tmp/mgr-paired-answer.0v90pl7G/gate --check-timeout 180
dsr quality --tool paired-answer-train --work-dir /data/ssd/tmp/mgr-paired-answer.0v90pl7G/gate --check-timeout 1200
for run in answer-ce answer-swap; do
    export MGR_PAIR_RUN="$run"
    dsr quality --tool paired-answer-eval --work-dir /data/ssd/tmp/mgr-paired-answer.0v90pl7G/gate --check-timeout 240
done
