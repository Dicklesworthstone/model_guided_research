import hashlib
import itertools
import json
import math
import statistics
import sys
from collections import Counter
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import ragged as experiment
from address_fixtures import DIM, sha_json

SOURCE = "f1a1ac1e12f96c7846ca64daa09358d12a17f65a"
LOCK = "b67b422847d43de57c068fb551ac2d99c22840be81b2555a409f92cb86cb4802"
FAILED_LOCK = "3ce6f3394f3af9563f7a2bbc1b35cc3d95a51c1db5601084a04e7e16c7a8bcef"
FILES = ("address_fixtures.py", "topology.py", "ragged.py", "ragged.yaml", "frozen.sha256",
         "protocol.txt", "repair.txt", "ragged-raw.json", "ragged_replay.py", "argument.md", "replay.yaml",
         *(f"setup-failure/{name}" for name in ("ragged.py", "frozen.sha256", "receipt.json",
                                                "check-1.log", "checks-config.yaml")))


def hash_bytes(data):
    return hashlib.sha256(data).hexdigest()


def verify_receipt(read, names):
    receipt_path, = (p for p in names if p.startswith("receipts/") and p.endswith("/receipt.json"))
    receipt = json.loads(read(receipt_path))
    assert receipt["tool"] == "hierarchy-ragged-shape" and receipt["status"] == "passed"
    assert receipt["passed"] == receipt["executed"] == receipt["total"] == 1
    assert not receipt["dry_run"] and not receipt["skipped"]
    check, = receipt["checks"]
    assert check["passed"] and check["executed"] and check["exit_code"] == 0
    log_path = Path(receipt_path).with_name(Path(check["log_path"]).name).as_posix()
    assert hash_bytes(read(log_path)) == check["log_sha256"]
    cfg = Path(receipt_path).with_name("checks-config.yaml").as_posix()
    assert read(cfg) == read("ragged.yaml")
    assert hash_bytes(read(cfg)) == receipt["config_sha256"] == receipt["config_sha256_after"]
    return Path(receipt_path).parent.name


def verify_setup_failure(read):
    previous = read("setup-failure/frozen.sha256")
    assert hash_bytes(previous) == FAILED_LOCK
    for line in previous.decode().splitlines():
        sha, path = line.split()
        source = "setup-failure/ragged.py" if path == "ragged.py" else path
        assert hash_bytes(read(source)) == sha
    old = read("setup-failure/ragged.py").splitlines()
    new = read("ragged.py").splitlines()
    insertion = new.index(b"            leaves.add(down)")
    assert new[:insertion] + new[insertion + 1:] == old
    receipt = json.loads(read("setup-failure/receipt.json"))
    assert receipt["status"] == "failed" and receipt["executed"] == receipt["failed"] == 1
    check, = receipt["checks"]
    assert check["exit_code"] == 1
    log = read("setup-failure/check-1.log")
    assert hash_bytes(log) == check["log_sha256"]
    assert b"assert len(leaves) == 64 and len(nodes) == N" in log and b"AssertionError" in log
    assert read("setup-failure/checks-config.yaml") == read("ragged.yaml")
    return Path(receipt["run_dir"]).name


def connected_profile(records, root, decode):
    stack = [(root, 0)]
    seen = set()
    depth_counts = Counter()
    while stack:
        p, depth = stack.pop()
        node = decode(p)
        if node in seen:
            return None
        seen.add(node)
        depth_counts[depth] += 1
        stack.extend((child, depth + 1) for child in records[node])
    if len(seen) != len(records):
        return None
    return [depth_counts[i] for i in range(max(depth_counts) + 1)]


def queried_path(records, root, query, decode):
    path = [decode(root)]
    for alias in query:
        row = records[path[-1]]
        if not row:
            return None
        path.append(decode(row[alias]))
    return None if records[path[-1]] else tuple(path)


def independent(case):
    first, second = [orientation["records"] for orientation in case["orientations"]]
    root, query, known = (case[field] for field in ("root", "query", "profile"))

    def missing(bank):
        parity = min(bank).bit_count() % 2
        hole, = (x for x in range(256) if x.bit_count() % 2 == parity and x not in bank)
        return hole

    missing_key = missing(set(first))
    missing_ptr = missing({root, *(symbol for entry in first.values() for symbol in entry)})
    full = 0
    maps = 0
    logs = [{arm: Counter() for arm in experiment.ARMS} for _ in range(2)]
    for images in itertools.permutations(tuple(1 << k for k in range(DIM))):
        def decode(encoded):
            relative = encoded ^ missing_ptr
            return missing_key ^ sum(bit for j, bit in enumerate(images) if relative & (1 << j))

        maps += 1
        profile = connected_profile(first, root, decode)
        if profile is None:
            continue
        full += 1
        for observed, log in zip((first, second), logs, strict=True):
            trace = queried_path(observed, root, query, decode)
            if trace is not None:
                log["tree"][trace] += 1
                if len(profile) == len(known):
                    log["height"][trace] += 1
                if profile == known:
                    log["profile"][trace] += 1
    return dict(bank_maps=maps, connected_maps=full, arms={arm: [
        dict(query_maps=sum(log[arm].values()), routes=[[route, count] for route, count in sorted(log[arm].items())])
        for log in logs] for arm in experiment.ARMS})


def check_case(case, family, namespace):
    first, second = case["orientations"]
    keys = first["records"].keys()
    assert keys == second["records"].keys() and len(keys) == 127 and all(key.bit_count() % 2 for key in keys)
    assert sum(not row for row in first["records"].values()) == 64
    assert sum(not row for row in second["records"].values()) == 64
    pivot, = (key for key in keys if first["records"][key] != second["records"][key])
    assert first["records"][pivot] == second["records"][pivot][::-1]
    assert first["gold"][case["edit_hop"]] == second["gold"][case["edit_hop"]] == pivot
    assert first["gold"][:case["edit_hop"]] == second["gold"][:case["edit_hop"]]
    assert first["gold"][-1] != second["gold"][-1]
    order, flips = namespace
    inverse = {int("".join(f"{key:08b}"[::-1][src] for src in reversed(order)), 2) ^ flips: key for key in keys}
    for orientation in (first, second):
        rows = orientation["records"]
        assert connected_profile(rows, case["root"], inverse.__getitem__) == case["profile"]
        assert queried_path(rows, case["root"], case["query"], inverse.__getitem__) == tuple(orientation["gold"])
    if family == "perfect":
        assert case["profile"] == [1 << i for i in range(7)]
    elif family == "regrafted":
        assert case["profile"] == [1, 2, 4, 8, 16, 32, 56, 8]


def unconstrained_counts():
    result = []
    for internal in (1, 2, 3):
        n = 2 * internal + 1
        valid = 0
        for labels in itertools.permutations(range(n)):
            root = labels[0]
            records = {key: labels[2*key+1:2*key+3] if key < internal else () for key in range(n)}
            valid += connected_profile(records, root, lambda word: word) is not None
        assert valid == math.factorial(n - 1)
        result.append(dict(nodes=n, unrestricted_bijections=math.factorial(n), rooted_full_trees=valid))
    return result


def replay(read, names):
    lock = read("frozen.sha256")
    assert hash_bytes(lock) == LOCK
    for line in lock.decode().splitlines():
        sha, path = line.split()
        assert hash_bytes(read(path)) == sha
    rows = json.loads(read("ragged-raw.json"))
    assert len(rows) == 72
    totals = {name: dict(pairs=0, connected=[], heights=[], early_edits=0,
                        arms={arm: dict(routes=0, endpoints=0, unique_maps=0, query_maps=[])
                              for arm in experiment.ARMS}) for name in experiment.FAMILIES}
    independent_cases = []
    for row, (seed, family, index, namespace, fixture) in zip(rows, experiment.fresh(), strict=True):
        check_case(fixture, family, namespace)
        assert (row["seed"], row["family"], row["index"], row["fixture"]) == (seed, family, index, sha_json(fixture))
        calc = experiment.process([view["records"] for view in fixture["orientations"]],
                                  fixture["root"], fixture["query"], fixture["profile"])
        for key, value in json.loads(json.dumps(calc)).items():
            assert row[key] == value
        if seed == experiment.SEEDS[0] and index == 0:
            assert independent(fixture) == calc
            independent_cases.append(family)
        assert row["bank_maps"] == 40320 and 1 <= row["connected_maps"] <= row["bank_maps"]
        family_record = totals[family]
        family_record["pairs"] += 1
        family_record["connected"].append(row["connected_maps"])
        family_record["heights"].append(len(fixture["profile"]) - 1)
        family_record["early_edits"] += fixture["edit_hop"] + 1 < len(fixture["query"])
        for orientation in range(2):
            previous = None
            for arm in experiment.ARMS:
                variant = row["arms"][arm][orientation]
                observed = {tuple(route): maps for route, maps in variant["routes"]}
                assert tuple(fixture["orientations"][orientation]["gold"]) in observed
                assert 1 <= variant["query_maps"] == sum(observed.values()) <= row["connected_maps"]
                if previous is not None:
                    assert all(0 < count <= previous.get(path, 0) for path, count in observed.items())
                previous = observed
        for arm, outcomes in row["arms"].items():
            cell = family_record["arms"][arm]
            cell["routes"] += all(len(entry["routes"]) == 1 for entry in outcomes)
            cell["endpoints"] += all(len({route[-1] for route, _ in entry["routes"]}) == 1 for entry in outcomes)
            cell["unique_maps"] += all(entry["query_maps"] == 1 for entry in outcomes)
            cell["query_maps"].extend(entry["query_maps"] for entry in outcomes)
    assert independent_cases == list(experiment.FAMILIES)
    for family in totals.values():
        assert family["pairs"] == 24
        family["connected_map_median"] = statistics.median(family.pop("connected"))
        heights = family.pop("heights")
        family["height_range"] = [min(heights), max(heights)]
        for cell in family["arms"].values():
            survival = cell.pop("query_maps")
            cell["query_map_median"] = statistics.median(survival)
    gates = dict(perfect_profile=totals["perfect"]["arms"]["profile"]["routes"] >= 20,
                 regrafted_profile=totals["regrafted"]["arms"]["profile"]["routes"] >= 18,
                 perfect_tree=totals["perfect"]["arms"]["tree"]["routes"] <= 8)
    return dict(source=SOURCE, fit_receipt=verify_receipt(read, names), setup_failure=verify_setup_failure(read),
                pairs=len(rows), gates=gates,
                pass_all=all(gates.values()), families=totals, independent=independent_cases,
                unrestricted=unconstrained_counts())


def verify(path):
    with ZipFile(path) as archive:
        names = archive.namelist()
        assert archive.testzip() is None and len(names) == len(set(names))
        result = replay(archive.read, names)
        assert result == json.loads(archive.read("decision.json"))
    print(json.dumps(result))


def build(root, bundle):
    files = {name: root / name for name in FILES}
    receipt, = (root / "receipts").glob("*/*/receipt.json")
    for name in ("receipt.json", "check-1.log", "checks-config.yaml"):
        path = receipt.with_name(name)
        files[path.relative_to(root).as_posix()] = path
    result = replay(lambda name: files[name].read_bytes(), files.keys())
    with ZipFile(bundle, "x", compression=ZIP_DEFLATED) as archive:
        for name, path in files.items():
            archive.write(path, name)
        archive.writestr("decision.json", json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    action, *paths = sys.argv[1:]
    {"build": build, "verify": verify}[action](*map(Path, paths))
