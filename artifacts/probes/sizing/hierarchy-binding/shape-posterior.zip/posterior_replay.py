import hashlib
import itertools
import json
import math
import statistics
import sys
from collections import Counter, defaultdict
from fractions import Fraction
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import posterior as post
from address_fixtures import DIM, sha_json

SOURCE = "94090df078faa69b657d4011f6e4cf56cd66996a"
LOCK = "23d860bd3867159435994e0d179fe3732c9e72c1d30a94d691e9282249119879"
FILES = ("address_fixtures.py", "topology.py", "posterior.py", "posterior.yaml", "frozen.sha256",
         "protocol.txt", "posterior-raw.json", "posterior_replay.py", "argument.md", "replay.yaml")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def receipt_id(read, names):
    path, = (name for name in names if name.endswith("/receipt.json"))
    doc = json.loads(read(path))
    assert doc["tool"] == "hierarchy-hook-posterior" and doc["status"] == "passed"
    assert doc["passed"] == doc["executed"] == doc["total"] == 1
    assert not doc["dry_run"] and not doc["skipped"]
    check, = doc["checks"]
    assert check["passed"] and check["executed"] and check["exit_code"] == 0
    log = Path(path).with_name(Path(check["log_path"]).name).as_posix()
    assert digest(read(log)) == check["log_sha256"]
    cfg = Path(path).with_name("checks-config.yaml").as_posix()
    assert read(cfg) == read("posterior.yaml")
    assert digest(read(cfg)) == doc["config_sha256"] == doc["config_sha256_after"]
    return Path(path).parent.name


def history_checks():
    histories = {frozenset(("",)): 1}
    report = []
    for m in range(6):
        assert len(histories) == math.comb(2 * m, m) // (m + 1)
        assert sum(histories.values()) == math.factorial(m)
        weights = []
        for leaves, count in histories.items():
            prefixes = {leaf[:i] for leaf in leaves for i in range(len(leaf))}
            assert len(prefixes) == m
            hooks = math.prod(sum(child.startswith(v) for child in prefixes) for v in prefixes)
            assert count * hooks == math.factorial(m)
            weights.append(Fraction(1, hooks))
        assert sum(weights) == 1
        report.append(dict(internal=m, shapes=len(histories), histories=sum(histories.values())))
        new = Counter()
        for leaves, count in histories.items():
            for leaf in leaves:
                new[frozenset((leaves - {leaf}) | {leaf + "0", leaf + "1"})] += count
        histories = new
    return report


def independent_catalog(records, root, query):
    def omitted(words):
        parity = min(words).bit_count() % 2
        hole, = (word for word in range(256) if word.bit_count() % 2 == parity and word not in words)
        return hole

    x0 = omitted(set(records))
    p0 = omitted({root, *(s for branches in records.values() for s in branches)})
    connected = 0
    bank_count = 0
    totals = Counter()
    for order in itertools.permutations(tuple(1 << k for k in range(DIM))):
        def decode(p):
            relative = p0 ^ p
            return x0 ^ sum(bit for k, bit in enumerate(order) if relative & (1 << k))

        def descend(pointer):
            selected = decode(pointer)
            if selected in seen:
                return -1, 0
            seen.add(selected)
            branches = records[selected]
            if not branches:
                return 0, 1
            left_n, left_h = descend(branches[0])
            right_n, right_h = descend(branches[1])
            size = 1 + left_n + right_n
            return size, size * left_h * right_h

        bank_count += 1
        seen = set()
        size, hooks = descend(root)
        if len(seen) != len(records):
            continue
        assert size == post.INTERNAL and hooks >= 1
        connected += 1
        pointer = root
        for alias in query:
            branch = records[decode(pointer)]
            if not branch:
                break
            pointer = branch[alias]
        else:
            key = decode(pointer)
            if not records[key]:
                totals[key, hooks] += 1
    return dict(bank_maps=bank_count, rooted_maps=connected,
                versions=[[key, hooks, count] for (key, hooks), count in sorted(totals.items())])


def oracle_fixture(records, root, query, target, namespace):
    order, flips = namespace
    inverse = {int("".join(f"{key:08b}"[::-1][i] for i in reversed(order)), 2) ^ flips: key for key in records}
    remaining = [root]
    seen = set()
    while remaining:
        key = inverse[remaining.pop()]
        assert key not in seen
        seen.add(key)
        remaining.extend(records[key])
    assert seen == records.keys()
    pointer = root
    for alias in query:
        pointer = records[inverse[pointer]][alias]
    assert inverse[pointer] == target and not records[target]


def check_exact_probabilities(raw):
    versions = raw["versions"]
    counts = Counter()
    histories = defaultdict(Fraction)
    for key, hooks, multiplicity in versions:
        counts[key] += multiplicity
        histories[key] += Fraction(multiplicity, hooks)
    for beta, weights in ((0, counts), (1, histories)):
        total = sum(weights.values())
        result = post.probabilities(versions, beta)
        assert result.keys() == weights.keys()
        assert all(math.isclose(result[key], float(Fraction(value, total)), rel_tol=0, abs_tol=1e-15)
                   for key, value in weights.items())


def replay(read, names):
    lock = read("frozen.sha256")
    assert digest(lock) == LOCK
    for line in lock.decode().splitlines():
        sha, path = line.split()
        assert digest(read(path)) == sha
    raw = json.loads(read("posterior-raw.json"))
    assert len(raw["rows"]) == len({r["fixture"] for r in raw["rows"]}) == 192
    splits = defaultdict(list)
    independent = []
    for row, (seed, family, phase, index, records, root, query, target, namespace) in zip(
        raw["rows"], post.fresh(), strict=True
    ):
        assert (row["seed"], row["family"], row["phase"], row["index"]) == (seed, family, phase, index)
        assert row["fixture"] == sha_json([records, root, query]) and row["target"] == target
        oracle_fixture(records, root, query, target, namespace)
        reproduced = post.catalog(records, root, query)
        assert all(row[key] == value for key, value in reproduced.items())
        if seed == post.SEEDS[0] and phase == "test" and index == 0:
            assert independent_catalog(records, root, query) == reproduced
            independent.append(family)
        check_exact_probabilities(row)
        assert target in {key for key, _, _ in row["versions"]}
        assert row["bank_maps"] == 40320 and 1 <= sum(count for _, _, count in row["versions"]) <= row["rooted_maps"]
        splits[seed, family, phase].append(row)
    assert independent == list(post.FAMILIES)
    details = {}
    for seed in post.SEEDS:
        details[str(seed)] = {}
        for family in post.FAMILIES:
            train = splits[seed, family, "train"]
            test = splits[seed, family, "test"]
            assert len(train) == len(test) == post.CASES
            beta, nll_grid = post.fit(train)
            quality = dict(beta=beta, train_grid_nll=nll_grid, uniform=post.evaluate(test, 0),
                           yule=post.evaluate(test, 1), learned=post.evaluate(test, beta))
            assert quality == raw["fitted"][str(seed)][family]
            details[str(seed)][family] = quality
    pooled = {}
    for family in post.FAMILIES:
        seen = [row for seed in post.SEEDS for row in splits[seed, family, "test"]]
        metrics = {arm: {
            key: sum(d[family][arm][key] for d in details.values()) if key == "correct"
            else statistics.mean(d[family][arm][key] for d in details.values()) for key in ("nll", "brier", "correct")
        } for arm in ("uniform", "yule", "learned")}
        pooled[family] = dict(cases=len(seen), ambiguous=sum(len({key for key, _, _ in row["versions"]}) > 1
                                                           for row in seen), metrics=metrics)
    yule = pooled["yule"]["metrics"]
    cat = pooled["catalan"]["metrics"]
    gates = dict(yule_oracle=yule["uniform"]["nll"] - yule["yule"]["nll"] >= .10,
                 yule_learned=all(d["yule"]["uniform"]["nll"] - d["yule"]["learned"]["nll"] >= .05
                                  for d in details.values()),
                 catalan_control=cat["learned"]["nll"] - cat["uniform"]["nll"] <= .15)
    return dict(source=SOURCE, receipt=receipt_id(read, names), train=96, test=96, details=details, pooled=pooled,
                gates=gates, pass_all=all(gates.values()), independent=independent, small_exact=history_checks())


def verify(bundle):
    with ZipFile(bundle) as archive:
        names = archive.namelist()
        assert archive.testzip() is None and len(names) == len(set(names))
        decision = replay(archive.read, names)
        assert decision == json.loads(archive.read("decision.json"))
    print(json.dumps(decision))


def build(root, bundle):
    files = {name: root / name for name in FILES}
    receipt, = (root / "receipts").glob("*/*/receipt.json")
    for name in ("receipt.json", "check-1.log", "checks-config.yaml"):
        path = receipt.with_name(name)
        files[path.relative_to(root).as_posix()] = path
    decision = replay(lambda name: files[name].read_bytes(), files.keys())
    with ZipFile(bundle, "x", compression=ZIP_DEFLATED) as archive:
        for name, path in files.items():
            archive.write(path, name)
        archive.writestr("decision.json", json.dumps(decision, indent=2) + "\n")
    print(json.dumps(decision))


if __name__ == "__main__":
    action, *paths = sys.argv[1:]
    {"build": build, "verify": verify}[action](*map(Path, paths))
