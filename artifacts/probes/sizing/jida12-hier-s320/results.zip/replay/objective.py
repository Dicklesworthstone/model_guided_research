import dataclasses
import hashlib
import json
import math
import random
import sys
import time
from pathlib import Path

import pyarrow.parquet as parquet
import torch

sys.path.insert(0, str(Path.cwd()))
from nanochat.checkpoint_manager import save_checkpoint
from nanochat.diagnostics_data import TASKS
from nanochat.gpt import GPT, GPTConfig
from nanochat.report import build_provenance
from nanochat.tokenizer import HuggingFaceTokenizer

SEED = 17
STEPS = 2048
BATCH_SIZE = 4
CONTEXT = 320

def param_hash(model):
    return hashlib.sha256(b"".join(parameter.detach().numpy().tobytes() for parameter in model.parameters())).hexdigest()

def main(root):
    base = root / "runs" / "standard" / "b30-s0" / "checkpoints"
    metadata = json.loads((base / "meta_003558.json").read_bytes())
    config = GPTConfig(**metadata["model_config"])
    assert (config.n_layer, config.n_embd, config.n_head, config.n_kv_head, config.sequence_len) == (4, 128, 8, 4, CONTEXT)
    tok = HuggingFaceTokenizer.from_directory(str(base / "tokenizer"))
    bos = tok.get_bos_token_id()
    docs = parquet.read_table(root / "data" / "hier" / "train_000.parquet", columns=["text"]).column("text").to_pylist()
    order = list(range(len(docs)))
    random.Random(SEED).shuffle(order)
    spec = TASKS["hier"]
    selected = []
    for index in order:
        doc = docs[index]
        tokens = tok.encode(doc, prepend=bos)
        if len(tokens) > CONTEXT + 1:
            continue
        prompt, _ = spec.split_prompt(doc)
        prompt_tokens = tok.encode(prompt, prepend=bos)
        assert 0 < len(prompt_tokens) < len(tokens) and tokens[:len(prompt_tokens)] == prompt_tokens
        selected.append((index, tokens, len(prompt_tokens)))
        if len(selected) == STEPS * BATCH_SIZE:
            break
    assert len(selected) == STEPS * BATCH_SIZE
    assert len({docs[index] for index, _, _ in selected}) == len(selected)
    inputs = torch.full((len(selected), CONTEXT), bos, dtype=torch.long)
    full_targets = torch.full_like(inputs, -1)
    answer_targets = torch.full_like(inputs, -1)
    for i, (_, tokens, prompt) in enumerate(selected):
        inputs[i, :len(tokens)-1] = torch.tensor(tokens[:-1])
        full_targets[i, :len(tokens)-1] = torch.tensor(tokens[1:])
        answer_targets[i, prompt-1:len(tokens)-1] = torch.tensor(tokens[prompt:])
    assert torch.equal(full_targets[answer_targets >= 0], answer_targets[answer_targets >= 0])
    assert (answer_targets >= 0).any(dim=1).all()
    schedule = {
        "row_count": len(selected), "source_row_ids": [row[0] for row in selected],
        "inputs_sha256": hashlib.sha256(inputs.numpy().tobytes()).hexdigest(),
        "full_target_tokens": int((full_targets >= 0).sum()), "answer_target_tokens": int((answer_targets >= 0).sum()),
        "tokenizer_sha256": hashlib.sha256((base / "tokenizer" / "tokenizer.json").read_bytes()).hexdigest(),
    }
    destination = root / "objective-schedule.json"
    with destination.open("x", encoding="utf-8") as handle:
        handle.write(json.dumps(schedule, indent=2) + "\n")
    starting_hash = None
    for run_id, targets in (("objective-full-s17", full_targets), ("objective-answer-s17", answer_targets)):
        torch.manual_seed(SEED)
        model = GPT(config)
        model.init_weights()
        initial = param_hash(model)
        if starting_hash is None:
            starting_hash = initial
        assert initial == starting_hash
        optimizer = torch.optim.AdamW(model.parameters(), lr=0.0006)
        start = time.perf_counter()
        for step in range(STEPS):
            group = slice(step * BATCH_SIZE, (step + 1) * BATCH_SIZE)
            optimizer.zero_grad(set_to_none=True)
            loss = model(inputs[group], targets=targets[group])
            if not math.isfinite(float(loss.detach())):
                raise ValueError(f"{run_id}: nonfinite loss at step {step}")
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            if step == 0 or (step + 1) % 256 == 0:
                print(f"{run_id} step {step + 1}/{STEPS} loss {float(loss.detach()):.6f}", flush=True)
        planned_flops = float(model.estimate_flops() * (BATCH_SIZE * CONTEXT * STEPS))
        elapsed = time.perf_counter() - start
        run = root / "runs" / "standard" / run_id
        checkpoint = run / "checkpoints"
        checkpoint.mkdir(parents=True)
        tok.save(str(checkpoint / "tokenizer"))
        save_checkpoint(str(checkpoint), STEPS - 1, model.state_dict(), None, {
            "model_config": dataclasses.asdict(config), "optimizer_type": "adamw", "scheduler_type": "none",
            "seed": SEED, "tokenizer": {"kind": "task", "dir": "tokenizer"},
            "budget": {"target_flops": planned_flops, "max_steps": STEPS},
            "lineage": {"run_id": run_id, "parent_run_ids": []},
        }, rank=0)
        options = {
            "run_id": run_id, "objective": run_id.split("-")[1], "seed": SEED,
            "steps": STEPS, "batch_size": BATCH_SIZE, "learning_rate": 0.0006, "gradient_clip": 1.0,
            "input_schedule_sha256": schedule["inputs_sha256"],
        }
        summary = dict(options=options, provenance=build_provenance(options), initial_parameter_sha256=initial,
                       final_parameter_sha256=param_hash(model), elapsed_training_seconds=elapsed,
                       measured_training_flops_est=planned_flops, final_training_ce=float(loss.detach()))
        with (run / "summary.json").open("x", encoding="utf-8") as handle:
            handle.write(json.dumps(summary, indent=2) + "\n")
        print(json.dumps(summary), flush=True)

if __name__ == "__main__":
    main(Path(sys.argv[1]))
