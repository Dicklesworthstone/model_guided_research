"""Benchmark exact conditioning of small-group indexes on the paid anchors."""

import argparse
import json
import random
from collections import defaultdict
from itertools import product
from pathlib import Path
from time import monotonic_ns, process_time_ns

from active import ANCHORS
from base_study import oracle_table
from catalogue_study import canonical, catalogue_learning, endpoint

ORDERS = (32, 64, 128)
PROFILES = ("0000", "0110", "0112", "0120", "0123")
ABELIAN = PROFILES[:3]


def partition(values):
    blocks = {}
    return "".join(str(blocks.setdefault(item, len(blocks))) for item in values)


PARTITIONS = sorted({partition(values) for values in product(range(4), repeat=4)})


def full_index(n, groups):
    shapes = set()
    for _, table in groups:
        for a, b in product(range(n), repeat=2):
            shape = canonical(table, a, b)
            if len(shape) == n:
                shapes.add(shape)
    indices = defaultdict(list)
    for shape in sorted(shapes):
        indices[partition(endpoint(shape, word) for word in ANCHORS)].append(shape)
    return {code: indices[code] for code in PARTITIONS}, len(groups) * n * n


def filtered_index(n, groups, code):
    if code not in PROFILES:
        return [], 0
    commuting = code in ABELIAN
    identical = code == "0000"
    equal_squares = code in {"0110", "0120"}
    traversals = 0
    shapes = set()
    for abelian, table in groups:
        if abelian != commuting:
            continue
        square = [table[i][i] for i in range(n)]
        pairs = ((a, a) for a in range(n)) if identical else product(range(n), repeat=2)
        for a, b in pairs:
            if not identical and (a == b or (square[a] == square[b]) != equal_squares):
                continue
            if not commuting and table[a][b] == table[b][a]:
                continue
            traversals += 1
            shape = canonical(table, a, b)
            if len(shape) == n:
                shapes.add(shape)
    return sorted(shapes), traversals


def lattice_index(n, code):
    if code not in ABELIAN:
        return [], 0
    shapes = []
    traversals = 0
    for width in range(1, n + 1):
        height, rest = divmod(n, width)
        if rest:
            continue
        for shift in range(width):
            # Quotient Z² by the column basis (width, 0), (shift, height).
            transitions = [
                (y * width + (x + 1) % width, (y + 1) * width + x if y < height - 1 else (x - shift) % width)
                for y, x in product(range(height), range(width))
            ]
            if partition(endpoint(transitions, word) for word in ANCHORS) == code:
                traversals += 1
                shapes.append(canonical(transitions, 0, 1))
    return sorted(shapes), traversals


def inversion_index(n):
    shapes = []
    for rotations in range(3, n + 1):
        layers, rest = divmod(n, rotations)
        if rest or layers % 2:
            continue
        for twist in (0, rotations // 2) if rotations % 2 == 0 else (0,):
            transitions = []
            for y, x in product(range(layers), range(rotations)):
                next_y = (y + 1) % layers
                next_x = x if next_y else (x + twist) % rotations
                delta = -1 if next_y % 2 else 1
                block = next_y * rotations
                transitions.append((block + next_x, block + (next_x + delta) % rotations))
            shapes.append(canonical(transitions, 0, 1))
    return sorted(shapes), len(shapes)


def timed(builder, *args):
    wall, cpu = monotonic_ns(), process_time_ns()
    result, calls = builder(*args)
    return result, {"calls": calls, "cpu_ns": process_time_ns() - cpu, "wall_ns": monotonic_ns() - wall}


def encode(shapes):
    return [bytes(step for row in shape for step in row).hex() for shape in shapes]


def learn_from(spec, reference, routed, inversion):
    name, kind, dimensions, primitives = spec
    action = tuple(zip(*oracle_table(kind, dimensions, primitives), strict=True))
    labels = [f"opaque{i:02d}" for i in range(len(action))]
    random.Random(251531 + (kind == "torus")).shuffle(labels)
    initial = {word: labels[endpoint(action, word)] for word in ANCHORS}
    code = partition(initial.values())
    rows = {}
    policies = {"full": reference[code], "routed": routed[code]}
    if code == "0120":
        policies["inversion"] = inversion
    for policy, shapes in policies.items():
        paid = []

        def ask(word, tape=paid):
            label = labels[endpoint(action, word)]
            tape.append([word, label])
            return label

        right, events, terminal = catalogue_learning(initial, set(labels), ask, shapes)
        rows[policy] = {"paid": paid, "right": right, "events": events, "terminal": terminal, "trace": None}
    return {"case": name, "spec": spec, "labels": labels, "initial": initial, "profile": code, "rows": rows}


def run_order(n, groups, *, reverse):
    if not reverse:
        reference, baseline = timed(full_index, n, groups)
    profiles, routed = {}, {}
    for code in reversed(PARTITIONS) if reverse else PARTITIONS:
        filtered, stats = timed(filtered_index, n, groups, code)
        profiles[code] = {"filtered": encode(filtered), "filter_work": stats}
        if code in ABELIAN:
            lattice, stats = timed(lattice_index, n, code)
            profiles[code].update(lattice=encode(lattice), lattice_work=stats)
            routed[code] = lattice
        else:
            routed[code] = filtered
    if reverse:
        reference, baseline = timed(full_index, n, groups)
    inversion, inversion_work = timed(inversion_index, n)
    profiles["0120"].update(inversion=encode(inversion), inversion_work=inversion_work)
    for code, row in profiles.items():
        row["full"] = encode(reference[code])
    integrations = []
    if n == 32:
        for spec in (
            ("dihedral-32", "ring", (16,), ("T", "FT")),
            ("four-by-eight", "torus", (4, 8), ("F", "F")),
        ):
            integrations.append(learn_from(spec, reference, routed, inversion))
    return {"order": n, "groups": len(groups), "full_work": baseline, "profiles": profiles, "integrations": integrations}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("tables", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--reverse", action="store_true")
    args = parser.parse_args()
    try:
        gap, smallgrp, _, tables = json.loads(args.tables.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        parser.error(str(error))
    if (gap, smallgrp) != ("4.16.1", "1.7.0"):
        raise ValueError("Unexpected source catalogue version")
    rows = []
    for n in ORDERS:
        groups = [(abelian, table) for size, _, _, abelian, table in tables if size == n]
        row = run_order(n, groups, reverse=args.reverse)
        rows.append(row)
        print(n, sum(len(p["full"]) for p in row["profiles"].values()), flush=True)
    with args.output.open("x", encoding="utf-8") as handle:
        json.dump({"orders": rows}, handle, sort_keys=True)
        handle.write("\n")


if __name__ == "__main__":
    main()
