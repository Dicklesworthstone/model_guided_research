import argparse
import json
import math
import statistics
import sys
from pathlib import Path

import torch

sys.path.insert(0, str(Path.cwd()))
from cli import _eval_split_examples, _load_eval_checkpoint
from nanochat.diagnostics_data import TASKS
from nanochat.tokenizer import checkpoint_tokenizer

def leaves(tree):
    words = iter(tree.split())
    trail = []
    for word in words:
        if word == "(":
            trail.append(next(words))
        elif word == ")":
            trail.pop()
        else:
            yield tuple(trail), word

def common_prefix(left, right):
    for index, (a, b) in enumerate(zip(left, right, strict=True)):
        if a != b:
            return index
    return len(left)

def score_answer(model, tok, prompt, answer):
    prefix = tok.encode(prompt, prepend=tok.get_bos_token_id())
    entire = tok.encode(f"{prompt} {answer}", prepend=tok.get_bos_token_id())
    assert entire[:len(prefix)] == prefix
    assert len(prefix) < len(entire) <= model.config.sequence_len + 1
    token_ids = torch.tensor(entire, dtype=torch.long)
    with torch.inference_mode():
        logits = model(token_ids[:-1].unsqueeze(0))[0, len(prefix)-1:].float()
        log_probs = logits.log_softmax(dim=-1)
        chosen = log_probs.gather(-1, token_ids[len(prefix):].unsqueeze(-1)).flatten()
    return float(chosen.sum()), len(chosen)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path)
    parser.add_argument("run")
    args = parser.parse_args()
    directory = args.root / "runs" / "standard" / args.run
    candidate = directory / "checkpoints"
    model, meta, step = _load_eval_checkpoint(candidate, None, torch.device("cpu"), fingerprint_weights=True)
    tok = checkpoint_tokenizer(candidate, meta)
    spec = TASKS["hier"]
    rows = []
    answer_nll = []
    for seed in (0, 1, 2):
        docs, _, _ = _eval_split_examples(spec, n=24, seed=seed)
        for index, doc in enumerate(docs):
            assert spec.checker(doc) is True
            prompt, answer = spec.split_prompt(doc)
            tree, source = prompt.removeprefix("TASK hier TREE ").split(" PATH ")
            query = tuple(source.removesuffix(" OUT").split())
            table = dict(leaves(tree))
            assert table[query] == answer
            observed = len(tok.encode(prompt))
            choices = []
            for path, value in table.items():
                if len(path) != len(query) or value == answer:
                    continue
                other = f"TASK hier TREE {tree} PATH {' '.join(path)} OUT"
                if len(tok.encode(other)) == observed:
                    choices.append((path, value, other))
            log_aa, count = score_answer(model, tok, prompt, answer)
            answer_nll.append(-log_aa / count)
            row = dict(seed=seed, index=index, query=query, answer=answer, answer_log_p=log_aa, answer_tokens=count)
            if choices:
                path, value, other = min(choices, key=lambda choice: (-common_prefix(query, choice[0]), choice[0]))
                assert spec.checker(f"{other} {value}") is True
                assert spec.checker(f"{other} {answer}") is False
                log_ab, _ = score_answer(model, tok, prompt, value)
                log_ba, _ = score_answer(model, tok, other, answer)
                log_bb, _ = score_answer(model, tok, other, value)
                row.update(other_query=path, other_answer=value, crossed_log_p=[log_ab, log_ba], other_answer_log_p=log_bb,
                           interaction_nats=((log_aa - log_ba) + (log_bb - log_ab)) / 2)
            rows.append(row)
    interactions = [row["interaction_nats"] for row in rows if "interaction_nats" in row]
    report = dict(run_id=args.run, checkpoint_step=step, checkpoint_sha256=meta["weights_sha256"],
                  evidence_use="sizing_only", panel_documents=len(rows), matched_pairs=len(interactions),
                  positive=sum(value > 0 for value in interactions), zero=interactions.count(0.0),
                  negative=sum(value < 0 for value in interactions),
                  mean_interaction_nats=statistics.mean(interactions) if interactions else None,
                  median_interaction_nats=statistics.median(interactions) if interactions else None,
                  mean_doc_answer_perplexity=statistics.mean(math.exp(nll) for nll in answer_nll),
                  rows=rows)
    with (directory / "answer-interaction.json").open("x", encoding="utf-8") as output:
        json.dump(report, output, indent=2)
        output.write("\n")
    print(json.dumps({key: value for key, value in report.items() if key != "rows"}))

if __name__ == "__main__":
    main()
