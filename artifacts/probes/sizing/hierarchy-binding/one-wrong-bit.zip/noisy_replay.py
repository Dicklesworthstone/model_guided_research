import hashlib
import json
import statistics
import sys
from collections import Counter
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import noisy
import probes
from address_fixtures import DIM, POOLS, sha_json
from posterior_replay import independent_catalog, oracle_fixture

SOURCE = "6f40d69f01f9a12ce4572d1be0bba116445626e2"
LOCK = "d0c349e5e84b765ca9435b1eb0adb4dfdc1f29080a4bbf981322898330fb6d1b"
SHADOW = "03c66dc47b91756fd082ed775d56f9ed741b7b434f887fdd4a1c46a2a1471793"
FILES = ("address_fixtures.py", "topology.py", "posterior.py", "posterior_replay.py", "probes.py",
         "noisy.py", "noisy.yaml", "frozen.sha256", "protocol.txt", "noisy-raw.json",
         "noisy_replay.py", "argument.md", "replay.yaml")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def verify_receipt(read, files):
    path, = (name for name in files if name.endswith("/receipt.json"))
    receipt = json.loads(read(path))
    assert receipt["tool"] == "hierarchy-one-wrong-bit" and receipt["status"] == "passed"
    assert receipt["passed"] == receipt["executed"] == receipt["total"] == 1
    assert not receipt["dry_run"] and not receipt["skipped"]
    check, = receipt["checks"]
    assert check["passed"] and check["executed"] and check["exit_code"] == 0
    log = Path(path).with_name(Path(check["log_path"]).name).as_posix()
    assert digest(read(log)) == check["log_sha256"]
    config = Path(path).with_name("checks-config.yaml").as_posix()
    assert read(config) == read("noisy.yaml")
    assert digest(read(config)) == receipt["config_sha256"] == receipt["config_sha256_after"]
    return Path(path).parent.name


def direct_encode(key, permutation, signs):
    digits = f"{key:08b}"[::-1]
    return int("".join(digits[i] for i in reversed(permutation)), 2) ^ signs


def trace_check(decisions, labels, truth, record_keys, predict_bit):
    truth_label = labels[truth]
    checks = 0
    for arm, outcomes in decisions.items():
        assert len(outcomes) == len(noisy.FLIPS)
        for flip, outcome in zip(noisy.FLIPS, outcomes, strict=True):
            trace = outcome["trace"]
            assert len(trace) <= (2 if arm == "noiseless" else noisy.BUDGET)
            for index, (key, coordinate, value) in enumerate(trace, start=1):
                assert key in record_keys and 0 <= coordinate < DIM and value in (0, 1)
                assert value == (predict_bit(truth, key, coordinate) ^ (index == flip))
            limit = int(arm != "noiseless")
            surviving = {label for i, label in enumerate(labels)
                         if sum(predict_bit(i, key, coordinate) != value for key, coordinate, value in trace) <= limit}
            expected = next(iter(surviving)) if len(surviving) == 1 else None
            assert expected == outcome["answer"]
            if limit:
                assert truth_label in surviving and expected in (None, truth_label)
            checks += 1
    assert checks == 24
    assert all(row["answer"] == decisions["noiseless"][0]["answer"] for row in decisions["repeat_check"])
    assert len(decisions["repeat_check"][0]["trace"]) <= 4


def check_toy(raw):
    assert raw == noisy.planted()
    trace_check(raw, [17, 93], 0, {7}, lambda i, _key, _pos: 1 - i)
    assert raw["noiseless"][1]["answer"] == 93
    assert all(row["answer"] == 17 for arm in noisy.ARMS[1:] for row in raw[arm])
    assert max(len(row["trace"]) for arm in noisy.ARMS[1:] for row in raw[arm]) == 3
    for b in (1, 2, 3):
        templates = {bit: {tuple(bit ^ (place == flip) for place in range(1, b + 1))
                           for flip in range(b + 1)} for bit in (0, 1)}
        assert len(templates[0]) == len(templates[1]) == b + 1
        assert templates[0].isdisjoint(templates[1]) == (2 * (b + 1) <= 2 ** b)
    return dict(noiseless_false_leaf=93, robust_leaf=17, minimum_repeated_bits=3)


def summarize(raw):
    denom = len(raw)
    metrics = {}
    for arm in noisy.ARMS:
        scenarios = [(row["decisions"][arm], row["target"]) for row in raw]
        metrics[arm] = dict(
            all_schedules_correct=sum(all(r["answer"] == gold for r in trace) for trace, gold in scenarios),
            no_error_correct=sum(trace[0]["answer"] == gold for trace, gold in scenarios),
            false_schedules=sum(r["answer"] not in (None, gold) for trace, gold in scenarios for r in trace),
            cases_with_false=sum(any(r["answer"] not in (None, gold) for r in trace) for trace, gold in scenarios),
            max_bits=max(len(r["trace"]) for trace, _ in scenarios for r in trace),
            mean_bits_without_error=statistics.mean(len(trace[0]["trace"]) for trace, _ in scenarios),
        )
    return dict(cases=denom, schedules=denom * len(noisy.FLIPS), arms=metrics,
                over_sphere_bound=sum(len({leaf for _, leaf in row["versions"]}) * (noisy.BUDGET + 1) > 2 ** noisy.BUDGET
                                      for row in raw))


def replay(read, names, independent=False):
    lock = read("frozen.sha256")
    assert digest(lock) == LOCK
    for line in lock.decode().splitlines():
        sha, path = line.split()
        assert digest(read(path)) == sha
    assert digest(read("posterior_replay.py")) == SHADOW
    raw = json.loads(read("noisy-raw.json"))
    rows = raw["rows"]
    assert len(rows) == len({row["fixture"] for row in rows}) == 72
    toy = check_toy(raw["toy"])
    audit = []
    for row, fixture in zip(rows, noisy.fresh(), strict=True):
        seed, family, index, records, root, query, gold, namespace = fixture
        assert (row["seed"], row["family"], row["index"]) == (seed, family, index)
        assert row["fixture"] == sha_json([records, root, query]) and row["target"] == gold
        x0, p0 = row["base"]
        pointer_set = {root, *(symbol for links in records.values() for symbol in links)}
        assert set(POOLS[1]) - records.keys() == {x0}
        assert set(POOLS[min(pointer_set).bit_count() % 2]) - pointer_set == {p0}
        permutations = [tuple(order) for order, _ in row["versions"]]
        assert len(permutations) == len(set(permutations)) and all(sorted(order) == list(range(DIM)) for order in permutations)
        possible = [(order, p0 ^ direct_encode(x0, order, 0)) for order in permutations]
        truth = possible.index(namespace)
        labels = [leaf for _, leaf in row["versions"]]
        assert labels[truth] == gold
        for candidate, target in zip(possible, labels, strict=True):
            oracle_fixture(records, root, query, target, candidate)

        def bit(index, key, coordinate):
            return (direct_encode(key, *possible[index]) >> coordinate) & 1

        trace_check(row["decisions"], labels, truth, records.keys(), bit)
        if independent:
            questions = noisy.physical_probes(records, row["versions"], x0, p0)
            assert row["decisions"] == noisy.assess(labels, questions, truth)
            reuse = probes.assess(labels, probes.partitions(records, row["versions"], x0, p0), truth, seed + index)
            assert row["decisions"]["repeat_check"][0]["answer"] == reuse["2"]["answer_lookahead"]["answer"]
        if index == 0:
            audit.append([seed, family])
            if independent:
                census = independent_catalog(records, root, query)
                assert census["bank_maps"] == 40320
                tally = Counter()
                for leaf, _, count in census["versions"]:
                    tally[leaf] += count
                assert tally == Counter(labels)
    assert len(audit) == 6
    primary = [row for row in rows if len({leaf for _, leaf in row["versions"]}) > 1]
    assert primary
    overall = summarize(primary)
    families = {family: summarize([row for row in primary if row["family"] == family]) for family in probes.FAMILIES}
    increase = overall["arms"]["answer"]["all_schedules_correct"] - overall["arms"]["repeat_check"]["all_schedules_correct"]
    zero_false = all(outcome["answer"] in (None, row["target"]) for row in rows
                     for arm in noisy.ARMS[1:] for outcome in row["decisions"][arm])
    repeated_exact = all(outcome["answer"] == row["decisions"]["noiseless"][0]["answer"] for row in rows
                         for outcome in row["decisions"]["repeat_check"])
    gates = dict(ambiguous_count=len(primary) >= 32, zero_false_robust=zero_false,
                 repeated_exact=repeated_exact, direct_gain=increase >= 3)
    return dict(source=SOURCE, receipt=verify_receipt(read, names), panel=72, primary=overall,
                by_family=families, controls=toy, audit=audit, gates=gates,
                pass_all=all(gates.values()))


def verify(path):
    with ZipFile(path) as archive:
        names = archive.namelist()
        assert archive.testzip() is None and len(names) == len(set(names))
        result = replay(archive.read, names, independent=True)
        assert result == json.loads(archive.read("decision.json"))
    print(json.dumps(result))


def build(root, bundle):
    paths = {name: root / name for name in FILES}
    receipt, = (root / "receipts").glob("*/*/receipt.json")
    for name in ("receipt.json", "check-1.log", "checks-config.yaml"):
        target = receipt.with_name(name)
        paths[target.relative_to(root).as_posix()] = target
    result = replay(lambda name: paths[name].read_bytes(), paths.keys())
    with ZipFile(bundle, "x", compression=ZIP_DEFLATED) as archive:
        for name, target in paths.items():
            archive.write(target, name)
        archive.writestr("decision.json", json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    action, *paths = sys.argv[1:]
    {"build": build, "verify": verify}[action](*map(Path, paths))
