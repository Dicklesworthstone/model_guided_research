import Lean

namespace GroupEndpointAcquisition

theorem squareFill {State : Type} (left right : State → State)
    (commutes : ∀ x, left (right x) = right (left x))
    (x leftX rightX diagonal : State)
    (leftEdge : left x = leftX) (rightEdge : right x = rightX)
    (farRightEdge : right leftX = diagonal) : left rightX = diagonal := by
  rw [← rightEdge, commutes x, leftEdge, farRightEdge]

theorem forcedEndpoint {Model Label : Type} (satisfies : Model → Prop)
    (evaluate : Model → Label) (actual : Model) (value : Label)
    (actualFits : satisfies actual)
    (noAlternative : ¬ ∃ m, satisfies m ∧ evaluate m ≠ value) :
    evaluate actual = value := by
  by_cases different : evaluate actual = value
  · exact different
  · exact False.elim (noAlternative ⟨actual, actualFits, different⟩)

def advance {State Symbol : Type} (edge : State → Symbol → State)
    (start : State) : List Symbol → State
  | [] => start
  | symbol :: rest => advance edge (edge start symbol) rest

theorem suffixExact {State Symbol : Type} (actual recovered : State → Symbol → State)
    (everyEdge : ∀ x a, recovered x a = actual x a)
    (start : State) (suffix : List Symbol) :
    advance recovered start suffix = advance actual start suffix := by
  induction suffix generalizing start with
  | nil => rfl
  | cons symbol remaining ih =>
      simp only [advance, everyEdge]
      exact ih (actual start symbol)

#print axioms squareFill
#print axioms forcedEndpoint
#print axioms suffixExact

end GroupEndpointAcquisition
