"""Compare a constructive unseen-label alternative with the frozen SMT policy."""

import argparse
import json
import random
import resource
import subprocess
from collections import deque
from pathlib import Path
from time import monotonic_ns, process_time_ns

from active import ANCHORS, RESOURCES, BoundedModels, active_learning, endpoint, shortest_disagreement
from compare import visible_exploration
from verify import witness_endpoint

from scripts.group_rewrite_probe import teach_panel_case

CASES = (
    ("square-mirrors", "ring", 4, ("T", "FT"), False),
    ("pentagon-mirrors", "ring", 5, ("T", "FT"), False),
    ("hexagon-turn-first", "ring", 6, ("T", "F"), False),
    ("octagon-turn-first", "ring", 8, ("T", "F"), False),
    ("quaternion-units", "quaternion", 8, ("T", "T"), False),
    ("two-axis-torus", "torus", 3, ("F", "F"), False),
    ("square-mirrors-exhausted", "ring", 4, ("T", "FT"), True),
)
ARMS = ("square", "visible", "native", "conjugation")


def table_for(kind, scale, primitives):
    if kind == "quaternion":
        # States are 1, i, j, k, -1, -i, -j, -k. Index values start at 0.
        return ((1, 4, 7, 2, 5, 0, 3, 6), (2, 3, 4, 5, 6, 7, 0, 1))
    if kind == "torus":
        return (
            tuple((i + scale) % (scale * scale) for i in range(scale * scale)),
            tuple(i - i % scale + (i + 1) % scale for i in range(scale * scale)),
        )

    def endpoint_of(state, primitive):
        position, facing = divmod(state, 2)
        for motion in primitive:
            if motion == "T":
                facing = 1 - facing
            else:
                position = (position + 1 - 2 * facing) % scale
        return 2 * position + facing

    return tuple(tuple(endpoint_of(i, action) for i in range(2 * scale)) for action in primitives)


def naming_alternative(first, names, observations):
    """Find the shortest access to a name the oracle has not exposed."""
    unseen = set(range(len(names))) - {names.index(name) for name in observations.values()}
    if len(unseen) < 2:
        return None
    frontier = deque((word, endpoint(first, word)) for word in ANCHORS)
    visited = set()
    while frontier:
        word, state = frontier.popleft()
        if state in unseen:
            other = min(unseen - {state})
            swap = list(range(len(names)))
            swap[state], swap[other] = other, state
            second = {
                "root": swap[first["root"]],
                **{key: [swap[first[key][swap[i]]] for i in range(len(names))] for key in ("R0", "R1", "L0", "L1")},
            }
            expected = (
                witness_endpoint(first, names, observations, word),
                witness_endpoint(second, names, observations, word),
            )
            if expected != (names[state], names[other]):
                raise ValueError("Unseen-name permutation changed a known label or failed to disagree")
            return word, second, [state, other]
        if state not in visited:
            visited.add(state)
            frontier.extend((word + a, first["R" + a][state]) for a in "01")
    raise ValueError("Transitive model cannot reach an unseen label")


def conjugation_learning(initial, names, ask, *, exhausted):
    solver = BoundedModels("z3", initial, sorted(names), ask, audit=True, low_resource=exhausted)
    observations = dict(initial)
    events = []
    termination = "query-cap"
    try:
        for _ in range(65):
            event = {"base": solver.check()}
            events.append(event)
            status = event["base"]["status"]
            if status == "unknown":
                termination = "unknown-base"
                break
            if status != "sat":
                raise ValueError("The public oracle transcript is inconsistent")
            first = solver.witness()
            event["first"] = first
            named = naming_alternative(first, solver.names, observations)
            if named is not None:
                word, second, swapped = named
                event["swap"] = swapped
            else:
                alternative, second = solver.alternative_right_table(first)
                event["alternative"] = alternative
                if alternative["status"] == "unsat":
                    right = {
                        key: {name: solver.names[i] for name, i in zip(solver.names, first["R" + key], strict=True)}
                        for key in "01"
                    }
                    return right, events, "unique-right-table"
                if alternative["status"] == "unknown":
                    termination = "unknown-alternative"
                    break
                if second is None:
                    raise ValueError("SAT alternative supplied no model")
                word = shortest_disagreement(first, second)
            if word in observations:
                raise ValueError("Proposed an observed word")
            answer = ask(word)
            event.update(second=second, word=word, answer=answer)
            observations[word] = answer
            solver.commands.append(solver.assert_endpoint(word, answer))
    finally:
        solver.close()
    closure, _ = teach_panel_case(observations, set(names), ask, squares=True)
    return {mark: closure.maps["R" + mark] for mark in "01"}, events, termination


def run_case(case_spec, case_index):
    name, kind, scale, primitives, exhausted = case_spec
    table = table_for(kind, scale, primitives)
    labels = [f"opaque{i:02d}" for i in range(len(table[0]))]
    random.Random(251181 + case_index).shuffle(labels)

    def endpoint_oracle(word):
        state = 0
        for symbol in word:
            state = table[int(symbol)][state]
        return labels[state]

    initial = {word: endpoint_oracle(word) for word in ANCHORS}
    names = set(labels)
    rows = {}
    offset = case_index % len(ARMS)
    for arm in ARMS[offset:] + ARMS[:offset]:
        tape = []

        def ask(word):
            answer = endpoint_oracle(word)
            tape.append([word, answer])
            return answer

        before_cpu, before_wall = process_time_ns(), monotonic_ns()
        children_before = resource.getrusage(resource.RUSAGE_CHILDREN)
        if arm == "square":
            actions, _ = teach_panel_case(initial, names, ask, squares=True)
            right = {mark: actions.maps["R" + mark] for mark in "01"}
            events, terminal = [], "closure"
        elif arm == "visible":
            right, _ = visible_exploration(initial, names, ask)
            events, terminal = [], "exploration"
        else:
            learner = active_learning if arm == "native" else conjugation_learning
            right, events, terminal = learner(initial, names, ask, exhausted=exhausted)
        children_after = resource.getrusage(resource.RUSAGE_CHILDREN)
        cpu = process_time_ns() - before_cpu + round(
            1e9 * (children_after.ru_utime + children_after.ru_stime
                   - children_before.ru_utime - children_before.ru_stime)
        )
        rows[arm] = {
            "right": right, "paid": tape, "events": events, "terminal": terminal,
            "cpu_ns": cpu, "wall_ns": monotonic_ns() - before_wall,
        }
    return {
        "case": name, "kind": kind, "scale": scale, "primitives": primitives,
        "exhausted": exhausted, "labels": labels, "initial": initial, "arms": rows,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    version = subprocess.check_output(["z3", "--version"], text=True).strip()
    if not version.startswith("Z3 version 4.15.4 "):
        raise ValueError(f"Unexpected Z3 version {version}")
    cases = []
    for index, spec in enumerate(CASES):
        row = run_case(spec, index)
        cases.append(row)
        print(row["case"], row["arms"]["native"]["terminal"], row["arms"]["conjugation"]["terminal"], flush=True)
    with args.output.open("x", encoding="utf-8") as handle:
        json.dump({"cases": cases, "rlimit": RESOURCES, "z3": version}, handle, sort_keys=True)
        handle.write("\n")


if __name__ == "__main__":
    main()
