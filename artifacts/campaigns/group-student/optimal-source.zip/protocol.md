# Exact finite-horizon acquisition

Compare four live acquisition methods on every distinct rooted, ordered
generating-pair action from the audited GAP SmallGrp multiplication tables.
Orders 6 and 10 are primary. Order 12 is a fixed stress test. Every marked
action of a given order receives equal weight. A reset and read costs 16,
each command costs one, and every session pays for the four anchors.
Catalogue indexing, policy compilation, and online CPU are tracked separately.

The four arms are square closure, the released shortlist heuristic, the
exhaustive shortest-layer heuristic, and the exact expected-cost planner.
All run through the same acquisition API. The primary prediction requires
both primary orders to solve within 300,000 work units each, with the exact
arm at or below both greedy arms on each order and strictly cheaper than
at least one. Run the stress order with the same cap and report it regardless
of outcome. The cap counts distinct solve states, reachable endpoint vectors,
and candidate evaluations. Exhaustion produces no policy. Do not rerun at
a larger cap or change the price after observing any result.

Run two independent processes with different opaque names, roster order,
hash seeds, and opposite case and arm traversal order. Regenerate the group
inventory with the existing audited Cayley-table verifier. In both runs,
verify all named tables, roots, legal paid queries, and endpoint replies
against the reference action. Recount each operation from the raw tape and
require identical words across the relabelings. The planner's weighted sum
must equal the recount. Report total reads, both command counts, compilation
and acquisition CPU, and case-level regressions from each live control.

## Why the search certifies a minimum

A state retains each compatible rooted shape and the ordered state positions
that produced the distinct replies. For any labeling of an action, a query
returns the rank of a seen endpoint or an unused name. For each compatible
shape, every assignment of the unused names to the unobserved positions
still fits. Choosing a policy based on the spelling of a new name cannot
improve its expected cost under arbitrary opaque labels and an independent
uniform labeling. The same minimum is attainable for every relabeling by
the equality-only policy. The roster gives no other shape information.

Each candidate word induces a vector of endpoint positions over the compatible
shapes. Appending the same symbol to equal vectors produces equal successor
vectors. All permitted words start with a length-two anchor prefix. Shortlex
breadth-first traversal from the anchors therefore covers the entire reachable
product and holds one cheapest spelling per vector. Equal vectors give the
same division of shapes and the same name information. Resetting before
every query makes all later words available regardless of the current choice.

An invariant reply that has already been read yields the same state. An
invariant reply that names the sole remaining roster label is also already
deducible for every compatible shape. Both cases can be removed from a
minimum-cost policy because a query has positive cost. All remaining
transitions reduce the number of compatible shapes or reveal a new name.
Induction over the number of compatible shapes and then the number of
unobserved labels gives a finite Bellman recursion. At each state the
objective pays the word price once for each compatible shape and adds the
optimal sums of all children. The forced anchor prefix uses the same
partition and cost accounting. Equal-cost choices retain the earliest word.

The exact named action determines its canonical rooted shape. With multiple
shapes still compatible the learner needs more information. With one shape
left, a paid word can identify at most one previously unnamed position.
Every label except the last must be observed to exclude permutations of the
unseen labels. Taking each missing position's cheapest access word and
omitting the most expensive one attains this lower bound.

The result is a bound and a realizable optimum for this closed symbolic
oracle, order, weight, and inventory. It includes no hardware calibration,
model-guided discovery advantage, or human-research baseline.
