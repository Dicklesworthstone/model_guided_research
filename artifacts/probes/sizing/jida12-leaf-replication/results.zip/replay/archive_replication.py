import hashlib
import json
import sys
import zipfile
from pathlib import Path


def digest(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def load(path):
    return json.loads(path.read_bytes())


campaign, root, destination = map(Path, sys.argv[1:])
arms = ("detached", "joint")
seeds = (30, 31, 32)
source_revision = "fb0fe89a34cddd43285903d497e0c9b0a4e4cdb1"
script_digest = "1b39baf09dd902d3356a21a88cdc4eef0027094fdb11769d4132ad964aeb27e6"
assert digest(campaign / "leaf_position.py") == script_digest
first = root / "seed-30"
decision = dict(training_pairs=len(seeds), source_revision=source_revision, script_sha256=script_digest,
                panel_sha256=digest(first / "panel.json"), per_seed={})
initials, schedules = set(), set()
files = {name: first / name for name in ("panel.json", "manifest.json")}
for name in ("leaf_position.py", "campaign.yaml", "run.sh", "archive_replication.py", "verify_replication.py"):
    files[f"replay/{name}"] = campaign / name
for seed in seeds:
    prefix = f"seed-{seed}"
    run = root / prefix
    preflight = load(run / "preflight.json")
    assert (run / "panel.json").read_bytes() == files["panel.json"].read_bytes()
    assert (run / "manifest.json").read_bytes() == files["manifest.json"].read_bytes()
    assert digest(run / "schedule.pt") == preflight["schedule_sha256"]
    files[f"{prefix}/preflight.json"] = run / "preflight.json"
    metrics, train, metadata, artifact_hashes = {}, {}, {}, {}
    for arm in arms:
        training = run / "runs" / arm
        evaluation = run / "evals" / arm / "summary.json"
        checkpoint = training / "checkpoints"
        metadata[arm] = load(checkpoint / "meta_002047.json")
        train[arm] = load(training / "summary.json")
        evaluated = load(evaluation)
        settings = train[arm]["settings"]
        assert settings["seed"] == metadata[arm]["seed"] == seed
        assert settings["steps"] == metadata[arm]["budget"]["max_steps"] == 2048
        assert settings["batch"] == 8 and settings["train_width"] == 128
        assert train[arm]["model_flops_est"] == metadata[arm]["budget"]["target_flops"] == 13812614823936
        assert not train[arm]["provenance"]["tainted"]
        assert train[arm]["provenance"]["git_sha"] == evaluated["source_revision"] == source_revision
        assert evaluated["run_id"] == settings["run_id"] == arm
        model_hash = digest(checkpoint / "model_002047.pt")
        head_hash = digest(checkpoint / "location_head.pt")
        assert model_hash == evaluated["weights_sha256"]
        assert head_hash == evaluated["location_head_sha256"] == train[arm]["location_head_sha256"]
        artifact_hashes[arm] = dict(model_sha256=model_hash, head_sha256=head_hash)
        tokenizer = checkpoint / "tokenizer" / "tokenizer.json"
        assert digest(tokenizer) == preflight["tokenizer_sha256"]
        files.setdefault("tokenizer.json", tokenizer)
        assert tokenizer.read_bytes() == files["tokenizer.json"].read_bytes()
        metrics[arm] = {region: {key: value for key, value in result.items() if key != "rows"}
                        for region, result in evaluated["regions"].items()}
        for path in (training / "summary.json", evaluation, checkpoint / "meta_002047.json"):
            files[f"{prefix}/{path.relative_to(run)}"] = path
    baseline, treatment = (train[arm] for arm in arms)
    assert metadata["detached"]["model_config"] == metadata["joint"]["model_config"]
    assert baseline["initial_parameters_sha256"] == treatment["initial_parameters_sha256"]
    initials.add(treatment["initial_parameters_sha256"])
    schedules.add(preflight["schedule_sha256"])
    assert baseline["settings"]["schedule_sha256"] == treatment["settings"]["schedule_sha256"] == preflight["schedule_sha256"]
    assert (baseline["settings"]["location_gradient_multiplier"], treatment["settings"]["location_gradient_multiplier"]) == (0, 1)
    assert all(baseline["settings"][key] == value for key, value in treatment["settings"].items()
               if key not in {"location_gradient_multiplier", "run_id"})
    detached, joint = (metrics[arm]["in_range"]["both_positions"] for arm in arms)
    criteria = dict(joint_at_least_18=joint >= 18, gain_at_least_9=joint - detached >= 9)
    receipts = sorted((campaign / prefix / "receipts").glob("*/*/receipt.json"))
    assert len(receipts) == 4
    for receipt in receipts:
        report = load(receipt)
        assert report["status"] == "passed" and len(report["checks"]) == 1
        for check in report["checks"]:
            path = Path(check["log_path"])
            assert path.parent == receipt.parent and digest(path) == check["log_sha256"]
            files[str(path.relative_to(campaign))] = path
        for path in (receipt, receipt.with_name("checks-config.yaml")):
            files[str(path.relative_to(campaign))] = path
    decision["per_seed"][str(seed)] = dict(
        metrics=metrics, criteria=criteria, pass_gate=all(criteria.values()), checkpoint_hashes=artifact_hashes,
        receipt_ids=[path.parent.name for path in receipts],
    )
assert len(initials) == len(schedules) == len(seeds)
decision["replication_pass"] = all(run["pass_gate"] for run in decision["per_seed"].values())
with zipfile.ZipFile(destination, "x", compression=zipfile.ZIP_DEFLATED) as archive:
    for name, path in files.items():
        archive.write(path, name)
    archive.writestr("decision.json", json.dumps(decision, indent=2) + "\n")
