"""Verify the training and evaluation contracts on each task's selected baseline."""
import json
from pathlib import Path
import sys
root = Path(sys.argv[1])
runs = {
    "arith": "arith-tasktok-shuf-b1", "dyck": "dyck-tasktok-shuf-b1",
    "regime": "regime-v2-tasktok-shuf-b2-s256", "copyops": "copyops-tasktok-shuf-b4",
    "rot": "rot-tasktok-shuf-b10-s64", "group": "group-tasktok-shuf-b2-s256",
    "needle": "needle-tasktok-shuf-b2-s256", "bag": "bag-tasktok-shuf-b2-s256",
    "rel": "rel-tasktok-shuf-b2-s256", "hier": "hier-tasktok-shuf-b2-s256",
}
read = lambda path: json.loads(path.read_bytes())
rows = []
for task, run in runs.items():
    folder = root / f"vdc4-{run}-rung"
    manifest = read(folder / "manifest.json")
    selected = [c for c in manifest["cells"] if c["task"] == task and c["mechanism"] == "standard"]
    assert sorted(c["seed"] for c in selected) == [0,1,2]
    for c in selected:
        assert c["status"] == "done" and c["returncode"] == 0
        train = read(folder/c["train_summary_path"])
        ev = read(folder/c["eval_summary_path"])
        argv = train["meta"]["argv"]
        assert int(argv[argv.index("--seed")+1]) == c["seed"]
        assert train["hparams"]["data_shuffle"] == "epoch"
        assert ev["schema_version"] == "mgr.evaltasks.v4" and ev["meta"]["evaluator"]["bos_prefixed"] is True
        assert ev["meta"]["seeds"] == [0,1,2] and ev["meta"]["examples_per_seed"] == 48
        for prov in (train["provenance"],ev["provenance"],ev["train_provenance"]):
            assert prov["git_dirty"] is False and prov["tainted"] is False
        assert ev["train_provenance"]["git_sha"] == train["provenance"]["git_sha"]
        data = read(folder/"data"/task/"manifest.json")
        assert data["size"] == manifest["config"]["dataset_size"] and data["size"] >= 40000
        rows.append(dict(task=task, seed=c["seed"], training_rows=data["split_sizes"]["train"],
                         dataset_size=data["size"], run=folder.name, budget=c["budget_flops"],
                         shuffled=train["hparams"]["data_shuffle"], evaluator=ev["schema_version"],
                         bos_prefixed=True, training_source=train["provenance"]["git_sha"],
                         evaluation_source=ev["provenance"]["git_sha"], training=c["train_summary_path"],
                         evaluation=c["eval_summary_path"], held_out=ev["tasks"][task]["exact_match"]["greedy"]["held_out"]["mean"]))
print(json.dumps(dict(training_units=len(rows), task_count=len(runs), rows=rows), indent=2))
