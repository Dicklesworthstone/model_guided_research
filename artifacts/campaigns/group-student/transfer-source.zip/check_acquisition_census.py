"""Check the exact census and compare charges across deterministic relabelings."""

import hashlib
import json
import sys
from collections import Counter
from copy import deepcopy

import numpy as np
from check_four_anchor import ANCHORS, access, movement_floor, position
from check_replay import load

ARMS = ("square", "tiered")
SHAPE_COUNTS = {32: 151, 64: 503, 128: 1799}


class Columns:
    """Independent endpoint partitions for checking structural handoff."""

    def __init__(self, shapes):
        self.edges = np.asarray(shapes, dtype=np.uint8)
        self.cases = np.arange(len(shapes))
        self.cached = {"": np.zeros(len(shapes), dtype=np.uint8)}

    def word(self, value):
        if value not in self.cached:
            for i, mark in enumerate(value):
                prefix = value[:i + 1]
                if prefix not in self.cached:
                    self.cached[prefix] = self.edges[self.cases, self.cached[value[:i]], int(mark)]
        return self.cached[value]

    def observe(self, live, references, word, label):
        column = self.word(word)
        current = column[live]
        known = tuple(references)
        matches = np.empty((len(known), len(live)), dtype=np.bool_)
        for row, state in enumerate(known):
            matches[row] = current == references[state][live]
        novel = ~matches.any(axis=0)
        if label in references:
            keep = matches[known.index(label)]
        else:
            keep = novel
            references[label] = column
        return live[keep], int(novel.sum()), int(matches.sum(axis=1).max(initial=0))


def naming_check(result, words, initial, graph, n, slot, columns):
    events = result["events"]
    if [(e["word"], e["answer"]) for e in events] != [(w, label) for w, label in result["tape"][:len(events)]]:
        raise ValueError("Trace does not match its paid oracle calls")
    live = columns.cases
    references = {}
    for word, label in initial:
        live, _, _ = columns.observe(live, references, word, label)
    structural_reads = len(initial)
    naming = []
    for event, (word, state) in zip(events, words):
        if event["phase"] == "structure" and not naming:
            free, before = max(1, n - len(references)), len(live)
            live, novel, largest_known = columns.observe(live, references, word, state)
            score = dict(before=before, after=len(live), worst=max(novel, free * largest_known),
                         movement_debt=len(word) * before, wasted_reads=before - novel if free > 1 else before)
            if (before < 2 or score["worst"] >= before * free
                    or any(event[key] != value for key, value in score.items())):
                raise ValueError("Incorrect version-space count or selected probe score")
            structural_reads += 1
        elif event["phase"] == "naming":
            if event["before"] != 1 or event["after"] != 1:
                raise ValueError("Naming trace did not have a single surviving action")
            naming.append((word, state))
        else:
            raise ValueError("Wrong structure-to-naming order")
    survivors = live.tolist()
    if result["terminal"] == "cap":
        if len(survivors) < 2 or slot not in survivors or structural_reads != n + 24 or naming:
            raise ValueError("Fallback occurred at the wrong version-space boundary")
        return
    if result["terminal"] != "unique" or survivors != [slot] or len(words) != len(events):
        raise ValueError("Incorrect uniqueness at naming handoff")
    expected_naming = [(word, state) for state, word in access(graph) if state not in references][:-1]
    if naming != expected_naming:
        raise ValueError("Incorrect shortest naming suffix")


def run_names(n, slot, renamed):
    multiplier = 19 if renamed else 17
    intercept = 7 * slot + 11 if renamed else 13 * slot + 7
    labels = [str((i * multiplier + intercept) % n) for i in range(n)]
    if len(set(labels)) != n:
        raise ValueError("A replay did not use a naming permutation")
    return labels


def verify_row(row, graph, renamed, columns):
    n, slot = row["order"], row["slot"]
    names = run_names(n, slot, renamed)
    invert = {name: state for state, name in enumerate(names)}
    anchors = {word: names[position(graph, word)] for word in ANCHORS}
    if row["anchors"] != anchors or set(row["arms"]) != set(ARMS):
        raise ValueError("Wrong anchors or study arms")
    labelled = [None] * n
    for state, (a, b) in enumerate(graph):
        labelled[int(names[state])] = [names[a], names[b]]
    truth = [names[0], labelled]
    read_floor = n + 3 - len(set(anchors.values()))
    symbol_floor = movement_floor(truth, anchors)
    canonical_anchors = [(word, invert[name]) for word, name in anchors.items()]
    normalized = {}
    costs = {}
    for arm, result in row["arms"].items():
        tape = result["tape"]
        paid = [*anchors.items(), *tape]
        if (result["action"] != truth or len(paid) < read_floor or len({word for word, _ in paid}) != len(paid)
                or any(len(word) < 2 or names[position(graph, word)] != value for word, value in paid)):
            raise ValueError("An exact action, oracle answer, or read floor failed")
        words = [(word, invert[value]) for word, value in tape]
        if arm == "tiered" and columns is not None:
            naming_check(result, words, canonical_anchors, graph, n, slot, columns)
        zeros = sum(word.count("0") for word, _ in paid)
        ones = sum(word.count("1") for word, _ in paid)
        if zeros + ones < symbol_floor:
            raise ValueError("A tape undershot the exact movement floor")
        costs[arm] = dict(cases=1, reads=len(paid), zeros=zeros, ones=ones, symbols=zeros + ones,
                          fallback=int(result["terminal"] == "cap"), cpu_ns=result["cpu_ns"], wall_ns=result["wall_ns"])
        if arm == "tiered":
            scored = [event["compared"] for event in result["events"] if event["phase"] == "structure"]
            if any(type(count) is not int or count < 1 for count in scored):
                raise ValueError("Invalid tier scoring count")
            costs[arm].update(scored_words=sum(scored), structure_steps=len(scored))
        events = [dict(e, answer=invert[e["answer"]]) for e in result["events"]]
        normalized[arm] = dict(tape=words, terminal=result["terminal"],
                               events=events)
    return normalized, costs, read_floor, symbol_floor, canonical_anchors


def check_controls(sample):
    fallback = sample["fallback"]
    (target,) = (row for row in sample["rows"] if (row["order"], row["slot"]) == (fallback["order"], fallback["slot"]))
    result = fallback["result"]
    square = target["arms"]["square"]
    if (result["terminal"] != "cap" or result["events"] or target["arms"]["tiered"]["events"][0]["phase"] != "structure"
            or any(result[key] != square[key] for key in ("tape", "action")) or sample["duplicate_rejected"] is not True):
        raise ValueError("Forced fallback or invalid naming control failed")
    return dict(order=fallback["order"], slot=fallback["slot"], duplicate_rejected=True)


def prior_inventory(previous):
    shapes = {}
    for row in previous["orders"]:
        n = row["order"]
        forms = []
        for profile in row["profiles"].values():
            for encoded in profile["full"]:
                data = bytes.fromhex(encoded)
                if len(data) != 2 * n or max(data) >= n:
                    raise ValueError("Invalid historical graph encoding")
                forms.append(tuple(zip(data[::2], data[1::2], strict=True)))
        if len(forms) != SHAPE_COUNTS[n] or len(set(forms)) != len(forms) or n in shapes:
            raise ValueError("The historical marked inventory is incomplete")
        shapes[n] = sorted(forms)
    if set(shapes) != set(SHAPE_COUNTS):
        raise ValueError("A held-out order is absent")
    return dict(sorted(shapes.items()))


def audit(previous_path, first_path, replay_path):
    previous, first, second = map(load, (previous_path, first_path, replay_path))
    shapes = prior_inventory(previous)
    independent = hashlib.sha256(json.dumps(shapes, separators=(",", ":"), sort_keys=True).encode()).hexdigest()
    expected_count = {str(n): len(s) for n, s in shapes.items()}
    if first["renamed"] or not second["renamed"]:
        raise ValueError("The naming permutation replay was skipped")
    for sample in (first, second):
        if (sample["shape_digest"] != independent or sample["shape_counts"] != expected_count
                or len(sample["rows"]) != sum(expected_count.values())):
            raise ValueError("The complete marked census is missing or has duplicates")
    groups = [{str(n): {kind: {arm: Counter() for arm in ARMS} for kind in ("all", "abelian", "nonabelian")}
               for n in shapes} for _ in range(2)]
    floors = {str(n): Counter() for n in shapes}
    paired = {str(n): Counter() for n in shapes}
    relation_rows = zip(first["rows"], second["rows"], strict=True)
    transitions = 0
    forged_rejected = False
    for n, forms in shapes.items():
        partitions = Columns(forms)
        for slot, graph in enumerate(forms):
            original, renamed = next(relation_rows)
            if any((row["order"], row["slot"]) != (n, slot) for row in (original, renamed)):
                raise ValueError("The complete census was reordered")
            norm, costs, read_floor, symbol_floor, anchors = verify_row(original, graph, False, partitions)
            replay, replay_costs, _, _, permutation = verify_row(renamed, graph, True, None)
            if norm != replay or anchors != permutation:
                raise ValueError("A renamed case gave a different canonical tape or terminal state")
            events = original["arms"]["tiered"]["events"]
            if not forged_rejected and events and events[0]["phase"] == "structure":
                forged = deepcopy(original)
                forged["arms"]["tiered"]["events"][0]["worst"] += 1
                try:
                    verify_row(forged, graph, False, partitions)
                except ValueError as error:
                    if str(error) != "Incorrect version-space count or selected probe score":
                        raise
                    forged_rejected = True
                else:
                    raise ValueError("The checker accepted a forged structure score")
            kind = "abelian" if original["anchors"]["01"] == original["anchors"]["10"] else "nonabelian"
            for run, charges in zip(groups, (costs, replay_costs), strict=True):
                for arm, charge in charges.items():
                    run[str(n)]["all"][arm].update(charge)
                    run[str(n)][kind][arm].update(charge)
            for metric in ("reads", "symbols"):
                delta = costs["square"][metric] - costs["tiered"][metric]
                direction = "fewer" if delta > 0 else "more" if delta < 0 else "same"
                paired[str(n)][f"{direction}_{metric}"] += 1
            floors[str(n)].update(reads=read_floor, symbols=symbol_floor)
            transitions += 2 * n * len(ARMS) * 2
    if not forged_rejected:
        raise ValueError("The forged score control never ran")
    gates = []
    cold = []
    for run, sample in zip(groups, (first, second), strict=True):
        order_gates, cold_order = {}, {}
        for n, groups_at_order in run.items():
            tiered, square = (groups_at_order["all"][arm] for arm in ("tiered", "square"))
            cooling = sample["setup"][n]
            cold_order[n] = {clock: tiered[clock] + sum(cooling[stage][clock] for stage in
                             ("parse", "builder", "preparation", "tier_setup")) for clock in ("cpu_ns", "wall_ns")}
            order_gates[n] = dict(reads=tiered["reads"] < square["reads"], symbols=tiered["symbols"] < square["symbols"],
                                  cold_cpu=cold_order[n]["cpu_ns"] < square["cpu_ns"])
        gates.append(order_gates)
        cold.append(cold_order)
    print(json.dumps(dict(
        groups=groups, gates=gates, transfer_passed=all(flag for run in gates for row in run.values() for flag in row.values()),
        floors=floors, paired=paired, shape_counts=expected_count, checked_transitions=transitions,
        controls=[check_controls(sample) for sample in (first, second)],
        forged_score_rejected=forged_rejected, cold=cold, setup=[sample["setup"] for sample in (first, second)],
    ), sort_keys=True))


if __name__ == "__main__":
    audit(*sys.argv[1:])
