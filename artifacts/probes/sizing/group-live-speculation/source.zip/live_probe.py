"""Compare live bounded equality scheduling to isolated plans and archived replay."""
import argparse
import itertools
import json
import time
import tracemalloc
from pathlib import Path
from zipfile import ZipFile

from order_free_probe import CALL_LIMIT, LIBRARY, PRIOR, arm, checked_catalog, even

from scripts.group_rewrite_probe import rooted_graph
from scripts.group_student_probe import (
    cancelled_key,
    digest,
    graph_digest,
    plan_acquire_with_memo,
    plan_known_family,
    run_bounded_proposal,
    save,
    walk_action,
)

REUSED = Path("artifacts/probes/sizing/group-order-free/coverage.json")
ARCHIVED = REUSED.with_name("verification.zip")


def retained_control(family, elements, size, excluded):
    first = {}
    for pair in itertools.product(elements, repeat=2):
        graph = rooted_graph(family, pair)
        fingerprint = graph_digest(graph)
        if len(graph) == size and fingerprint not in excluded:
            first.setdefault(fingerprint, pair)
    return [
        dict(family=family, graph_sha=fingerprint, generators=pair, fresh=True)
        for fingerprint, pair in sorted(first.items())
    ]


def cover(output):
    old, *later = [json.loads(path.read_bytes()) for path in (*PRIOR, REUSED)]
    consumed = set(old["spent"]) | {case["graph_sha"] for case in old["presentations"]}
    consumed.update(case["graph_sha"] for manifest in later for case in manifest["cases"])
    with ZipFile(LIBRARY) as archive:
        witnesses = json.loads(archive.read("run.json"))["transports"]
    holdout = [
        dict(family="s5", graph_sha=key, generators=row["generators"], fresh=True)
        for key, row in sorted(witnesses.items())
        if key not in consumed
    ]
    a4 = [p for p in itertools.permutations(range(4)) if even(p)]
    c3 = [tuple((x + shift) % 3 for x in range(3)) for shift in range(3)]
    controls_a4 = retained_control("a4", a4, 12, consumed)
    controls_c3 = retained_control("c3", c3, 3, consumed)
    if (len(holdout), len(controls_a4), len(controls_c3)) != (2, 4, 4):
        raise ValueError("Unexpected remaining S5, A4 or C3 marking capacity")
    save(output, dict(
        producer=digest(Path(__file__)), reused=digest(REUSED), archived=digest(ARCHIVED),
        prior=[digest(path) for path in PRIOR], library=digest(LIBRARY),
        cases=holdout + controls_a4 + controls_c3,
    ))


def certified_proposal(catalog, certificates):
    selection = yield from plan_known_family(catalog)
    key = selection["marked_class"]
    observed = {tuple(row["pair"]): row["answer"] for row in selection["queries"]}
    checks = []
    for left, right, expected in certificates[key]:
        pair = (left, right)
        reused = pair in observed
        answer = observed[pair] if reused else (yield pair)
        checks.append(dict(pair=[left, right], expected=expected, answer=answer, reused=reused))
        if answer != expected:
            return None
    return dict(edges=catalog[key], proposal=selection, checks=checks)


def live_arm(graph, catalog, certificates):
    physical = []
    oracle_seconds = 0.0

    def equal(left, right):
        nonlocal oracle_seconds
        if len(physical) >= CALL_LIMIT:
            raise RuntimeError("The run exhausted its oracle call budget")
        start = time.perf_counter()
        answer = walk_action(left, graph) == walk_action(right, graph)
        oracle_seconds += time.perf_counter() - start
        physical.append((left, right, answer))
        return answer

    start = time.perf_counter()
    result = run_bounded_proposal(
        plan_acquire_with_memo(None, cancelled_key), certified_proposal(catalog, certificates), equal
    )
    elapsed = time.perf_counter() - start
    if [t[1:] for t in result["paid"]] != physical:
        raise ValueError("The live callback disagrees with the scheduler's charge tape")
    if tuple(tuple(row) for row in result["result"]["edges"]) != graph:
        raise ValueError("The live scheduler recovered the wrong action")
    result["seconds"] = elapsed
    result["oracle_seconds"] = oracle_seconds
    return result


def run(coverage, output):
    manifest = json.loads(coverage.read_bytes())
    if any(manifest[key] != digest(path) for key, path in (
        ("producer", Path(__file__)), ("reused", REUSED), ("archived", ARCHIVED), ("library", LIBRARY)
    )) or manifest["prior"] != [digest(path) for path in PRIOR]:
        raise ValueError("Experimental inputs differ from the freeze")
    initial = time.perf_counter()
    catalog, certificates = checked_catalog()
    catalog_seconds = time.perf_counter() - initial
    reused = json.loads(REUSED.read_bytes())
    panels = (("reused", reused["cases"]), ("conformance", manifest["cases"]))
    recorded = []
    for name, panel in panels:
        for index, case in enumerate(panel):
            graph = rooted_graph(case["family"], tuple(tuple(g) for g in case["generators"]))
            if graph_digest(graph) != case["graph_sha"]:
                raise ValueError("Case does not reconstruct to the frozen digest")
            baseline = arm(graph)
            isolated = arm(graph, catalog, certificates)
            scheduled = live_arm(graph, catalog, certificates)
            recorded.append(dict(
                panel=name, index=index, **case, baseline=baseline,
                isolated=isolated, live=scheduled,
            ))
    save(output, dict(
        coverage_sha256=digest(coverage), cases=recorded, catalog_seconds=catalog_seconds,
    ))


def peak(memory_task):
    tracemalloc.start()
    try:
        memory_task()
        return tracemalloc.get_traced_memory()[1]
    finally:
        tracemalloc.stop()


def memory(run_path, output):
    run_data = json.loads(run_path.read_bytes())
    catalog, certificates = checked_catalog()
    measurements = []
    chosen = set()
    for row in run_data["cases"]:
        stratum = row["panel"], row["family"]
        if stratum in chosen:
            continue
        chosen.add(stratum)
        graph = rooted_graph(row["family"], tuple(tuple(g) for g in row["generators"]))
        measurements.append(dict(
            panel=row["panel"], family=row["family"], index=row["index"],
            baseline_bytes=peak(lambda: arm(graph)),
            live_bytes=peak(lambda: live_arm(graph, catalog, certificates)),
        ))
    save(output, measurements)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("cover", "run", "memory"))
    parser.add_argument("--input", type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    if args.phase == "cover":
        cover(args.output)
    elif args.input is None:
        parser.error("run and memory require --input")
    elif args.phase == "run":
        run(args.input, args.output)
    else:
        memory(args.input, args.output)
