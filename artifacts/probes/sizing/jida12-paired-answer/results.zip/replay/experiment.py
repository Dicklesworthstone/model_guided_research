import dataclasses
import hashlib
import json
import math
import random
import sys
import time
from collections import Counter
from pathlib import Path

import pyarrow.parquet as pq
import torch
from torch.nn import functional as F

sys.path.insert(0, str(Path.cwd()))
from cli import _eval_split_examples, _load_eval_checkpoint
from nanochat.checkpoint_manager import save_checkpoint
from nanochat.diagnostics_data import TASKS
from nanochat.gpt import GPT, GPTConfig
from nanochat.report import build_provenance
from nanochat.tokenizer import HuggingFaceTokenizer, padded_vocab_size

TRAIN_SEED = 17
EVAL_SEEDS = (10, 11, 12)
STEPS = 2048
BATCH = 8
WIDTH = 128
CONTEXT = 320
COEFFICIENTS = {"answer-ce": 0.0, "answer-swap": 1.0}
SPEC = TASKS["hier_paired"]

def digest(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()

def write_json(path, contents):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as handle:
        handle.write(json.dumps(contents, indent=2) + "\n")

def tokenized_pair(tok, documents):
    examples = []
    for doc in documents:
        prompt, answer = SPEC.split_prompt(doc)
        prefix = tok.encode(prompt, prepend=tok.get_bos_token_id())
        tokens = tok.encode(doc, prepend=tok.get_bos_token_id())
        assert tokens[:len(prefix)] == prefix
        suffix = tokens[len(prefix):]
        assert suffix and answer
        examples.append((tokens, suffix))
    left, right = (suffix for _, suffix in examples)
    if left[:-1] != right[:-1] or left[-1] == right[-1]:
        return None
    return examples

def verify_pair(seen, rows):
    left, right = rows
    tree, _ = left.split(" PATH ", 1)
    assert right.split(" PATH ", 1)[0] == tree and tree not in seen
    seen.add(tree)
    answers = [SPEC.split_prompt(doc)[1] for doc in rows]
    assert answers[0] != answers[1] and all(SPEC.checker(doc) for doc in rows)
    return tree, answers

def contrast(logits, correct):
    competitor = correct.reshape(-1, 2).flip(1).flatten()
    return F.softplus(logits.gather(1, competitor[:, None]) - logits.gather(1, correct[:, None])).mean()

def preflight(root, reference):
    corpus = reference / "data" / "hier_paired"
    manifest = json.loads((corpus / "manifest.json").read_bytes())
    assert manifest["task"] == "hier_paired" and manifest["seed"] == 42 and manifest["size"] == 64000
    tok_path = reference / "runs" / "standard" / "b5-s0" / "checkpoints" / "tokenizer"
    tok = HuggingFaceTokenizer.from_directory(str(tok_path))
    seen = set()
    files = {}
    for name, sha in manifest["sha256"].items():
        path = corpus / name
        assert digest(path) == sha
        rows = pq.read_table(path, columns=["text"]).column("text").to_pylist()
        pairs = list(zip(rows[::2], rows[1::2], strict=True))
        for pair in pairs:
            verify_pair(seen, pair)
        files[name] = pairs
    assert len(seen) == 32000

    total = STEPS * BATCH
    inputs = torch.full((total, WIDTH), tok.get_bos_token_id(), dtype=torch.long)
    targets = torch.full_like(inputs, -1)
    lengths = torch.zeros(total, dtype=torch.long)
    train = files["train_000.parquet"]
    order = list(range(len(train)))
    random.Random(TRAIN_SEED).shuffle(order)
    selected = []
    for i in order:
        pair = tokenized_pair(tok, train[i])
        if pair is None or any(len(tokens) > WIDTH + 1 for tokens, _ in pair):
            continue
        offset = 2 * len(selected)
        for k, (tokens, suffix) in enumerate(pair, offset):
            end = len(tokens) - 1
            inputs[k, :end] = torch.tensor(tokens[:-1])
            targets[k, end - len(suffix):end] = torch.tensor(suffix)
            lengths[k] = end - 1
        selected.append(i)
        if len(selected) == total // 2:
            break
    assert len(selected) == len(set(selected)) == 8192
    prefix_controls = torch.tensor([[2.0, -2.0], [-2.0, 2.0]])
    labels = torch.tensor([0, 1])
    right = contrast(prefix_controls, labels)
    wrong = contrast(prefix_controls.flip(1), labels)
    blind = contrast(prefix_controls[0:1].expand_as(prefix_controls), labels)
    assert float(right) < float(blind) < float(wrong)
    assert torch.argmax(prefix_controls[0:1].expand_as(prefix_controls), dim=1).tolist() == [0, 0]
    panel = {region: [] for region in ("in_range", "held_out")}
    for seed in EVAL_SEEDS:
        in_range, held_out, _ = _eval_split_examples(SPEC, n=24, seed=seed)
        for region, docs in (("in_range", in_range), ("held_out", held_out)):
            for idx, rows in enumerate(zip(docs[::2], docs[1::2], strict=True)):
                _, answers = verify_pair(seen, rows)
                pairs = tokenized_pair(tok, rows)
                assert pairs is not None
                token_lengths = [len(tokens) for tokens, _ in pairs]
                assert max(token_lengths) <= CONTEXT + 1
                panel[region].append(dict(seed=seed, pair_index=idx, documents=rows, answers=answers,
                                          lengths=token_lengths, oracle_both=True, tree_only_both=False))
    assert len(seen) == 32072 and all(len(rows) == 36 for rows in panel.values())
    root.mkdir(parents=True, exist_ok=True)
    torch.save(dict(inputs=inputs, targets=targets, lengths=lengths), root / "schedule.pt")
    write_json(root / "manifest.json", manifest)
    write_json(root / "panel.json", panel)
    report = {
        "selected_pair_indices": selected, "schedule_sha256": digest(root / "schedule.pt"),
        "input_bytes_sha256": hashlib.sha256(inputs.numpy().tobytes()).hexdigest(),
        "answer_targets": int((targets >= 0).sum()),
        "tokenizer_sha256": digest(tok_path / "tokenizer.json"),
        "corpus_and_panel_unique_trees": len(seen),
        "max_eval_lengths": {region: max(max(row["lengths"]) for row in rows) for region, rows in panel.items()},
        "loss_controls": {"correct": float(right), "tree_only": float(blind), "swapped": float(wrong)},
        "oracle_both": {region: sum(row["oracle_both"] for row in rows) for region, rows in panel.items()},
        "tree_only_both": {region: sum(row["tree_only_both"] for row in rows) for region, rows in panel.items()},
    }
    write_json(root / "preflight.json", report)
    print(json.dumps({k: v for k, v in report.items() if k != "selected_pair_indices"}), flush=True)

def model_hash(model):
    hasher = hashlib.sha256()
    for param in model.parameters():
        hasher.update(param.detach().numpy().tobytes())
    return hasher.hexdigest()

def train(root, reference):
    preflight_report = json.loads((root / "preflight.json").read_bytes())
    assert digest(root / "schedule.pt") == preflight_report["schedule_sha256"]
    tok_path = reference / "runs" / "standard" / "b5-s0" / "checkpoints" / "tokenizer"
    assert digest(tok_path / "tokenizer.json") == preflight_report["tokenizer_sha256"]
    tok = HuggingFaceTokenizer.from_directory(str(tok_path))
    schedule = torch.load(root / "schedule.pt", weights_only=True)
    inputs, targets, lengths = (schedule[key] for key in ("inputs", "targets", "lengths"))
    config = GPTConfig(sequence_len=CONTEXT, vocab_size=padded_vocab_size(tok.get_vocab_size()),
                       n_layer=4, n_embd=128, n_head=8, n_kv_head=4, attention_type="standard")
    starting = None
    for name, coefficient in COEFFICIENTS.items():
        torch.manual_seed(TRAIN_SEED)
        model = GPT(config)
        model.init_weights()
        init = model_hash(model)
        if starting is None:
            starting = init
        assert starting == init
        optimizer = torch.optim.AdamW(model.parameters(), lr=0.0006)
        batch_rows = torch.arange(BATCH)
        start = time.perf_counter()
        for step in range(STEPS):
            selection = slice(step * BATCH, (step + 1) * BATCH)
            optimizer.zero_grad(set_to_none=True)
            logits = model(inputs[selection]).float()
            labels, terminal = targets[selection], lengths[selection]
            ce = F.cross_entropy(logits.flatten(0, 1), labels.flatten(), ignore_index=-1)
            aux = contrast(logits[batch_rows, terminal], labels[batch_rows, terminal])
            loss = ce + coefficient * aux
            if not math.isfinite(float(loss.detach())):
                raise ValueError(f"{name}: nonfinite training loss at {step}")
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            if step == 0 or (step + 1) % 256 == 0:
                print(f"{name} {step+1}/{STEPS} CE={float(ce.detach()):.6f} contrast={float(aux.detach()):.6f}", flush=True)
        elapsed = time.perf_counter() - start
        train_flops = float(model.estimate_flops() * (BATCH * WIDTH * STEPS))
        run = root / "runs" / name
        checkpoint = run / "checkpoints"
        checkpoint.mkdir(parents=True)
        tok.save(str(checkpoint / "tokenizer"))
        schedule_hash = preflight_report["schedule_sha256"]
        opts = dict(run_id=name, seed=TRAIN_SEED, steps=STEPS, train_width=WIDTH, batch=BATCH, learning_rate=0.0006,
                    gradient_clip=1.0, contrast_coefficient=coefficient, schedule_sha256=schedule_hash)
        save_checkpoint(
            str(checkpoint), STEPS - 1, model.state_dict(), None,
            dict(model_config=dataclasses.asdict(config), optimizer_type="adamw", scheduler_type="none",
                 seed=TRAIN_SEED, tokenizer={"kind": "task", "dir": "tokenizer"},
                 budget={"target_flops": train_flops, "max_steps": STEPS}, lineage={"run_id": name, "parent_run_ids": []}),
            rank=0,
        )
        summary = dict(provenance=build_provenance(opts), options=opts, initial_parameters_sha256=init,
                       final_parameters_sha256=model_hash(model), elapsed_seconds=elapsed, model_flops_est=train_flops,
                       final_answer_ce=float(ce.detach()), final_aux_loss=float(aux.detach()))
        write_json(run / "summary.json", summary)
        print(json.dumps(summary), flush=True)

@torch.inference_mode()
def evaluate_diagnostic(root, name):
    checkpoint = root / "runs" / name / "checkpoints"
    device = torch.device("cpu")
    model, metadata, step = _load_eval_checkpoint(checkpoint, None, device, fingerprint_weights=True)
    tok = HuggingFaceTokenizer.from_directory(str(checkpoint / "tokenizer"))
    panel = json.loads((root / "panel.json").read_bytes())
    output = root / "evals" / "tasks" / name
    summary = json.loads((output / "summary.json").read_bytes())
    assert summary["meta"]["sizing_input"] and summary["meta"]["seeds"] == list(EVAL_SEEDS)
    assert not summary["provenance"]["tainted"] and not summary["train_provenance"]["tainted"]
    assert summary["provenance"]["git_sha"] == summary["train_provenance"]["git_sha"]
    assert metadata["weights_sha256"] == summary["meta"]["checkpoint"]["weights_sha256"]
    assert step == STEPS - 1
    receipts = {}
    for line in (output / "generations.jsonl").read_text().splitlines():
        row = json.loads(line)
        key = row["region"], row["eval_seed"], row["doc_index"]
        assert key not in receipts and row["mode"] == "greedy"
        receipts[key] = row
    assert len(receipts) == 144
    regions = {}
    for region, pairs in panel.items():
        rows = []
        for pair in pairs:
            examples = tokenized_pair(tok, pair["documents"])
            assert examples is not None
            margins = []
            correct = []
            predictions = []
            for index, (tokens, suffix) in enumerate(examples):
                other_suffix = examples[1 - index][1]
                prediction = model(torch.tensor([tokens[:-1]]))[0, -1]
                margins.append(float(prediction[suffix[-1]] - prediction[other_suffix[-1]]))
                record = receipts[(region, pair["seed"], 2 * pair["pair_index"] + index)]
                expected, generated = record["expected"].split(), record["got"].split()
                assert record["expected"] == pair["answers"][index]
                exact = generated[:len(expected)] == expected
                assert exact == record["correct"]
                correct.append(exact)
                predictions.append(generated[0] if generated else None)
            rows.append(dict(seed=pair["seed"], index=pair["pair_index"], margins=margins,
                             answers=pair["answers"], correct=correct, first_tokens=predictions))
        greedy = sum(all(row["correct"]) for row in rows)
        choice = sum(all(margin > 0 for margin in row["margins"]) for row in rows)
        task = summary["tasks"]["hier_paired"]
        counts = task["paired_exact_match"]["counts"][region]
        assert sum(row["both_correct"] for row in counts) == greedy
        assert sum(row["incomplete"] for row in counts) == 0
        prior = sum(max(Counter(answer for row in rows if row["seed"] == seed for answer in row["answers"]).values())
                    for seed in EVAL_SEEDS)
        exact_single = sum(sum(row["correct"]) for row in rows)
        assert math.isclose(task["exact_match"]["greedy"][region]["mean"], exact_single / 72)
        assert math.isclose(task["answer_prior"][region]["mean"], prior / 72)
        regions[region] = dict(pairs=len(rows), both_greedy=greedy, both_forced=choice,
                               single_greedy=exact_single, single_prior=prior,
                               same_first_answer=sum(row["first_tokens"][0] is not None and
                                                     row["first_tokens"][0] == row["first_tokens"][1] for row in rows),
                               mean_margin_nats=sum(sum(row["margins"]) for row in rows) / 72, rows=rows)
    result = dict(run_id=name, checkpoint_sha256=metadata["weights_sha256"], regions=regions)
    write_json(output / "contrast-recount.json", result)
    print(json.dumps({region: {k: v for k, v in record.items() if k != "rows"}
                      for region, record in regions.items()}), flush=True)

if __name__ == "__main__":
    command, root, argument = sys.argv[1:]
    if command == "preflight":
        preflight(Path(root), Path(argument))
    elif command == "train":
        train(Path(root), Path(argument))
    elif command == "diagnostic":
        evaluate_diagnostic(Path(root), argument)
    else:
        raise ValueError(command)
