import json
import math
import random
import sys
from collections import Counter, defaultdict
from pathlib import Path

from address_fixtures import DIM, POOLS, SEEDS, encode, evaluation, make_pair, sha_json

DESIGNED = (0, 0b10101010, 0b11001100, 0b11110000)
PANEL_SEEDS = (11011, 11012, 11013)
CELLS = ((2, 24), (3, 24), (4, 24), (6, 12))
MODES = ("designed4", "designed3", "random4", "bank", "leaf", "leaf_bank")


def signature_masks(words):
    base = words[0]
    masks = defaultdict(int)
    for bit in range(DIM):
        signature = sum(((word ^ base) >> bit & 1) << i for i, word in enumerate(words[1:]))
        masks[signature] |= 1 << bit
    return dict(sorted(masks.items()))


def profiles(keys, pointers, anchors):
    if not anchors:
        return dict.fromkeys(keys, ()), dict.fromkeys(pointers, ()), math.factorial(DIM) * (1 << DIM)
    left, right = zip(*anchors, strict=True)
    known, encoded = map(signature_masks, (left, right))
    assert known.keys() == encoded.keys()
    known, encoded = tuple(known.values()), tuple(encoded.values())
    sizes = [mask.bit_count() for mask in known]
    assert sizes == [mask.bit_count() for mask in encoded]
    keep = {word: tuple(((word ^ left[0]) & mask).bit_count() for mask in known) for word in keys}
    seek = {word: tuple(((word ^ right[0]) & mask).bit_count() for mask in encoded) for word in pointers}
    return keep, seek, math.prod(math.factorial(size) for size in sizes)


def refine(left, right):
    # Each table assigns a color to one namespace. Use a shared palette.
    def relabel(x, y):
        palette = {key: i for i, key in enumerate(sorted(set(x.values()) | set(y.values())))}
        return {word: palette[value] for word, value in x.items()}, {word: palette[value] for word, value in y.items()}

    def neighborhood(colors):
        return {word: (color, tuple(sorted(Counter(((word ^ other).bit_count(), tag)
                                                for other, tag in colors.items()).items())))
                for word, color in colors.items()}

    left, right = relabel(left, right)
    rounds = 0
    while True:
        old = len(set(left.values()))
        left, right = relabel(neighborhood(left), neighborhood(right))
        assert Counter(left.values()) == Counter(right.values())
        rounds += 1
        if len(set(left.values())) == old:
            return left, right, rounds


def resolve(keys, pointers, anchors, use_bank):
    known, encoded, possibilities = profiles(keys, pointers, anchors)
    rounds, inferred = 0, []
    if use_bank:
        left_colors, right_colors, rounds = refine(known, encoded)
        buckets = defaultdict(list)
        for word, color in left_colors.items():
            buckets[color].append(word)
        inferred = [(buckets[color][0], q) for q, color in right_colors.items() if len(buckets[color]) == 1]
        combined = tuple(dict.fromkeys([*anchors, *inferred]))
        known, encoded, possibilities = profiles(keys, pointers, combined)
        known = {word: (value, left_colors[word]) for word, value in known.items()}
        encoded = {word: (value, right_colors[word]) for word, value in encoded.items()}
    buckets = defaultdict(list)
    for word, signature in known.items():
        buckets[signature].append(word)
    candidates = {q: tuple(buckets[signature]) for q, signature in encoded.items()}
    assert all(candidates.values())
    return candidates, possibilities, rounds, len(inferred)


def observe(doc):
    return dict(zip(doc["keys"], map(tuple, doc["link"]), strict=True))


def traverse(records, root, query, candidates):
    route = []
    q = root
    for hop in range(len(query) + 1):
        options = candidates[q]
        if len(options) != 1:
            break
        node = options[0]
        route.append(node)
        if hop < len(query):
            q = records[node][query[hop]]
    return route


def score(pair, namespace, external):
    left, right = pair
    records = observe(left)
    keys = sorted(records)
    pointers = sorted({left["root"], *(q for row in records.values() for q in row)})
    assert len(pointers) == len(keys)
    truth = {encode(key, *namespace): key for key in keys}
    assert set(pointers) == truth.keys()
    leaf = tuple((key, q) for key, (q, r) in records.items() if q == r)
    known = tuple((key, encode(key, *namespace)) for key in DESIGNED)
    random_anchors = tuple((key, encode(key, *namespace)) for key in external)
    methods = {
        "designed4": (known, False), "designed3": (known[:3], False),
        "random4": (random_anchors, False), "bank": ((), True),
        "leaf": (leaf, False), "leaf_bank": (leaf, True),
    }
    assert tuple(methods) == MODES
    result = {}
    for name, (anchors, use_bank) in methods.items():
        candidates, possibilities, rounds, inferred = resolve(keys, pointers, anchors, use_bank)
        assert all(truth[pointer] in options for pointer, options in candidates.items())
        routes = []
        for doc in (left, right):
            trace = traverse(observe(doc), doc["root"], doc["query"], candidates)
            want = [doc["keys"][index] for index in doc["chain"]]
            assert want[:len(trace)] == trace
            routes.append(len(trace) == len(want))
        result[name] = dict(complete=all(routes), docs=sum(routes),
                            unique=sum(len(options) == 1 for options in candidates.values()),
                            maps_from_matches=possibilities, refinement_rounds=rounds, inferred=inferred)
    return result


def fresh():
    seen = set()
    for seed in PANEL_SEEDS:
        for depth, total in CELLS:
            rng = random.Random(seed + 40031 + 200 * depth)
            for pair_id in range(total):
                while True:
                    code = tuple(rng.sample(range(DIM), DIM)), rng.randrange(1 << DIM)
                    if code not in seen:
                        seen.add(code)
                        break
                pair = make_pair(rng, depth, pair_id, POOLS[1], code)
                external = rng.sample(POOLS[0], 4)
                yield seed, depth, pair_id, pair, code, external


def witness():
    records = {4: (1, 2), 1: (8, 16), 2: (32, 64), **{x: (x, x) for x in (8, 16, 32, 64)}}
    keys = tuple(records)
    roots = (4, (0, 0))
    anchors = tuple((x, x) for x in (0, 12, 48))
    swaps = [(tuple(range(DIM)), 0), ((1, 0, 2, 3, 4, 5, 6, 7), 0)]
    leaves = []
    for perm in swaps:
        address = {encode(key, *perm): key for key in keys}
        trace = traverse(records, *roots, {q: (key,) for q, key in address.items()})
        leaves.append(trace[-1])
        assert all(address[q] == key for key, q in anchors if q in address)
        assert all(encode(key, *perm) == q for key, q in anchors)
        assert all(address[q] == key for key, (q, r) in records.items() if q == r)
    leaf_anchors = [(key, q) for key, (q, r) in records.items() if q == r]
    for use_bank in (False, True):
        candidates, possible, _, _ = resolve(keys, keys, (*anchors, *leaf_anchors), use_bank)
        assert possible >= 2 and traverse(records, *roots, candidates) == [4]
        assert {1, 2} <= set(candidates[1])
    assert leaves == [8, 32]
    return dict(root=4, query=roots[1], records=records, external_anchors=anchors, two_valid_targets=leaves)


def run(output):
    rows, old = [], []
    for seed, depth, pair_id, pair, code, external in fresh():
        rows.append(dict(seed=seed, depth=depth, pair_id=pair_id, namespace=code, fixture=sha_json(pair),
                         outcomes=score(pair, code, external)))
    for seed in SEEDS:
        # Repeat exactly the prior case identities and code from the published fixture generator.
        code_rng = random.Random(seed + 10080)
        code = code_rng.sample(range(DIM), DIM), code_rng.randrange(1 << DIM)
        for depth, docs in evaluation(seed).items():
            exact, slots = 0, 0
            for left, right in zip(docs[::2], docs[1::2], strict=True):
                records = observe(left)
                keys = sorted(records)
                anchors = tuple((key, q) for key, (q, r) in records.items() if q == r)
                pointers = sorted({left["root"], *(q for row in records.values() for q in row)})
                matches, _, _, _ = resolve(keys, pointers, anchors, False)
                solved = []
                for doc in (left, right):
                    trace = traverse(observe(doc), doc["root"], doc["query"], matches)
                    gold = [doc["keys"][index] for index in doc["chain"]]
                    assert gold[:len(trace)] == trace
                    solved.append(trace == gold)
                exact += all(solved)
                slots += 1
            old.append(dict(seed=seed, depth=int(depth), solved=exact, pairs=slots))
    assert len(rows) == 252 and sum(cell["pairs"] for cell in old) == 360
    with output.open("x", encoding="utf-8") as stream:
        json.dump(dict(rows=rows, prior_leaf_anchor=old, witness=witness()), stream)


if __name__ == "__main__":
    run(Path(sys.argv[1]))
