"""Check hidden-oracle isolation, relabeling, every table entry, and the registered finite contrast."""
import hashlib
import itertools
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

from scripts.group_rewrite_probe import teach_panel_case

panel = json.loads(Path(sys.argv[1]).read_bytes())
assert panel["seed"] == 2026112301 and len(panel["cases"]) == 20
totals = defaultdict(Counter)
ids = defaultdict(set)
for c in panel["cases"]:
    group, names = c["group"], c["names"]
    gen = c["generators"]
    def advance(p, a):
        if group == "z60":
            return ((p[0] + gen[a][0]) % 60,)
        return tuple(gen[a][x] for x in p)
    identity = (0,) if group == "z60" else tuple(range(len(gen[0])))
    ordered = [identity]
    for p in ordered:
        for a in (0,1):
            dst = advance(p, a)
            if dst not in ordered:
                ordered.append(dst)
    assert len(ordered) == len(set(names)) == len(names)
    graph = [[ordered.index(advance(p,a)) for a in (0,1)] for p in ordered]
    digest = hashlib.sha256(json.dumps(graph).encode()).hexdigest()
    assert digest == c["graph_digest"] and digest not in ids[group]
    ids[group].add(digest)
    def answer(word):
        p = identity
        for a in word:
            p = advance(p,int(a))
        return names[ordered.index(p)]
    training = {w:answer(w) for n in range(2,9) for letters in itertools.product("01",repeat=n) for w in ["".join(letters)]}
    assert len(training)==c["short_words"]==508
    unseen = len(names)-len(set(training.values()))
    assert unseen==c["unseen"] and max(0,unseen-1)==c["lower_bound"]
    totals[group]["lower_bound"] += c["lower_bound"]
    totals[group]["cases"] += 1
    for arm,record in c["arms"].items():
        pairs=record["queries"]
        assert len(set(w for w,_ in pairs))==len(pairs)
        assert all(w not in training and answer(w)==label for w,label in pairs)
        right=record["right"]
        for i,name in enumerate(names):
            for a in (0,1):
                assert right[str(a)][name]==names[graph[i][a]]
        assert record["verified_edges"]==2*len(names)
        totals[group][arm] += len(pairs)
        # The learner receives permuted opaque names, and only a fixed tape of
        # purchased answers. A divergent or extra oracle request fails here.
        rename={name:'anonymous-'+str(len(names)-i) for i,name in enumerate(names)}
        tape=iter(pairs)
        def taped(w):
            expected,label=next(tape)
            assert w==expected
            return rename[label]
        recovered,queries=teach_panel_case({w:rename[y] for w,y in training.items()},set(rename.values()),taped,squares=arm=="commuting")
        assert next(tape,None) is None and len(queries)==len(pairs)
        for a in "01":
            assert recovered.maps["R"+a]=={rename[k]:rename[v] for k,v in right[a].items()}
    if group in ("s5","a5","s3"):
        assert any(graph[graph[i][0]][1]!=graph[graph[i][1]][0] for i in range(len(names)))
    totals[group]["edges_per_arm"] += 2*len(names)
assert {g:t['cases'] for g,t in totals.items()}=={'s5':6,'a5':6,'s3':2,'z60':6}
primary=totals["s5"] + totals["a5"]
print(json.dumps(totals,sort_keys=True))
print('Primary:',dict(primary),'at_most_half:',2*primary["commuting"]<=primary["ablation"])
print('Checked every query, all rooted action tables and all forty relabeled tape-only acquisitions.')
