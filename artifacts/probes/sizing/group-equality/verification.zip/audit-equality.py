"""Rebuild the proof from exact Boolean answer tapes and pointwise permutations."""
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

panel_path = Path(sys.argv[1])
cohort = Path(sys.argv[2])
prior = json.loads(Path("artifacts/campaigns/group-student/student-score.json").read_text())
expected_arms = ("breadth_first", "symbol_counts", "one_view", "seven_views", "training_cache")
results = json.loads(panel_path.read_text())
totals = defaultdict(Counter)
breakdown = defaultdict(Counter)
prompt_count = 0
edge_count = 0
word_count = 0


def check_tape(arm, entry, case, action):
    advertised = case["label_count"]
    reps = [""]
    used = [set(), set()]
    rows = []
    counts = Counter()
    tape = iter(entry["trace"])
    short = dict(case["arms"]["short_only"]["rows"][:508])
    for word in reps:
        pair = []
        for column, symbol in enumerate("01"):
            event = next(tape)
            candidate = word + symbol
            assert event["word"] == candidate
            available = set(range(len(reps))) - used[column]
            tests = event["trials"]
            accepted = None
            for n, (choice, channel, answer) in enumerate(tests):
                assert choice in available and type(answer) is bool and channel in ("cache", "oracle")
                assert channel == "oracle" or arm == "training_cache"
                available.remove(choice)
                if channel == "cache":
                    prefix = "0" * max(0, 2 - min(len(candidate), len(reps[choice])))
                    assert (short[prefix + candidate] == short[prefix + reps[choice]]) is answer
                assert (action(candidate) == action(reps[choice])) is answer
                counts[f"{channel}_{'equal' if answer else 'different'}"] += 1
                if answer:
                    assert n == len(tests) - 1
                    accepted = choice
            if accepted is None:
                if len(reps) == advertised:
                    assert not tests and len(available) == 1
                    accepted = next(iter(available))
                    counts["forced"] += 1
                else:
                    assert not available and action(candidate) not in {action(ref) for ref in reps}
                    accepted = len(reps)
                    counts["new"] += 1
                    reps.append(candidate)
                    counts["oracle_new"] += sum(channel == "oracle" for _, channel, _ in tests)
            assert action(candidate) == action(reps[accepted])
            assert accepted == event["target"] and accepted not in used[column]
            pair.append(accepted)
            used[column].add(accepted)
        rows.append(pair)
    assert next(tape, None) is None and rows == entry["edges"] and reps == entry["representatives"]
    assert len(rows) == advertised and len({action(w) for w in reps}) == advertised
    assert dict((k, v) for k, v in counts.items() if k != "oracle_new" and v) == entry["counts"]
    indices = {action(w): i for i, w in enumerate(reps)}
    for word, expected, _ in case["primary"]:
        current = 0
        for g in word:
            current = rows[current][int(g)]
        assert current == indices[action(word)]
    return counts


assert len(results["results"]) == 24 and len(prior["results"]) == 24
for i, row in enumerate(results["results"]):
    case = json.loads((cohort / f"{i:02}.json").read_text())
    assert i == row["index"] == case["index"] and row["group"] == case["group"] == ("s5" if i < 12 else "a5")
    assert row["checkpoint"] == prior["results"][i]["arms"]["short_only"]["training"]["weights_sha"]
    assert row["graph_sha"] == case["graph_sha"]
    gens = case["generator_pair"]

    def action(word):
        result = list(range(5))
        for g in word:
            result = [gens[int(g)][s] for s in result]
        return tuple(result)

    assert set(row["strategies"]) == set(expected_arms)
    for arm in expected_arms:
        checked = check_tape(arm, row["strategies"][arm], case, action)
        paid = checked["oracle_equal"] + checked["oracle_different"]
        totals[row["group"]][arm] += paid
        breakdown[arm]["new"] += checked["oracle_new"]
        breakdown[arm]["revisit"] += paid - checked["oracle_new"]
        breakdown[arm]["cache"] += checked["cache_equal"] + checked["cache_different"]
        breakdown[arm]["forced"] += checked["forced"]
        edge_count += 2 * case["label_count"]
        word_count += len(case["primary"])
    if i == 0:
        entry = row["strategies"]["seven_views"]
        event = next(item for item in entry["trace"] if item["trials"])
        first, channel, answer = event["trials"][0]
        event["trials"][0] = (first, channel, not answer)
        try:
            check_tape("seven_views", entry, case, action)
        except AssertionError:
            pass
        else:
            raise AssertionError("Corrupt truth value was accepted")
        event["trials"][0] = (first, channel, answer)
    prompt_count += row["forward_prompts"]
    assert row["forward_seconds"] > 0
assert totals == results["totals"]
pooled = totals["s5"] + totals["a5"]
assert dict(pooled) == {name: n for name, n in results["pooled"].items() if n}
gate = all(10 * pooled["seven_views"] <= 9 * pooled[control] for control in expected_arms[:3])
gate &= all(row["seven_views"] <= row["one_view"] for row in totals.values())
assert gate == results["continuation_gate"]
print(json.dumps(dict(edges=edge_count, words=word_count, forward_prompts=prompt_count, totals=totals,
                      breakdown=breakdown, pooled=results["pooled"], continuation_gate=gate), sort_keys=True))
