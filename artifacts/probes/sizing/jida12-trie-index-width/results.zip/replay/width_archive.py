import hashlib
import json
import statistics
import sys
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


REGISTRATION = "bc80b418e0e6773017df9930cb66de2ca53fc644"
MANIFEST = "eee02e4131956e4ba7f799975530b9594c718bedfbd6cf4a8b9a2e7b8081067e"
SHIPPED = "d5679f9f7eae2b47d4c56231aee2cb72c90fc3ab4a4cd3e0602b7557c9c6819e"
GRID = {(radix, length) for radix in (2, 16) for length in (256, 1024, 4096)}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_result(read, names):
    manifest = read("replay/frozen.sha256")
    assert sha(manifest) == MANIFEST
    for line in manifest.decode().splitlines():
        expected, name = line.split()
        assert sha(read(name if name == "panel.json" else f"replay/{name}")) == expected
    data = json.loads(read("results.json"))
    assert data["shipped_sha256"] == sha(read("replay/shipped_trie.py")) == SHIPPED
    assert data["candidate_sha256"] == sha(read("replay/candidate_trie.py"))
    assert data["panel_sha256"] == sha(read("panel.json"))
    assert data["K"] == data["head_dim"] == 16 and data["heads"] == 4
    assert data["paired_samples"] == 17 and data["copies_per_sample"] == 64
    assert data["panel_correct"] == dict.fromkeys(("native", "reordered", "mixed2", "depth3", "reordered3"), 144)
    cases = {(row["radix"], row["length"]): row for row in data["workloads"]}
    assert len(data["workloads"]) == 6 and set(cases) == GRID
    for (p, _), row in cases.items():
        assert row["bitwise_queries"] == 64 and row["reset_checks"] == 4 and row["duplicate_keys"] == 2
        for samples, estimate in (("copy_ns", "copy_speedup"), ("query_ns", "query_speedup")):
            times = row[samples]
            assert len(times) == 17 and all(set(item["order"]) == {"shipped", "narrow"} for item in times)
            assert all(item["shipped"] > 0 and item["narrow"] > 0 for item in times)
            assert statistics.median(item["shipped"] / item["narrow"] for item in times) == row[estimate]
        caps = row["capacities"]
        occupied = row["occupied"]
        assert len(caps) == len(occupied) == 4
        assert all(1 <= size <= cap for cap, size in zip(caps, occupied, strict=True))
        dtypes = [(2, "torch.int16") if cap <= 32768 else (4, "torch.int32") for cap in caps]
        assert [name for _, name in dtypes] == row["narrower_child_dtypes"]
        expected = {}
        for field, rows in (("bytes_allocated", caps), ("live_copy_bytes", occupied)):
            expected[field] = {
                "shipped": sum(count * (4 * p + 68) for count in rows),
                "narrow": sum(count * (width * p + 68) for count, (width, _) in zip(rows, dtypes, strict=True)),
            }
            assert row[field] == expected[field]
        assert row["storage_fraction_saved"] == 1 - expected["bytes_allocated"]["narrow"] / expected["bytes_allocated"]["shipped"]
    primary, binary = (cases[key] for key in ((16, 1024), (2, 4096)))
    assert all(cap >= 65536 for cap in cases[(16, 4096)]["capacities"])
    criteria = dict(primary_bytes=primary["storage_fraction_saved"] >= .20,
                    primary_copy=primary["copy_speedup"] >= 1.10,
                    binary_bytes=binary["storage_fraction_saved"] >= .05,
                    binary_copy=binary["copy_speedup"] >= .95,
                    query_no_large_regression=all(row["query_speedup"] >= .90 for row in cases.values()))
    assert criteria == data["criteria"] and data["advance"] == all(criteria.values())
    paths = [name for name in names if name.endswith("/receipt.json")]
    assert len(paths) == 1 and "/hierarchy-trie-index-width/" in paths[0]
    receipt = json.loads(read(paths[0]))
    assert receipt["status"] == "passed" and len(receipt["checks"]) == 1
    check = receipt["checks"][0]
    assert sha(read(paths[0].removesuffix("receipt.json") + Path(check["log_path"]).name)) == check["log_sha256"]
    return dict(registration=REGISTRATION, receipt_id=paths[0].split("/")[-2], **data)


def bundle(root, out):
    manifest = root / "frozen.sha256"
    paths = {"replay/frozen.sha256": manifest, "replay/width_archive.py": root / "width_archive.py",
             "replay/shipped_trie.py": root / "source/nanochat/ultrametric_attention_torch.py",
             "results.json": root / "results.json"}
    for line in manifest.read_text().splitlines():
        _, name = line.split()
        paths[name if name == "panel.json" else f"replay/{name}"] = root / name
    for receipt in (root / "receipts").glob("*/*/receipt.json"):
        for filename in ("receipt.json", "check-1.log", "checks-config.yaml"):
            path = receipt.with_name(filename)
            paths[str(path.relative_to(root))] = path
    decision = read_result(lambda name: paths[name].read_bytes(), paths)
    with ZipFile(out, "x", compression=ZIP_DEFLATED) as archive:
        for name, path in paths.items():
            archive.write(path, name)
        archive.writestr("decision.json", json.dumps(decision, indent=2) + "\n")


def verify(out):
    with ZipFile(out) as archive:
        assert archive.testzip() is None
        names = archive.namelist()
        assert len(names) == len(set(names))
        assert not any(name.endswith((".pt", ".parquet", ".safetensors")) for name in names)
        result = read_result(archive.read, names)
        assert result == json.loads(archive.read("decision.json"))
    print(json.dumps(result))


if __name__ == "__main__":
    command, *paths = sys.argv[1:]
    {"bundle": bundle, "verify": verify}[command](*map(Path, paths))
