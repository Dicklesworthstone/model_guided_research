import argparse
import json
import math
from collections import Counter
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("path", type=Path)
args = parser.parse_args()
report = json.loads((args.path / "summary.json").read_bytes())
rows = [json.loads(line) for line in (args.path / "generations.jsonl").read_text().splitlines()]
task = report["tasks"]["hier"]
assert report["meta"]["sizing_input"] and report["meta"]["seeds"] == [0, 1, 2]
assert report["meta"]["examples_per_seed"] == 24
assert report["meta"]["checkpoint"]["lineage"]["run_id"] == args.path.name
assert report["meta"]["checkpoint"]["model_config"]["sequence_len"] == 320
assert report["provenance"]["git_sha"] == "1655ab3defe353c0b09da35cf5b53c0b5b057f83"
assert not report["provenance"]["tainted"]
assert not report["train_provenance"]["tainted"]
assert len({(row["region"], row["eval_seed"], row["doc_index"]) for row in rows}) == len(rows)
totals = {}
for region in ("in_range", "held_out"):
    parts = []
    for index, seed in enumerate((0, 1, 2)):
        chosen = [row for row in rows if row["region"] == region and row["eval_seed"] == seed and row["mode"] == "greedy"]
        answer_counts = Counter(row["expected"] for row in chosen)
        n = len(chosen)
        correct = sum(got["got"].split()[:len(got["expected"].split())] == got["expected"].split() for got in chosen)
        prior = max(answer_counts.values(), default=0)
        if n:
            assert math.isclose(correct/n, task["exact_match"]["greedy"][region]["per_seed"][index])
            assert math.isclose(prior/n, task["answer_prior"][region]["per_seed"][index])
        parts.append({"eval_seed": seed, "scored": n, "correct": correct, "constant_answer_correct": prior})
    totals[region] = {
        "count": sum(part["scored"] for part in parts), "correct": sum(part["correct"] for part in parts),
        "constant_answer_correct": sum(part["constant_answer_correct"] for part in parts),
        "perplexity": task["perplexity"][region], "eval_seeds": parts,
    }
in_range = totals["in_range"]
clears = in_range["count"] == 72 and in_range["correct"] > in_range["constant_answer_correct"]
print(json.dumps({
    "run_id": args.path.name, "weights_sha256": report["meta"]["checkpoint"]["weights_sha256"],
    "scored_input_sha256": task["perplexity_input_sha256"], "clears": clears, "regions": totals,
}, indent=2))
