# Optimal known-family equality baseline

The existing congruence command has a trusted-family S5 control. It
starts with all 57 possible rooted marked actions and pays for exact
equality of pairs of words. The earlier greedy policy sometimes used
nine calls. The experiment asks whether legal word comparisons realize
the information bound on this entire finite catalogue. Freeze the old
implementation at `c79c8d1`. Keep the default CLI and historical
evidence intact, and expose the compiled policy through
`congruence --known-family-policy optimal`.

One equality answer is binary, so 57 targets require a worst-case depth
of at least six. A minimum external path length binary tree has leaves
at two consecutive levels. For 57 targets the best distribution is seven
leaves at depth five and 50 at depth six, totaling 335 calls across the
catalogue. This counts each target once and uses a trusted family prior.
The same tree need not be optimal under a nonuniform prior or for
movement cost. [Minimum-redundancy binary trees](https://web.stanford.edu/class/ee398a/handouts/papers/Huffman%20-%20Min%20Redundancy%20Codes%20-%20IRE52.pdf)

Compile from the union of edge equations of the canonical actions.
Compute each legal question's exact truth mask across the catalogue.
Keep a shortest question among identical and complementary partitions.
Search the depth-capacity and minimum-total constraints recursively,
preferring balanced splits and using total word length and lexicographic
ties. If this pool cannot realize both bounds, try every pair among
the distinct endpoint vectors of the same words, represented by their
shortest words. Stop after those two pools. A compiler that cannot attain
the bounds must fail visibly instead of claiming success.

Use simultaneous conjugation by generators of S5 to enumerate one
ordered generating pair per reachable conjugacy class. A conjugation
fixes the identity and transports both marked maps, so discarding
its other orbit members preserves every canonical graph. Compare the
complete actively built catalogue against the previous all-pair loop,
including the deterministic identifier order.

The primary gate is all 57 correct known-family identifications,
maximum six calls, and exactly 335 total calls. Auditing each tape
re-evaluates every query against the true action and the surviving
graphs. Flip one recorded answer and require the auditor to reject it.
Record greedy calls, both arms' total word symbols, cold catalogue
construction, compiler CPU and total online CPU. The cost countermetric
is the sum of both queried word lengths on each paid comparison.
Repeat with a second Python hash seed and reverse the build and arm
order. Require exact agreement of every non-timing field.

Run the original and candidate default congruence CLI on the same
18 frozen presentations. Independently require all non-timing fields
to agree. Run the candidate with the compiled policy and require it
to select the independently audited leaf and tape on each of the six
S5 cases, with the other twelve rows and all other arms unchanged.
The new policy is a known-family control. Untrusted catalogue
proposals still require their own verification and fallback.

This finite retrospective comparison changes no registered hypothesis
or owner hold. Do not interpret it as a new external acquisition or
population study. It reuses the equality oracle on exact action tables.
