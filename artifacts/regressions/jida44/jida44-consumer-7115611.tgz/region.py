from common import *

inp=root/"inputs"
out=root/"runs/region"
out.mkdir(parents=True,exist_ok=True)
expected=load(inp/"regions-native/regions/summary.json")
cli(consumer,"routes","--checkpoint",inp/"training/baseline/nanochat/cpu-11/checkpoints",
    "--step",1,"--task","hier","--sample",4,"--seed",42,"--device","cpu","--region-count","--out",out/"native")
recomputed=load(out/"native/regions/summary.json")
assert recomputed["results"]==expected["results"]
for key in ("curve_weight_source","support_comparison_weight_source","seed","support_comparison_seed","checkpoint_step"):
    assert recomputed["meta"][key]==expected["meta"][key]
sys.path.insert(0,str(consumer))
import cli as api
summaries=[]
for i,seed in enumerate(seeds):
    old=load(inp/f"region-cohorts/generated/{i}/summary.json")
    new=api.run_tropical_region_count_protocol(seed=seed,n_samples=64,seq_lengths=(2,4,8,16,32))
    assert old["results"]==new["results"] and old["meta"]["seed"]==new["meta"]["seed"]
    res=new["results"]
    summaries.append(dict(seed=seed,all_oracles=res["all_bruteforce_verified"],
                     dense=res["dense_multi_head_regions"],structured=res["structured_multi_head_regions"],
                     support_violations=res["support_arm_bound_violations"]))
result=dict(native_curve_source=recomputed["meta"]["curve_weight_source"],
            native_support_source=recomputed["meta"]["support_comparison_weight_source"],
            native_context_lengths=sorted(map(int,recomputed["results"]["curve_by_T"])),generated=summaries)
save(out/"result.json",result)
print(json.dumps(result,sort_keys=True))
