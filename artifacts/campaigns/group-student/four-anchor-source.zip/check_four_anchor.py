"""Independently reconstruct the complete catalogue and audit every paid query."""

import hashlib
import json
import sys
from collections import Counter, deque
from itertools import product
from pathlib import Path

from check_replay import follow, group_is_valid, independently_named, load

ANCHORS = ("00", "01", "10", "11")
ARMS = ("square", "full", "short")


def rooted(table, a, b):
    states = [0]
    inverse = {0: 0}
    for source in states:
        for target in (table[source][a], table[source][b]):
            if target not in inverse:
                inverse[target] = len(states)
                states.append(target)
    if len(states) == len(table):
        return tuple((inverse[table[x][a]], inverse[table[x][b]]) for x in states)
    return None


def reconstruct(library):
    gap, package, tables = library
    sorted_ids = [(n, i) for n, count in ((60, 13), (120, 47)) for i in range(1, count + 1)]
    if (gap, package) != ("4.16.1", "1.7.0") or [tuple(t[:2]) for t in tables] != sorted_ids:
        raise ValueError("Incomplete catalogue inventory")
    by_order = {60: set(), 120: set()}
    for n, _, table in tables:
        if not group_is_valid(n, table):
            raise ValueError("An input table violated the group axioms")
        for a, b in product(range(n), repeat=2):
            shape = rooted(table, a, b)
            if shape is not None:
                by_order[n].add(shape)
    return {n: sorted(graphs) for n, graphs in by_order.items()}


def strip_timing(value):
    if isinstance(value, dict):
        return {k: strip_timing(v) for k, v in value.items() if not k.endswith("_ns")}
    if isinstance(value, list):
        return [strip_timing(v) for v in value]
    return value


def position(shape, word):
    state = 0
    for mark in word:
        state = shape[state][int(mark)]
    return state


def access(shape):
    # Independent multi-source search, seeded in shortlex order.
    queued = deque()
    seen = set()
    for word in ANCHORS:
        state = position(shape, word)
        if state not in seen:
            queued.append((state, word))
            seen.add(state)
    while queued:
        state, word = queued.popleft()
        yield state, word
        for mark, target in enumerate(shape[state]):
            if target not in seen:
                seen.add(target)
                queued.append((target, word + str(mark)))


def filter_shapes(fitting, word, answer):
    accepted = []
    for g, names, locations in fitting:
        state = position(g, word)
        if names.get(state, answer) == answer and locations.get(answer, state) == state:
            names[state] = answer
            locations[answer] = state
            accepted.append((g, names, locations))
    return accepted


def verify_trace(arm, graphs, initial, result, n, cap):
    tape = result["tape"]
    events = result["events"]
    if len(events) > len(tape) or [[e["word"], e["answer"]] for e in events] != tape[:len(events)]:
        raise ValueError("Trace and paid tape disagree")
    fitting = [(graph, {}, {}) for graph in graphs]
    named = set(initial.values())
    seen_words = set(initial)
    expected_tail = None
    for word, answer in initial.items():
        fitting = filter_shapes(fitting, word, answer)
    for event in events:
        word, answer = event["word"], event["answer"]
        before = len(fitting)
        if before == 0 or word in seen_words or event["before"] != before:
            raise ValueError("Invalid version-space state")
        if event["phase"] == "structure":
            if before <= 1 or len(seen_words) >= cap or expected_tail is not None:
                raise ValueError("Wrong structural probe")
            buckets = Counter(names.get(position(graph, word)) for graph, names, _ in fitting)
            fresh = buckets.pop(None, 0)
            free = max(1, n - len(named))
            worst = max(fresh, free * max(buckets.values(), default=0))
            if event["worst"] != worst or worst >= before * free:
                raise ValueError("Probe failed its version-space reduction")
        elif event["phase"] == "naming":
            if before != 1:
                raise ValueError("Named states before determining the structure")
            if expected_tail is None:
                graph, names, _ = fitting[0]
                expected_tail = deque([w for state, w in access(graph) if state not in names][:-1])
            if not expected_tail or expected_tail.popleft() != word or answer in named:
                raise ValueError("Naming did not use the minimal unread access words")
        else:
            raise ValueError(f"Unrecognized phase in {arm}")
        fitting = filter_shapes(fitting, word, answer)
        named.add(answer)
        seen_words.add(word)
        if event["after"] != len(fitting):
            raise ValueError("Incorrect feasible-action count after oracle reply")
    terminal = result["terminal"]
    if terminal == "unique":
        if len(fitting) != 1 or len(named) < n - 1 or expected_tail or len(tape) != len(events):
            raise ValueError("Premature uniqueness or unpaid coverage")
    elif terminal != "cap" or len(fitting) <= 1 or len(seen_words) != cap or expected_tail is not None:
        raise ValueError("Incorrect fallback transition")


def outside_action(table, marks):
    order = len(table)
    names = [str((17 * x + 5) % order) for x in range(order)]
    rows = {names[x]: [names[table[x][mark]] for mark in marks] for x in range(order)}
    return [names[0], [rows[str(i)] for i in range(order)]]


def audit(cohort, input_path, prior_path, old_cost, first_path, second_path):
    library, previous, before, first, second = map(load, (input_path, prior_path, old_cost, first_path, second_path))
    if strip_timing(first) != strip_timing(second):
        raise ValueError("Cross-seed replay changed a non-timing field")
    graphs = reconstruct(library)
    expected = hashlib.sha256(json.dumps(graphs, separators=(",", ":"), sort_keys=True).encode()).hexdigest()
    if first["shape_digest"] != expected or first["shape_counts"] != {str(n): len(v) for n, v in graphs.items()}:
        raise ValueError("A marked action was omitted or duplicated")
    tables = {(n, i): table for n, i, table in library[2]}
    counts = {panel: {arm: Counter() for arm in ARMS} for panel in ("historical", "outside")}
    maximum_excess = {arm: 0 for arm in ARMS}
    floor = Counter()
    transitions = predictions = 0
    if len(first["rows"]) != 30:
        raise ValueError("Wrong number of cases")
    for i, row in enumerate(first["rows"]):
        n = row["order"]
        if row["index"] != i:
            raise ValueError("Cases were reordered")
        initial = row["anchors"]
        if i < 24:
            panel = "historical"
            source = load(Path(cohort) / f"{i:02}.json")
            truth = list(independently_named(source))
            heldout = [entry[:2] for split in ("primary", "secondary") for entry in source[split]]
            if row["control"] is not None:
                raise ValueError("A historical case was replaced")
        else:
            panel = "outside"
            number, a, b = previous["control_pairs"][str(i - 24)]
            if (n, row["control"]) != (60 if i < 27 else 120, [number, a, b]):
                raise ValueError("An outside control was replaced")
            truth = outside_action(tables[n, number], (a, b))
            heldout = []
        if n != len(truth[1]) or initial != {word: follow(truth, word) for word in ANCHORS}:
            raise ValueError("Wrong public anchors or action size")
        floor_reads = len(ANCHORS) + n - 1 - len(set(initial.values()))
        floor[panel] += floor_reads
        for arm in ARMS:
            report = row["arms"][arm]
            paid = [*initial.items(), *report["tape"]]
            if len({word for word, _ in paid}) != len(paid) or len(paid) < floor_reads:
                raise ValueError("Duplicate payment or impossible naming cost")
            if report["action"] != truth or any(follow(truth, word) != label for word, label in paid):
                raise ValueError("Wrong exact result or recorded oracle reply")
            if any(follow(report["action"], word) != label for word, label in heldout):
                raise ValueError("Incorrect held-out observation")
            if arm != "square":
                verify_trace(arm, graphs[n], initial, report, n, n + 24)
            extra = len(paid) - floor_reads
            maximum_excess[arm] = max(maximum_excess[arm], extra)
            counts[panel][arm].update(reads=len(paid), symbols=sum(len(word) for word, _ in paid), excess=extra,
                                      fallback=int(report["terminal"] == "cap"))
            transitions += 2 * n
            predictions += len(heldout)

    control = first["rows"][0]
    forced = first["fallback"]
    if forced["action"] != control["arms"]["square"]["action"] or forced["tape"] != control["arms"]["square"]["tape"]:
        raise ValueError("Forced fallback changed the live square policy")
    verify_trace("forced", graphs[control["order"]], control["anchors"], forced, control["order"], 4)
    timings = []
    for sample in (first, second):
        timing = {metric: {arm: sum(row["arms"][arm][metric] for row in sample["rows"][:24]) for arm in ARMS}
                  for metric in ("cpu_ns", "wall_ns")}
        timings.append(dict(**timing, build=sample["build"]))
    previous_reads = 24 * 508 + before["totals"]["batch_tables"]["calls"]
    candidate = counts["historical"]["full"]
    square_counts = counts["historical"]["square"]
    gate = square_counts["excess"] > 0 and 5 * candidate["excess"] <= 4 * square_counts["excess"]
    print(json.dumps(dict(
        shapes=first["shape_counts"], indexed_words=first["word_counts"], old_archived_reads=previous_reads,
        counts=counts, floors=floor, max_excess=maximum_excess, timings=timings,
        excess_gate=gate, prior_reads_gate=10 * candidate["reads"] <= 3 * previous_reads,
        checked_transitions=transitions, heldout=predictions, forced_fallback=True,
    ), sort_keys=True))


if __name__ == "__main__":
    audit(*sys.argv[1:])
