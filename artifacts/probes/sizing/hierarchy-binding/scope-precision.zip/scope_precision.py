import itertools
import json
import math
import sys
from collections import Counter, defaultdict
from fractions import Fraction
from pathlib import Path
from zipfile import ZipFile

from recount import CELLS, parse, sha

ADDRESSED = "94a8d7a97010089a771b5d6d6554ab7e08e297fc8748b9a5fe8647b740ccc75a"
PANEL = "dc3e3e32584d1f71d437ec768005abcd2edfdf49d3ca79f64186f6c566ba9d43"
WIDTHS = (0, 1, 2, 3)


def residue(path, width):
    return sum(side << index for index, side in enumerate(path[:width]))


def compiled_bits(data):
    fit = data["outcomes"]["addressed"]["exhaustive"]
    table = {}
    for i, (a, swap) in enumerate(itertools.product((0, 1), repeat=2)):
        result = tuple(int(row[1] > row[0]) for row in fit[i])
        assert result == (swap, 1 ^ swap)
        table[a, a ^ swap] = result[0]
    return table


def estimate(bucket_size):
    expected = Fraction(1, 2) + Fraction(math.comb(bucket_size - 1, (bucket_size - 1) // 2), 2**bucket_size)
    numerator = sum(max(word.bit_count(), bucket_size - word.bit_count()) for word in range(2**bucket_size))
    enumerated = Fraction(numerator, bucket_size * 2**bucket_size)
    assert expected == enumerated
    return dict(exact=str(expected), accuracy=float(expected), allocations=2**bucket_size)


def score(doc, operator, width, index, witnesses):
    query, gold, rows, _ = parse(doc)
    bits = {path: operator[row[0], row[1]] for path, row in rows.items()}
    groups = defaultdict(list)
    for path, swap in bits.items():
        groups[(len(path), residue(path, width))].append((path, swap))
    readout = {}
    local = defaultdict(lambda: {"correct": 0, "total": 0, "conflicting_groups": 0})
    for (depth, address), options in groups.items():
        counts = Counter(swap for _, swap in options)
        selected = int(counts[1] > counts[0])
        readout[depth, address] = selected
        correct = sum(swap == selected for _, swap in options)
        assert correct == max(counts.values())
        local[depth]["correct"] += correct
        local[depth]["total"] += len(options)
        if len(counts) == 2:
            local[depth]["conflicting_groups"] += 1
            if depth not in witnesses:
                a, _ = next((path, b) for path, b in options if b == 0)
                b, _ = next((path, c) for path, c in options if c == 1)
                assert a != b and residue(a, width) == residue(b, width)
                # One query alias, same observed address and fixed table, distinct targets.
                witnesses[depth] = dict(doc_index=index, retained_bits=width, depth=depth,
                                        residue=address, alias=0, parents=[list(a), list(b)], expected_children=[0, 1])
    path = ()
    for alias in query:
        swap = readout[len(path), residue(path, width)]
        path = path + (alias ^ swap,)
    return path == gold, dict(local)


def recount(archive):
    assert sha(archive.read_bytes()) == ADDRESSED
    with ZipFile(archive) as source:
        assert sha(source.read("panel.json")) == PANEL
        assert json.loads(source.read("decision.json"))["fixed_gate"]
        panel = json.loads(source.read("panel.json"))
        operators = [compiled_bits(json.loads(source.read(f"fit-{seed}.json"))) for seed in (8831, 8832, 8833)]
    assert operators[0] == operators[1] == operators[2]
    operator = operators[0]
    theory = {m: estimate(m) for m in (1, 2, 4, 8, 16)}
    results = {}
    for cell in CELLS:
        docs = [doc for seed in sorted(panel) for doc in panel[seed][cell]]
        depth = int(cell[-1])
        assert len(docs) == 72
        widths = {}
        per_doc = [None for _ in docs]
        for width in WIDTHS:
            witnesses, flags = {}, []
            totals = {i: Counter() for i in range(depth)}
            perfect_local = 0
            for index, doc in enumerate(docs):
                ok, local = score(doc, operator, width, index, witnesses)
                flags.append(ok)
                for h, row in local.items():
                    totals[h].update(row)
                if all(row["correct"] == row["total"] for row in local.values()):
                    perfect_local += 1
                    if per_doc[index] is None:
                        per_doc[index] = width
            for hop, row in totals.items():
                assert row["total"] == len(docs) * (2**hop)
                if width >= hop:
                    assert row["correct"] == row["total"] and row["conflicting_groups"] == 0
                else:
                    assert row["correct"] < row["total"] and hop in witnesses
            widths[width] = dict(individual_correct=sum(flags), pairs_both=sum(
                a and b for a, b in zip(flags[::2], flags[1::2], strict=True)
            ), perfect_local_documents=perfect_local, per_parent_depth=totals, witnesses=witnesses)
        assert widths[depth-1]["individual_correct"] == 72 and widths[depth-1]["pairs_both"] == 36
        assert None not in per_doc
        results[cell] = dict(widths=widths, minimum_lossless_widths=Counter(per_doc))
    return dict(panel_sha256=PANEL, source_archive_sha256=ADDRESSED, theory=theory,
                documents_per_cell=72, pairs_per_cell=36, results=results)


if __name__ == "__main__":
    source, destination = map(Path, sys.argv[1:])
    result = recount(source)
    with destination.open("x", encoding="utf-8") as output:
        json.dump(result, output, indent=2, sort_keys=True)
        output.write("\n")
    print(json.dumps({
        cell: {width: (row["pairs_both"], row["perfect_local_documents"]) for width, row in info["widths"].items()}
        for cell, info in result["results"].items()
    }))
