import json
import math
import random
import statistics
import sys
from pathlib import Path

import evidence
import posterior as post
from address_fixtures import DIM, POOLS, encode, sha_json

SEEDS = (21111, 21112, 21113)
REGIMES = (("catalan_heavy", (11, 6, 3)), ("yule_heavy", (3, 6, 11)))
PHASES = ("train", "test")
COMPONENTS = tuple(evidence.TRUTHS)
UNIT = 20
BATCH = 20
ARMS = ("uniform", "single", "static", "stale", "adaptive", "oracle")


def fresh():
    for seed in SEEDS:
        for regime_num, (regime, proportions) in enumerate(REGIMES):
            for phase_num, phase in enumerate(PHASES):
                rng = random.Random(seed + 88143 + 3198 * regime_num + 7987 * phase_num)
                for index in range(BATCH):
                    draw = rng.randrange(UNIT)
                    component = 0 if draw < proportions[0] else int(draw >= sum(proportions[:2])) + 1
                    family, _ = COMPONENTS[component]
                    leaves = evidence.half_leaves(rng) if family == "half" else post.generate_leaves(rng, family)
                    nodes = sorted({path[:i] for path in leaves for i in range(len(path) + 1)})
                    assert len(leaves) == 64 and len(nodes) == 127
                    namespace = tuple(rng.sample(range(DIM), DIM)), rng.randrange(1 << DIM)
                    keys = dict(zip(nodes, rng.sample(POOLS[1], len(nodes)), strict=True))
                    pointers = {path: encode(key, *namespace) for path, key in keys.items()}
                    rows = {keys[path]: () if path in leaves else (pointers[path + (0,)], pointers[path + (1,)])
                            for path in rng.sample(nodes, len(nodes))}
                    query = rng.choice(sorted(leaves))
                    yield seed, regime, phase, index, rows, pointers[()], query, keys[query], component, namespace


def simplex():
    for a in range(1, UNIT - 1):
        for b in range(1, UNIT - a):
            yield a, b, UNIT - a - b


def likelihood(versions):
    logs = [evidence.relative_log_likelihood(versions, beta) for _, beta in COMPONENTS]
    maximum = max(logs)
    return tuple(math.exp(value - maximum) for value in logs)


def fit(masses):
    # masses are normalized evidence vectors, with no endpoint or source label.
    grid = []
    for weights in simplex():
        value = statistics.mean(math.log(math.fsum(w * x / UNIT for w, x in zip(weights, row, strict=True)))
                                for row in masses)
        grid.append([weights, value])
    selected, best = max(grid, key=lambda row: (row[1], tuple(-w for w in row[0])))
    return dict(weights=selected, best=best, grid=grid)


def predict(versions, masses, weights, condition=True):
    t = tuple(w * m for w, m in zip(weights, masses, strict=True)) if condition else weights
    denominator = math.fsum(t)
    component = tuple(value / denominator for value in t)
    answer = [post.probabilities(versions, beta) for _, beta in COMPONENTS]
    support = answer[0].keys()
    assert all(p.keys() == support for p in answer)
    posterior = {key: math.fsum(weight * p[key] for weight, p in zip(component, answer, strict=True))
                 for key in support}
    return posterior, component


def verdicts(train_fit, old_fit, proportions, row):
    masses = likelihood(row["versions"])
    uniform = post.probabilities(row["versions"], 0)
    single = post.probabilities(row["versions"], train_fit["single_beta"])
    preds = {"uniform": (uniform, None), "single": (single, None)}
    for arm, weights, cond in (
        ("static", train_fit["weights"], False),
        ("stale", old_fit["weights"], True),
        ("adaptive", train_fit["weights"], True),
        ("oracle", proportions, True),
    ):
        preds[arm] = predict(row["versions"], masses, weights, cond)
    assert tuple(preds) == ARMS
    return preds


def compare(rows):
    estimates = {}
    for seed in SEEDS:
        estimates[seed] = {}
        for regime, _truth in REGIMES:
            train = [row for row in rows if (row["seed"], row["regime"], row["phase"]) == (seed, regime, "train")]
            assert len(train) == BATCH
            catalogs = [row["versions"] for row in train]
            estimate = fit([likelihood(catalog) for catalog in catalogs])
            estimate["single_beta"], _ = evidence.estimate_evidence(catalogs)
            estimates[seed][regime] = estimate
    result = {}
    for seed in SEEDS:
        result[seed] = {}
        for regime_index, (regime, truth) in enumerate(REGIMES):
            test = [row for row in rows if (row["seed"], row["regime"], row["phase"]) == (seed, regime, "test")]
            assert len(test) == BATCH
            metrics = {arm: [] for arm in ARMS}
            current = estimates[seed][regime]
            stale = estimates[seed][REGIMES[1 - regime_index][0]]
            for row in test:
                for arm, (answer, component) in verdicts(current, stale, truth, row).items():
                    key = row["target"]
                    score = dict(nll=-math.log(answer[key]),
                                 brier=math.fsum((prob - (label == key)) ** 2 for label, prob in answer.items()),
                                 correct=int(min(answer, key=lambda label: (-answer[label], label)) == key))
                    if component is not None:
                        source = row["component"]
                        score.update(origin_nll=-math.log(component[source]),
                                     origin_correct=int(max(range(len(component)), key=lambda i: component[i]) == source))
                    metrics[arm].append(score)
            result[seed][regime] = dict(fit=current, test={arm: {
                key: sum(row[key] for row in measures) if key.endswith("correct")
                else statistics.mean(row[key] for row in measures)
                for key in measures[0]} for arm, measures in metrics.items()})
    return result


def run(path):
    raw = []
    for seed, regime, phase, index, records, root, query, target, component, _namespace in fresh():
        census = post.catalog(records, root, query)
        assert target in {key for key, _, _ in census["versions"]}
        raw.append(dict(seed=seed, regime=regime, phase=phase, index=index, target=target, component=component,
                        fixture=sha_json([records, root, query]), **census))
        if index == BATCH - 1:
            print(seed, regime, phase, BATCH, flush=True)
    assert len(raw) == 240
    with path.open("x", encoding="utf-8") as file:
        json.dump(dict(rows=raw, fits=compare(raw)), file, allow_nan=False, separators=(",", ":"))


if __name__ == "__main__":
    run(Path(sys.argv[1]))
