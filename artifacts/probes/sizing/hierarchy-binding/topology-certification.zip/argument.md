# When internal links identify a route

The records identify the key of each row and the two coded pointers at an internal row. Leaf records are empty. The root pointer plus the interior pointers contain each code once. The underlying tree has a specified full binary shape.

A candidate signed permutation must preserve Hamming distances. Fix one pointer and enumerate all keys with the same multiset of distances to the bank. Once this pair is fixed, XOR with each landmark determines the sign mask for a proposed coordinate permutation. Unary counts of ones and pairwise counts of joint ones in the normalized banks are further necessary conditions. The enumerator checks all permutations satisfying them and retains exactly those mapping the pointer set onto the key set.

At depth six the key and pointer banks each contain a parity class minus one word. The omitted words are necessarily paired. Normalizing them both to zero gives the same set of nonzero even-parity words. Every coordinate permutation preserves that set, so exactly 8 factorial bank-compatible mappings remain. This symmetry is a property of the sets. Their ordered links supply additional constraints.

A topology-compatible mapping must send the root pointer to a row from which all rows occur at the required levels. Every internal row contributes exactly two ordered links, every leaf appears at the final depth, and the traversal visits every row once. The solver follows the query separately under each valid mapping. Agreement of all routes gives an exact certificate, including in cases where the mapping itself is ambiguous. The two planted examples show both outcomes. In one, two valid encodings lead to different leaves. In the other, the ambiguity changes an unqueried branch and both encodings give the same queried path.

This is finite inference with a given record schema, ordered links, eight-bit signed permutations, and specified tree shape. General graph isomorphism uses related invariant and search ideas, for example [McKay and Piperno](https://arxiv.org/abs/1301.1493).
