"""Independent verifier for the online congruence acquisition and known-family control."""
import hashlib
import itertools
import json
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path
from zipfile import ZipFile

coverage, experiment = (Path(value) for value in sys.argv[1:3])
manifest = json.loads(coverage.read_bytes())
results = json.loads(experiment.read_bytes())
assert hashlib.sha256(coverage.read_bytes()).hexdigest() == results["coverage_sha256"]
assert manifest["seed"] == 2026112311
cohort = Path(sys.argv[3])
seen = {json.loads(path.read_bytes())["graph_sha"] for path in cohort.glob("*.json")}
seen.update(
    case["graph_digest"]
    for case in json.loads(Path("artifacts/probes/sizing/group-query-completion/panel.json").read_bytes())["cases"]
)
archive_path = Path("artifacts/probes/sizing/group-equality/verification.zip")
assert hashlib.sha256(archive_path.read_bytes()).hexdigest() == manifest["archive_sha256"]
with ZipFile(archive_path) as archive:
    prior = json.loads(archive.read("relators.json"))
seen.update(prior["excluded_incomplete_s5"])
seen.update(row["graph_sha"] for row in prior["results"])
assert not seen.difference(manifest["spent"])
seen = set(manifest["spent"])


def pointwise(group, gens):
    identity = (0,) if group == "z60" else tuple(range(len(gens[0])))

    def advance(state, letter):
        if group == "z60":
            return ((state[0] + gens[letter][0]) % 60,)
        return tuple(gens[letter][i] for i in state)

    def evaluate(word):
        state = identity
        for letter in word:
            state = advance(state, int(letter))
        return state

    states = [identity]
    ids = {identity: 0}
    names = [""]
    edges = []
    for index, state in enumerate(states):
        row = []
        for ch in (0, 1):
            dst = advance(state, ch)
            if dst not in ids:
                ids[dst] = len(states)
                states.append(dst)
                names.append(names[index] + str(ch))
            row.append(ids[dst])
        edges.append(row)
    return edges, names, evaluate, ids


def digest(graph):
    return hashlib.sha256(json.dumps(graph).encode()).hexdigest()


def cancelled(left, right):
    left_start = 0
    for a, b in zip(left, right):
        if a != b:
            break
        left_start += 1
    left, right = left[left_start:], right[left_start:]
    right_start = 0
    for a, b in zip(reversed(left), reversed(right)):
        if a != b:
            break
        right_start += 1
    if right_start:
        left, right = left[:-right_start], right[:-right_start]
    return min((left, right), (right, left))


def replay(arm, table, graph, reps, action):
    known = 1
    used = [set(), set()]
    memo = {("", ""): True}
    count = Counter()
    rules = {}
    matcher = None
    normalized = {}

    def reduce_word(word):
        if word in normalized:
            return normalized[word]
        original = word
        steps = []
        if matcher is not None:
            while match := matcher.search(word):
                lhs = match[0]
                rhs = rules[lhs]
                steps.append([match.start(), lhs, rhs])
                newer = word[:match.start()] + rhs + word[match.end():]
                assert (len(newer), newer) < (len(word), word)
                word = newer
        assert action(word) == action(original)
        normalized[original] = (word, steps)
        return normalized[original]

    def key(a, b):
        pair = cancelled(a,b)
        if arm == "cancelled":
            return pair
        while True:
            a, b = (reduce_word(word)[0] for word in pair)
            nxt = cancelled(a,b)
            if nxt == pair:
                return pair
            pair = nxt

    input_tape = iter(table["trace"])
    for source, row in enumerate(graph):
        for digit, destination in enumerate(row):
            event = next(input_tape)
            word = reps[source] + str(digit)
            assert event["word"] == word and event["target"] == destination
            choices = set(range(known)) - used[digit]
            refs = {text: i for i, text in enumerate(reps[:known])}
            normal, proof = reduce_word(word) if arm == "congruence" else (word, [])
            trials = event["trials"]
            paid = 0
            if arm == "congruence" and normal in refs:
                assert event["normal_form"] == normal and event["substitutions"] == proof
                assert destination == refs[normal] and destination in choices and not trials
                count["rewritten"] += 1
                count["rewrite_steps"] += len(proof)
            elif known == len(graph) and len(choices) == 1:
                assert not trials and destination == next(iter(choices)) and "normal_form" not in event
                count["forced"] += 1
            else:
                assert "normal_form" not in event
                def priority(i):
                    a, b = (abs(word.count(c) - reps[i].count(c)) for c in "01")
                    return (144 * ((a % 2) + (b % 2)) + a + b, i)
                ordered = sorted(choices, key=priority)
                accept = False
                for index, (target, source_kind, answer) in enumerate(trials):
                    assert target == ordered[index] and type(answer) is bool
                    ref = reps[target]
                    pair = key(word, ref)
                    cached = memo.get(pair)
                    if arm == "congruence":
                        a,b = pair
                        if a == b:
                            cached = True
                        elif a in refs and b in refs:
                            cached = False
                    assert source_kind == ("cache" if cached is not None else "oracle")
                    assert answer is (action(word) == action(ref))
                    if cached is not None:
                        assert answer is cached
                    else:
                        memo[pair] = answer
                        paid += 1
                    count[f"{source_kind}_{'equal' if answer else 'different'}"] += 1
                    if answer:
                        assert index == len(trials)-1 and target == destination
                        accept = True
                if not accept:
                    assert len(trials) == len(ordered) and destination == known and reps[known] == word
                    known += 1
                    count["new"] += 1
                    count["paid_new"] += paid
            assert destination not in used[digit] and action(word) == action(reps[destination])
            used[digit].add(destination)
            if arm == "congruence" and word != reps[destination]:
                target = reps[destination]
                assert (len(word),word) > (len(target), target)
                rules[word] = target
                matcher = re.compile("|".join(sorted(rules, key=lambda w: (-len(w),w))))
                normalized.clear()
    assert next(input_tape, None) is None and known == len(graph)
    assert table["edges"] == graph and table["representatives"] == reps
    derived = {"paid_new", "rewrite_steps"}
    assert {k:v for k,v in count.items() if k not in derived and v} == table["counts"]
    assert table["memo_entries"] == len(memo)
    assert table["memo_symbols"] == sum(len(a)+len(b) for a,b in memo)
    if arm == "congruence":
        assert table["rule_count"] == len(rules)
        assert table["rule_symbols"] == sum(len(a)+len(b) for a,b in rules.items())
    assert 0 <= table["oracle_seconds"] <= table["seconds"]
    count["paid"] = count["oracle_equal"] + count["oracle_different"]
    return count


def build_catalog():
    perms = list(itertools.permutations(range(5)))
    graphs = {}
    for pair in itertools.product(perms, repeat=2):
        graph, reps, _, _ = pointwise("s5", pair)
        if len(graph) != 120:
            continue
        equations = sorted({
            tuple(sorted((reps[i]+str(g),reps[d])))
            for i,row in enumerate(graph) for g,d in enumerate(row) if reps[i]+str(g) != reps[d]
        })
        graphs[digest(graph)] = (graph, equations)
    return dict(sorted(graphs.items()))


def replay_family(family, catalog, action, target):
    remaining = list(catalog)

    def eval_graph(graph, word):
        i = 0
        for c in word:
            i = graph[i][int(c)]
        return i

    for question in family["queries"]:
        balances = []
        count = len(remaining)
        for a,b in catalog[remaining[0]][1]:
            pos = {
                h for h in remaining
                if eval_graph(catalog[h][0], a) == eval_graph(catalog[h][0], b)
            }
            if 0 < len(pos) < count:
                balances.append((abs(2 * len(pos)-count), (a,b), pos))
        _, best, yes = min(balances, key=lambda row: row[:2])
        assert best == tuple(question["pair"]) and len(yes) == question["predicted_yes"]
        assert question["candidates"] == count
        a,b = best
        answer = action(a) == action(b)
        assert question["answer"] is answer
        remaining = [h for h in remaining if (h in yes) is answer]
    assert remaining == [target] == [family["marked_class"]]
    assert 0 <= family["oracle_seconds"] <= family["seconds"]


catalog = build_catalog()
assert results["catalog_size"] == len(catalog)
totals = defaultdict(lambda: defaultdict(Counter))
counts_by_case = []
catalog_counts = []
checked_edges = checked_words = 0
tamper_trials = tamper_rewrite = False
assert len(manifest["presentations"]) == len(results["results"]) == 18
for index, (presentation, case) in enumerate(zip(manifest["presentations"], results["results"], strict=True)):
    group = presentation["group"]
    assert group == case["group"] == (["s5"]*6+["a6"]*6+["z60"]*6)[index]
    graph, reps, action, ids = pointwise(group,presentation["generators"])
    target = digest(graph)
    assert target not in seen
    seen.add(target)
    assert target == presentation["graph_sha"] == case["graph_sha"] and index == case["index"]
    assert len(graph) == presentation["size"] == {"s5":120,"a6":360,"z60":60}[group]
    if group == "s5":
        replay_family(case["family"], catalog, action, target)
        catalog_counts.append(len(case["family"]["queries"]))
    else:
        assert case["family"] is None
    assert Counter(len(word) for word,_ in case["samples"]) == {16:48,32:48,64:48,128:48}
    assert len({word for word,_ in case["samples"]}) == 192
    assert all(ids[action(word)] == answer for word,answer in case["samples"])
    counts = {}
    for arm in ("cancelled","congruence"):
        table = case["arms"][arm]
        counted = replay(arm, table, graph, reps, action)
        totals[group][arm].update(counted)
        counts[arm] = dict(counted)
        checked_edges += 2*len(graph)
        checked_words += 192
    counts_by_case.append(dict(index=index, group=group, counts=counts))
    treatment = case["arms"]["congruence"]
    for event in treatment["trace"]:
        if not tamper_trials and event["trials"]:
            target_i, mode, bit = event["trials"][0]
            event["trials"][0] = [target_i,mode,not bit]
            try:
                replay("congruence",treatment,graph,reps,action)
            except AssertionError:
                tamper_trials = True
            event["trials"][0] = [target_i,mode,bit]
        if not tamper_rewrite and event.get("substitutions"):
            step = event["substitutions"].pop()
            try:
                replay("congruence",treatment,graph,reps,action)
            except AssertionError:
                tamper_rewrite = True
            event["substitutions"].append(step)
        if tamper_trials and tamper_rewrite:
            break
assert tamper_trials and tamper_rewrite
primary = {arm: totals["s5"][arm]+totals["a6"][arm] for arm in ("cancelled","congruence")}
b,t = primary["cancelled"],primary["congruence"]
decision = 100*t["paid"] <= 85*b["paid"] and 100*t["paid_new"] <= 90*b["paid_new"]
print(json.dumps(dict(totals=totals,primary=primary,decision=decision,catalog_size=len(catalog),
                      family_queries=catalog_counts,checked_edges=checked_edges,checked_words=checked_words,
                      per_case=counts_by_case,tamper_trials=tamper_trials,tamper_rewrite=tamper_rewrite),sort_keys=True))
