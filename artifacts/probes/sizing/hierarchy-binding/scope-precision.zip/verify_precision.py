import hashlib
import json
import sys
from pathlib import Path
from zipfile import ZipFile

result_path, prior_path, receipts_path = (Path(item) for item in sys.argv[1:])
result = json.loads(result_path.read_bytes())
assert hashlib.sha256(prior_path.read_bytes()).hexdigest() == result["source_archive_sha256"]
with ZipFile(prior_path) as prior:
    assert hashlib.sha256(prior.read("panel.json")).hexdigest() == result["panel_sha256"]
    original = json.loads(prior.read("panel.json"))
witnesses = 0
for cell, measurements in result["results"].items():
    documents = [doc for eval_seed in sorted(original) for doc in original[eval_seed][cell]]
    for width, row in measurements["widths"].items():
        for depth, witness in row["witnesses"].items():
            doc = documents[witness["doc_index"]]
            table = doc.split(" BIND ")[1].split(" PATH ")[0]
            sources = {words[0]: dict(zip(words[1::2], words[2::2], strict=True))
                       for words in (record.split() for record in table.split(" ; "))}
            assert witness["retained_bits"] == int(width) and witness["depth"] == int(depth)
            for path, child in zip(witness["parents"], witness["expected_children"], strict=True):
                digits = "".join(map(str, path))
                assert len(digits) == int(depth)
                residue = int(digits[::-1], 2) % (2**int(width))
                assert residue == witness["residue"]
                assert sources[f"r{digits}"][f"a{witness['alias']}"] == f"k{child}"
            assert set(witness["expected_children"]) == {0,1}
            witnesses += 1
assert witnesses == 10
receipt_path, = receipts_path.glob("*/*/receipt.json")
receipt = json.loads(receipt_path.read_bytes())
assert receipt["status"] == "passed" and len(receipt["checks"]) == 1
check, = receipt["checks"]
assert hashlib.sha256(receipt_path.with_name(Path(check["log_path"]).name).read_bytes()).hexdigest() == check["log_sha256"]
print(f"Checked {witnesses} recorded collisions against original text and verified the terminal DSR log.")
