#!/bin/bash
set -euo pipefail
export PATH="/home/ubuntu/.local/bin:$PATH"
export MGR_ORBIT=/data/ssd/tmp/mgr-sibling-orbit.PlnAYAg1
export MGR_ORBIT_PRIOR=/data/ssd/tmp/mgr-sibling-order.2nI9WLzN
export DSR_REPOS_FILE="$MGR_ORBIT/campaign.yaml" DSR_QUALITY_LOG_DIR="$MGR_ORBIT/receipts"
export UV_PROJECT_ENVIRONMENT=/data/ssd/tmp/mgr-eval-ci.bevt3nLW/qualified-venv
export MGR_LEAF_TRAIN_SEED=32 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 PYTHONDONTWRITEBYTECODE=1
case "$1" in
  prepare)
    mkdir -p "$MGR_ORBIT/gate"
    dsr quality --tool hierarchy-sibling-orbit-prepare --work-dir "$MGR_ORBIT/gate" --check-timeout 240
    ;;
  canonical|augmented)
    export MGR_ORBIT_ARM="$1" MGR_ORBIT_SHA="$2"
    mkdir -p "$MGR_ORBIT/gate-$1"
    dsr quality --tool hierarchy-sibling-orbit-eval --work-dir "$MGR_ORBIT/gate-$1" --check-timeout 360
    ;;
  *) exit 2 ;;
esac
