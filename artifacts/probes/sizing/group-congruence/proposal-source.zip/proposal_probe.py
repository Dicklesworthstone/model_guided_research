"""Frozen f2f6 study of untrusted marked-group proposals with exact certificates."""
import argparse
import json
import random
import time
from pathlib import Path

from nanochat.diagnostics_data import _group_elements
from scripts.group_rewrite_probe import rooted_graph
from scripts.group_student_probe import (
    acquire_with_memo, cancelled_key, digest, distinct_words, graph_digest, graph_equations,
    identify_known_family, pair_key, s5_catalog, save, walk_action,
)

PREVIOUS = Path("artifacts/probes/sizing/group-congruence/coverage.json")


def marked_action(group, pair):
    if group == "s5":
        return rooted_graph(group, pair)
    states = [tuple(range(5)) + (0,) if group == "a5xc2" else (0, 0)]
    index = {states[0]: 0}
    rows = []
    for state in states:
        out = []
        for gen in pair:
            if group == "a5xc2":
                destination = tuple(gen[i] for i in state[:5]) + (gen[5] ^ state[5],)
            else:
                amount, mirror = gen
                position, parity = state
                modulus = 120 if group == "c120" else 60
                destination = ((amount + (-position if mirror else position)) % modulus, mirror ^ parity)
            if destination not in index:
                index[destination] = len(states)
                states.append(destination)
            out.append(index[destination])
        rows.append(tuple(out))
    return tuple(rows)


def preflight(output):
    old = json.loads(PREVIOUS.read_bytes())
    excluded = set(old["spent"]) | {g["graph_sha"] for g in old["presentations"]}
    families = (
        ("s5", _group_elements("s5"), 6),
        ("c120", [(i, 0) for i in range(120)], 6),
        ("d60", [(i, bit) for i in range(60) for bit in range(2)], 3),
        ("a5xc2", [tuple(p) + (bit,) for p in _group_elements("a5") for bit in range(2)], 3),
    )
    rng = random.Random(2026112314)
    cases = []
    for family, elements, quota in families:
        retained = 0
        for _ in range(10000):
            pair = rng.choice(elements), rng.choice(elements)
            edges = marked_action(family, pair)
            fingerprint = graph_digest(edges)
            if len(edges) == 120 and fingerprint not in excluded:
                excluded.add(fingerprint)
                cases.append(dict(family=family, pair=pair, graph_sha=fingerprint))
                retained += 1
                if retained == quota:
                    break
        else:
            raise ValueError(f"Insufficient fresh coverage for {family}")
    save(output, dict(seed=2026112314, cases=cases, prior=digest(PREVIOUS), producer=digest(Path(__file__))))


def certify(catalog, equal):
    source = identify_known_family(catalog, equal)
    observed = {pair_key(*row["pair"]): row["answer"] for row in source["queries"]}
    fingerprint = source["marked_class"]
    certificate = []
    new_queries = 0
    for pair in graph_equations(catalog[fingerprint]):
        reused = pair in observed
        answer = observed[pair] if reused else equal(*pair)
        certificate.append(dict(pair=pair, answer=answer, reused=reused))
        new_queries += int(not reused)
        if not answer:
            break
    if len(graph_equations(catalog[fingerprint])) != 121 or not certificate:
        raise ValueError("The proposal is not a rooted two-generator 120-state action")
    return dict(proposal=source, certificate=certificate, new_queries=new_queries, accepted=certificate[-1]["answer"])


def run(coverage, output):
    manifest = json.loads(coverage.read_bytes())
    if manifest["producer"] != digest(Path(__file__)) or manifest["prior"] != digest(PREVIOUS):
        raise ValueError("Source or prior coverage does not match the preflight")
    before = time.perf_counter()
    catalog = s5_catalog()
    index_seconds = time.perf_counter() - before
    results = []
    for i, case in enumerate(manifest["cases"]):
        family = case["family"]
        graph = marked_action(family, tuple(tuple(x) for x in case["pair"]))
        if graph_digest(graph) != case["graph_sha"]:
            raise ValueError("Marked graph differs from the input manifest")
        equality_seconds = 0.0

        def equal(a, b):
            nonlocal equality_seconds
            before = time.perf_counter()
            predicted = walk_action(a, graph) == walk_action(b, graph)
            equality_seconds += time.perf_counter() - before
            return predicted

        baseline = acquire_with_memo(120, equal, cancelled_key)
        baseline["oracle_seconds"] = equality_seconds
        equality_seconds = 0.0
        start = time.perf_counter()
        result = certify(catalog, equal)
        fallback = None
        if result["accepted"]:
            table = catalog[result["proposal"]["marked_class"]]
        else:
            fallback = acquire_with_memo(120, equal, cancelled_key)
            table = tuple(tuple(row) for row in fallback["edges"])
        wall = time.perf_counter() - start
        if table != graph:
            raise ValueError("Proposal verification or fallback failed to recover the target")
        rng = random.Random(98130 + i)
        used = set()
        samples = [(w,walk_action(w,table)) for n in (16,32,64,128) for w in distinct_words(rng,used,48,n)]
        results.append(dict(
            index=i, family=family, graph_sha=case["graph_sha"], samples=samples, baseline=baseline,
            accelerated=result, fallback=fallback, seconds=wall, oracle_seconds=equality_seconds,
        ))
        print(i, family, result["accepted"], len(result["proposal"]["queries"]), result["new_queries"], flush=True)
    save(output, dict(coverage_sha256=digest(coverage), catalog=len(catalog), catalog_seconds=index_seconds, results=results))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("cover", "run"))
    parser.add_argument("--coverage", required=True, type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.phase == "cover":
        preflight(args.coverage)
    elif args.output is None:
        parser.error("run requires --output")
    else:
        run(args.coverage, args.output)
