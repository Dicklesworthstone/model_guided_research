if LoadPackage("smallgrp") <> true then Error("SmallGrp unavailable"); fi;
for order in [32, 64, 128, 256, 512] do
  Print(order, " total=", NumberSmallGroups(order),
        " one_generator=", NumberSmallGroups(order, RankPGroup, 1),
        " two_generator=", NumberSmallGroups(order, RankPGroup, 2), "\n");
od;
QUIT;
