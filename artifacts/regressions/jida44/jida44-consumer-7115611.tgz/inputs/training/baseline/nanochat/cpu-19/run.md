# nanochat run (fixed FLOPs)

- Run ID: `cpu-19`
- Generated: 2026-11-23T00:40:06Z
- Artifacts: `baseline/nanochat/cpu-19`
- Commit: 404ef9850de0576a595bf44e3a1ba7524dc4984b
- Attention schedule: `tropical`

## Command

```bash
uv run python -m nanochat.train --device cpu --max-steps 6 --batch-size 2 --sequence-len 32 --n-layer 1 --n-head 2 --n-kv-head 2 --n-embd 16 --seed 19 --warmup-steps 0 --artifacts-dir /private/tmp/mgr-route-verifier.hMb9aRVM/training --run-id cpu-19 --checkpoint-interval 2 --save-initial-weights --attention-type tropical --tokenizer task --data-dir /private/tmp/mgr-route-verifier.hMb9aRVM/datasets/hier
```

## Budget

- steps: 6
- warmup_steps: 0
- tokens/step (global): 64
- FLOPs/token (est): 61,440
- FLOPs/step (est): 3,932,160
- planned_total_FLOPs (est): 23,592,960

## Compilation

- torch.compile: False
- compile_backend: 'inductor'
- compile_mode: None
- compile_fullgraph: False
- compile_dynamic: None
- compile_flex_attention: False

## Numerics (debug)

- check_numerics: False
- detect_anomaly: False

## Results (measured after warmup)

- measured_steps: 6
- measured_tokens: 384
- measured_time_s: 0.174
- tokens/s: 2,209
- TFLOP/s (est): 0.00
- peak_memory_allocated_gb: n/a
- final_train_ce: 5.7193
- val_interval: 0
- val_batches: n/a
- final_val_ce: n/a
- final_val_bpb: n/a (bits per byte; comparable across tokenizers)

See `summary.json` for full details.
