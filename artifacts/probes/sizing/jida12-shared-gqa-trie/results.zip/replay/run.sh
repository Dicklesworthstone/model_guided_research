#!/bin/bash
set -euo pipefail
export PATH="/home/ubuntu/.local/bin:$PATH"
export MGR_GQA=/data/ssd/tmp/mgr-trie-gqa.KC9qiM2s MGR_GQA_SHA="$1"
export DSR_REPOS_FILE="$MGR_GQA/campaign.yaml" DSR_QUALITY_LOG_DIR="$MGR_GQA/receipts"
export UV_PROJECT_ENVIRONMENT=/data/ssd/tmp/mgr-eval-ci.bevt3nLW/qualified-venv
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
mkdir -p "$MGR_GQA/gate"
dsr quality --tool hierarchy-shared-gqa-trie --work-dir "$MGR_GQA/gate" --check-timeout 360
